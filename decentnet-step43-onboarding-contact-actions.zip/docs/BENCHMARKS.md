# Benchmark reference numbers

Measured on a reasonably fast Linux CI runner (x86_64, Python 3.12).
Your numbers will differ. These are order-of-magnitude references,
not contracts.

Regenerate with:

```
python scripts/bench.py --out bench-$(date +%Y%m%d).json
```

## Crypto primitives

| Benchmark                         | p50    | p90    | p99    |
|-----------------------------------|--------|--------|--------|
| `ed25519_sign`                    |  73 µs |  94 µs | 106 µs |
| `ed25519_verify`                  | 120 µs | 136 µs | 166 µs |
| `record_build_and_serialize`      | 137 µs | 176 µs | 215 µs |
| `record_parse_and_verify`         | 179 µs | 220 µs | 329 µs |
| `encrypted_envelope_build`        | 317 µs | 422 µs | 596 µs |

### Interpretation

- A node publishing a record does `build_and_sign` + serialize +
  send. The bottleneck is the Ed25519 signing step — everything
  else is microseconds.
- Verifying a record on receive is ~180 µs end-to-end. Even a node
  receiving thousands of records per second spends single-digit
  percent CPU on verification.
- The encrypted-envelope path costs about 2x a plain record signing
  — unsurprising given it adds an X25519 ECDH + HKDF + AEAD encrypt.
  This cost is incurred once per recipient, not per record.

## Wire codecs

| Benchmark               | p50   | p90   | p99   | bytes |
|-------------------------|-------|-------|-------|-------|
| `json_encode`           |  4 µs |  5 µs | 10 µs | ~67   |
| `cbor_encode`           | 15 µs | 18 µs | 29 µs | ~46   |
| `stun_roundtrip`        | 11 µs | 16 µs | 27 µs | ~28   |

### Interpretation

- CBOR is about 30% smaller on the wire but ~4x slower to encode
  because we implemented it in pure Python. Appropriate tradeoff
  for a byte-count-constrained link (mesh, LoRa); JSON remains the
  default on ample networks.
- STUN round-trip is so fast you should never see it in a profile
  — STUN latency is entirely dominated by network RTT.

## DHT throughput

| Benchmark                          | per-op |
|------------------------------------|--------|
| `dht_resolve_100_node_network`     | ~27 ms |

On a 100-node in-process DHT, a resolve from a random far-side
node takes about 27 ms. Real-network resolves add network RTT × 2
or 3 (iterative Kademlia).

## Memory

| Benchmark                      | delta |
|--------------------------------|-------|
| `memory_growth_1000_records`   | ~930 KB RSS (1000 records) |

About 930 bytes of RSS per cached record, including SQLite overhead
and Python object heap. A node holding 10 000 peers fits in ~9 MB.

## Scaling notes

- **Signature verification is a parallelizable workload.** We
  currently verify sequentially; a thread pool could easily push
  verify throughput past 10 000 records / s.
- **The DHT's serial RPCs are a 2x-to-5x win target** (today the
  engine does `send_and_wait` one contact at a time for safety;
  parallelising the alpha-concurrent iterative step is standard
  Kademlia practice).
- **SQLite is the cache backend.** Fast enough for < 100 000
  records. Beyond that, a real embedded KV store (LMDB, sled) is
  the natural upgrade.
