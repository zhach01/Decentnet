# decentnet — Direct Signaling (Phase 4)

Once the Directory (Phase 2) has told you *where* a peer is, the
signaling layer covers *talking to them directly*. No intermediary
relays the message; the two peers exchange signed UDP datagrams
end-to-end.

This doc pairs with `PROTOCOL.md` (LocatorRecord wire format) and
`DIRECTORY.md` (how you find the endpoint in the first place).

## Design goals

1. **Cryptographic authentication on every message.** Every signaling
   message carries an Ed25519 signature verified against the sender's
   public key (which the receiver already has from their
   `LocatorRecord` in L1).
2. **Replay resistance.** Every message carries a fresh 128-bit nonce
   and a unique `msg_id`. The receiver remembers recent msg_ids per
   session and rejects duplicates.
3. **Freshness bound.** Messages with `issued_at` outside a small skew
   window are rejected, so captured messages can't be replayed days
   later.
4. **Explicit trust promotion.** A peer is "DHT-resolved" by default,
   "trusted" only after a successful hello/hello_ack handshake. APIs
   like `ring()` refuse to run without an established session.
5. **Negative cache.** Repeated signaling failures (timeouts, bad
   replies) back off exponentially per peer, so a misbehaving peer
   can't be spammed into producing traffic.
6. **Transport-agnostic semantics.** The exact same engine runs over
   the in-process transport (for deterministic tests) or real UDP
   (for deployment). Phase 4 ships both.

## Message envelope

Every signaling message is a transport `Message` with:

```
type         = "sig.<subtype>"  (e.g. "sig.hello")
sender       = peer_id (base32)
msg_id       = uuid hex
in_reply_to  = msg_id this answers (optional)
sent_at      = UNIX seconds
payload      = {
    app_magic    : "decentnet"          (cross-protocol reject)
    sig_version  : 1                    (signaling protocol version)
    target       : peer_id (base32)     (who this is for)
    nonce        : 128-bit hex          (fresh per message)
    issued_at    : UNIX seconds         (freshness)
    body         : {...}                (subtype-specific)
    signature    : base64url(Ed25519)   (over canonical JSON of above)
}
```

The signature covers the canonical JSON of the full envelope minus
the signature itself, the same pattern used by `LocatorRecord`.

## Subtypes

| Subtype           | Purpose                                                    | Verified? |
|-------------------|------------------------------------------------------------|-----------|
| `sig.hello`       | Initiate session establishment                             | yes       |
| `sig.hello_ack`   | Accept session, exchange nonces                            | yes       |
| `sig.ring`        | Request a logical call/interaction                         | yes       |
| `sig.ring_ack`    | Accept the ring (moves session → IN_CALL)                  | yes       |
| `sig.keepalive`   | Liveness check                                             | yes       |
| `sig.bye`         | Close session                                              | yes       |
| `sig.offer`       | Pass-through: application OFFER (e.g. SDP)                 | yes*      |
| `sig.answer`      | Pass-through: application ANSWER                           | yes*      |
| `sig.candidate`   | Pass-through: application transport candidate (e.g. ICE)   | yes*      |
| `sig.chat_control`| Pass-through: app-level chat control signal                | yes*      |

*"yes\*" — the envelope is verified (sig, replay, target, freshness);
 the `body` payload is not interpreted by the signaling engine. A
 WebRTC-style application built on top parses the payload itself.

## Session state machine

```
             hello
    FRESH ─────────► HANDSHAKING ─────hello_ack────► ESTABLISHED
      ▲                                                    │
      │                                                    │  ring
      │                                                    ▼
      │                                                  RINGING
      │                                                    │
      │                                                    │  ring_ack
      │                                                    ▼
      │                                                  IN_CALL
      │                                                    │
      │                                                    │  bye / idle
      └────────────────────────────────────────────────── CLOSED
```

Transitions happen only on validated messages. Any unexpected state
(e.g. a RING arriving before a HELLO_ACK) is audited and dropped.

## Rejection reasons

The engine writes an audit event with `kind=signal.reject` and a
machine-readable `reason` for each drop:

| Reason                         | Cause                                              |
|--------------------------------|----------------------------------------------------|
| `unknown_sender`               | No `LocatorRecord` in L1 for the claimed sender    |
| `app_magic mismatch`           | Message is from a different protocol               |
| `unsupported sig_version N`    | Protocol mismatch                                  |
| `not addressed to me`          | `target` field isn't us                            |
| `issued_in_future`             | `issued_at` outside future skew window (120s)      |
| `issued_too_long_ago`          | `issued_at` outside past skew window (300s)        |
| `missing nonce`                | Envelope malformed                                 |
| `missing signature`            | Envelope malformed                                 |
| `signature verification failed`| Not signed by the claimed sender                   |
| `replayed_msg_id`              | Same msg_id seen from this peer before             |

Every reason surfaces in the audit log and is also directly visible
to the test suite.

## Negative cache

Failures per peer are tallied; after the configured threshold we
back off exponentially (5s, 10s, 20s, …, capped at 1 hour) before
attempting another operation against that peer. A successful
handshake clears the counter.

This prevents:

* A misconfigured peer with the wrong key from causing endless
  failing handshakes.
* A hostile peer from exploiting the signaling surface for DoS
  amplification.

## Transport layer

The signaling engine is **transport-agnostic**: it takes any
`Transport` implementation. Phase 4 ships two:

* `InProcessTransport` — synchronous message bus used by the test
  suite and the simulator. Every `send()` delivers immediately.
* `UDPTransport` — real UDP socket on a bound host/port. A dedicated
  reader thread dispatches incoming datagrams to the signaling
  engine. Used by the `examples/phase4_demo.py` two-node demo and
  suitable as the transport for a real deployment.

### UDPTransport limitations (honest)

* No fragmentation. Maximum datagram size is 60,000 bytes (well over
  typical MTU); smaller payloads are still better. All Phase 4 signaling
  messages fit in ~500–700 bytes.
* No retransmission. Packet loss → `send_and_wait` times out. The
  negcache soaks up repeated losses gracefully.
* No congestion control. At signaling rates (handful of messages
  per peer per minute) this isn't an issue.
* No NAT traversal yet — both peers need reachable endpoints. Phase 5
  adds STUN-assisted external address discovery; Phase 6 adds ICE-style
  candidate selection and optional TURN/relay fallback.

## What the signaling engine does *not* do

* It doesn't carry media. OFFER/ANSWER/CANDIDATE are envelopes — a
  WebRTC/ORTC-capable application layer reads the body and sets up
  the media path using the host's WebRTC stack.
* It doesn't guarantee message delivery. Use RING_ACK / KEEPALIVE to
  detect a broken session.
* It doesn't deduplicate across sessions. A new session after BYE
  starts with an empty replay window; that's fine because the nonces
  are still fresh.
* It doesn't multiplex. One session per `(local_peer, remote_peer)`
  pair.

## Example

```python
# Both sides already have Node(cfg, network=...) running and have
# resolved each other (so peer pubkey is in L1).

# Alice initiates:
result = alice.signaling.hello(bob.peer_id.value, timeout_s=3.0)
assert result.ok

# Bob's app decides which rings to accept:
bob.signaling.on_ring(lambda peer, body: body.get("topic") == "chat")

# Alice rings:
result = alice.signaling.ring(
    bob.peer_id.value,
    body={"topic": "chat"},
    timeout_s=5.0,
)
assert result.ok  # → session IN_CALL

# Pass-through OFFER:
alice.signaling.send_passthrough(
    bob.peer_id.value,
    SignalType.OFFER,
    {"sdp": "v=0...your-sdp-here..."},
)
# Bob retrieves:
for sender, msg in bob.signaling.drain_inbox():
    print(msg.type, msg.payload["body"])

# Alice hangs up:
alice.signaling.bye(bob.peer_id.value)
```

See `examples/phase4_demo.py` for the full loopback-UDP version.
