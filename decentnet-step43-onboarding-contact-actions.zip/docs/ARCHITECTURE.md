# decentnet — Architecture

## Mental model

```
  ┌──────────────────────────────────────────────────────────────────┐
  │                            Application                           │
  │                 (chat, voice, file transfer, etc.)               │
  └──────────────▲──────────────────────────────────▲────────────────┘
                 │ direct peer-to-peer user traffic  │
                 │      (not routed through          │
                 │       the decentnet fabric)       │
  ┌──────────────┴──────────────┐  ┌─────────────────┴──────────────┐
  │   Direct Signaling (Ph.4)   │  │    Direct Transport (Ph.4–6)   │
  │   hello/ring/offer/answer   │  │   UDP + STUN + ICE + TURN*     │
  └──────────────▲──────────────┘  └────────────────▲───────────────┘
                 │ "where is peer X right now?"      │
  ┌──────────────┴───────────────────────────────────┴──────────────┐
  │                  Resolution / Control plane                     │
  │                                                                 │
  │   L1  Local cache           (Phase 1 — ✅ implemented)          │
  │   L2  Neighbor/cluster hints (Phase 2 — planned)                │
  │   L3  Global directory       (Phase 2 — planned, DHT/gossip)    │
  └──────────────▲──────────────────────────────────────────────────┘
                 │ signed records only; never user content
  ┌──────────────┴──────────────────────────────────────────────────┐
  │                  Data plane (the signed record)                 │
  │   LocatorRecord { peer_id, pubkey, seq, TTLs, endpoints, sig }  │
  └──────────────▲──────────────────────────────────────────────────┘
                 │
  ┌──────────────┴──────────────────────────────────────────────────┐
  │                 Identity (Ed25519, PeerId = b32(sha256(pk)))    │
  └─────────────────────────────────────────────────────────────────┘
```

The **control plane** (resolution) is strictly separated from the
**data plane** (user traffic). The decentnet fabric carries only
signed metadata. User messages and media flow directly between peers
after resolution succeeds.

## Phase 1 layers (what's built)

### Identity — `decentnet.identity`

- `Keypair` wraps Ed25519 from the `cryptography` library.
- Private key is persisted in a JSON file with 0600 permissions (best
  effort; Windows is a known gap). Atomic replace on save.
- **PeerId = unpadded lowercase base32 of SHA-256(public_key)** —
  52 characters, fixed width. Hashing the key (rather than using the
  raw key) gives us room for future key rotation while keeping the
  visible ID stable.
- `Keypair.load_or_create(path)` is the one-line entry point callers
  use.

### Records — `decentnet.records`

- `Endpoint` carries `{type, address, priority, confidence,
  discovered_by, last_success}`. The type enum covers `lan_udp`,
  `public_udp`, `public_tcp`, `websocket`, `webrtc_candidate`,
  `relay_candidate`. New types can be added without breaking older
  records because the parser round-trips unknown optional fields.
- `LocatorRecord` is the core wire object. It carries:
  `version, peer_id, public_key, seq, issued_at, expires_at,
  soft_expires_at, endpoints, capabilities, nat_metadata,
  topic_hashes, prev_key_rotation?, signature`.
- Canonical serialization: JSON with sorted keys, no whitespace,
  NFC-normalized strings, binary fields in base64url. Signing input
  is `canonical_json(record_minus_signature)`.
- `verify()` returns `(bool, reason)` rather than raising, which makes
  the cache's decision log explicit and machine-readable.
- `record_is_newer(candidate, existing)` defines the precedence rule:
  higher `seq` wins; ties broken by later `issued_at`; exact duplicates
  are **not** newer (so they're rejected, preventing equal-seq
  thrashing from bouncy gossip).

### Local cache (L1) — `decentnet.cache`

SQLite-backed store with three tables: `locator_records`,
`negative_endpoints`, `meta`. Schema version is checked on open.

The full validation pipeline on `put`:

1. `LocatorRecord.verify()` — structural + cryptographic.
2. Not hard-expired (wall-clock check).
3. Not a rollback (seq/issued_at monotonic against the existing
   cached entry).
4. **Identity continuity** — if we've seen this `peer_id` before, the
   `public_key` field must match. A genuine key rotation would produce
   a *different* peer_id; same peer_id with a different key is spoofing.
   In Phase 2 we'll layer on an authenticated rotation path via
   `prev_key_rotation`.

Additional behaviours:

- **Soft TTL** predicate lets callers decide when to proactively
  refresh a record even though it's still valid.
- **Access counters** and **popularity eviction** (lowest
  `access_count` then oldest `last_accessed` get evicted first).
- **Negative cache** for endpoint addresses that have repeatedly
  failed direct connections.
- **Persistence across restart** via SQLite.
- **GC** drops hard-expired rows.
- **Audit events** for every put/reject/expire/evict/negcache action.

### Node facade — `decentnet.node`

- Composes identity, cache, audit, and a persisted seq counter.
- `publish_own_record(endpoints, ...)` bumps the counter, signs, and
  stores.
- `lookup(peer_id)` is L1-only in Phase 1; Phase 2 extends it with a
  directory fallback behind the same interface.
- `ingest_record_bytes(data, source)` is the single entry point for
  records from anywhere — CLI import today, gossip/DHT tomorrow.
- A small JSON file next to the keyfile stores the last `seq` issued,
  so the counter never regresses across restarts.

### Audit — `decentnet.audit`

Append-only JSONL log. Every significant cache decision has an entry.
This is deliberately plain-text so the simulator (Phase 3) can parse
it, tests can assert against it, and operators can grep it.

### CLI — `decentnet.cli`

Thin wrapper over `Node`. `python -m decentnet <command> ...`.

## Design decisions and tradeoffs

### Canonical JSON vs CBOR

Phase 1 uses canonical JSON with sorted keys and NFC normalization.
This is debuggable, trivially inspectable, and portable. Deterministic
CBOR (RFC 8949 §4.2) is the preferred future wire format — it's more
compact and handles binary natively — and the `utils.encoding` module
is structured so it can be added alongside, versioned, and swapped per
protocol version. The signature is always computed over bytes, not
Python objects, so swapping the encoding layer requires no changes to
higher layers.

### Why hash the public key into the PeerId?

- Fixed 52-character IDs decouple wire format from key length.
- The derivation is deterministic, so anyone can verify
  `PeerId == b32(SHA-256(pubkey))` in one line.
- Leaves room to add a "rotation receipt" linking an old key to a new
  key without changing the ID semantics, to be formalised in Phase 2.

### Seq + issued_at + hard TTL together

Each of these protects a different attack/failure mode:

| Concern                              | Defence                           |
|--------------------------------------|-----------------------------------|
| Replay of an old record              | monotonic `seq` per peer          |
| Two nodes publishing with same seq   | `issued_at` tiebreaker            |
| Forever-stale record sitting in cache| hard TTL `expires_at`             |
| Silent staleness                     | soft TTL `soft_expires_at`        |
| Clock skew malice                    | Phase 2: cap on future issued_at  |
| Identity takeover                    | `public_key` continuity check     |
| Field tampering                      | Ed25519 signature over canonical  |

### Honesty about "pure serverless" over WAN

A fully decentralized locator fabric needs **rendezvous**. Two devices
have to find *something* in common before they can find each other.
In practice the least-centralized honest design is:

- A **rotating bootstrap list** of long-lived peers (can be run by
  anyone, can change over time, signed and published out-of-band).
- A **DHT** overlay (Kademlia-style) for peer-ID resolution.
- **Public STUN** to discover external mappings for UDP.
- Optional **TURN / relay** as a *reliability* fallback, only if the
  two parties' NATs refuse to cooperate.

Everything except TURN/relay respects the "no user payloads in the
fabric" rule. Phase 2 will implement the DHT + bootstrap list;
Phase 5 integrates STUN. These are documented clearly rather than
pretended away.

## Security notes (Phase 1)

**Protected by the current design:**

- Record forgery (signatures).
- Record tampering (signatures over canonical bytes).
- Rollback of a peer's own record (seq monotonic).
- Silent spoofing of a known peer (identity continuity).
- Long-lived stale records (hard TTL drop).

**Not yet protected — deferred to later phases:**

- **Sybil attacks on the global directory** — bundled into the
  Phase 2 DHT design (node-ID puzzle + S/Kademlia-style replication).
- **Metadata visibility** — endpoint records are publicly inspectable
  by default. Phase 9 (privacy) adds selective disclosure / encrypted
  locator entries for allowed peers only.
- **Key-at-rest encryption** — Phase 7 adds a passphrase-wrapped
  keystore.
- **Arbitrarily-future `issued_at`** — Phase 2 will clamp accepted
  records to `now + skew_max`.
- **Denial-of-service via record storms** — Phase 2 adds per-peer rate
  limits on the ingest path.

## Roadmap

| Phase | Focus                                                             | Status |
|-------|-------------------------------------------------------------------|--------|
| 1     | identity, signed records, local cache, node, CLI, persistence     | ✅     |
| 2     | distributed directory (DHT + gossip), anti-entropy, repair, L2/L3 | ✅     |
| 3     | simulation and visualization suite (scenarios, SVG, HTML timeline)| ✅     |
| 4     | direct UDP signaling, hello/ring/offer/answer, validated peers    | ✅     |
| 5     | STUN, external address discovery, publish mapped endpoints        | ✅     |
| 6     | ICE-style candidate selection, optional TURN/relay fallback       | ✅     |
| 7     | Kivy/mobile hooks, daemon/client split, productionization pass    |        |

## Phase 2 in detail (what was added)

Phase 2 adds the **L3 distributed directory** and the **repair layer**.
The L1 local cache now falls through to L3 on miss via
`Node.resolve(peer_id)`. See `docs/DIRECTORY.md` and `docs/REPAIR.md`
for the full discussion.

New modules:

| Module           | Purpose                                                        |
|------------------|----------------------------------------------------------------|
| `transport/`     | `Transport` interface + `InProcessTransport` (sync message bus, churn/partition model) |
| `dht/`           | XOR distance, `RoutingTable`/`KBucket`, `DHTStore`, `DHTEngine` (PING/FIND_NODE/STORE/FIND_VALUE with iterative lookups) |
| `directory/`     | `Directory` facade (DHT + anti-entropy) and signed `BootstrapManifest` |
| `repair/`        | `AntiEntropy` — digest-request / record-push sync               |
| `limits/`        | Per-source token-bucket `RateLimiter`                          |
| `sim/`           | `SimNetwork` harness — builds/teardowns small DHTs, models offline/partition |
| `records/validation.py` | Shared `validate_for_storage` used by both L1 and DHT store, with clock-skew clamp |

`Node` is backwards-compatible: without a `network=` argument it
behaves exactly as in Phase 1 (all 39 Phase 1 tests still pass). With
a network it participates in the DHT, publishes via `publish_to_network()`,
resolves via `resolve(peer_id)` with L1→L3 fallthrough and write-through
to L1, and can run anti-entropy via `sync_with(peer)`.

### New safety protections in Phase 2

| Protection                          | Implemented in                        |
|-------------------------------------|---------------------------------------|
| Clock-skew clamp on `issued_at`     | `validate_for_storage` (default 300s) |
| Per-source ingest rate limit        | `Node.ingest_record_bytes` (token bucket) |
| Quorum-merged L3 reads              | `DHTEngine.find_value` (newest valid wins) |
| Replay at L3 store rejected         | `DHTStore.put` + shared validator     |
| Signed bootstrap seed lists         | `BootstrapManifest`                   |

### Still deferred after Phase 2

- **Sybil / eclipse hardening on the DHT** — Phase 7+ (S/Kademlia
  crypto-puzzle IDs, multi-path lookups, reputation).
- **Disk persistence for the DHT store** — Phase 3.
- **Bidirectional anti-entropy + Merkle/Bloom summaries** — Phase 3.
- **Periodic republish loop** — Phase 3 (easy hook; not yet scheduled).
- **Real transport (UDP)** — Phase 4.
- **STUN / NAT traversal** — Phases 5–6.
- **Metadata privacy / selective disclosure** — Phase 9.
