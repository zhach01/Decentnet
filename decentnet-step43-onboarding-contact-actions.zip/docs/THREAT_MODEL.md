# decentnet threat model

This document enumerates the security-relevant primitives in
decentnet, the adversaries we protect against, the threats we do
*not* protect against, and the invariants that hold if the
cryptography is correctly used.

Scope note: decentnet has not been reviewed by an external security
auditor. This document describes our design intent and what the
implementation does; it is not a substitute for audit. Treat it as
a starting point for reasoning, not a guarantee.


## Adversary models

We reason about three flavours of adversary:

**Passive network attacker.** Can observe all network traffic, but
not modify or inject. Knows every IP the node talks to.

**Active network attacker.** Can modify, drop, replay, reorder, or
inject UDP datagrams. Can run their own decentnet node and attempt
to participate in DHT.

**Offline-file attacker.** Has read access to the keyfile on disk
(e.g. a stolen laptop). Does not have the running process's memory.


## Primitives and their claims

### Ed25519 record signing

Every `LocatorRecord` is signed by the publisher's Ed25519 private
key. The `peer_id` is `b32(sha256(public_key))`, which binds the
record to that identity by construction.

Protects against: record forgery, tampering in transit, third
parties publishing on behalf of another peer.

Does not protect against: the publisher themselves publishing
false endpoints (that's their prerogative — clients who don't
trust them should refuse to talk to them); replay of an *older*
valid record, *except* that the cache's `(seq, issued_at)`
precedence rule rejects older records once a newer one is seen.

### Key rotation with signed receipts

A `RotationReceipt` is signed by the old key and attests to the new
peer_id. Clients update their ledger transparently; the
`peer_id → public_key` binding for the *new* identity still holds
by construction (new public key, new peer_id).

Protects against: attacker who steals the old key pretending the
rotation didn't happen (any record signed by the old key after the
rotation receipt is still valid by signature alone — but clients
that have processed the receipt will follow the chain to the new
identity, so trust drifts to the new key).

Does not protect against: an attacker who steals the old key
*before* the rotation is published and issues their *own* rotation
receipt handing over to an attacker-controlled key. This is why
rotation should happen immediately on suspicion of compromise.

### Encrypted keystore (scrypt + AES-GCM)

`identity/keystore.py` wraps the keyfile with scrypt-derived AES-256-GCM.
The AEAD AAD binds the public key. Default scrypt parameters:
n=2^15, r=8, p=1 — about 50 ms on a laptop.

Protects against: offline-file attacker without the passphrase
(within the limits of the chosen scrypt parameters and the
entropy of the passphrase).

Does not protect against: a weak passphrase (anything under ~40
bits of entropy falls to a modest GPU cluster at n=2^15);
attackers with access to the process's memory while the keyfile
is unlocked; attackers who can observe key derivation via side
channels (timing, power).

### Selective disclosure (X25519 + ChaCha20-Poly1305)

`records/disclosure.py` encrypts per-recipient endpoint envelopes.
Ephemeral X25519 keypair per envelope + HKDF-SHA256 → ChaCha20-Poly1305.
AAD binds `(publisher_peer_id, recipient_peer_id, ephemeral_pubkey)`.

Protects against: non-recipients learning the private endpoints;
replay of envelopes across publisher identities (AAD won't match).

Does not protect against: traffic analysis (the recipient peer_id
list is in the clear); the recipient leaking the decrypted
endpoints to anyone else (there's nothing to prevent this short of
DRM-style measures we don't attempt); compromise of the long-term
Ed25519 key (since X25519 is derived from it).

### STUN / NAT discovery

`NATDiscovery` uses public STUN servers. The response is unsigned
(STUN doesn't authenticate in our configuration), so we treat the
mapped address as advisory only. We never use the STUN-reported
address as a *proof* of identity — peers still authenticate via
Ed25519 signatures.

Protects against: nothing on STUN specifically — STUN is
infrastructure, not trust.

Does not protect against: a malicious STUN server lying about our
mapped address. Worst case: we publish a wrong endpoint and other
peers can't reach us there; they fall back to other candidates or
the relay.

### Cooperative UDP relay

`RelayServer` issues short-lived `RelayToken`s signed by the
relay's Ed25519 key. The relay forwards UDP datagrams between
authenticated peers. Payloads passing through the relay are
*already* the signaling envelopes or application frames peers
exchanged — they are opaque to the relay.

Protects against: unauthenticated use of the relay (token must
verify); token replay across relays (AAD binds the relay pubkey).

Does not protect against: a malicious relay dropping, delaying,
reordering, or selectively forwarding traffic; traffic analysis
by the relay operator; denial of service against the relay itself;
a compromised relay lying about load so peers route through it.

### DHT and reputation

The DHT uses plain Kademlia with Ed25519-signed records at rest.
`ReputationTracker` decays peer scores on failure/malice.

Protects against: casual misbehaviour (a peer that times out
repeatedly gets deprioritised); forged records stored on replicas
(signature verification rejects them); the single-peer case of
content injection.

Does not protect against: Sybil attacks against Kademlia (a large
attacker can flood the routing table with their own IDs — our k=8
default and reputation help but do not prevent this at scale);
coordinated eclipse attacks; targeted replica poisoning at scale;
the fundamental Kademlia trust-the-neighbours assumption.

### Signaling (hello / ring / bye / keepalive)

Every signaling message is Ed25519-signed and carries a strictly
increasing message ID. `SessionState` FSM rejects out-of-order
transitions. `NegativeCache` rate-limits hello attempts to absent
peers.

Protects against: signaling forgery, signaling replay (within the
replay window), hello-flood from a peer.

Does not protect against: a peer with the valid keypair flooding
hellos from multiple sources (the NegativeCache is per-target, not
per-source); sophisticated traffic analysis of session timing.


## Threats explicitly out of scope

- **Identity privacy.** PeerIDs are observable. Which peer talks to
  which peer is knowable to anyone with network view. If you need
  onion routing, decentnet is not that system.
- **Anonymous sets for selective disclosure.** Recipient peer_ids
  are in the clear. Disguising who the envelopes are for would
  require a hash-tag scheme we do not implement.
- **Bulletproof byzantine DHT.** Kademlia isn't S/Kademlia. Reputation
  helps; it doesn't make the DHT truly Byzantine-tolerant.
- **Forward secrecy.** The encrypted envelopes use fresh ephemeral
  X25519 keys, but the publisher's record itself is signed by the
  long-term Ed25519. Compromise of that key retroactively lets the
  attacker pose as the publisher (though not decrypt anyone else's
  envelopes for records they didn't produce).
- **Protection against physical coercion.** Forced disclosure of
  the passphrase is outside our model. Nothing in software can
  stop that.


## Invariants (what we assert, given correct crypto)

1. A record whose signature doesn't verify is never cached, never
   replicated, never returned by lookup.
2. A record's `peer_id` equals `b32(sha256(public_key))` where
   `public_key` is the signing key — verified on every accept.
3. `(seq, issued_at)` is strictly monotonic per peer_id; older
   records are refused at the cache boundary (see
   `validate_for_storage`).
4. A rotation chain is only accepted if every link is signed by
   the previous key; forged links are rejected.
5. A selectively-disclosed endpoint is only readable by holders of
   the listed recipient private keys; non-recipients see ciphertext.
6. The relay operator cannot impersonate a client (the client's
   signatures on signaling messages are what the far-side peer
   checks, not the relay's forwarding).
7. A STUN response is never used as evidence of identity; it's only
   ever a hint about the NAT mapping for purpose of publishing.


## Known attack scenarios and mitigations

| Scenario                               | Mitigation                           | Residual risk             |
|----------------------------------------|--------------------------------------|---------------------------|
| Forged record injected via DHT STORE   | Signature + `validate_for_storage`   | None (rejected at input)  |
| Replayed old record                    | `(seq, issued_at)` precedence        | Attacker can force an old  |
|                                        |                                      | version briefly if newer   |
|                                        |                                      | record hasn't propagated   |
| Noisy neighbour flooding RPCs          | `RateLimiter` + reputation decay     | Under-configured rates     |
| Stolen keyfile offline                 | Scrypt+AES-GCM if `keystore encrypt` | Weak passphrases           |
| Malicious STUN lying about mapping     | STUN advisory only; signatures still | Wasted publish bandwidth   |
|                                        | authenticate peers                   |                            |
| Compromised relay dropping traffic     | Client can rotate relays             | DoS window                 |
| Sybil / eclipse of DHT neighbourhood   | Reputation + topic scoping help      | Not fully mitigated        |
| Signaling replay                       | Replay window + FSM state            | None within window         |


## Reporting security issues

For security issues, contact the maintainers privately (see the
project README). Do not file public issues for security bugs
before a fix is available.
