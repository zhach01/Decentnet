# decentnet — Final phase

Everything added after Phase 6 to complete the original brief. The
prior phases' docs (`ARCHITECTURE.md`, `DIRECTORY.md`, `PROTOCOL.md`,
`REPAIR.md`, `SIGNALING.md`, `NAT.md`, `ICE.md`, `SIMULATOR.md`) still
apply; this one summarizes the gap closures.

## Feature index

| Area                           | Module(s)                                             | Test coverage                       |
|--------------------------------|-------------------------------------------------------|-------------------------------------|
| Key rotation                   | `identity/rotation.py`, `identity/ledger.py`          | `test_gap_features.py::rotation*`   |
| Selective disclosure           | `records/disclosure.py`                               | `test_gap_features.py::disclosure*` |
| Multi-source confidence        | `cache/confidence.py`                                 | `test_gap_features.py::confidence*` |
| Deferred writes                | `cache/deferred.py`                                   | `test_gap_features.py::deferred*`   |
| Topic-scoped replication       | `dht/topics.py`                                       | `test_gap_features.py::topic*`      |
| Global snapshots / reconstruct | `repair/snapshot.py`                                  | `test_gap_features.py::snap*`       |
| Neighbour reputation           | `limits/reputation.py`                                | `test_final_modules.py::reputation*`|
| Bloom + Merkle digests         | `repair/digests.py`                                   | `test_final_modules.py::bloom*/merkle*` |
| CBOR canonical codec           | `utils/cbor.py`                                       | `test_final_modules.py::cbor*`      |
| Audit log rotation             | `audit/log.py`                                        | `test_final_modules.py::audit*`     |
| Encrypted keystore             | `identity/keystore.py`                                | `test_final_modules.py::keystore*`  |
| Background schedulers          | `schedulers.py`                                       | `test_final_modules.py::*scheduler*`|
| Full CLI parity                | `cli/main.py` (25+ subcommands)                       | `test_cli_and_daemon.py`            |
| Daemon + control socket        | `daemon.py`                                           | `test_cli_and_daemon.py::daemon*`   |
| Simulator adversaries          | `sim/network.py` (`inject_*`/`make_silent`)           | `test_new_scenarios.py`             |
| Missing scenarios (11)         | `sim/builtin_scenarios.py`                            | `test_new_scenarios.py`             |
| Full RFC 5780 NAT classifier   | `nat/stun.py` + `nat/discovery.py` + `nat/simnat.py`  | `test_rfc5780.py`                   |

## Key rotation

Ed25519 peers rotate by having the OLD key sign a `RotationReceipt`
naming the new peer_id. The FIRST record published under the new
identity carries this receipt in `prev_key_rotation`. Receivers
with a cached record under the old identity:

1. Parse and `verify()` the receipt (must be signed by the old
   public key and hand over to the exact new identity).
2. Record `old_pid → new_pid` in the `RotationLedger` (SQLite, TTL
   default 30 days).
3. Future lookups for the old pid transparently follow the chain
   via `Node.lookup()` — chain walks are transitive.

A forged same-peer_id-different-key record is still rejected:
`peer_id` must equal `b32(sha256(public_key))`. Rotation changes
the peer_id by construction; pretending to rotate without
generating a new keypair doesn't work.

CLI: `decentnet rotate --endpoint public_udp:2.2.2.2:2`

## Selective disclosure / encrypted endpoint envelopes

A `LocatorRecord` can carry `encrypted_endpoints`: a per-recipient
envelope list. Each envelope uses:

- **X25519 ECDH** between a fresh per-envelope ephemeral key and the
  recipient's X25519 public key, derived from their Ed25519 pubkey
  via the standard Edwards→Montgomery birational map (RFC 7748).
- **HKDF-SHA256** to turn the shared secret into an AEAD key.
- **ChaCha20-Poly1305** over the JSON-encoded endpoint list, with
  AAD binding `(publisher_peer_id, recipient_peer_id, ephemeral_pub)`.

Intended recipients decrypt with their own keypair. Non-recipients
see ciphertext only. Because AAD binds the publisher peer_id,
envelopes can't be replayed from one publisher under another's
identity.

What this does NOT hide: who the recipients are. Recipient peer_ids
appear in the clear. Anonymous recipient sets require a separate
(hash-of-id) tag scheme.

## Multi-source confidence

Every accepted `LocalCache.put` triggers an `on_accept` hook that
records `(peer_id, source_label)` into `ConfidenceTracker`. Sources
include `"self"`, `"imported"`, and DHT replica labels. A
`confidence(peer_id, current_seq=?)` query returns a score in
`[0, 0.99]` weighted by number of corroborating sources and
recency (1-hour half-life).

CLI: `decentnet confidence [peer_id]`

## Deferred writes

`Node.publish_to_network()` detects "no reachable peers" and queues
the record in `DeferredWriteBuffer` (SQLite). `Node.drain_deferred()`
retries. Useful for offline-first mobile clients that publish before
they have a network.

CLI: `decentnet deferred list|drain`

## Topic-scoped replication

`TopicPolicy` per node holds a subscription set + a `replicate_all`
flag. When `DHTStore.put(record)` is called, the topic policy
vetoes records whose `topic_hashes` don't intersect our subscriptions
(unless `replicate_all=True` or the record is untagged). The policy
persists as JSON so subscriptions survive restart.

CLI: `decentnet topic list|subscribe|mode`

## Global snapshots + catastrophic reconstruction

`Node.take_snapshot()` produces a signed `GlobalSnapshot` containing
every locator record the node currently holds. The snapshot itself
is Ed25519-signed by the producer; every record inside still
carries its own independent signature.

`Node.import_snapshot(bytes)` validates both the outer snapshot and
every inner record, then walks each through `LocalCache.put`. For
multiple snapshots, `reconstruct_from_snapshots` takes the
highest-`(seq, issued_at)` record per peer_id — multi-source
reconstruction resistant to a single poisoned snapshot.

CLI: `decentnet snapshot take|import|reconstruct`

## Neighbour reputation

`ReputationTracker` keeps a signed per-peer score that decays with
a 1-day half-life. `DHTEngine` notes:

- `note_success(peer)` on accepted STORE replies
- `note_failure(peer)` on timeouts, transport errors, rejections
- `note_malicious(peer, reason=...)` on sig-verify failures

`score(peer_id)` squashes to `[-1, +1]`. `is_blacklisted(pid)` is
convenience sugar.

## Bloom + Merkle anti-entropy digests

`repair/digests.py` adds two compact summaries alongside the flat
`(peer_id, seq, issued_at)` list:

- `BloomSummary.for_capacity(n, fp=0.01)` — classic k-hash bloom with
  shortest-to-describe size. Sent along with `DIGEST_REQUEST` so the
  receiver can apply a "probably in sender's store" filter.
- `MerkleBucketSummary.build(entries)` — 256 buckets keyed by
  `sha256(peer_id)[0]`, root per bucket. Two nodes with near-identical
  stores can `diff_buckets(other)` and only exchange the small
  fraction that differs.

Wire integration is opportunistic: anti-entropy attaches a bloom
when there's something to summarize; older peers that don't
understand the `bloom` payload field ignore it harmlessly.

## CBOR canonical codec

`utils/cbor.py` is a hand-rolled deterministic CBOR subset (major
types 0–5 + 7-false/true/null/float64). Keys sorted byte-wise,
shortest integer encoding, fixed-width floats. Roughly 30–40%
smaller than canonical JSON for a typical LocatorRecord. Gated by
a `codec: cbor` envelope flag — JSON is still the default.

## Audit log rotation

`AuditLog` now accepts `max_bytes` and `keep_rotated`. When the
active JSONL file exceeds `max_bytes`, it rotates to `<path>.1`,
shifting older rotations up and dropping the oldest. In-memory
tail is capped at `max_memory_entries` (default 10 000) so
long-running processes don't grow unbounded.

## Encrypted keystore (key-at-rest)

`identity/keystore.py`:

- `wrap_keyfile(path, passphrase)` — atomic in-place conversion to
  version-2 encrypted format (scrypt-KDF + AES-256-GCM, AAD binds
  the public key).
- `unwrap_keyfile(path, passphrase)` — atomic reverse.
- `Keypair.load(path, passphrase=...)` — handles both formats.

CLI: `decentnet keystore encrypt|decrypt|status`

## Background schedulers

`schedulers.BackgroundRefresh` walks the cache every `interval_s`
and triggers `resolve(peer, force_network=True)` for soft-expired
records. `KeepaliveScheduler` sends `sig.keepalive` to every trusted
session.

The in-process transport deduplicates echoed keepalives (reply only
if `in_reply_to is None`) so two peers can keep each other warm
without ping-ponging to stack overflow.

API: `Node.enable_background_refresh() / enable_keepalive()`.

## Full CLI parity

Every phase now has CLI coverage. New subcommands:

- `dht store | anti-entropy <peer>`
- `signaling peers | hello <peer> | ring <peer> [--body JSON] | bye <peer>`
- `nat probe --server HOST:PORT | classify --server ... [--server ...]`
- `ice enumerate <peer>`
- `relay serve [--host H --port P] | issue-token <peer> [--ttl N]`
- `rotate --endpoint ... [--endpoint ...]`
- `topic list | subscribe <name> | mode true|false`
- `snapshot take [--out FILE] | import FILE | reconstruct`
- `deferred list | drain`
- `confidence [peer_id]`
- `keystore encrypt | decrypt | status`
- `daemon [--socket PATH] [--udp-port N]`
- `client [--socket PATH] <JSON_REQUEST>`

## Daemon

`decentnet daemon` starts a long-running `Node` wrapped with a real
`UDPTransport` and exposes a Unix-domain control socket (default
`<root>/control.sock`, mode `0600`). Clients speak newline-delimited
JSON: requests `{"cmd": "<verb>", ...}`, replies `{"ok": true/false, ...}`.

Supported verbs: `status`, `publish`, `publish_network`, `lookup`,
`resolve`, `peers`, `log`, `signaling.{hello,ring,bye,peers}`,
`snapshot.take`, `deferred.drain`, `rotate`, `shutdown`.

## Simulator adversaries

`SimNetwork` gains three adversary primitives:

- `inject_corrupt_replica(node, peer_id, fake_address=...)` — forces
  a node's DHT store to hold a forged record for a target peer. Honest
  resolvers reject it on validation.
- `start_noisy_neighbor(attacker, target, rate_per_step=N)` — queues
  junk traffic; `step_noisy_neighbors()` fires one round.
- `make_silent(node)` — the node swallows all incoming messages (no
  replies to DHT RPCs either).

## New scenarios

Eleven new built-in scenarios bring the total to sixteen:

- `ip_change_without_refresh`
- `endpoint_remap`
- `concurrent_updates_seq_conflict`
- `symmetric_nat_relay_path`
- `cache_warming`
- `mass_churn`
- `popularity_eviction_multi_node`
- `burst_lookups`
- `adversary_corrupt_replica`
- `adversary_noisy_neighbor`
- `adversary_silent_node`

Every scenario runs from `decentnet sim run <name>` and emits
JSON + Markdown + SVG + HTML.

## Architecture diagrams

`docs/diagrams/` contains three SVGs:

- `01-layered.svg` — the full layer stack
- `02-dht-topology.svg` — how records replicate by XOR distance
- `03-session-path.svg` — signaling → ICE → relay flow

Regenerate with `python scripts/render_diagrams.py`.

## Demo

`examples/final_demo.py` exercises every item above end-to-end on
loopback. Run:

```
python examples/final_demo.py
```

## Test summary

After this phase:

- 236 / 236 tests passing
- 96 new tests across rotation, disclosure, confidence, deferred,
  topics, snapshots, reputation, digests, schedulers, CBOR, audit
  rotation, keystore, CLI, daemon, new scenarios, adversary primitives,
  and full RFC 5780 NAT classification.

No regressions against the 140-test Phase 6 baseline.

---

# Phase 7 additions

Phase 7 completed: mobile integration, productionization pass,
hardening, real-network testing.

## Mobile (Kivy)

`decentnet/mobile.py` — `MobileNode` wrapping `Node` with
lifecycle-aware scheduling. `PowerMode` (foreground / background /
low power), `NetworkKind` (wifi / cellular / none), `MobilePolicy`
dataclass with three presets: `DEFAULT_MOBILE` (balanced),
`DEFAULT_DESKTOP` (always-on), `DEFAULT_LOW_POWER` (aggressive).
Cellular multiplier on all intervals. Coming back online
auto-drains the deferred-writes queue. `examples/kivy_app/` has a
runnable Kivy skeleton + `buildozer.spec` for Android.

## Productionization

| Piece | Location |
|-------|----------|
| TOML + env-var config | `decentnet/config_file.py` |
| Structured JSON logging | `decentnet/log.py` |
| Prometheus metrics + HTTP endpoint | `decentnet/metrics.py` |
| SIGHUP config reload | `decentnet/daemon.py` |
| Health + metrics + reload verbs | `decentnet/daemon.py` |
| Per-verb `client` subcommands | `decentnet/cli/main.py` |
| Packaging (PyPI-ready) | `pyproject.toml` |
| Systemd unit with hardening flags | `packaging/decentnet.service` |
| Dockerfile + docker-compose | `packaging/Dockerfile`, `packaging/docker-compose.yml` |
| Apache 2.0 license | `LICENSE` |

Daemon flags: `--config PATH`, `--metrics-host H`, `--metrics-port N`,
`--log-level debug|info|warning|error|critical`. `SIGHUP` reloads
config and adjusts live policies (log level, `replicate_all`).

`decentnet client {status|health|metrics|reload|lookup|resolve|...}`
no longer requires raw JSON. `client raw '{...}'` remains as an
escape hatch.

## Hardening

- `docs/THREAT_MODEL.md` — adversary models (passive / active /
  offline-file), per-primitive claims and limits (Ed25519 records,
  key rotation, encrypted keystore, selective disclosure, STUN,
  relay, DHT+reputation, signaling), explicit out-of-scope threats,
  invariants, known-scenarios table.
- `tests/test_fuzz_parsers.py` — 10 `hypothesis`-based property
  tests. Parsers covered: STUN, CBOR (roundtrip + decode robustness
  + determinism), signaling envelope, LocatorRecord, GlobalSnapshot.
  Property: for any byte string, parsers either return a valid object
  or raise a documented exception — never crash.
- `scripts/bench.py` — 10 benchmarks (crypto, wire, DHT, memory).
  Reference numbers in `docs/BENCHMARKS.md`.

## Real-network testing

- `tests/test_real_network.py` — 3 opt-in tests (env-var gated)
  hitting public STUN. Skip cleanly when offline.
- `scripts/two_host_test.py` — a `host-a` / `host-b` harness that
  exercises the full UDP + signaling + ring path across two
  separate machines. Emits JSONL events.
- `docs/REAL_NETWORK.md` — setup guide, failure-mode table,
  pre-deployment checklist.

## Final test counts

- 236 from Phase Final (pre-Phase-7 baseline)
- + 7 mobile
- + 12 production (config, log, metrics)
- + 10 fuzz / property-based
- + 3 real-network (skip by default)
- = **265 passing, 3 skipped** (268 total collected)

No regressions against the 140-test Phase 6 baseline. Full
end-to-end demo still runs clean from `examples/final_demo.py`.
