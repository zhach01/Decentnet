# decentnet — Wire Protocol v1

This document specifies the on-wire format of a `LocatorRecord` in
Phase 1. It is normative for any implementation.

## Encoding

- **Serialization:** JSON (UTF-8) with:
  - sorted object keys at every depth
  - no whitespace
  - NFC-normalized string values
  - binary fields encoded as unpadded base64url
- **PeerId encoding:** unpadded lowercase base32 (RFC 4648) of the
  32-byte SHA-256 digest of the raw Ed25519 public key.
- **Signature algorithm:** Ed25519 per RFC 8032.

Future protocol versions MAY switch to deterministic CBOR (RFC 8949
§4.2). The `version` field gates this.

## LocatorRecord

```
{
  "version":         1,                               // integer, required
  "peer_id":         "<base32>",                      // string, required
  "public_key":      "<b64url 32 bytes>",             // string, required
  "seq":             42,                              // non-negative int
  "issued_at":       1700000000,                      // UNIX seconds, int
  "expires_at":      1700003600,                      // UNIX seconds, int
  "soft_expires_at": 1700001800,                      // UNIX seconds, int
  "endpoints":       [ <Endpoint>, ... ],             // array
  "capabilities":    [ "signaling-v1", ... ],         // array of strings
  "nat_metadata":    { ... },                         // object (free)
  "topic_hashes":    [ "<b64url or hex>", ... ],      // array of strings
  "prev_key_rotation": { ... } | absent,              // reserved for Ph.2
  "signature":       "<b64url>"                       // required on the wire
}
```

### Endpoint

```
{
  "type":          "lan_udp" | "public_udp" | "public_tcp"
                   | "websocket" | "webrtc_candidate" | "relay_candidate",
  "address":       "<host>:<port>"        // or URL for websocket/webrtc
                                          // IPv6: "[::1]:41234"
  "priority":      0,                     // int, higher = prefer
  "confidence":    0.5,                   // float in [0,1]
  "discovered_by": "self" | "stun" | "observed" | ...,  // optional string
  "last_success":  1700000000             // optional int, usually cache-only
}
```

## Signature

Let `canonical(x)` be the canonical JSON encoding defined above.

The signing input is:

```
signing_input = canonical( record without the "signature" field )
```

The `signature` field is:

```
signature = ed25519_sign(private_key, signing_input)
```

A receiver MUST reject the record unless **all** of the following hold:

1. `version` is supported.
2. `public_key` decodes to exactly 32 bytes.
3. `peer_id == base32(sha256(public_key))` (lowercase, unpadded).
4. `seq >= 0`.
5. `issued_at <= soft_expires_at <= expires_at`.
6. `ed25519_verify(public_key, signing_input, signature)` succeeds.

## Freshness and precedence

A receiver MUST drop a record if `now >= expires_at`.

A receiver SHOULD refresh (re-request or re-resolve) if
`soft_expires_at <= now < expires_at`.

Given two records `A` and `B` for the same `peer_id`, `A` is **newer**
than `B` iff:

- `A.seq > B.seq`, or
- `A.seq == B.seq` AND `A.issued_at > B.issued_at`.

A cache MUST NOT replace an existing record with one that is not
strictly newer. Exact duplicates (same seq, same issued_at) are not
newer and MUST be treated as duplicates.

## Identity continuity

If a cache already holds a record for `peer_id = P`, then a new record
for `peer_id = P` MUST carry the same `public_key` to be accepted.

A genuine key rotation produces a **new** `peer_id` (because the ID is
derived from the key). Phase 2 will add an authenticated
`prev_key_rotation` path for applications that want to link an old ID
to a new one.

## Capabilities

`capabilities` is an open-ended list of ASCII strings. Suggested
prefixes:

- `signaling-v<n>` — speaks the v<n> direct-signaling protocol
- `chat-v<n>`      — app-level capability
- `media-v<n>`     — voice/video capable
- `relay-v<n>`     — can serve as an optional relay candidate

Unknown capabilities MUST be preserved across parse/serialize cycles
so older nodes don't strip them.

## Topic hashes

`topic_hashes` is an optional array of opaque identifiers the peer
chooses to advertise (e.g. room hashes, interest tags). The fabric
does not define semantics beyond "if you're also in this set, we
might want to talk".

## NAT metadata

Free-form object, advisory only. Suggested shape:

```
"nat_metadata": {
  "type": "unknown" | "full_cone" | "restricted" | "port_restricted" | "symmetric",
  "observed_from": "stun:stun.example.org:3478"   // optional
}
```

Phase 5 will populate this automatically from STUN observations.

## Backwards / forwards compatibility

- Implementations MUST preserve unknown top-level fields across
  parse → serialize round-trips (subject to canonical encoding).
- Implementations MUST reject records whose `version` they do not
  support.
- New endpoint types MAY be added in later versions; older parsers
  that don't recognise a type SHOULD skip it rather than fail the
  whole record.

## Example (Phase 1, pretty-printed for readability — the wire form is
compact)

```json
{
  "capabilities": ["signaling-v1"],
  "endpoints": [
    {"address": "203.0.113.5:41234", "confidence": 0.5,
     "discovered_by": "self", "priority": 0, "type": "public_udp"}
  ],
  "expires_at": 1776323211,
  "issued_at": 1776319611,
  "nat_metadata": {},
  "peer_id": "kedrzswdp6pnxm6xqyjwkxy5egu6i6qeavgrpyhcircyxwmfcfdq",
  "public_key": "<b64url-32-bytes>",
  "seq": 1,
  "signature": "<b64url-64-bytes>",
  "soft_expires_at": 1776320511,
  "topic_hashes": [],
  "version": 1
}
```
