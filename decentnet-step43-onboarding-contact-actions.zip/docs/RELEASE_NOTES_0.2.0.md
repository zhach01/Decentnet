# decentnet 0.2.0 release notes

## Summary

Release `0.2.0` is the first unified candidate that packages together the networking
reliability work, operator tooling, dashboard visibility, and final report/export flow.

## Highlights

- Automatic signaling bootstrap using attached signed `LocatorRecord`s.
- ICE candidate probing starts automatically after session establishment.
- Selected path persistence plus keepalive-driven path health and restart.
- Relay fallback with explicit lifecycle tracking and safer reuse/invalidation.
- Runtime candidate refresh when endpoint sets change.
- Two-host harness with local, SSH, matrix, soak, and pack modes.
- Dashboard trend views and import/exportable snapshots.

## Upgrade notes

- The old assumption that a peer had to already exist in local cache before `hello()`
  is no longer required when bootstrap records travel inside `HELLO` / `HELLO_ACK`.
- Operators should prefer `scripts/two_host_test.py orchestrate`, `matrix`, `soak`,
  and `pack` instead of the original manual two-terminal flow.
- Use `decentnet dashboard` for both live views and archived snapshot inspection.

## Tested surfaces

The release candidate was validated through focused signaling/ICE/relay suites, mesh
integration with rebind/partition/restart churn, operator harness flows, dashboard
export/import tests, and local real-UDP smoke checks.

Real-network STUN tests remain opt-in because they require working external DNS and
outbound UDP from the runner environment.

## Known limits

- NAT traversal is improved but still environment-dependent; hard NAT cases may still
  require relay use.
- Cooperative relay support is intentionally simpler than full TURN service behavior.
- Public-internet long-haul campaigns still need operator-managed hosts or VMs.

## Recommended docs

- `docs/PRODUCTION_RUNBOOK.md`
- `docs/REAL_NETWORK.md`
- `docs/THREAT_MODEL.md`
- `CHANGELOG.md`
