# Real-network testing

By default, DecentNet's automated test suite runs on loopback with a mock STUN
server. This document covers:

- opt-in real STUN smoke tests
- a two-host / two-network operator harness
- machine-readable pass/fail summaries

## 1. Real STUN integration

Three tests in `tests/test_real_network.py` talk to public STUN servers. They
are opt-in:

```bash
DECENTNET_ENABLE_REAL_NETWORK=1 pytest tests/test_real_network.py -v -rs
```

Behaviour when enabled:

- DNS fails → skip
- UDP egress blocked → skip cleanly
- STUN server timeout → skip cleanly
- success → assert the parsed mapping is plausible and NAT classification is
  returned

## 2. Two-host live harness

`scripts/two_host_test.py` is the operator-facing harness for cross-machine
validation. It standardises:

- exported bootstrap bundles
- machine-readable per-host summaries
- a merged pass/fail report

### Bundle format

The exported bundle is a JSON file containing:

- `peer_id`
- `peer_addr`
- `record_wire`
- `format`

Host B needs host A's bundle to start the first connection. Host A does **not**
need B's bundle copied back for the first handshake anymore because `HELLO` and
`HELLO_ACK` now carry the signed record for automatic bootstrap.

### Host A

```bash
python scripts/two_host_test.py host-a \
  --root /tmp/decentnet-a \
  --udp-port 41234 \
  --public-address 198.51.100.10:41234 \
  --bundle-out /tmp/decentnet-a.bundle.json \
  --summary-out /tmp/decentnet-a.summary.json \
  --duration 120 \
  --stop-on-success \
  --expect-ring
```

### Host B

Copy host A's bundle to host B, then run:

```bash
python scripts/two_host_test.py host-b \
  --root /tmp/decentnet-b \
  --udp-port 41235 \
  --public-address 203.0.113.20:41235 \
  --peer-bundle /tmp/decentnet-a.bundle.json \
  --self-bundle-out /tmp/decentnet-b.bundle.json \
  --summary-out /tmp/decentnet-b.summary.json \
  --send-ring \
  --send-keepalive
```

### Merged report

Once both sides have finished, merge the summaries into a single verdict:

```bash
python scripts/two_host_test.py report \
  --host-a-summary /tmp/decentnet-a.summary.json \
  --host-b-summary /tmp/decentnet-b.summary.json \
  --out /tmp/decentnet-report.json
```

The merged report contains:

- global `ok`
- host-A and host-B per-role summaries
- `hello_completed`
- `ring_completed`
- selected path kind on both sides
- whether relay was used

This file is intended to be easy to archive in CI or operator runbooks.

## 3. Same-machine validation

For logic validation on one machine, use loopback addresses and separate roots:

```bash
python scripts/two_host_test.py host-a \
  --root /tmp/decentnet-a \
  --udp-port 41234 \
  --public-address 127.0.0.1:41234 \
  --bundle-out /tmp/decentnet-a.bundle.json \
  --summary-out /tmp/decentnet-a.summary.json \
  --duration 20 \
  --stop-on-success \
  --expect-ring
```

```bash
python scripts/two_host_test.py host-b \
  --root /tmp/decentnet-b \
  --udp-port 41235 \
  --public-address 127.0.0.1:41235 \
  --peer-bundle /tmp/decentnet-a.bundle.json \
  --self-bundle-out /tmp/decentnet-b.bundle.json \
  --summary-out /tmp/decentnet-b.summary.json \
  --send-ring
```

Then merge the summaries with the `report` mode shown above.

## 4. Operator orchestration

From one operator machine you can run both sides with `orchestrate`:

```bash
python scripts/two_host_test.py orchestrate \
  --host-a-runner local \
  --host-b-runner local \
  --host-a-root /tmp/decentnet-a \
  --host-b-root /tmp/decentnet-b \
  --host-a-udp-port 41234 \
  --host-b-udp-port 41235 \
  --host-a-public-address 127.0.0.1:41234 \
  --host-b-public-address 127.0.0.1:41235 \
  --send-ring \
  --send-keepalive \
  --report-out /tmp/decentnet-report.json
```

For repeated validation, use `matrix` to run multiple scenarios/trials and emit
an aggregate JSON report plus an optional HTML summary:

```bash
python scripts/two_host_test.py matrix \
  --host-a-runner local \
  --host-b-runner local \
  --host-a-root-prefix /tmp/decentnet-a \
  --host-b-root-prefix /tmp/decentnet-b \
  --host-a-public-host 127.0.0.1 \
  --host-b-public-host 127.0.0.1 \
  --base-port 42000 \
  --scenario direct \
  --scenario full \
  --trials 2 \
  --report-out /tmp/decentnet-matrix.json \
  --html-out /tmp/decentnet-matrix.html
```

`direct` runs a hello-only flow, `ring` adds a ring exchange, and `full` adds
ring plus keepalive.

## 5. Real two-network operator checklist

Before running across the public internet:

1. Confirm each host knows its reachable `host:port`.
2. Allow inbound UDP on the chosen ports.
3. Export host A's bundle and copy it to host B.
4. Run host A first, then host B.
5. Archive both summary files and the merged report.
6. If the selected path kind is `relay/relay`, direct traversal failed but relay
   fallback succeeded.
7. If the merged report is not OK, inspect the summaries' `audit_counts` and
   `stats` sections.

## 6. What this still does not automate

- secure file transfer of bundles between independent hosts
- public cloud provisioning / firewall setup
- multi-hour soak testing on the public internet
- LTE / 5G / CGNAT-specific operator automation

## 7. Recommended pre-deployment check

Before shipping DecentNet into a real environment, we recommend:

1. Running the full unit/integration suite.
2. Running the real STUN smoke test from the target network.
3. Running the two-host harness between representative peers.
4. Archiving the per-host summaries and merged report.
5. Reviewing whether the final selected path was direct or relay-backed.

## 6. Repeated soak campaigns

For longer validation, use the `soak` mode. It runs repeated `matrix`
campaigns, keeps a rolling JSON report, and can also render an aggregate HTML
trend page.

Example:

```bash
python scripts/two_host_test.py soak \
  --host-a-runner local \
  --host-b-runner local \
  --host-a-root-prefix /tmp/decentnet-a \
  --host-b-root-prefix /tmp/decentnet-b \
  --host-a-public-host 127.0.0.1 \
  --host-b-public-host 127.0.0.1 \
  --base-port 43000 \
  --scenario direct \
  --scenario full \
  --trials 1 \
  --rounds 5 \
  --rolling-out /tmp/decentnet-soak.json \
  --html-out /tmp/decentnet-soak.html
```

Important knobs:

- `--rounds N`: run exactly N matrix campaigns.
- `--max-wall-time-s SECONDS`: stop after a total wall-clock budget.
- `--sleep-between-runs`: delay between runs inside one matrix campaign.
- `--sleep-between-campaigns`: delay between matrix campaigns.
- `--fail-fast`: stop on the first failing campaign.
- `--port-stride`: reserve a fresh block of ports per campaign.

The rolling report contains campaign-level trends such as:

- total campaigns and success rate
- total runs and run success rate
- relay-used run count
- per-scenario pass/fail totals
- longest success/failure streaks

## 7. What this still does not automate

- secure file transfer of bundles between independent hosts
- public cloud provisioning / firewall setup
- multi-hour soak testing on the public internet
- LTE / 5G / CGNAT-specific operator automation

## 8. Recommended pre-deployment check

Before shipping DecentNet into a real environment, we recommend:

1. Running the full unit/integration suite.
2. Running the real STUN smoke test from the target network.
3. Running the two-host harness between representative peers.
4. Running a short soak campaign on representative peers.
5. Archiving the per-host summaries, merged report, and soak report.
6. Reviewing whether the final selected path was direct or relay-backed.

## Dashboard snapshots and archived operator pages

You can now archive a self-contained dashboard snapshot as JSON and HTML.
This is useful after a matrix or soak campaign when you want one portable
page that includes:

- current node/cache topology
- recent relay and ICE events
- merged two-host operator reports
- matrix / soak summaries pointed at with `--soak-report` or `--operator-report`

Export a snapshot without starting the live server:

```bash
python -m decentnet.cli.main dashboard \
  --watch-root /tmp/decentnet-a \
  --watch-root /tmp/decentnet-b \
  --operator-report /tmp/decentnet-orchestrated-report.json \
  --soak-report /tmp/decentnet-soak.json \
  --snapshot-json-out /tmp/decentnet-dashboard-snapshot.json \
  --snapshot-html-out /tmp/decentnet-dashboard-snapshot.html \
  --once
```

Serve a previously exported snapshot later:

```bash
python -m decentnet.cli.main dashboard \
  --snapshot-in /tmp/decentnet-dashboard-snapshot.json \
  --host 127.0.0.1 \
  --port 8765
```

## Operator bundle export pack

You can now collect the key artifacts from a validation window into one
shareable archive:

- merged/operator reports
- matrix and soak reports
- selected logs
- dashboard snapshot JSON
- dashboard snapshot HTML
- manifest JSON and an index page

Example:

```bash
python scripts/two_host_test.py pack \
  --watch-root /tmp/decentnet-a \
  --watch-root /tmp/decentnet-b \
  --operator-report /tmp/decentnet-orchestrated-report.json \
  --matrix-report /tmp/decentnet-matrix.json \
  --soak-report /tmp/decentnet-soak.json \
  --log-file /tmp/decentnet-a.log \
  --log-file /tmp/decentnet-b.log \
  --out-dir /tmp/decentnet-bundle \
  --archive-out /tmp/decentnet-bundle.zip
```

The resulting directory contains at least:

- `manifest.json`
- `index.html`
- `dashboard-snapshot.json`
- `dashboard-snapshot.html`
- copied reports under `reports/`
- copied logs under `logs/`

The manifest records source paths, packaged paths, file sizes, and SHA-256
checksums for auditing or later review.
