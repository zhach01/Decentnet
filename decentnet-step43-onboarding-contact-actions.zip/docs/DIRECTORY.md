# decentnet — Directory (L3 Distributed Resolution)

This document covers the distributed directory introduced in Phase 2:
how records are stored, replicated, and found across a network of
nodes. Pair with `REPAIR.md` (anti-entropy) and `PROTOCOL.md` (wire
format).

## Goals

1. Resolve a peer ID to a fresh, signed `LocatorRecord` across the
   open internet without a single central server.
2. Remain correct under partial failure: offline nodes, corrupted
   replicas, partitions, stale or forged records.
3. Never carry user payloads — the directory is strictly a control
   plane for signed endpoint metadata.

## Why Kademlia

The directory is a Kademlia-style DHT. Reasons:

- **XOR metric** is self-correcting: every routing step at least
  halves the remaining distance. Lookups are `O(log N)` hops.
- **k-buckets** give us a replication topology for free: the k
  XOR-closest nodes to a record's key are its replicas.
- **Well-understood failure modes** make security analysis tractable.

The DHT node ID is the Peer ID (base32 of SHA-256 of pubkey), so a
peer's DHT identity and their cryptographic identity are the same.
Consequences:

1. An attacker cannot cheaply pick a node ID close to a victim's key
   without grinding public keys — a weak but meaningful Sybil defence.
2. No separate node-ID registration step; joining is "show up with a
   keypair".

## Data structures

### Routing table

* 256 buckets, each with capacity `k` (default 8).
* Bucket `i` holds contacts whose XOR distance to self has highest
  set bit at position `i`.
* Contact = `(peer_id, endpoint_hint, last_seen)`.
* Insertion refreshes-or-inserts. When full, Kademlia's "PING the
  LRU; if alive, keep it; else evict" rule applies.

### DHT replica store

* Separate from the L1 local cache.
* Holds only records this node is responsible for replicating — i.e.
  records where this node is among the k XOR-closest known nodes to
  the record's key.
* Uses the **same** `validate_for_storage` as the L1 cache.
* In-memory in Phase 2; disk persistence is a Phase 3 addition.

### L1 write-through

When a `STORE` RPC is accepted, the record is also written into L1
via `local_cache_observer`. This means a publisher's record
propagates to L1 on every replica that accepts it, so future
`Node.lookup()` on that key hits immediately.

## RPCs (`transport/messages.py`)

| RPC           | Request             | Responses                          |
|---------------|---------------------|------------------------------------|
| PING          | —                   | PONG                               |
| FIND_NODE     | target peer_id      | NODE_LIST (up to k closest)        |
| STORE         | signed record       | STORE_OK / STORE_REJECT(reason)    |
| FIND_VALUE    | peer_id             | VALUE(record) or VALUE_MISS(nodes) |
| DIGEST_REQUEST| summary list        | DIGEST_RESPONSE + RECORD_PUSHes    |
| RECORD_PUSH   | signed record       | (unacked)                          |

Every hop re-validates records. A record's validity does not depend
on any intermediary being trustworthy.

## Algorithms

### Iterative lookup

Classic Kademlia shortlist:

1. Seed with the k closest-known contacts to `target`.
2. Pick `alpha` nearest-unqueried contacts (default 3).
3. Send queries; absorb responses into the shortlist; trim to k nearest.
4. Repeat until no new unqueried contact is closer than queried ones.

Phase 2's in-process transport is synchronous, so the `alpha`
parallelism executes serially — correct but not fast. Phase 4's UDP
transport gets real fan-out without changing call sites.

### Quorum-merged FIND_VALUE

`FIND_VALUE` keeps polling after the first `VALUE` response and
collects every valid record along the shortlist. It returns the
**highest-`(seq, issued_at)` record**:

- If all replicas agree → trivial.
- If one is stale → freshest wins.
- If one is corrupt → fails `verify()` on the client side, ignored.
- A malicious replica cannot force a rollback — by precedence, the
  newest signed record wins, and the attacker cannot produce a
  record signed by the victim's key.

`LookupResult` exposes raw variants so tests and later reputation
scoring can see disagreement explicitly.

### Publishing

`store_on_network(record)`:

1. `find_node(record.peer_id)` iterative lookup.
2. Add self if among the closest k.
3. Send `STORE(record)` to each; collect OK / REJECT / unreachable.
4. Return a summary dict.

Phase 3 adds a **republish loop**: each node re-broadcasts its own
record every `soft_ttl_s`, so records survive churn even without
explicit re-issuance by the owner.

## Bootstrap

A fresh node needs at least one reachable peer. `BootstrapManifest`
is a signed seed list:

```
{ version, issued_at, expires_at, publisher_public_key, seeds[], signature }
```

Publishers are whoever operates a rotating list of long-lived seeds.
The manifest is signed so distribution channels can be untrusted
(mirrors, CDNs, QR codes). A node that already has one can fetch a
newer one signed by the same key.

**Honest note:** there is no realistic alternative to "some seed
list" for wide-area bootstrapping. The design choice is to make that
list minimal, verifiable, and replaceable — not to pretend it
doesn't exist.

## Security

Protected:

- Record forgery / tampering (signatures; verified at every hop).
- Rollback at L1 and DHT store (`validate_for_storage`).
- Identity spoofing (`peer_id = b32(sha256(pubkey))`).
- Far-future pinning (`max_future_skew_s`).
- Ingest flood DoS (per-source token bucket).

Not yet protected:

- **Sybil / eclipse on the DHT**: spinning up many nodes XOR-close to
  a victim can eclipse their lookups. Phase 7+ mitigations: S/Kademlia
  crypto-puzzle node IDs, multi-path lookups over disjoint buckets,
  reputation decay on misbehaving peers.
- **Metadata visibility**: records are plaintext. Phase 9 adds
  selective disclosure (encrypted records for allowed peers) and
  topic hashing.
- **Traffic analysis**: we don't hide who is asking about whom.
  Phase 9 will discuss padding / onion lookups.

## Performance

- Each record stored on k ≈ 8 peers.
- Lookups cost `O(log N)` RPC rounds.
- Digests are `O(M)` for M replicated records — fine for sim networks,
  but Phase 3 should switch to Merkle-tree bucket hashes + Bloom
  filter summaries for large N.
- Per-record cost: one Ed25519 verify (~50 μs) plus JSON parse. The
  rate limiter caps abuse.
