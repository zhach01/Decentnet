# decentnet — ICE & Relay Fallback (Phase 6)

Phase 5 lets a node learn a public UDP mapping it can advertise.
Phase 6 is what happens *between* two peers once each has a list of
candidate endpoints: probing pairs in priority order, picking the
best one, and falling back to a minimal cooperative relay if no
direct path works.

This pairs with `SIGNALING.md` (the envelope we use for checks) and
`NAT.md` (how candidates are discovered).

## What "ICE" means here

Full RFC 8445 ICE is large: STUN-over-STUN checks with short-term
credentials, four-way matrices of CONTROLLING / CONTROLLED roles,
keepalive on the selected pair, restart sequences, and interop with
every WebRTC stack shipped in the last decade.

decentnet Phase 6 implements the **core idea** — prioritized
candidate-pair probing — without the STUN USERNAME /
MESSAGE-INTEGRITY / FINGERPRINT apparatus, because our signaling
envelope already provides stronger authentication (Ed25519 over
canonical JSON).

Trade-off: decentnet ICE does not interop on the wire with browser
WebRTC. Inside a decentnet↔decentnet session that's fine. A future
phase can add a STUN-compatible dialect if we ever need to bridge
to browsers.

## Candidates

`IceCandidate` models:

| Type  | Source                                | Typical preference |
|-------|---------------------------------------|-------------------:|
| host  | local interface (LAN IP)              | 126                |
| srflx | server-reflexive (STUN-learned)       | 100                |
| prflx | peer-reflexive (learned during ICE)   | 110                |
| relay | allocated via a cooperative relay     |   0                |

`candidates_from_endpoints(record.endpoints)` converts a signed
`LocatorRecord` to an ICE candidate list, preserving publisher hints
(`priority`, `confidence`) as ICE `local_preference`.

## Priority math (RFC 8445 §5.1.2.1)

```
priority = (type_pref << 24) | (local_pref << 8) | (256 - component)
```

and the pair priority (§6.1.2.3):

```
pair = (min(G,D) << 32) + 2*max(G,D) + (tiebreak bit)
```

Higher is better. Pair enumeration sorts descending, probing the
highest pair first — which in the common case is host↔host on a
LAN or srflx↔srflx between two STUN-mapped peers across the open
internet.

## Connectivity checks

We ride decentnet's existing signed envelope:

| Message                | Role                                        |
|------------------------|---------------------------------------------|
| `sig.conn_check`       | "please ack this check_id"                  |
| `sig.conn_check_ack`   | "ack; I saw you at <observed_remote>"       |

Each check:

1. Builds a `sig.conn_check` with a fresh `check_id` and signs it.
2. Emits the datagram on the local candidate's socket to the remote
   candidate's address. **This is also the hole-punch pulse**: it
   opens local NAT state that lets the peer's mirror check return.
3. Waits up to `timeout_s` for a matching `sig.conn_check_ack`.
4. On ack, marks the pair `SUCCEEDED` and records RTT.
5. The controlling agent nominates the highest-priority
   `SUCCEEDED` pair; the controlled agent adopts that nomination.

If no pair succeeds after exhausting the list, the agent returns
`None` and the caller falls back (to a relay, typically).

The ack carries `observed_remote`, the address the receiver actually
saw — the peer-reflexive address under NAT. Higher layers can use
this to install a `prflx` candidate and rerun selection if needed.

## Hole punching

Hole punching is implicit in how checks work. Because both agents
start probing simultaneously (coordinated by higher-level signaling
that happens via the DHT), each side's outbound check opens its own
NAT. The first pair whose two punches cross each other's NAT mapping
succeeds.

For explicitly coordinated punches (when one side knows to send a
pulse to open its mapping at the right moment), the
`sig.punch / sig.punch_ack` message types are reserved. Phase 6
ships the envelope; scheduling it finely per-NAT-type behaviour is
application-level policy and is left for consumers.

## Relay fallback

Two peers behind incompatible NATs (common case: both symmetric)
cannot make any direct pair work. The relay is a **minimal
cooperative UDP forwarder**:

- One socket, one allocation table, one forwarding loop.
- Clients prove they're authorized by presenting a signed
  `RelayToken` issued by the relay operator.
- After allocation, `FORWARD { target: <peer_id> }` datagrams get
  rewrapped with a short header revealing the source peer_id and
  delivered to the target's current address.

### What the relay is NOT

- **Not an RFC 5766 TURN server.** No ChannelBind, no permissions,
  no attribute-based auth. Interop is not a goal.
- **Not a general VPN.** It forwards datagrams between pre-allocated
  peer_ids only.
- **Not a media relay at scale.** It's for situations where nothing
  else works. Use it for signaling and small control traffic.
- **Not anonymous.** The relay operator sees which peer_ids talk to
  which; in a fair threat model that's equivalent to an ISP seeing
  connection 5-tuples.

### What the relay guarantees

- **Authenticated allocation.** Tokens are Ed25519-signed by the
  relay operator; forging one means stealing the operator's key.
- **No plaintext content visibility.** decentnet signaling payloads
  are opaque to the relay (they're signed JSON, and the parts that
  matter — OFFER / ANSWER payloads — are whatever the app put in
  them; a typical deployment encrypts).
- **Deterministic cleanup.** Tokens have TTLs; allocations expire.

### When to use it

Only after ICE has exhausted direct pairs. A deployment should
publish an optional `relay_candidate` endpoint in the
`LocatorRecord` (type `relay_candidate`), and peers treat it as
lowest priority. The relay-allocated address becomes a candidate
pair; connectivity checks sent through the relay succeed whenever
both peers are allocated, by construction.

## Integration points

- `Node` exposes no direct ICE surface in Phase 6 — the agent is
  constructed per session by higher-level code, because candidate
  lists depend on the specific peer you're talking to.
- A future Phase 7 productionization pass wires `SignalingEngine`
  to auto-run ICE right after hello_ack using each peer's
  `LocatorRecord.endpoints`, producing a "the session has a selected
  path" event that apps can key off.
- Relay servers are standalone processes (`python -m
  decentnet.relay.serve <host> <port>`, a future CLI subcommand).
  For Phase 6 we expose the in-process `RelayServer` class directly
  and the test suite exercises it.

## What Phase 6 explicitly does NOT ship

- A production-ready TURN server. Ours is cooperative, not compliant.
- **Automatic ICE triggering on session setup.** Wiring this into
  the signaling engine is straightforward but introduces an
  always-on socket policy decision. Deferred to Phase 7.
- **Path switchover after failure.** ICE today picks once; a
  production system should renegotiate when the selected path
  stops working (Phase 7).
- **Congestion control on relay traffic.** A busy relay needs
  per-peer rate limits. Easy add, not shipped.

Everything above is tracked in `docs/ARCHITECTURE.md` and in the
honest-limits sections of per-phase docs.
