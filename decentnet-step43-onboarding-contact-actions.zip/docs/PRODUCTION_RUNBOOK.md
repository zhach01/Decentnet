# Production runbook

## Scope

This runbook covers deployment, validation, observability, and incident-handling entry
points for the `decentnet` 0.2.0 candidate.

## Before deployment

1. Confirm Python 3.11+ is available.
2. Install with `python -m pip install -e .` or package from the tagged release tree.
3. Verify the node root path is writable and persistent.
4. Ensure UDP ports and any relay ports are permitted by local firewall policy.
5. Decide whether the environment expects direct paths, relay fallback, or both.

## Initial bring-up

1. Initialize a node identity with `decentnet init`.
2. Publish at least one reachable endpoint.
3. If a daemonized setup is desired, launch `decentnet daemon ...` with metrics enabled.
4. Use `decentnet whoami`, `decentnet stats`, and `decentnet log` to confirm the node is healthy.

## Operator validation workflow

Preferred commands:

- Single two-host validation: `scripts/two_host_test.py orchestrate`
- Repeated scenario runs: `scripts/two_host_test.py matrix`
- Rolling validation over time: `scripts/two_host_test.py soak`
- Final collection bundle: `scripts/two_host_test.py pack`

See `docs/REAL_NETWORK.md` for concrete command lines.

## Dashboard and observability

Use:

```bash
decentnet dashboard --watch-root /path/to/node/root
```

Recommended dashboard inputs:
- `--operator-report` for orchestrated/merged reports
- `--soak-report` or `--soak-dir` for long-run trend visibility
- `--snapshot-json-out` and `--snapshot-html-out` for archived review

## Health signals to watch

- repeated `signal.rate_limited` or `relay.rate_limited` events
- repeated `ice.restart` without later `ice.path_selected`
- relay-selected sessions increasing unexpectedly in an environment that should allow direct paths
- growing negative-cache entries or repeated `signal.bootstrap_reject`

## Incident response checklist

1. Capture a fresh operator bundle with `scripts/two_host_test.py pack`.
2. Export a dashboard snapshot JSON and HTML page.
3. Inspect whether sessions are direct, relay-selected, or repeatedly restarting ICE.
4. Confirm endpoint records are current and that candidate refresh has propagated.
5. If public-network validation is involved, verify DNS resolution and UDP reachability for STUN/relay endpoints.

## Release handoff checklist

- `CHANGELOG.md` updated
- `docs/RELEASE_NOTES_0.2.0.md` present
- `docs/REAL_NETWORK.md` current
- `docs/PRODUCTION_RUNBOOK.md` current
- operator bundle smoke-tested
- dashboard snapshot export/import smoke-tested


## Pre-flight doctor checks

Before running orchestrate, matrix, soak, or pack workflows, run a local diagnostic:

```bash
decentnet doctor --json --bind-udp-port 0
```

To probe a reachable STUN server and verify an operator bundle archive:

```bash
decentnet doctor --json \
  --bind-udp-port 0 \
  --stun-server stun.l.google.com:19302 \
  --pack /path/to/decentnet-bundle.zip
```

The command returns exit code `0` only when all requested checks succeed.


## Step 21: remote deployment and validation automation

The two-host harness now includes a `deploy` mode that can prepare two hosts,
run `decentnet doctor`, optionally sync the repo, and then launch a validation,
matrix, or soak run from one operator machine.

Local fake-remote example:

```bash
python scripts/two_host_test.py deploy   --host-a-runner local   --host-b-runner local   --host-a-repo /tmp/lab/a_repo   --host-b-repo /tmp/lab/b_repo   --host-a-root /tmp/lab/a_root   --host-b-root /tmp/lab/b_root   --host-a-public-address 127.0.0.1:41234   --host-b-public-address 127.0.0.1:41235   --sync-repo   --install-mode skip   --send-ring
```

SSH-backed example:

```bash
python scripts/two_host_test.py deploy   --host-a-runner ssh   --host-b-runner ssh   --host-a-target user@host-a   --host-b-target user@host-b   --host-a-repo /opt/decentnet   --host-b-repo /opt/decentnet   --host-a-root /var/lib/decentnet/a   --host-b-root /var/lib/decentnet/b   --host-a-public-address 198.51.100.10:41234   --host-b-public-address 203.0.113.20:41235   --install-mode editable   --emit-systemd-dir ./units   --run-pack   --pack-archive-out ./decentnet-operator-bundle.zip
```

Use `--dry-run` first to inspect the exact preparation and validation plan
without changing either host.


## VPN / overlay endpoints

DecentNet can now detect and publish overlay addresses for Tailscale, WireGuard, and generic VPN/tunnel interfaces.

Examples:

```bash
decentnet publish --endpoint public_udp:203.0.113.5:41234 --auto-vpn
```

```bash
decentnet doctor --json --vpn-port 41234
```

Detection sources:
- explicit `DECENTNET_VPN_ENDPOINT` / `DECENTNET_VPN_ENDPOINTS`
- env vars like `TAILSCALE_IP` and `WIREGUARD_IP`
- interface parsing from `ip -o addr show up`

When overlay endpoints are present, ICE prefers them over plain public UDP candidates.
