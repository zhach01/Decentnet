# decentnet — Repair (Anti-Entropy)

Repair covers what happens when nodes *already* store records but
disagree about which is freshest — typical after partitions, churn,
or lost replicas. Phase 2 ships a simple but real anti-entropy layer;
later phases harden it.

## When is repair needed?

| Situation                            | How repair helps                     |
|--------------------------------------|--------------------------------------|
| Partition heals                      | Each side pulls newer records        |
| Node was offline during a republish  | On rejoin, syncs to catch up         |
| One replica holds a stale record     | Digest exchange reveals the delta    |
| Catastrophic replica loss            | Late joiner re-learns from any peer  |

Repair does **not** compensate for lost private keys — that's a
security concern handled by key rotation (Phase 2+ has the field;
acceptance rules come later).

## Mechanism: summary exchange

Two DHT-participating nodes exchange compact summaries of what they
hold. A summary is a list of `(peer_id, seq, issued_at)` tuples —
just enough to decide "who has the newer record" per peer_id.

Flow:

1. Initiator A sends `DIGEST_REQUEST` with its own summary to B.
2. Responder B compares:
   * For each entry B holds but A doesn't → B wins; push.
   * For each entry where B's `(seq, issued_at)` beats A's → B wins;
     push.
   * Otherwise → skip.
3. B sends `DIGEST_RESPONSE` with the count of records it will push.
4. B sends one `RECORD_PUSH` per selected record.
5. A validates each push via `validate_for_storage` in its DHT store;
   invalid records are logged and dropped.

This is **one-directional per round**: A learns what B has that A
lacks. To sync the other way, A initiates the same flow with B.
Keeping it one-directional keeps logic and test determinism simple.

## Why just summaries?

In Phase 2 the summary is a full list of stored entries. This costs
`~80 bytes × M` per exchange (M = records held). That's fine for the
in-process simulator and small real networks.

For large N, Phase 3 should move to:

* **Merkle-tree bucket hashes** — split the key space into buckets,
  send the root of each bucket's Merkle tree. If two nodes agree on a
  root they skip the bucket entirely; otherwise they descend.
* **Bloom filter summaries** — probabilistic set-membership check
  bounds bandwidth regardless of M, at the cost of occasional false
  negatives (which a follow-up exchange catches).

Both are compatible with the message types we already ship; they only
change what goes inside the DIGEST_REQUEST payload.

## Validation is the safety net

Every record that arrives via `RECORD_PUSH` is run through the same
`validate_for_storage` pipeline. That gives us:

- No push can install a forged record (signature check).
- No push can install a stale record (seq precedence).
- No push can install a future-pinning record (skew clamp).
- No push can install a record for a different identity under the
  same peer_id (public key continuity).

So a malicious or buggy peer initiating anti-entropy cannot corrupt
a receiver's store. The worst they can do is waste a few CPU cycles,
and the rate limiter bounds that.

## Scheduling

Phase 2 ships only on-demand `sync_with(peer_id)`. Callers decide
when to run it. Typical triggers (Phase 3 will schedule these
automatically):

- After `join_network()` completes, sync with a seed.
- On detection of partition heal.
- Periodically (e.g. once per `soft_ttl_s`), with a neighbour picked
  at random from the routing table.
- When a lookup returns disagreeing variants — sync with the replica
  that held the newer record.

## What repair still doesn't do (Phase 2)

- **Bidirectional sync in one round.** An initiator learns, but does
  not simultaneously teach. Two sequential calls cover it.
- **Sync only touches the DHT store, not L1.** L1 is per-peer
  popularity-scoped, so re-populating it from a neighbour would be
  noisy. Callers that want fresh L1 entries should call `resolve()`.
- **No selective sync.** Phase 3 can add per-topic filters so nodes
  with narrow interests don't download the whole world.

## Observability

Every push/accept/reject is logged as an audit event:

```
{"kind": "antientropy.ingest",
 "peer_id": "...", "seq": N, "accepted": true/false,
 "reason": "...", "from_peer": "..."}
```

The `SyncResult` returned by `sync_with()` includes `received` and
`skipped_stale`. Tests assert on this directly (see
`tests/test_scenarios.py::test_scenario_partition_then_merge_via_antientropy`).
