# decentnet — Simulator & Visualization (Phase 3)

Phase 3 makes the distributed behaviour introduced in Phase 2 *legible*:
you can script a scenario, drive it with a virtual clock, snapshot
network state at meaningful moments, and render those snapshots as
SVG graphs with a single-page HTML timeline viewer.

## Why this layer exists

Phase 2's `tests/test_scenarios.py` proves the distributed layer behaves
correctly under partition, churn, corruption, and replay. But "it passes
assertions" is not the same as "I understand what happened when". The
simulator exists so that:

- A human can *see* a scenario unfold (SVG per checkpoint, HTML viewer).
- A tool can parse the results (`report.json`).
- A summary reader can skim (`report.md`).
- Time-sensitive behaviour is deterministic (virtual clock).
- New scenarios are one `add("label", step)` call.

## Components

| Module                        | Purpose                                                    |
|-------------------------------|------------------------------------------------------------|
| `sim/clock.py`                | `VirtualClock`: controllable `now_s()`, ordered timers     |
| `sim/snapshot.py`             | `take_snapshot(sim, subject, label)` → structured state    |
| `sim/render.py`               | SVG renderer + HTML timeline index                         |
| `sim/scenario.py`             | `Scenario` DSL + `run_scenario()` runner                   |
| `sim/builtin_scenarios.py`    | Five prebuilt scenarios + registry                         |
| `decentnet.cli sim`           | CLI wrappers: `sim list`, `sim run <name> [-o DIR]`        |

## Virtual clock

```python
from decentnet.sim import VirtualClock

clock = VirtualClock(start=1_700_000_000)
with clock.install():
    # now_s() returns the virtual time; every TTL, GC, and issued_at
    # in the code base uses this.
    clock.advance(3600)
    clock.after(300, lambda: print("5 min later"))
    clock.advance(600)
```

Semantics:
- `advance(seconds)` moves the clock forward, firing any registered
  timers in chronological order before advancing past their fire-time.
- Timers installed by `.after(delay, cb)` are single-shot. A repeating
  tick re-registers itself at the end of its callback (the pattern
  `Node.enable_republish` uses).
- `install()` is a context manager; leaving the block restores the
  real system clock.
- The virtual clock only affects `utils.time.now_s`. Monotonic timing
  (`monotonic_ms`, used by `RateLimiter`) stays on the real clock
  because rate-limit windows are real-time concerns.

## Snapshot format

`take_snapshot(sim, subject_peer_id, label)` produces a `Snapshot`
with one `NodeSnapshot` per node. The core label per node is
`record_state`, one of:

| State       | Meaning                                               |
|-------------|-------------------------------------------------------|
| `publisher` | This is the subject's own node                        |
| `fresh`     | DHT store holds the subject's record; not stale       |
| `stale`     | Past soft TTL but not hard TTL                        |
| `expired`   | Past hard TTL (normally GC'd before snapshot)         |
| `corrupted` | Present in store but `verify()` fails                 |
| `missing`   | No record held                                        |

Other fields (online flag, partition group, routing table size, seq
number, endpoint) support the renderer and aren't normative.

## SVG rendering

The renderer is zero-dependency (no matplotlib, no d3, no fetch). It
emits a standalone `<svg>` with inline `<style>`, so each SVG opens
in any browser without extra files. Layout is a ring: nodes at equal
angles, subject's publisher at 12 o'clock with a blue ring.

Edges shown:

- Green edge from publisher to every node holding a `fresh` replica.
- Amber edge for `stale` holders.
- Red edge for `corrupted` holders.
- Offline nodes drawn with dashed outline + reduced opacity.
- Partition groups drawn as coloured halos (group 1 blue, 2 red,
  3 green, 4 amber).

## HTML timeline viewer

`render_index_html(snapshots, svg_filenames)` produces a single-file
viewer that loads each SVG into an iframe. Controls:

- ← / → arrow keys to step, or click the pills at the bottom.
- `prev` / `next` buttons.
- Label and notes update per frame.

No JS frameworks, no external assets, works offline.

## Scenario DSL

```python
sc = Scenario(
    name="my_scenario",
    description="What this demonstrates.",
    n_nodes=6,
    k=4,
)

def setup(ctx):
    ctx.note("optional setup note for the initial snapshot")

sc.setup = setup

sc.add("01 publisher publishes",
       lambda ctx: (ctx.sim.publish(ctx.sim[0],
                                    [Endpoint(type="public_udp",
                                              address="1.1.1.1:1")])
                    and "v1 pushed to k-closest replicas"))
```

Every `step` gets a `ScenarioContext` exposing the live `SimNetwork`
and `VirtualClock`, and may return a string note that gets attached
to the snapshot taken after that step. Steps can also call
`ctx.note(...)` or, for manual control, `ctx.checkpoint("mid-step")`
to take extra snapshots.

Register a new scenario in `builtin_scenarios.REGISTRY` to expose it
to the CLI.

## CLI

```bash
# list available scenarios
python -m decentnet sim list

# run one with visual artifacts
python -m decentnet sim run partition_then_merge --output /tmp/out

# open /tmp/out/index.html in any browser
```

Without `--output`, the scenario runs in memory and prints the
structured snapshot stream as JSON to stdout — useful for piping into
other analysis tools.

## What Phase 3 intentionally *doesn't* do

**Message-delay modelling.** The in-process transport still delivers
synchronously. This keeps scenarios deterministic and debuggable.
Realistic delay/loss comes with Phase 4's UDP transport, where it's
not optional.

**Live animation.** Each frame is a snapshot taken at a logical
checkpoint, not frames sampled at fixed wall-clock rate. For
"animating" gossip propagation, add more checkpoints inside the step
that drives it.

**Merkle/Bloom digest summaries.** Anti-entropy still ships the full
summary list. It's fine for the current scale; the test suite is the
correctness proof. The swap is planned but not needed to make Phase 3
useful.

**DHT reputation scoring.** A good simulator would let you seed
adversarial behaviour (replicas that refuse to answer, noisy
neighbours that spam digests). The base pieces are present
(`InProcessNetwork.set_offline`, per-source rate limits); what's
missing is a scenario DSL for injecting adversaries at checkpoints.
Good follow-up, not ready in Phase 3.

## Determinism notes

With `VirtualClock` installed, record TTL checks, GC, and `issued_at`
are all fully deterministic. The remaining nondeterminism source in
tests is Python's `dict` ordering of routing-table contacts (which
affects which replicas get picked first on ties), and `uuid.uuid4()`
for message IDs. Neither affects correctness — the DHT's quorum-merge
returns the same answer regardless — but if pixel-exact SVGs are ever
required, those are the two things to mock.
