# decentnet — NAT Discovery (Phase 5)

Phase 5 lets a node learn its **external UDP address** via STUN
(RFC 5389 / 8489) and publish that address as an endpoint candidate
in its `LocatorRecord`. Other peers can then reach it directly across
the public internet without any relay, as long as the NAT in front
of the node behaves well.

This doc pairs with `DIRECTORY.md` (how peers find endpoints) and
`SIGNALING.md` (what they do once they've reached one). ICE-style
path selection and TURN/relay fallback come in Phase 6.

## Why STUN at all?

A node bound to `0.0.0.0:41234` on a laptop behind a home router
has no idea what the world sees as its address. The OS socket only
knows the **local** bind. To publish something useful into the DHT
we need the **externally observed** `(IP, port)` — which is what the
NAT maps our local address to when we send traffic out.

STUN is the simplest honest way to learn that. You send a single
request to a well-known STUN server; it replies with "I saw you
at `<ip>:<port>`". You put that in your record.

## Honest limits upfront

- **STUN servers are infrastructure.** There's no fully-serverless
  way to do this. The design choice is to make the infrastructure
  replaceable: any STUN server works (public, yours, your friend's).
  No authentication, no state, no privileged relationship.
- **The reported mapping is only useful if the NAT doesn't rewrite
  it per-destination.** "Cone-like" NATs keep the mapping stable;
  "symmetric" NATs rewrite it, so what the STUN server saw is not
  what your peer will see. We now distinguish these cases via full
  RFC 5780 classification (below).
- **Full RFC 5780 NAT behaviour discovery is implemented.** The
  codec handles CHANGE-REQUEST, RESPONSE-ORIGIN, OTHER-ADDRESS, and
  the legacy CHANGED-ADDRESS/SOURCE-ADDRESS attributes. The mock
  server is dual-socket and RFC-5780-compliant; the classifier runs
  the mapping test (§3) and filtering test (§4) and produces a
  precise `NATBehaviour { mapping, filtering, nat_type }`. The
  collapsed NAT type can be any of: `FULL_CONE`, `RESTRICTED_CONE`,
  `PORT_RESTRICTED_CONE`, `SYMMETRIC`, `OPEN_INTERNET`, `BLOCKED`,
  or `UNKNOWN`. Where the configured server doesn't advertise
  OTHER-ADDRESS we fall back to a heuristic labelling with
  `OPEN_INTERNET / CONE_LIKE / SYMMETRIC / UNKNOWN`.
- **No hole punching yet.** Knowing your public port doesn't by
  itself get inbound traffic to you through a NAT without prior
  outbound state. Phase 6's ICE layer sequences the hole-punch
  handshake; Phase Final extends reputation + scheduler support
  on top of that.

## Components

| Module                  | Role                                                       |
|-------------------------|------------------------------------------------------------|
| `nat/stun.py`           | STUN codec (Binding Request / Success, XOR-MAPPED-ADDRESS), + `MockSTUNServer` for tests |
| `nat/discovery.py`      | `NATDiscovery` — sends probes on the node's UDP socket, classifies |
| `transport/udp.py`      | Updated to demux STUN vs decentnet JSON via magic-cookie check; adds `send_raw()` and `set_stun_handler()` |
| `node/node.py`          | `enable_nat_discovery / refresh_external_address / classify_nat / publish_with_external_address` |

## STUN codec

Implemented:

- Binding Request (message type `0x0001`).
- Binding Success Response (message type `0x0101`).
- XOR-MAPPED-ADDRESS attribute (`0x0020`), IPv4 and IPv6.

Deliberately **not** implemented:

- MESSAGE-INTEGRITY, FINGERPRINT, USERNAME, REALM — not needed for
  unauthenticated address discovery.
- MAPPED-ADDRESS (legacy, pre-RFC 5389). Modern servers always send
  XOR-MAPPED-ADDRESS.
- TURN allocations — Phase 6.

The codec is ~140 lines. Every field used for mapping extraction is
covered by unit tests.

### Magic-cookie demux

STUN packets start with `0b00 ...` in the first two bits and carry
the magic cookie `0x2112A442` at bytes 4-7. JSON datagrams never
match both simultaneously, so the same UDP socket can carry both
without ambiguity:

```python
# in UDPTransport._read_loop:
if _stun.is_stun_packet(data):
    self._stun_handler(data, addr)        # -> NATDiscovery
    continue
# else try JSON-as-Message ...
```

## NATDiscovery

```python
from decentnet.nat import NATDiscovery
disc = NATDiscovery(udp_transport, [("stun.l.google.com", 19302)])
mapped = disc.discover(timeout_s=2.0)     # -> (host, port) or None
nat = disc.classify(timeout_s=2.0)        # -> NATType enum
```

### Classification heuristic

With one server:

- If the mapping equals our local `(bind_host, bind_port)` →
  `OPEN_INTERNET`.
- Otherwise → `UNKNOWN`. With only one observation we cannot
  distinguish cone from symmetric.

With two servers:

- If the mapping equals our bind → `OPEN_INTERNET`.
- If both servers see the *same* mapping → `CONE_LIKE`.
- If the external IP is the same but the port differs → `SYMMETRIC`.
- Otherwise → `UNKNOWN`.

`CONE_LIKE` is deliberately a broader label than RFC 3489's full/
restricted/port-restricted trio. We report what we can measure; we
don't guess what we can't.

## Node integration

```python
node = Node(cfg, network=net)

# UDP transport is required. If the node already runs over UDP for
# the DHT, pass `udp_transport=node._transport`. If it runs over
# InProcessTransport (test/sim), supply a separate UDPTransport
# whose lifecycle you own.
udp = UDPTransport(node.peer_id.value)
node.enable_nat_discovery(
    [("stun1.example.org", 3478), ("stun2.example.org", 3478)],
    udp_transport=udp,
)

# Probe once, classify, and publish.
node.classify_nat(timeout_s=2.0)
rec = node.publish_with_external_address(
    extra_endpoints=[Endpoint(type="lan_udp", address="192.168.1.42:41234")],
)
# rec now carries:
#   - a public_udp endpoint with discovered_by="stun"
#   - the LAN hint we supplied
# Other peers pull this record from the DHT and try the public
# endpoint first, falling back to the LAN hint on local networks.
```

## Audit events

| Kind                 | When                                          |
|----------------------|-----------------------------------------------|
| `nat.stun_mapping`   | Successful Binding Response                   |
| `nat.stun_timeout`   | No response within the timeout                |
| `nat.classify`       | `classify()` completed with a verdict         |
| `nat.classify_incomplete` | A probe in classification timed out       |

All structured, grep-friendly in `audit.jsonl`.

## Privacy note

Publishing your STUN-learned `(public_ip, public_port)` into a DHT
exposes the same information any server you've ever sent a UDP
packet to already has. It's public by definition: if another
internet host can reach you at that address, anyone observing
packets near either end can see it. This framework treats endpoint
records as **public**; sensitive metadata (room hashes, identities
of peers you want to talk to) are a separate concern handled at the
selective-disclosure layer (Phase 9).

## What comes next (Phase 6)

- **ICE-style candidate testing.** A peer publishing three endpoints
  (LAN, STUN-learned public, relay) should have its counterpart
  systematically probe each and pick the best one. Phase 6 defines
  candidate pairs, priorities, connectivity checks.
- **Hole punching.** Two cone-like NATs can be made to connect
  directly by coordinating outbound packets through the signaling
  layer. The prerequisite (both peers know their mapped addresses)
  is exactly what Phase 5 provides.
- **TURN / relay fallback.** Where even hole punching fails
  (symmetric NATs, enterprise firewalls), an optional cooperative
  relay. Minimized in scope so the relay never sees plaintext
  content — just signed signaling envelopes + encrypted media.

## Full RFC 5780 behaviour discovery

`NATDiscovery.classify_behaviour()` runs the full RFC 5780 FSM and
returns a `NATBehaviour` dataclass with two orthogonal axes plus a
collapsed label.

### Mapping behaviour (RFC 5780 §3)

How the NAT chooses the external port when the client sends to
different destinations:

| `MappingBehaviour` value            | Meaning                                                 |
|-------------------------------------|---------------------------------------------------------|
| `ENDPOINT_INDEPENDENT`              | Same external port for every destination (cone family) |
| `ADDRESS_DEPENDENT`                 | Same port per destination IP                            |
| `ADDRESS_AND_PORT_DEPENDENT`        | Per (dest IP, dest port) — the "symmetric" case         |

We drive this with three probes:
1. Test I: plain request to primary STUN.
2. Test II: request to the server's alt port, same IP.
3. Test III: request to the server's alt IP.

Each probe returns an XOR-MAPPED-ADDRESS; comparing the three tells
us which bucket applies.

### Filtering behaviour (RFC 5780 §4)

Which inbound packets the NAT permits back through an established
mapping:

| `FilteringBehaviour` value          | Meaning                                                 |
|-------------------------------------|---------------------------------------------------------|
| `ENDPOINT_INDEPENDENT`              | Any source can hit the mapped port (full cone)          |
| `ADDRESS_DEPENDENT`                 | Only hosts we've sent to (restricted cone)              |
| `ADDRESS_AND_PORT_DEPENDENT`        | Only (host, port) pairs we've sent to (port-restricted) |

Two probes with CHANGE-REQUEST:
1. Test F1: change_ip + change_port — server replies from the
   alternate IP and port. If the reply arrives, the filter is
   endpoint-independent.
2. Test F2: change_port only — server replies from same IP, alt
   port. If that arrives (but F1 didn't) the filter is
   address-dependent.
3. Otherwise (neither arrives): address-and-port-dependent.

### Collapsed `NATType`

`classify_behaviour()` also fills in a single-word label:

- `OPEN_INTERNET` — no NAT (mapped == local bind).
- `FULL_CONE` — endpoint-independent mapping + endpoint-independent filtering.
- `RESTRICTED_CONE` — endpoint-independent mapping + address-dependent filtering.
- `PORT_RESTRICTED_CONE` — endpoint-independent mapping + address-and-port-dependent filtering.
- `SYMMETRIC` — address(+port)-dependent mapping (any filtering).
- `BLOCKED` — test I timed out; UDP is blocked.
- `CONE_LIKE` / `UNKNOWN` — produced only by the heuristic fallback
  when the server doesn't implement RFC 5780 (no OTHER-ADDRESS).

### The dual-socket mock server

`MockSTUNServer(rfc5780=True)` binds two UDP sockets (loopback + a
second port), reports each as the OTHER-ADDRESS of the other, and
faithfully honours CHANGE-REQUEST by sending the response from the
alternate socket. Tests toggle `drop_change_ip` / `drop_change_port`
to simulate NATs that block those paths.

### The in-memory NAT simulator

`decentnet/nat/simnat.py` provides `SimulatedNAT`, a userspace UDP
bridge that applies configurable `SimMapping` × `SimFiltering`
rules. Tests use it to exercise every limb of the classifier FSM
end-to-end on loopback without needing kernel iptables.
