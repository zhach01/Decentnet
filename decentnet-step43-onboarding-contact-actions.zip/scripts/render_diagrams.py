"""Generate decentnet's architecture diagrams.

Run:
    python -m scripts.render_diagrams

Writes SVGs into `docs/diagrams/`. Pure stdlib — no matplotlib.
"""
from __future__ import annotations

import sys
from pathlib import Path


_REPO = Path(__file__).resolve().parent.parent
OUTPUT = _REPO / "docs" / "diagrams"
OUTPUT.mkdir(parents=True, exist_ok=True)


def _box(x, y, w, h, label, *, fill="#f0f4fa", stroke="#5680b0", fontsize=12, lines=None):
    lines_txt = ""
    if lines is None:
        # Center single-line label.
        lines_txt = (
            f'<text x="{x + w / 2}" y="{y + h / 2 + 4}" '
            f'text-anchor="middle" font-family="monospace" '
            f'font-size="{fontsize}" fill="#222">{label}</text>'
        )
    else:
        line_h = fontsize + 3
        start_y = y + h / 2 - (len(lines) - 1) * line_h / 2 + 4
        for i, line in enumerate(lines):
            lines_txt += (
                f'<text x="{x + w / 2}" y="{start_y + i * line_h}" '
                f'text-anchor="middle" font-family="monospace" '
                f'font-size="{fontsize}" fill="#222">{line}</text>'
            )
    return (
        f'<rect x="{x}" y="{y}" width="{w}" height="{h}" '
        f'fill="{fill}" stroke="{stroke}" stroke-width="2" rx="6"/>'
        f'{lines_txt}'
    )


def _arrow(x1, y1, x2, y2, label="", *, color="#333"):
    marker = (
        f'<defs><marker id="arrow-{color[1:]}" '
        'markerWidth="8" markerHeight="8" refX="7" refY="4" '
        'orient="auto" markerUnits="strokeWidth">'
        f'<path d="M0,0 L8,4 L0,8 z" fill="{color}"/>'
        '</marker></defs>'
    )
    line = (
        f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" '
        f'stroke="{color}" stroke-width="1.5" '
        f'marker-end="url(#arrow-{color[1:]})"/>'
    )
    txt = ""
    if label:
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2 - 4
        txt = (
            f'<text x="{mx}" y="{my}" text-anchor="middle" '
            f'font-family="sans-serif" font-size="11" fill="#555">{label}</text>'
        )
    return marker + line + txt


# ----- Diagram 1: layered architecture ------------------------------

def diagram_layered() -> str:
    width, height = 840, 660
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" '
        f'height="{height}" viewBox="0 0 {width} {height}">',
        f'<rect width="{width}" height="{height}" fill="#ffffff"/>',
        f'<text x="{width / 2}" y="30" text-anchor="middle" '
        f'font-family="sans-serif" font-size="18" font-weight="bold" '
        f'fill="#222">decentnet — layer stack</text>',
    ]
    # Layers from bottom to top.
    layers = [
        ("Transport",
         "InProcessTransport · UDPTransport (thread-driven) · STUN demux · send_raw",
         "#fce9d5", "#c37a3a"),
        ("Identity",
         "Ed25519 keypair · PeerId = b32(sha256(pub)) · RotationReceipt + RotationLedger · encrypted keystore (scrypt+AES-GCM)",
         "#e8e3f3", "#6e5ba4"),
        ("Records",
         "LocatorRecord (signed) · EncryptedEnvelope (X25519+ChaCha20-Poly1305 selective disclosure) · validate_for_storage",
         "#dff0e2", "#3c8c57"),
        ("Cache (L1/L2/L3)",
         "LocalCache (popularity evict) · ConfidenceTracker (multi-source) · DeferredWriteBuffer · DHTStore (topic-filtered)",
         "#e0edf7", "#3b6d9e"),
        ("Directory (DHT)",
         "RoutingTable (Kademlia) · DHTEngine (iterative find_node/value/store) · ReputationTracker · quorum reads",
         "#e2e9fb", "#4653b3"),
        ("Repair",
         "AntiEntropy (summary + Bloom digest) · MerkleBucketSummary · GlobalSnapshot + reconstruction",
         "#edf6fa", "#3f87a6"),
        ("Signaling",
         "hello/hello_ack/ring/bye/keepalive · session FSM · replay window · NegativeCache · pass-through offer/answer/candidate",
         "#fff4d0", "#b68b19"),
        ("NAT + ICE + Relay",
         "STUN codec · NATDiscovery · IceCandidate + pair priority · ICEAgent probing · cooperative RelayServer (signed tokens)",
         "#f8e0e8", "#a8356b"),
        ("Node + CLI + Daemon + Simulator",
         "Node facade · CLI (25+ subcommands) · Daemon (UNIX control socket) · SimNetwork + scenarios + adversary injection",
         "#eaeaea", "#555"),
    ]
    top = 60
    row_h = 62
    pad_y = 10
    for i, (title, body, fill, stroke) in enumerate(layers):
        y = top + i * (row_h + pad_y)
        parts.append(_box(
            40, y, width - 80, row_h,
            label="",
            fill=fill, stroke=stroke,
            lines=[title + "  —  " + body.split("·")[0].strip(),
                   "·".join(body.split("·")[1:]).strip(" ·")],
            fontsize=11,
        ))
    parts.append("</svg>")
    return "\n".join(parts)


# ----- Diagram 2: DHT topology (Kademlia ring illustration) ----------

def diagram_dht_topology() -> str:
    import math
    width, height = 640, 640
    cx, cy, r = width / 2, height / 2, 220
    n_peers = 12
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" '
        f'height="{height}" viewBox="0 0 {width} {height}">',
        f'<rect width="{width}" height="{height}" fill="#ffffff"/>',
        f'<text x="{width / 2}" y="30" text-anchor="middle" '
        f'font-family="sans-serif" font-size="17" font-weight="bold" '
        f'fill="#222">DHT topology: key K stored on k-closest by XOR</text>',
        f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="none" '
        'stroke="#bbb" stroke-dasharray="3,3"/>',
    ]
    # Peers around the ring.
    positions = []
    for i in range(n_peers):
        ang = -math.pi / 2 + i * (2 * math.pi / n_peers)
        px, py = cx + r * math.cos(ang), cy + r * math.sin(ang)
        positions.append((px, py, ang))
        # Colour the k-closest to the target key.
        color = "#e8e8f5"
        stroke = "#888"
        label = f"peer{i:02}"
        if 5 <= i <= 7:
            color = "#f5e0e0"
            stroke = "#b35555"
        parts.append(
            f'<circle cx="{px}" cy="{py}" r="22" fill="{color}" '
            f'stroke="{stroke}" stroke-width="2"/>'
            f'<text x="{px}" y="{py + 4}" text-anchor="middle" '
            f'font-family="monospace" font-size="10" fill="#222">{label}</text>'
        )
    # Target key marker.
    i_key = 6
    kx, ky, _ = positions[i_key]
    parts.append(
        f'<circle cx="{kx}" cy="{ky - 50}" r="14" fill="#ffd14a" '
        'stroke="#9a6b00" stroke-width="2"/>'
        f'<text x="{kx}" y="{ky - 46}" text-anchor="middle" '
        'font-family="monospace" font-size="11" font-weight="bold" '
        'fill="#222">K</text>'
    )
    # k-closest brackets.
    for j in (5, 6, 7):
        px, py, _ = positions[j]
        parts.append(
            f'<line x1="{kx}" y1="{ky - 36}" x2="{px}" y2="{py - 22}" '
            'stroke="#c48a1f" stroke-width="1.5" stroke-dasharray="4,3"/>'
        )
    parts.append(
        f'<text x="{cx}" y="{cy + r + 55}" text-anchor="middle" '
        f'font-family="sans-serif" font-size="12" fill="#444">'
        f'Record for key K replicated on 3 peers with smallest XOR(peer_id, K)</text>'
    )
    parts.append(
        f'<text x="{cx}" y="{cy + r + 80}" text-anchor="middle" '
        f'font-family="sans-serif" font-size="11" fill="#666">'
        f'Anti-entropy (Bloom/Merkle digest) keeps the triad in sync.</text>'
    )
    parts.append("</svg>")
    return "\n".join(parts)


# ----- Diagram 3: session + path selection ------------------------

def diagram_session_path() -> str:
    width, height = 820, 540
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" '
        f'height="{height}" viewBox="0 0 {width} {height}">',
        f'<rect width="{width}" height="{height}" fill="#ffffff"/>',
        f'<text x="{width / 2}" y="30" text-anchor="middle" '
        f'font-family="sans-serif" font-size="17" font-weight="bold" '
        f'fill="#222">From resolve to in-call: data flow</text>',
    ]
    # Two peers.
    parts.append(_box(40, 70, 180, 60, "Peer A", fill="#e8f0fb", stroke="#3b6d9e"))
    parts.append(_box(600, 70, 180, 60, "Peer B", fill="#e8f0fb", stroke="#3b6d9e"))

    # DHT cloud.
    parts.append(
        '<ellipse cx="410" cy="105" rx="150" ry="40" '
        'fill="#f7f5e8" stroke="#b79c4a" stroke-width="2"/>'
        '<text x="410" y="110" text-anchor="middle" '
        'font-family="monospace" font-size="12" fill="#333">DHT directory</text>'
    )
    parts.append(_arrow(220, 100, 265, 100, "resolve(B)"))
    parts.append(_arrow(555, 100, 600, 100, "LocatorRecord"))

    # STUN servers.
    parts.append(_box(110, 185, 130, 40, "STUN A", fill="#f2e9dd", stroke="#b3893b", fontsize=11))
    parts.append(_box(580, 185, 130, 40, "STUN B", fill="#f2e9dd", stroke="#b3893b", fontsize=11))
    parts.append(_arrow(130, 130, 145, 185, "Binding"))
    parts.append(_arrow(670, 130, 655, 185, "Binding"))

    # ICE candidate negotiation.
    parts.append(_box(40, 270, 180, 70, "ICE candidates", fill="#eaf0e5", stroke="#5b8a3a",
                      lines=["host / srflx", "relay"]))
    parts.append(_box(600, 270, 180, 70, "ICE candidates", fill="#eaf0e5", stroke="#5b8a3a",
                      lines=["host / srflx", "relay"]))
    parts.append(_arrow(130, 130, 130, 270))
    parts.append(_arrow(690, 130, 690, 270))

    # Connectivity checks.
    parts.append(_arrow(220, 305, 600, 305, "signed sig.conn_check / ack pairs"))

    # Relay fallback.
    parts.append(_box(325, 420, 170, 50, "Cooperative relay",
                      fill="#f8e0e8", stroke="#a8356b"))
    parts.append(_arrow(130, 340, 340, 420, "allocate(token)", color="#a8356b"))
    parts.append(_arrow(690, 340, 480, 420, "allocate(token)", color="#a8356b"))
    parts.append(_arrow(410, 420, 410, 365, "forward", color="#a8356b"))

    parts.append(
        f'<text x="{width / 2}" y="510" text-anchor="middle" '
        'font-family="sans-serif" font-size="11" fill="#555">'
        'Relay path is last-resort; plaintext never visible to DHT or relay.'
        '</text>'
    )
    parts.append("</svg>")
    return "\n".join(parts)


def main() -> None:
    diagrams = {
        "01-layered.svg": diagram_layered(),
        "02-dht-topology.svg": diagram_dht_topology(),
        "03-session-path.svg": diagram_session_path(),
    }
    for name, svg in diagrams.items():
        (OUTPUT / name).write_text(svg)
        print(f"wrote {OUTPUT / name}")


if __name__ == "__main__":
    main()
