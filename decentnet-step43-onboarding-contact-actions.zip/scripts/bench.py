"""Simple benchmark harness.

Run:
    python scripts/bench.py           # run default benchmarks
    python scripts/bench.py --dht     # DHT throughput only
    python scripts/bench.py --crypto  # crypto primitives only
    python scripts/bench.py --out bench.json

The benchmarks here are intended for development iteration. They
are not scientific microbenchmarks — absolute numbers depend on
your machine. Trends and order-of-magnitude comparisons are
meaningful; single-digit-percent comparisons are not.
"""
from __future__ import annotations

import argparse
import json
import statistics
import sys
import tempfile
import time
from pathlib import Path
from typing import Callable


_REPO = Path(__file__).resolve().parent.parent
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))


def bench(fn: Callable[[], None], *, name: str, iterations: int = 500) -> dict:
    """Run `fn` `iterations` times, collect per-call latency statistics."""
    # Warm-up.
    for _ in range(min(10, iterations // 10)):
        fn()
    samples_ns = []
    for _ in range(iterations):
        t0 = time.perf_counter_ns()
        fn()
        samples_ns.append(time.perf_counter_ns() - t0)
    samples_ns.sort()
    return {
        "name": name,
        "iterations": iterations,
        "p50_us": samples_ns[len(samples_ns) // 2] / 1000,
        "p90_us": samples_ns[int(len(samples_ns) * 0.9)] / 1000,
        "p99_us": samples_ns[int(len(samples_ns) * 0.99)] / 1000,
        "min_us": samples_ns[0] / 1000,
        "max_us": samples_ns[-1] / 1000,
        "mean_us": statistics.mean(samples_ns) / 1000,
    }


# --------------- crypto primitives ---------------


def bench_ed25519_sign():
    from decentnet.identity.keypair import Keypair
    kp = Keypair.generate()
    msg = b"hello world" * 10
    return bench(
        lambda: kp.sign(msg),
        name="ed25519_sign",
    )


def bench_ed25519_verify():
    from decentnet.identity.keypair import Keypair, verify_with_public_key
    kp = Keypair.generate()
    msg = b"hello world" * 10
    sig = kp.sign(msg)
    return bench(
        lambda: verify_with_public_key(kp.public_key_bytes, msg, sig),
        name="ed25519_verify",
    )


def bench_record_sign_and_serialize():
    from decentnet.identity.keypair import Keypair
    from decentnet.records.endpoints import Endpoint
    from decentnet.records.locator import LocatorRecord
    kp = Keypair.generate()
    eps = [Endpoint(type="public_udp", address=f"1.2.3.{i}:1000") for i in range(4)]
    def _do():
        rec = LocatorRecord.build_and_sign(kp, eps, seq=1)
        rec.to_wire_bytes()
    return bench(_do, name="record_build_and_serialize")


def bench_record_parse_and_verify():
    from decentnet.identity.keypair import Keypair
    from decentnet.records.endpoints import Endpoint
    from decentnet.records.locator import LocatorRecord
    kp = Keypair.generate()
    eps = [Endpoint(type="public_udp", address=f"1.2.3.{i}:1000") for i in range(4)]
    rec = LocatorRecord.build_and_sign(kp, eps, seq=1)
    wire = rec.to_wire_bytes()
    def _do():
        LocatorRecord.from_wire_bytes(wire).verify()
    return bench(_do, name="record_parse_and_verify")


def bench_encrypted_envelope_build():
    from decentnet.identity.keypair import Keypair
    from decentnet.identity.peer_id import PeerId
    from decentnet.records.disclosure import encrypt_endpoints_for
    from decentnet.records.endpoints import Endpoint
    pub = Keypair.generate()
    pub_pid = PeerId.from_public_key(pub.public_key_bytes).value
    recip = Keypair.generate()
    eps = [Endpoint(type="public_udp", address="5.5.5.5:1")]
    return bench(
        lambda: encrypt_endpoints_for(pub_pid, recip.public_key_bytes, eps),
        name="encrypted_envelope_build",
    )


# --------------- wire codecs ---------------


def bench_cbor_encode():
    from decentnet.utils.cbor import canonical_cbor
    body = {"peer": "abcdefghij" * 5, "seq": 1234, "endpoints": [
        {"addr": f"1.2.3.{i}:1000"} for i in range(4)
    ]}
    return bench(lambda: canonical_cbor(body), name="cbor_encode")


def bench_json_encode():
    import json as _json
    body = {"peer": "abcdefghij" * 5, "seq": 1234, "endpoints": [
        {"addr": f"1.2.3.{i}:1000"} for i in range(4)
    ]}
    return bench(lambda: _json.dumps(body, sort_keys=True), name="json_encode")


def bench_stun_encode_decode():
    from decentnet.nat.stun import (
        build_binding_request,
        build_binding_success_response,
        parse_stun_message,
    )
    def _do():
        _, tid = build_binding_request()
        data = build_binding_success_response(tid, ("1.2.3.4", 41234))
        parse_stun_message(data)
    return bench(_do, name="stun_roundtrip")


# --------------- DHT scale ---------------


def bench_dht_publish_resolve_100_nodes():
    from decentnet.node import Node, NodeConfig
    from decentnet.records.endpoints import Endpoint
    from decentnet.transport.inproc import InProcessNetwork
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        net = InProcessNetwork()
        nodes = []
        for i in range(100):
            nodes.append(Node(NodeConfig.at(root / f"n{i}"), network=net))
        try:
            # Ring-topology bootstrap.
            for i, n in enumerate(nodes):
                nbrs = [nodes[(i + 1) % 100], nodes[(i + 5) % 100]]
                n.join_network([(p.peer_id.value, "") for p in nbrs])
            # Publish a single record.
            publisher = nodes[0]
            publisher.publish_own_record(
                endpoints=[Endpoint(type="public_udp", address="9.9.9.9:1")]
            )
            publisher.publish_to_network()
            # Benchmark: resolve from 10 random far-side nodes.
            sample_nodes = [nodes[i] for i in range(10, 100, 10)]
            t0 = time.perf_counter_ns()
            for n in sample_nodes:
                n.resolve(publisher.peer_id.value, force_network=True)
            total_ns = time.perf_counter_ns() - t0
            per_lookup_us = total_ns / len(sample_nodes) / 1000
            return {
                "name": "dht_resolve_100_node_network",
                "iterations": len(sample_nodes),
                "per_lookup_us": per_lookup_us,
            }
        finally:
            for n in nodes:
                n.close()


def bench_memory_growth_under_pubload():
    """Publish 1000 records into a single node; report final cache bytes."""
    import resource
    from decentnet.node import Node, NodeConfig
    from decentnet.records.endpoints import Endpoint
    with tempfile.TemporaryDirectory() as td:
        node = Node(NodeConfig.at(td))
        try:
            rss_before = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            for i in range(1000):
                from decentnet.identity.keypair import Keypair
                from decentnet.records.locator import LocatorRecord
                kp = Keypair.generate()
                rec = LocatorRecord.build_and_sign(
                    kp,
                    [Endpoint(
                        type="public_udp", address=f"10.0.0.{i % 256}:{i}"
                    )],
                    seq=1,
                )
                node.cache.put(rec, source="bench")
            rss_after = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            return {
                "name": "memory_growth_1000_records",
                "iterations": 1000,
                "rss_delta_kb": rss_after - rss_before,
            }
        finally:
            node.close()


# --------------- runners ---------------


ALL_BENCHMARKS = [
    ("crypto", bench_ed25519_sign),
    ("crypto", bench_ed25519_verify),
    ("crypto", bench_record_sign_and_serialize),
    ("crypto", bench_record_parse_and_verify),
    ("crypto", bench_encrypted_envelope_build),
    ("wire",   bench_cbor_encode),
    ("wire",   bench_json_encode),
    ("wire",   bench_stun_encode_decode),
    ("dht",    bench_dht_publish_resolve_100_nodes),
    ("mem",    bench_memory_growth_under_pubload),
]


def main():
    parser = argparse.ArgumentParser(description="decentnet benchmarks")
    parser.add_argument("--crypto", action="store_true")
    parser.add_argument("--wire", action="store_true")
    parser.add_argument("--dht", action="store_true")
    parser.add_argument("--mem", action="store_true")
    parser.add_argument("--out", default=None, help="Write JSON to this file")
    args = parser.parse_args()
    selected = [args.crypto, args.wire, args.dht, args.mem]
    if any(selected):
        wanted = set()
        if args.crypto: wanted.add("crypto")
        if args.wire:   wanted.add("wire")
        if args.dht:    wanted.add("dht")
        if args.mem:    wanted.add("mem")
    else:
        wanted = {"crypto", "wire", "dht", "mem"}

    results = []
    for category, fn in ALL_BENCHMARKS:
        if category not in wanted:
            continue
        print(f"running {fn.__name__} ...", flush=True)
        r = fn()
        results.append(r)
        _print_result(r)
    if args.out:
        Path(args.out).write_text(json.dumps(results, indent=2))
        print(f"wrote {args.out}")


def _print_result(r: dict) -> None:
    name = r["name"]
    if "p50_us" in r:
        print(f"  {name:42s}  p50={r['p50_us']:.1f}µs  "
              f"p90={r['p90_us']:.1f}µs  p99={r['p99_us']:.1f}µs  "
              f"(n={r['iterations']})")
    elif "per_lookup_us" in r:
        print(f"  {name:42s}  avg={r['per_lookup_us']:.0f}µs "
              f"(n={r['iterations']})")
    elif "rss_delta_kb" in r:
        print(f"  {name:42s}  rss_delta={r['rss_delta_kb']} KB "
              f"(n={r['iterations']})")


if __name__ == "__main__":
    main()
