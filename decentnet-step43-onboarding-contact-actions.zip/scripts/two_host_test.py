#!/usr/bin/env python3
"""Two-host real-network harness for DecentNet.

This script is designed for operator use across two real machines/VMs.
It standardises:
- the exported bootstrap bundle format
- machine-readable per-host summaries
- a merged pass/fail report

Workflow
--------
Host A:
    python scripts/two_host_test.py host-a \
        --root /tmp/decentnet-a \
        --udp-port 41234 \
        --public-address 198.51.100.10:41234 \
        --bundle-out /tmp/decentnet-a.bundle.json \
        --summary-out /tmp/decentnet-a.summary.json \
        --duration 120

Copy A's bundle to host B.

Host B:
    python scripts/two_host_test.py host-b \
        --root /tmp/decentnet-b \
        --udp-port 41235 \
        --public-address 203.0.113.20:41235 \
        --peer-bundle /tmp/decentnet-a.bundle.json \
        --self-bundle-out /tmp/decentnet-b.bundle.json \
        --summary-out /tmp/decentnet-b.summary.json

Optional: copy B's bundle back to A for explicit seeding. Current DecentNet
can auto-bootstrap from HELLO/HELLO_ACK, so this reverse copy is no longer
required for the first handshake.

Merged report:
    python scripts/two_host_test.py report \
        --host-a-summary /tmp/decentnet-a.summary.json \
        --host-b-summary /tmp/decentnet-b.summary.json \
        --out /tmp/decentnet-report.json
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
import tarfile
import os
from collections import Counter
from pathlib import Path
from typing import Any, Optional

_REPO = Path(__file__).resolve().parent.parent
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from decentnet.node import Node, NodeConfig
from decentnet.records.endpoints import Endpoint
from decentnet.signaling.engine import SignalingEngine
from decentnet.transport.udp import UDPTransport


def _json_default(obj: Any) -> Any:
    if isinstance(obj, Path):
        return str(obj)
    if isinstance(obj, bytes):
        return obj.decode("utf-8", errors="replace")
    if hasattr(obj, "to_dict"):
        try:
            return obj.to_dict()
        except Exception:
            pass
    if hasattr(obj, "__dict__"):
        try:
            return obj.__dict__
        except Exception:
            pass
    return str(obj)


def log(kind: str, **fields: Any) -> None:
    payload = {"ts": time.time(), "kind": kind, **fields}
    print(json.dumps(payload, sort_keys=True, default=_json_default), flush=True)


def log_audit(entry: dict[str, Any]) -> None:
    log(
        "audit",
        audit_kind=entry.get("kind"),
        **{k: v for k, v in entry.items() if k != "kind"},
    )


def write_json(path: str | Path, payload: dict[str, Any]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        json.dumps(payload, indent=2, sort_keys=True, default=_json_default),
        encoding="utf-8",
    )


def read_json(path: str | Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def parse_host_port(value: str) -> tuple[str, int]:
    host, sep, port_str = value.rpartition(":")
    if not sep or not host or not port_str:
        raise SystemExit(f"Invalid address {value!r}; expected HOST:PORT")
    try:
        return host, int(port_str)
    except ValueError as e:
        raise SystemExit(f"Invalid port in {value!r}") from e


class HarnessError(RuntimeError):
    pass


class HostRunner:
    def __init__(
        self,
        *,
        mode: str,
        repo: str | Path,
        python_bin: str,
        target: Optional[str] = None,
        ssh_bin: str = "ssh",
        scp_bin: str = "scp",
    ) -> None:
        self.mode = mode
        self.repo = str(repo)
        self.python_bin = python_bin
        self.target = target
        self.ssh_bin = ssh_bin
        self.scp_bin = scp_bin
        if self.mode == "ssh" and not self.target:
            raise HarnessError("ssh runner requires a --host-*-target value")

    def _shell_python(self, script_rel: str, args: list[str]) -> str:
        parts = [
            f"cd {shlex.quote(self.repo)}",
            "&&",
            shlex.quote(self.python_bin),
            shlex.quote(script_rel),
        ]
        parts.extend(shlex.quote(a) for a in args)
        return " ".join(parts)

    def build_invocation(self, script_rel: str, args: list[str]) -> list[str]:
        if self.mode == "local":
            return [self.python_bin, str(Path(self.repo) / script_rel), *args]
        return [self.ssh_bin, self.target, self._shell_python(script_rel, args)]

    def popen_python(self, script_rel: str, args: list[str], *, stdout=None, stderr=None):
        cmd = self.build_invocation(script_rel, args)
        return subprocess.Popen(cmd, cwd=self.repo if self.mode == "local" else None, stdout=stdout, stderr=stderr, text=True)

    def run_python(self, script_rel: str, args: list[str], *, capture_output: bool = True, timeout: Optional[float] = None):
        cmd = self.build_invocation(script_rel, args)
        return subprocess.run(cmd, cwd=self.repo if self.mode == "local" else None, capture_output=capture_output, text=True, timeout=timeout)

    def file_exists(self, path: str | Path) -> bool:
        if self.mode == "local":
            return Path(path).exists()
        r = subprocess.run([self.ssh_bin, self.target, f"test -f {shlex.quote(str(path))}"], capture_output=True, text=True)
        return r.returncode == 0

    def push_file(self, local_path: str | Path, remote_path: str | Path) -> None:
        if self.mode == "local":
            dst = Path(remote_path)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(local_path, dst)
            return
        subprocess.run([self.ssh_bin, self.target, f"mkdir -p {shlex.quote(str(Path(remote_path).parent))}"], check=True, capture_output=True, text=True)
        subprocess.run([self.scp_bin, str(local_path), f"{self.target}:{remote_path}"], check=True, capture_output=True, text=True)

    def fetch_file(self, remote_path: str | Path, local_path: str | Path) -> None:
        dst = Path(local_path)
        dst.parent.mkdir(parents=True, exist_ok=True)
        if self.mode == "local":
            shutil.copy2(remote_path, dst)
            return
        subprocess.run([self.scp_bin, f"{self.target}:{remote_path}", str(local_path)], check=True, capture_output=True, text=True)

    def build_shell_invocation(self, command: str) -> list[str]:
        if self.mode == "local":
            return ["bash", "-lc", f"cd {shlex.quote(self.repo)} && {command}"]
        return [self.ssh_bin, self.target, f"cd {shlex.quote(self.repo)} && {command}"]

    def run_shell(self, command: str, *, capture_output: bool = True, timeout: Optional[float] = None, check: bool = False):
        cmd = self.build_shell_invocation(command)
        return subprocess.run(cmd, capture_output=capture_output, text=True, timeout=timeout, check=check)

    def ensure_dir(self, path: str | Path) -> None:
        if self.mode == "local":
            Path(path).mkdir(parents=True, exist_ok=True)
            return
        subprocess.run([self.ssh_bin, self.target, f"mkdir -p {shlex.quote(str(path))}"], check=True, capture_output=True, text=True)

    def remove_file(self, path: str | Path) -> None:
        if self.mode == "local":
            try:
                Path(path).unlink()
            except FileNotFoundError:
                pass
            return
        subprocess.run([self.ssh_bin, self.target, f"rm -f {shlex.quote(str(path))}"], check=True, capture_output=True, text=True)

    def sync_repo_from(self, local_repo: str | Path) -> None:
        src = Path(local_repo)
        if self.mode == "local":
            dst = Path(self.repo)
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(
                src,
                dst,
                ignore=shutil.ignore_patterns('.git', '.pytest_cache', '__pycache__', '*.pyc', '*.pyo', '*.zip'),
                dirs_exist_ok=False,
            )
            return
        tmpdir = Path(tempfile.mkdtemp(prefix='decentnet-sync-'))
        tar_path = tmpdir / 'repo.tar.gz'
        with tarfile.open(tar_path, 'w:gz') as tf:
            tf.add(src, arcname=Path(self.repo).name, filter=_repo_tar_filter)
        remote_parent = str(Path(self.repo).parent)
        remote_tmp = f"/tmp/{Path(self.repo).name}.tar.gz"
        subprocess.run([self.scp_bin, str(tar_path), f"{self.target}:{remote_tmp}"], check=True, capture_output=True, text=True)
        subprocess.run([self.ssh_bin, self.target, f"mkdir -p {shlex.quote(remote_parent)} && rm -rf {shlex.quote(self.repo)} && tar -xzf {shlex.quote(remote_tmp)} -C {shlex.quote(remote_parent)} && rm -f {shlex.quote(remote_tmp)}"], check=True, capture_output=True, text=True)
        shutil.rmtree(tmpdir, ignore_errors=True)


def _repo_tar_filter(info: tarfile.TarInfo) -> Optional[tarfile.TarInfo]:
    parts = set(Path(info.name).parts)
    banned = {'.git', '.pytest_cache', '__pycache__'}
    if parts & banned:
        return None
    if info.name.endswith(('.pyc', '.pyo', '.zip')):
        return None
    return info


def build_node(root: str | Path, udp_port: int) -> tuple[Node, UDPTransport]:
    cfg = NodeConfig.at(root)
    cfg.ensure()
    node = Node(cfg)
    udp = UDPTransport(node.peer_id.value, bind_port=udp_port)
    node.signaling = SignalingEngine(
        local_peer_id=node.peer_id.value,
        keypair=node.keypair,
        transport=udp,
        local_cache=node.cache,
        audit=node.audit,
    )
    return node, udp


def publish_self(node: Node, public_address: str) -> dict[str, Any]:
    rec = node.publish_own_record(
        endpoints=[Endpoint(type="public_udp", address=public_address)]
    )
    return {
        "seq": rec.seq,
        "endpoints": [e.address for e in rec.endpoints],
    }


def make_bundle(node: Node, peer_addr: str, out_path: str | Path) -> dict[str, Any]:
    wire = node.export_own_record().decode("utf-8")
    return {
        "peer_id": node.peer_id.value,
        "peer_addr": peer_addr,
        "record_wire": wire,
        "record_path": str(out_path),
        "written_at": int(time.time()),
        "format": 2,
    }


def ingest_bundle(
    node: Node,
    udp: Optional[UDPTransport],
    bundle_path: str | Path,
    *,
    source: str,
) -> dict[str, Any]:
    bundle = read_json(bundle_path)
    record_wire = bundle.get("record_wire")
    if not isinstance(record_wire, str) or not record_wire:
        raise HarnessError(f"{bundle_path} does not contain a valid 'record_wire'")

    result = node.ingest_record_bytes(record_wire.encode("utf-8"), source=source)

    peer_id = bundle.get("peer_id")
    peer_addr = bundle.get("peer_addr")
    if udp is not None and isinstance(peer_id, str) and isinstance(peer_addr, str):
        try:
            host, port = parse_host_port(peer_addr)
            udp.register_endpoint(peer_id, host, port)
        except Exception:
            pass

    rec = node.cache.get(peer_id) if isinstance(peer_id, str) else None
    return {
        "accepted": getattr(result, "accepted", None),
        "reason": getattr(result, "reason", None),
        "peer_id": peer_id,
        "peer_addr": peer_addr,
        "resolved": rec is not None,
        "seq": getattr(rec, "seq", None) if rec is not None else None,
    }


def _collect_audit_entries(node: Node, limit: int = 200) -> list[dict[str, Any]]:
    return list(node.audit.tail(limit))


def _audit_counter(entries: list[dict[str, Any]]) -> dict[str, int]:
    return dict(Counter(entry.get("kind") for entry in entries if entry.get("kind")))


def collect_summary(
    node: Node,
    *,
    role: str,
    bundle_path: Optional[str | Path] = None,
    peer_id: Optional[str] = None,
    hello: Optional[dict[str, Any]] = None,
    ring: Optional[dict[str, Any]] = None,
    notes: Optional[list[str]] = None,
) -> dict[str, Any]:
    audits = _collect_audit_entries(node)
    counts = _audit_counter(audits)
    session = node.signaling.session(peer_id) if peer_id else None
    stats = node.signaling.stats() if hasattr(node.signaling, "stats") else {}
    summary = {
        "role": role,
        "peer_id": node.peer_id.value,
        "bundle_path": str(bundle_path) if bundle_path else None,
        "own_record_published": node.own_record() is not None,
        "audit_counts": counts,
        "notes": notes or [],
        "stats": stats,
        "peer": None,
        "hello": hello,
        "ring": ring,
        "ok": False,
    }
    if peer_id:
        summary["peer"] = {
            "peer_id": peer_id,
            "resolved": node.cache.get(peer_id) is not None,
            "session_state": session.state.value if session is not None else None,
            "selected_pair_kind": session.selected_pair_kind if session is not None else None,
            "selected_remote_addr": list(session.selected_remote_addr) if session is not None and session.selected_remote_addr is not None else None,
            "selected_nominated": session.selected_nominated if session is not None else None,
            "relay_selected": session.selected_pair_kind == "relay/relay" if session is not None else False,
        }

    if role == "host-a":
        saw_hello = counts.get("signal.hello_ack_sent", 0) > 0 or counts.get("signal.established", 0) > 0
        saw_ring = counts.get("signal.ring_ack_sent", 0) > 0 or counts.get("signal.in_call", 0) > 0
        summary["ok"] = bool(saw_hello and (saw_ring or ring is None))
        summary["observed"] = {
            "hello": saw_hello,
            "ring": saw_ring,
        }
    else:
        hello_ok = bool(hello and hello.get("ok"))
        ring_ok = bool(ring is None or ring.get("ok"))
        summary["ok"] = hello_ok and ring_ok

    return summary


def merge_summaries(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
    host_a_ok = bool(a.get("ok"))
    host_b_ok = bool(b.get("ok"))
    peer_a = a.get("peer") or {}
    peer_b = b.get("peer") or {}
    merged = {
        "kind": "two_host_report",
        "ok": host_a_ok and host_b_ok,
        "host_a_ok": host_a_ok,
        "host_b_ok": host_b_ok,
        "host_a": a,
        "host_b": b,
        "verdict": {
            "hello_completed": bool((b.get("hello") or {}).get("ok")) or bool((a.get("observed") or {}).get("hello")),
            "ring_completed": bool((b.get("ring") or {}).get("ok")) or bool((a.get("observed") or {}).get("ring")),
            "selected_pair_kind_a": peer_a.get("selected_pair_kind"),
            "selected_pair_kind_b": peer_b.get("selected_pair_kind"),
            "relay_used": bool(peer_a.get("relay_selected") or peer_b.get("relay_selected")),
        },
        "checked_at": int(time.time()),
    }
    if not merged["ok"]:
        reasons = []
        if not host_a_ok:
            reasons.append("host_a_summary_not_ok")
        if not host_b_ok:
            reasons.append("host_b_summary_not_ok")
        merged["reasons"] = reasons
    return merged


def run_host_a(args: argparse.Namespace) -> int:
    node = None
    udp = None
    summary: Optional[dict[str, Any]] = None
    try:
        node, udp = build_node(args.root, args.udp_port)
        public_address = args.public_address or f"127.0.0.1:{udp.bind_port}"

        log("host_a_started", peer_id=node.peer_id.value, udp_port=udp.bind_port)

        pub = publish_self(node, public_address)
        bundle_path = Path(args.bundle_out or (Path(args.root) / "published_record.json"))
        bundle = make_bundle(node, public_address, bundle_path)
        write_json(bundle_path, bundle)
        log("published", record_path=str(bundle_path), **pub)

        if args.peer_bundle_in:
            log("watching_peer_bundle", path=args.peer_bundle_in)
        log("waiting_for_hello", duration_s=args.duration)

        seen: set[tuple[Any, Any, Any]] = set()
        ingested_peer = False
        hello_seen = False
        ring_seen = False
        start = time.time()

        while time.time() - start < args.duration:
            time.sleep(0.5)

            if args.peer_bundle_in and not ingested_peer and Path(args.peer_bundle_in).exists():
                try:
                    info = ingest_bundle(node, udp, args.peer_bundle_in, source="bootstrap")
                    ingested_peer = bool(info.get("accepted"))
                    log("peer_bundle_ingested", **info)
                except Exception as e:
                    log("peer_bundle_ingest_failed", path=args.peer_bundle_in, error=str(e))

            for entry in node.audit.tail(100):
                marker = (entry.get("ts"), entry.get("kind"), entry.get("peer_id") or entry.get("sender") or entry.get("peer"))
                if marker in seen:
                    continue
                seen.add(marker)
                k = entry.get("kind")
                if k in ("signal.hello_ack_sent", "signal.established"):
                    hello_seen = True
                if k in ("signal.ring_ack_sent", "signal.in_call"):
                    ring_seen = True
                log_audit(entry)

            if args.stop_on_success and hello_seen and (ring_seen or not args.expect_ring):
                log("host_a_success_observed", hello=hello_seen, ring=ring_seen)
                break

        summary = collect_summary(
            node,
            role="host-a",
            bundle_path=bundle_path,
            ring=None if not args.expect_ring else {"ok": ring_seen},
        )
        if args.summary_out:
            write_json(args.summary_out, summary)
            log("summary_written", path=args.summary_out, ok=summary["ok"])
        return 0 if summary["ok"] else 2
    finally:
        if udp is not None:
            try:
                udp.close()
            except Exception as e:
                log("close_error", component="udp", error=str(e))
        if node is not None:
            try:
                node.close()
            except Exception as e:
                log("close_error", component="node", error=str(e))
        log("host_a_stopped", ok=summary.get("ok") if summary else None)


def run_host_b(args: argparse.Namespace) -> int:
    node = None
    udp = None
    summary: Optional[dict[str, Any]] = None
    try:
        if not args.peer_bundle:
            raise SystemExit("host-b requires --peer-bundle pointing to host A's bundle JSON")

        node, udp = build_node(args.root, args.udp_port)
        log("host_b_started", peer_id=node.peer_id.value, udp_port=udp.bind_port)

        public_address = args.public_address or f"127.0.0.1:{udp.bind_port}"
        pub = publish_self(node, public_address)
        self_bundle_path = Path(args.self_bundle_out or (Path(args.root) / "published_record.json"))
        self_bundle = make_bundle(node, public_address, self_bundle_path)
        write_json(self_bundle_path, self_bundle)
        log("self_published", record_path=str(self_bundle_path), **pub)

        info = ingest_bundle(node, udp, args.peer_bundle, source="bootstrap")
        log("peer_bundle_ingested", bundle_path=args.peer_bundle, **info)

        peer_id = info.get("peer_id")
        peer_addr = info.get("peer_addr")
        if not isinstance(peer_id, str) or not isinstance(peer_addr, str):
            raise HarnessError("peer bundle missing peer_id or peer_addr")

        host, port = parse_host_port(peer_addr)
        udp.register_endpoint(peer_id, host, port)
        log("peer_registered", peer_id=peer_id, addr=peer_addr)

        resolved = node.cache.get(peer_id)
        log(
            "peer_resolve_check",
            ok=resolved is not None,
            peer_id=peer_id,
            seq=getattr(resolved, "seq", None) if resolved is not None else None,
        )

        if args.hello_delay > 0:
            log("hello_delay", seconds=args.hello_delay)
            time.sleep(args.hello_delay)

        r = node.signaling.hello(peer_id, timeout_s=args.hello_timeout)
        hello = {"ok": r.ok, "reason": r.reason, "state": r.session_state}
        log("hello_result", **hello)

        ring = None
        if r.ok and args.send_ring:
            log("sending_ring")
            r2 = node.signaling.ring(peer_id, body={"msg": "hello from B"}, timeout_s=args.ring_timeout)
            ring = {"ok": r2.ok, "reason": r2.reason}
            log("ring_result", **ring)

        if args.send_keepalive:
            try:
                rk = node.signaling.keepalive(peer_id, timeout_s=args.keepalive_timeout)
                log("keepalive_result", ok=rk.ok, reason=rk.reason, state=rk.session_state)
            except Exception as e:
                log("keepalive_failed", error=str(e))

        time.sleep(args.audit_wait)
        for entry in node.audit.tail(100):
            log_audit(entry)

        summary = collect_summary(
            node,
            role="host-b",
            bundle_path=self_bundle_path,
            peer_id=peer_id,
            hello=hello,
            ring=ring,
        )
        if args.summary_out:
            write_json(args.summary_out, summary)
            log("summary_written", path=args.summary_out, ok=summary["ok"])
        return 0 if summary["ok"] else 2
    finally:
        if udp is not None:
            try:
                udp.close()
            except Exception as e:
                log("close_error", component="udp", error=str(e))
        if node is not None:
            try:
                node.close()
            except Exception as e:
                log("close_error", component="node", error=str(e))
        log("host_b_stopped", ok=summary.get("ok") if summary else None)




def run_orchestrate(args: argparse.Namespace) -> int:
    stage_dir = Path(args.stage_dir) if args.stage_dir else Path(tempfile.mkdtemp(prefix="decentnet-orch-"))
    stage_dir.mkdir(parents=True, exist_ok=True)

    host_a_bundle_remote = args.host_a_bundle_remote or str(Path(args.host_a_root) / "published_record.json")
    host_b_peer_bundle_remote = args.host_b_peer_bundle_remote or str(Path(args.host_b_root) / "peer_a.bundle.json")
    host_b_bundle_remote = args.host_b_bundle_remote or str(Path(args.host_b_root) / "published_record.json")
    host_a_summary_remote = args.host_a_summary_remote or str(Path(args.host_a_root) / "host_a.summary.json")
    host_b_summary_remote = args.host_b_summary_remote or str(Path(args.host_b_root) / "host_b.summary.json")

    a_runner = HostRunner(
        mode=args.host_a_runner,
        repo=args.host_a_repo or _REPO,
        python_bin=args.host_a_python,
        target=args.host_a_target,
        ssh_bin=args.ssh_bin,
        scp_bin=args.scp_bin,
    )
    b_runner = HostRunner(
        mode=args.host_b_runner,
        repo=args.host_b_repo or _REPO,
        python_bin=args.host_b_python,
        target=args.host_b_target,
        ssh_bin=args.ssh_bin,
        scp_bin=args.scp_bin,
    )

    local_a_bundle = stage_dir / "host_a.bundle.json"
    local_b_summary = Path(args.host_b_summary_local) if args.host_b_summary_local else stage_dir / "host_b.summary.json"
    local_a_summary = Path(args.host_a_summary_local) if args.host_a_summary_local else stage_dir / "host_a.summary.json"
    report_out = Path(args.report_out) if args.report_out else stage_dir / "report.json"
    a_log = Path(args.host_a_log_local) if args.host_a_log_local else stage_dir / "host_a.log"
    b_log = Path(args.host_b_log_local) if args.host_b_log_local else stage_dir / "host_b.log"

    a_args = [
        "host-a",
        "--root", str(args.host_a_root),
        "--udp-port", str(args.host_a_udp_port),
        "--public-address", args.host_a_public_address,
        "--bundle-out", str(host_a_bundle_remote),
        "--summary-out", str(host_a_summary_remote),
        "--duration", str(args.duration),
        "--stop-on-success",
    ]
    if args.send_ring:
        a_args.append("--expect-ring")
    if args.host_a_peer_bundle_in:
        a_args.extend(["--peer-bundle-in", str(args.host_a_peer_bundle_in)])

    b_args = [
        "host-b",
        "--root", str(args.host_b_root),
        "--udp-port", str(args.host_b_udp_port),
        "--public-address", args.host_b_public_address,
        "--peer-bundle", str(host_b_peer_bundle_remote),
        "--self-bundle-out", str(host_b_bundle_remote),
        "--summary-out", str(host_b_summary_remote),
        "--hello-delay", str(args.hello_delay),
        "--hello-timeout", str(args.hello_timeout),
        "--ring-timeout", str(args.ring_timeout),
        "--keepalive-timeout", str(args.keepalive_timeout),
        "--audit-wait", str(args.audit_wait),
    ]
    if args.send_ring:
        b_args.append("--send-ring")
    if args.send_keepalive:
        b_args.append("--send-keepalive")

    a_proc = None
    try:
        # Clear stale artifacts from prior runs. The orchestrator waits for host A's
        # bundle path to appear; if an old bundle is still present, a later campaign
        # can accidentally transfer stale endpoint data to host B.
        for runner, path in (
            (a_runner, host_a_bundle_remote),
            (a_runner, host_a_summary_remote),
            (b_runner, host_b_peer_bundle_remote),
            (b_runner, host_b_bundle_remote),
            (b_runner, host_b_summary_remote),
        ):
            runner.remove_file(path)

        with a_log.open("w", encoding="utf-8") as a_log_fh:
            a_proc = a_runner.popen_python("scripts/two_host_test.py", a_args, stdout=a_log_fh, stderr=subprocess.STDOUT)

        deadline = time.time() + args.bundle_wait_timeout
        while time.time() < deadline:
            if a_runner.file_exists(host_a_bundle_remote):
                break
            if a_proc.poll() is not None:
                raise HarnessError(f"host-a exited before bundle export; see {a_log}")
            time.sleep(0.1)
        else:
            raise HarnessError(f"timed out waiting for host-a bundle at {host_a_bundle_remote}")

        a_runner.fetch_file(host_a_bundle_remote, local_a_bundle)
        b_runner.push_file(local_a_bundle, host_b_peer_bundle_remote)
        log("orchestrate_bundle_transferred", from_host="a", to_host="b", local_copy=str(local_a_bundle))

        b_run = b_runner.run_python("scripts/two_host_test.py", b_args, timeout=args.duration + args.extra_wait_s)
        b_log.write_text((b_run.stdout or "") + ("\n" + b_run.stderr if b_run.stderr else ""), encoding="utf-8")
        if b_run.returncode != 0:
            raise HarnessError(f"host-b failed with exit code {b_run.returncode}; see {b_log}")

        b_runner.fetch_file(host_b_summary_remote, local_b_summary)
        summary_b = read_json(local_b_summary)

        if a_proc is not None:
            a_rc = a_proc.wait(timeout=args.duration + args.extra_wait_s)
            if a_rc != 0:
                raise HarnessError(f"host-a failed with exit code {a_rc}; see {a_log}")

        a_runner.fetch_file(host_a_summary_remote, local_a_summary)
        summary_a = read_json(local_a_summary)

        merged = merge_summaries(summary_a, summary_b)
        merged["kind"] = "two_host_orchestrated_report"
        merged["stage_dir"] = str(stage_dir)
        merged["host_a_log"] = str(a_log)
        merged["host_b_log"] = str(b_log)
        write_json(report_out, merged)
        print(json.dumps(merged, indent=2, sort_keys=True, default=_json_default))
        return 0 if merged["ok"] else 2
    finally:
        if a_proc is not None and a_proc.poll() is None:
            a_proc.terminate()
            try:
                a_proc.wait(timeout=5)
            except Exception:
                a_proc.kill()


def run_report(args: argparse.Namespace) -> int:
    a = read_json(args.host_a_summary)
    b = read_json(args.host_b_summary)
    merged = merge_summaries(a, b)
    if args.out:
        write_json(args.out, merged)
    print(json.dumps(merged, indent=2, sort_keys=True, default=_json_default))
    return 0 if merged["ok"] else 2


def _resolve_pack_roots(args: argparse.Namespace) -> list[Path]:
    roots = [Path(r) for r in (getattr(args, "watch_root", None) or [])]
    for d in (getattr(args, "roots_dir", None) or []):
        dp = Path(d)
        if dp.exists():
            roots.extend(sorted(p for p in dp.iterdir() if p.is_dir()))
    dedup: list[Path] = []
    seen = set()
    for r in roots:
        key = str(r.resolve()) if r.exists() else str(r)
        if key not in seen:
            dedup.append(r)
            seen.add(key)
    return dedup


def _resolve_input_files(paths: list[str] | None, dirs: list[str] | None) -> list[Path]:
    out: list[Path] = []
    seen = set()
    for raw in paths or []:
        p = Path(raw)
        if p.exists():
            key = str(p.resolve())
            if key not in seen:
                out.append(p)
                seen.add(key)
    for raw_dir in dirs or []:
        d = Path(raw_dir)
        if not d.exists():
            continue
        for p in sorted(d.iterdir()):
            if p.is_file() and p.suffix.lower() == '.json':
                key = str(p.resolve())
                if key not in seen:
                    out.append(p)
                    seen.add(key)
    return out


def _safe_name(name: str) -> str:
    return ''.join(ch if ch.isalnum() or ch in '._-' else '_' for ch in name)


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def _copy_into_pack(src: Path, out_root: Path, rel_dir: str, records: list[dict[str, Any]], *, category: str) -> Path:
    dst_dir = out_root / rel_dir
    dst_dir.mkdir(parents=True, exist_ok=True)
    base = _safe_name(src.name)
    dst = dst_dir / base
    if dst.exists():
        stem = dst.stem
        suffix = dst.suffix
        idx = 2
        while True:
            cand = dst_dir / f"{stem}-{idx}{suffix}"
            if not cand.exists():
                dst = cand
                break
            idx += 1
    shutil.copy2(src, dst)
    records.append({
        'category': category,
        'source_path': str(src),
        'bundle_path': str(dst.relative_to(out_root)),
        'size': dst.stat().st_size,
        'sha256': _sha256_file(dst),
    })
    return dst


def render_pack_index_html(manifest: dict[str, Any]) -> str:
    files = manifest.get('files', [])
    rows = []
    for item in files:
        rows.append(
            f"<tr><td>{item.get('category')}</td><td><code>{item.get('bundle_path')}</code></td>"
            f"<td>{item.get('size')}</td><td><code>{item.get('sha256')}</code></td></tr>"
        )
    rows_html = '\n'.join(rows)
    counts = manifest.get('counts', {})
    snap = manifest.get('snapshot', {})
    return f"""<!doctype html>
<html><head><meta charset='utf-8'><title>DecentNet operator bundle</title>
<style>body{{font-family:Arial,sans-serif;margin:24px}} table{{border-collapse:collapse;width:100%}} td,th{{border:1px solid #ccc;padding:6px 8px}} th{{background:#f5f5f5}} code{{font-size:12px}}</style>
</head><body>
<h1>DecentNet operator bundle</h1>
<ul>
<li>Generated at: {manifest.get('generated_at')}</li>
<li>Root count: {counts.get('roots')}</li>
<li>Operator reports: {counts.get('operator_reports')}</li>
<li>Soak/matrix reports: {counts.get('soak_reports')}</li>
<li>Log files: {counts.get('log_files')}</li>
<li>Extra files: {counts.get('extra_files')}</li>
<li>Total packaged files: {counts.get('files')}</li>
</ul>
<p>Snapshot JSON: <code>{snap.get('json')}</code><br>Snapshot HTML: <code>{snap.get('html')}</code></p>
<table>
<tr><th>Category</th><th>Bundle path</th><th>Size (bytes)</th><th>SHA-256</th></tr>
{rows_html}
</table>
</body></html>"""


def run_pack(args: argparse.Namespace) -> int:
    from decentnet.dashboard import export_dashboard_snapshot

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    roots = _resolve_pack_roots(args)
    operator_reports = _resolve_input_files((args.operator_report or []), (args.operator_report_dir or []))
    matrix_reports = _resolve_input_files((args.matrix_report or []), (args.matrix_dir or []))
    soak_reports = _resolve_input_files((args.soak_report or []), (args.soak_dir or []))
    combined_soak_reports: list[Path] = []
    seen_sr = set()
    for p in [*matrix_reports, *soak_reports]:
        key = str(p.resolve())
        if key not in seen_sr:
            combined_soak_reports.append(p)
            seen_sr.add(key)
    log_files = _resolve_input_files((args.log_file or []), [])
    extra_files = _resolve_input_files((args.extra_file or []), [])

    snapshot_json_name = args.snapshot_json_name or 'dashboard-snapshot.json'
    snapshot_html_name = args.snapshot_html_name or 'dashboard-snapshot.html'
    snapshot_json = out_dir / snapshot_json_name
    snapshot_html = out_dir / snapshot_html_name
    state = export_dashboard_snapshot(
        roots,
        audit_tail=args.audit_tail,
        event_limit=args.event_limit,
        soak_reports=combined_soak_reports,
        operator_reports=operator_reports,
        json_out=snapshot_json,
        html_out=snapshot_html,
    )

    records: list[dict[str, Any]] = []
    copied_roots = []
    for root in roots:
        copied_roots.append(str(root))
    for src in operator_reports:
        _copy_into_pack(src, out_dir, 'reports/operator', records, category='operator_report')
    for src in combined_soak_reports:
        _copy_into_pack(src, out_dir, 'reports/soak', records, category='soak_report')
    for src in log_files:
        _copy_into_pack(src, out_dir, 'logs', records, category='log')
    for src in extra_files:
        _copy_into_pack(src, out_dir, 'extra', records, category='extra')
    _copy_into_pack(snapshot_json, out_dir, '.', records, category='dashboard_snapshot_json')
    _copy_into_pack(snapshot_html, out_dir, '.', records, category='dashboard_snapshot_html')

    manifest = {
        'kind': 'decentnet_operator_bundle',
        'generated_at': int(time.time()),
        'out_dir': str(out_dir),
        'roots': copied_roots,
        'snapshot': {
            'json': snapshot_json.name,
            'html': snapshot_html.name,
            'global': state.get('global', {}),
            'operator': state.get('operator', {}),
        },
        'counts': {
            'roots': len(roots),
            'operator_reports': len(operator_reports),
            'soak_reports': len(combined_soak_reports),
            'log_files': len(log_files),
            'extra_files': len(extra_files),
            'files': len(records),
        },
        'files': records,
    }
    manifest_path = Path(args.manifest_out) if args.manifest_out else (out_dir / 'manifest.json')
    write_json(manifest_path, manifest)
    index_path = Path(args.index_html_out) if args.index_html_out else (out_dir / 'index.html')
    index_path.write_text(render_pack_index_html(manifest), encoding='utf-8')

    archive_out = Path(args.archive_out) if args.archive_out else out_dir.with_suffix('.zip')
    archive_out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive_out, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(out_dir.rglob('*')):
            if path.is_file():
                zf.write(path, path.relative_to(out_dir))
    result = {
        'kind': 'decentnet_operator_bundle_result',
        'ok': True,
        'out_dir': str(out_dir),
        'archive_out': str(archive_out),
        'manifest': str(manifest_path),
        'index_html': str(index_path),
        'snapshot_json': str(snapshot_json),
        'snapshot_html': str(snapshot_html),
        'counts': manifest['counts'],
    }
    print(json.dumps(result, indent=2, sort_keys=True, default=_json_default))
    return 0


def build_orchestrate_cli_args(args: argparse.Namespace, *, stage_dir: Path, report_out: Path,
                               host_a_root: str | Path, host_b_root: str | Path,
                               host_a_port: int, host_b_port: int,
                               host_a_public_address: str, host_b_public_address: str,
                               send_ring: bool, send_keepalive: bool) -> list[str]:
    cli = [
        sys.executable,
        str(Path(__file__).resolve()),
        "orchestrate",
        "--host-a-runner", args.host_a_runner,
        "--host-b-runner", args.host_b_runner,
        "--host-a-repo", str(args.host_a_repo or _REPO),
        "--host-b-repo", str(args.host_b_repo or _REPO),
        "--host-a-python", args.host_a_python,
        "--host-b-python", args.host_b_python,
        "--ssh-bin", args.ssh_bin,
        "--scp-bin", args.scp_bin,
        "--host-a-root", str(host_a_root),
        "--host-b-root", str(host_b_root),
        "--host-a-udp-port", str(host_a_port),
        "--host-b-udp-port", str(host_b_port),
        "--host-a-public-address", host_a_public_address,
        "--host-b-public-address", host_b_public_address,
        "--stage-dir", str(stage_dir),
        "--report-out", str(report_out),
        "--duration", str(args.duration),
        "--bundle-wait-timeout", str(args.bundle_wait_timeout),
        "--extra-wait-s", str(args.extra_wait_s),
        "--hello-delay", str(args.hello_delay),
        "--hello-timeout", str(args.hello_timeout),
        "--ring-timeout", str(args.ring_timeout),
        "--keepalive-timeout", str(args.keepalive_timeout),
        "--audit-wait", str(args.audit_wait),
    ]
    if args.host_a_target:
        cli.extend(["--host-a-target", args.host_a_target])
    if args.host_b_target:
        cli.extend(["--host-b-target", args.host_b_target])
    if args.host_a_bundle_remote:
        cli.extend(["--host-a-bundle-remote", args.host_a_bundle_remote])
    if args.host_b_peer_bundle_remote:
        cli.extend(["--host-b-peer-bundle-remote", args.host_b_peer_bundle_remote])
    if args.host_b_bundle_remote:
        cli.extend(["--host-b-bundle-remote", args.host_b_bundle_remote])
    if args.host_a_summary_remote:
        cli.extend(["--host-a-summary-remote", args.host_a_summary_remote])
    if args.host_b_summary_remote:
        cli.extend(["--host-b-summary-remote", args.host_b_summary_remote])
    if args.host_a_peer_bundle_in:
        cli.extend(["--host-a-peer-bundle-in", args.host_a_peer_bundle_in])
    if send_ring:
        cli.append("--send-ring")
    if send_keepalive:
        cli.append("--send-keepalive")
    return cli


def _scenario_flags(name: str) -> tuple[bool, bool]:
    if name == "direct":
        return False, False
    if name == "ring":
        return True, False
    if name == "full":
        return True, True
    raise HarnessError(f"unknown scenario {name!r}")


def render_matrix_html(report: dict[str, Any]) -> str:
    rows = []
    for run in report.get("runs", []):
        status = "PASS" if run.get("ok") else "FAIL"
        relay = "yes" if run.get("relay_used") else "no"
        rows.append(
            f"<tr><td>{run.get('scenario')}</td><td>{run.get('trial')}</td><td>{status}</td>"
            f"<td>{relay}</td><td>{run.get('duration_s')}</td><td>{run.get('selected_pair_kind')}</td>"
            f"<td><code>{run.get('report_path')}</code></td></tr>"
        )
    rows_html = "\n".join(rows)
    scenario_items = "".join(
        f"<li><strong>{k}</strong>: {v['passed']}/{v['total']} passed</li>"
        for k, v in sorted((report.get('by_scenario') or {}).items())
    )
    return f"""<!doctype html>
<html><head><meta charset='utf-8'><title>DecentNet two-host matrix report</title>
<style>body{{font-family:Arial,sans-serif;margin:24px}} table{{border-collapse:collapse;width:100%}} td,th{{border:1px solid #ccc;padding:6px 8px}} th{{background:#f5f5f5}} .ok{{color:#0a7d1f}} .bad{{color:#b00020}}</style>
</head><body>
<h1>DecentNet two-host matrix report</h1>
<p>Status: <strong class="{'ok' if report.get('ok') else 'bad'}">{'PASS' if report.get('ok') else 'FAIL'}</strong></p>
<ul>
<li>Total runs: {report.get('total_runs')}</li>
<li>Passed: {report.get('passed_runs')}</li>
<li>Failed: {report.get('failed_runs')}</li>
<li>Relay-used runs: {report.get('relay_runs')}</li>
<li>Average duration (s): {report.get('avg_duration_s')}</li>
</ul>
<h2>Scenario summary</h2><ul>{scenario_items}</ul>
<h2>Runs</h2>
<table>
<tr><th>Scenario</th><th>Trial</th><th>Status</th><th>Relay</th><th>Duration (s)</th><th>Selected pair</th><th>Report path</th></tr>
{rows_html}
</table>
</body></html>"""




def _compute_consecutive_streaks(values: list[bool]) -> dict[str, int]:
    best_ok = 0
    best_fail = 0
    cur_ok = 0
    cur_fail = 0
    for v in values:
        if v:
            cur_ok += 1
            cur_fail = 0
        else:
            cur_fail += 1
            cur_ok = 0
        best_ok = max(best_ok, cur_ok)
        best_fail = max(best_fail, cur_fail)
    return {"max_ok_streak": best_ok, "max_fail_streak": best_fail}


def aggregate_soak_reports(campaigns: list[dict[str, Any]], *, stage_dir: str | Path) -> dict[str, Any]:
    total_campaigns = len(campaigns)
    successful_campaigns = sum(1 for c in campaigns if c.get("ok"))
    failed_campaigns = total_campaigns - successful_campaigns
    total_runs = sum(int(c.get("total_runs", 0)) for c in campaigns)
    passed_runs = sum(int(c.get("passed_runs", 0)) for c in campaigns)
    failed_runs = sum(int(c.get("failed_runs", 0)) for c in campaigns)
    relay_runs = sum(int(c.get("relay_runs", 0)) for c in campaigns)
    avg_campaign_duration_s = round(sum(float(c.get("duration_s", 0.0)) for c in campaigns) / total_campaigns, 3) if campaigns else 0.0
    avg_run_duration_s = round(sum(float(c.get("avg_duration_s", 0.0)) for c in campaigns) / total_campaigns, 3) if campaigns else 0.0
    by_scenario: dict[str, dict[str, int]] = {}
    for campaign in campaigns:
        for name, vals in (campaign.get("by_scenario") or {}).items():
            slot = by_scenario.setdefault(name, {"total": 0, "passed": 0, "failed": 0})
            slot["total"] += int(vals.get("total", 0))
            slot["passed"] += int(vals.get("passed", 0))
            slot["failed"] += int(vals.get("failed", 0))
    streaks = _compute_consecutive_streaks([bool(c.get("ok")) for c in campaigns])
    report = {
        "kind": "two_host_soak_report",
        "ok": failed_campaigns == 0,
        "total_campaigns": total_campaigns,
        "successful_campaigns": successful_campaigns,
        "failed_campaigns": failed_campaigns,
        "total_runs": total_runs,
        "passed_runs": passed_runs,
        "failed_runs": failed_runs,
        "relay_runs": relay_runs,
        "avg_campaign_duration_s": avg_campaign_duration_s,
        "avg_run_duration_s": avg_run_duration_s,
        "success_rate": round(successful_campaigns / total_campaigns, 4) if total_campaigns else 0.0,
        "run_success_rate": round(passed_runs / total_runs, 4) if total_runs else 0.0,
        "by_scenario": by_scenario,
        "campaigns": campaigns,
        "stage_dir": str(stage_dir),
        "checked_at": int(time.time()),
        **streaks,
    }
    return report


def render_soak_html(report: dict[str, Any]) -> str:
    rows = []
    for camp in report.get("campaigns", []):
        status = "PASS" if camp.get("ok") else "FAIL"
        rows.append(
            f"<tr><td>{camp.get('campaign')}</td><td>{status}</td><td>{camp.get('scenario_list')}</td>"
            f"<td>{camp.get('trials')}</td><td>{camp.get('total_runs')}</td><td>{camp.get('passed_runs')}</td>"
            f"<td>{camp.get('relay_runs')}</td><td>{camp.get('duration_s')}</td><td><code>{camp.get('report_path')}</code></td></tr>"
        )
    rows_html = "\n".join(rows)
    scenario_items = "".join(
        f"<li><strong>{k}</strong>: {v['passed']}/{v['total']} passed</li>"
        for k, v in sorted((report.get('by_scenario') or {}).items())
    )
    return f"""<!doctype html>
<html><head><meta charset='utf-8'><title>DecentNet two-host soak report</title>
<style>body{{font-family:Arial,sans-serif;margin:24px}} table{{border-collapse:collapse;width:100%}} td,th{{border:1px solid #ccc;padding:6px 8px}} th{{background:#f5f5f5}} .ok{{color:#0a7d1f}} .bad{{color:#b00020}}</style>
</head><body>
<h1>DecentNet two-host soak report</h1>
<p>Status: <strong class="{'ok' if report.get('ok') else 'bad'}">{'PASS' if report.get('ok') else 'FAIL'}</strong></p>
<ul>
<li>Total campaigns: {report.get('total_campaigns')}</li>
<li>Successful campaigns: {report.get('successful_campaigns')}</li>
<li>Failed campaigns: {report.get('failed_campaigns')}</li>
<li>Total runs: {report.get('total_runs')}</li>
<li>Run success rate: {report.get('run_success_rate')}</li>
<li>Relay-used runs: {report.get('relay_runs')}</li>
<li>Average campaign duration (s): {report.get('avg_campaign_duration_s')}</li>
<li>Average run duration (s): {report.get('avg_run_duration_s')}</li>
<li>Max success streak: {report.get('max_ok_streak')}</li>
<li>Max failure streak: {report.get('max_fail_streak')}</li>
</ul>
<h2>Scenario trend summary</h2><ul>{scenario_items}</ul>
<h2>Campaigns</h2>
<table>
<tr><th>Campaign</th><th>Status</th><th>Scenarios</th><th>Trials</th><th>Total runs</th><th>Passed runs</th><th>Relay runs</th><th>Duration (s)</th><th>Report path</th></tr>
{rows_html}
</table>
</body></html>"""


def run_soak(args: argparse.Namespace) -> int:
    stage_dir = Path(args.stage_dir) if args.stage_dir else Path(tempfile.mkdtemp(prefix="decentnet-soak-"))
    stage_dir.mkdir(parents=True, exist_ok=True)
    rolling_out = Path(args.rolling_out) if args.rolling_out else (stage_dir / "soak-report.json")
    html_out = Path(args.html_out) if args.html_out else None
    campaigns: list[dict[str, Any]] = []
    started = time.time()
    campaign = 0
    scenarios = list(args.scenario or ["direct"])

    while True:
        campaign += 1
        if args.rounds is not None and campaign > args.rounds:
            break
        if args.max_wall_time_s is not None and campaign > 1 and (time.time() - started) >= args.max_wall_time_s:
            break

        run_stage = stage_dir / f"campaign-{campaign:03d}"
        run_stage.mkdir(parents=True, exist_ok=True)
        matrix_report = run_stage / "matrix.json"
        matrix_html = run_stage / "matrix.html"
        base_port = args.base_port + (campaign - 1) * args.port_stride
        cmd = [
            sys.executable,
            str(Path(__file__).resolve()),
            "matrix",
            "--host-a-runner", args.host_a_runner,
            "--host-b-runner", args.host_b_runner,
            "--host-a-repo", str(args.host_a_repo or _REPO),
            "--host-b-repo", str(args.host_b_repo or _REPO),
            "--host-a-python", args.host_a_python,
            "--host-b-python", args.host_b_python,
            "--ssh-bin", args.ssh_bin,
            "--scp-bin", args.scp_bin,
            "--host-a-root-prefix", str(args.host_a_root_prefix),
            "--host-b-root-prefix", str(args.host_b_root_prefix),
            "--host-a-public-host", args.host_a_public_host,
            "--host-b-public-host", args.host_b_public_host,
            "--base-port", str(base_port),
            "--trials", str(args.trials),
            "--stage-dir", str(run_stage),
            "--report-out", str(matrix_report),
            "--html-out", str(matrix_html),
            "--duration", str(args.duration),
            "--bundle-wait-timeout", str(args.bundle_wait_timeout),
            "--extra-wait-s", str(args.extra_wait_s),
            "--hello-delay", str(args.hello_delay),
            "--hello-timeout", str(args.hello_timeout),
            "--ring-timeout", str(args.ring_timeout),
            "--keepalive-timeout", str(args.keepalive_timeout),
            "--audit-wait", str(args.audit_wait),
            "--sleep-between", str(args.sleep_between_runs),
        ]
        if args.host_a_target:
            cmd.extend(["--host-a-target", args.host_a_target])
        if args.host_b_target:
            cmd.extend(["--host-b-target", args.host_b_target])
        if args.host_a_bundle_remote:
            cmd.extend(["--host-a-bundle-remote", args.host_a_bundle_remote])
        if args.host_b_peer_bundle_remote:
            cmd.extend(["--host-b-peer-bundle-remote", args.host_b_peer_bundle_remote])
        if args.host_b_bundle_remote:
            cmd.extend(["--host-b-bundle-remote", args.host_b_bundle_remote])
        if args.host_a_summary_remote:
            cmd.extend(["--host-a-summary-remote", args.host_a_summary_remote])
        if args.host_b_summary_remote:
            cmd.extend(["--host-b-summary-remote", args.host_b_summary_remote])
        if args.host_a_peer_bundle_in:
            cmd.extend(["--host-a-peer-bundle-in", args.host_a_peer_bundle_in])
        for sc in scenarios:
            cmd.extend(["--scenario", sc])

        t0 = time.time()
        proc = subprocess.run(cmd, cwd=str(_REPO), capture_output=True, text=True, timeout=args.campaign_timeout_s or (args.duration + args.extra_wait_s + 120.0))
        duration_s = round(time.time() - t0, 3)
        matrix = read_json(matrix_report) if matrix_report.exists() else {"ok": False, "error": "missing matrix report"}
        info = {
            "campaign": campaign,
            "ok": bool(proc.returncode == 0 and matrix.get("ok")),
            "returncode": proc.returncode,
            "duration_s": duration_s,
            "total_runs": int(matrix.get("total_runs", 0)),
            "passed_runs": int(matrix.get("passed_runs", 0)),
            "failed_runs": int(matrix.get("failed_runs", 0)),
            "relay_runs": int(matrix.get("relay_runs", 0)),
            "avg_duration_s": float(matrix.get("avg_duration_s", 0.0)),
            "by_scenario": matrix.get("by_scenario", {}),
            "report_path": str(matrix_report),
            "html_path": str(matrix_html),
            "scenario_list": list(scenarios),
            "trials": args.trials,
            "stdout_tail": (proc.stdout or "")[-800:],
            "stderr_tail": (proc.stderr or "")[-800:],
        }
        campaigns.append(info)
        report = aggregate_soak_reports(campaigns, stage_dir=stage_dir)
        write_json(rolling_out, report)
        if html_out:
            html_out.parent.mkdir(parents=True, exist_ok=True)
            html_out.write_text(render_soak_html(report), encoding="utf-8")
        log("soak_campaign_complete", **info)
        if args.fail_fast and not info["ok"]:
            break
        if args.max_wall_time_s is not None and (time.time() - started) >= args.max_wall_time_s:
            break
        if args.sleep_between_campaigns > 0:
            time.sleep(args.sleep_between_campaigns)

    final = aggregate_soak_reports(campaigns, stage_dir=stage_dir)
    write_json(rolling_out, final)
    if html_out:
        html_out.write_text(render_soak_html(final), encoding="utf-8")
    print(json.dumps(final, indent=2, sort_keys=True, default=_json_default))
    return 0 if final.get("ok") else 2

def run_matrix(args: argparse.Namespace) -> int:
    stage_dir = Path(args.stage_dir) if args.stage_dir else Path(tempfile.mkdtemp(prefix="decentnet-matrix-"))
    stage_dir.mkdir(parents=True, exist_ok=True)

    runs: list[dict[str, Any]] = []
    scenario_summary: dict[str, dict[str, int]] = {}
    run_index = 0

    scenarios = list(args.scenario or ["direct"])
    for scenario in scenarios:
        send_ring, send_keepalive = _scenario_flags(scenario)
        scenario_summary.setdefault(scenario, {"total": 0, "passed": 0, "failed": 0})
        for trial in range(1, args.trials + 1):
            run_index += 1
            host_a_port = args.base_port + (run_index - 1) * 2
            host_b_port = host_a_port + 1
            run_stage = stage_dir / f"{scenario}-trial{trial}"
            run_stage.mkdir(parents=True, exist_ok=True)
            report_path = run_stage / "report.json"
            host_a_root = f"{args.host_a_root_prefix}-{scenario}-t{trial}"
            host_b_root = f"{args.host_b_root_prefix}-{scenario}-t{trial}"
            host_a_public_address = f"{args.host_a_public_host}:{host_a_port}"
            host_b_public_address = f"{args.host_b_public_host}:{host_b_port}"
            cmd = build_orchestrate_cli_args(
                args,
                stage_dir=run_stage,
                report_out=report_path,
                host_a_root=host_a_root,
                host_b_root=host_b_root,
                host_a_port=host_a_port,
                host_b_port=host_b_port,
                host_a_public_address=host_a_public_address,
                host_b_public_address=host_b_public_address,
                send_ring=send_ring,
                send_keepalive=send_keepalive,
            )
            started = time.time()
            proc = subprocess.run(cmd, cwd=str(_REPO), capture_output=True, text=True, timeout=args.duration + args.extra_wait_s + 30.0)
            duration_s = round(time.time() - started, 3)
            merged = read_json(report_path) if report_path.exists() else {"ok": False, "error": "missing report", "stdout": proc.stdout, "stderr": proc.stderr}
            ok = bool(proc.returncode == 0 and merged.get("ok"))
            relay_used = bool((merged.get("verdict") or {}).get("relay_used"))
            selected_pair_kind = (merged.get("host_b") or {}).get("peer", {}).get("selected_pair_kind")
            run_info = {
                "scenario": scenario,
                "trial": trial,
                "ok": ok,
                "returncode": proc.returncode,
                "relay_used": relay_used,
                "duration_s": duration_s,
                "selected_pair_kind": selected_pair_kind,
                "report_path": str(report_path),
                "stdout_tail": (proc.stdout or "")[-800:],
                "stderr_tail": (proc.stderr or "")[-800:],
            }
            runs.append(run_info)
            scenario_summary[scenario]["total"] += 1
            if ok:
                scenario_summary[scenario]["passed"] += 1
            else:
                scenario_summary[scenario]["failed"] += 1
            log("matrix_run_complete", **run_info)
            if args.sleep_between > 0 and not (scenario == scenarios[-1] and trial == args.trials):
                time.sleep(args.sleep_between)

    passed_runs = sum(1 for r in runs if r["ok"])
    failed_runs = len(runs) - passed_runs
    relay_runs = sum(1 for r in runs if r["relay_used"])
    avg_duration_s = round(sum(r["duration_s"] for r in runs) / len(runs), 3) if runs else 0.0
    report = {
        "kind": "two_host_matrix_report",
        "ok": failed_runs == 0,
        "total_runs": len(runs),
        "passed_runs": passed_runs,
        "failed_runs": failed_runs,
        "relay_runs": relay_runs,
        "avg_duration_s": avg_duration_s,
        "by_scenario": scenario_summary,
        "runs": runs,
        "checked_at": int(time.time()),
        "stage_dir": str(stage_dir),
    }
    if args.report_out:
        write_json(args.report_out, report)
    if args.html_out:
        Path(args.html_out).write_text(render_matrix_html(report), encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True, default=_json_default))
    return 0 if report["ok"] else 2


def render_daemon_unit(*, service_name: str, repo: str, root: str, python_bin: str, udp_port: int, socket_path: str | None = None, config_path: str | None = None) -> str:
    args = [shlex.quote(python_bin), '-m', 'decentnet', '--root', shlex.quote(root), 'daemon', '--udp-port', str(udp_port)]
    if socket_path:
        args.extend(['--socket', shlex.quote(socket_path)])
    if config_path:
        args.extend(['--config', shlex.quote(config_path)])
    exec_start = f"/bin/bash -lc 'cd {shlex.quote(repo)} && {' '.join(args)}'"
    return f"""[Unit]
Description=DecentNet daemon ({service_name})
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory={repo}
ExecStart={exec_start}
Restart=on-failure
RestartSec=2

[Install]
WantedBy=multi-user.target
"""


def _deploy_python_for(args: argparse.Namespace, which: str) -> str:
    install_mode = getattr(args, 'install_mode', 'skip')
    if install_mode == 'skip':
        return getattr(args, f'{which}_python')
    venv = getattr(args, f'{which}_venv')
    return str(Path(venv) / 'bin' / 'python')


def _run_checked(runner: HostRunner, command: str, *, timeout: float, dry_run: bool, plan: list[dict[str, Any]], stage: str) -> subprocess.CompletedProcess | None:
    plan.append({'runner': runner.mode, 'target': runner.target, 'repo': runner.repo, 'stage': stage, 'command': command})
    if dry_run:
        return None
    res = runner.run_shell(command, timeout=timeout)
    if res.returncode != 0:
        raise HarnessError(f"{stage} failed on {runner.target or 'local'}: {(res.stdout or '').strip()}\n{(res.stderr or '').strip()}")
    return res


def _prepare_host(args: argparse.Namespace, which: str, plan: list[dict[str, Any]]) -> dict[str, Any]:
    runner = HostRunner(
        mode=getattr(args, f'{which}_runner'),
        repo=getattr(args, f'{which}_repo') or _REPO,
        python_bin=getattr(args, f'{which}_python'),
        target=getattr(args, f'{which}_target', None),
        ssh_bin=args.ssh_bin,
        scp_bin=args.scp_bin,
    )
    if args.sync_repo:
        plan.append({'runner': runner.mode, 'target': runner.target, 'repo': runner.repo, 'stage': f'{which}:sync_repo', 'source_repo': str(_REPO)})
        if not args.dry_run:
            runner.sync_repo_from(_REPO)
    root = getattr(args, f'{which}_root')
    timeout = args.deploy_timeout
    install_mode = args.install_mode
    py_before = getattr(args, f'{which}_python')
    py_exec = py_before
    if install_mode in {'editable', 'source'}:
        venv = getattr(args, f'{which}_venv')
        _run_checked(runner, f"{shlex.quote(py_before)} -m venv {shlex.quote(venv)}", timeout=timeout, dry_run=args.dry_run, plan=plan, stage=f'{which}:venv')
        py_exec = str(Path(venv) / 'bin' / 'python')
        _run_checked(runner, f"{shlex.quote(py_exec)} -m pip install -U pip", timeout=timeout, dry_run=args.dry_run, plan=plan, stage=f'{which}:pip_upgrade')
        install_cmd = f"{shlex.quote(py_exec)} -m pip install -e ." if install_mode == 'editable' else f"{shlex.quote(py_exec)} -m pip install ."
        _run_checked(runner, install_cmd, timeout=max(timeout, 120.0), dry_run=args.dry_run, plan=plan, stage=f'{which}:install')
    if not args.skip_init:
        _run_checked(runner, f"{shlex.quote(py_exec)} -m decentnet --root {shlex.quote(str(root))} init", timeout=timeout, dry_run=args.dry_run, plan=plan, stage=f'{which}:init')
    doctor_cmd = f"{shlex.quote(py_exec)} -m decentnet --root {shlex.quote(str(root))} doctor --json --bind-udp-port {int(args.doctor_bind_udp_port)}"
    for server in args.doctor_stun_server or []:
        doctor_cmd += f" --stun-server {shlex.quote(server)}"
    doctor_res = _run_checked(runner, doctor_cmd, timeout=max(timeout, 30.0), dry_run=args.dry_run, plan=plan, stage=f'{which}:doctor')
    doctor_json = None
    if doctor_res is not None:
        try:
            doctor_json = json.loads((doctor_res.stdout or '').strip() or '{}')
        except Exception:
            doctor_json = {'ok': False, 'raw': doctor_res.stdout}
    return {'runner': runner, 'python_exec': py_exec, 'doctor': doctor_json}


def _emit_systemd_units(args: argparse.Namespace, *, python_a: str, python_b: str) -> list[str]:
    out_dir = Path(args.emit_systemd_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    a_unit = render_daemon_unit(service_name='host-a', repo=str(args.host_a_repo or _REPO), root=str(args.host_a_root), python_bin=python_a, udp_port=int(args.host_a_udp_port), socket_path=str(Path(args.host_a_root) / 'control.sock'))
    b_unit = render_daemon_unit(service_name='host-b', repo=str(args.host_b_repo or _REPO), root=str(args.host_b_root), python_bin=python_b, udp_port=int(args.host_b_udp_port), socket_path=str(Path(args.host_b_root) / 'control.sock'))
    a_path = out_dir / 'decentnet-host-a.service'
    b_path = out_dir / 'decentnet-host-b.service'
    a_path.write_text(a_unit, encoding='utf-8')
    b_path.write_text(b_unit, encoding='utf-8')
    return [str(a_path), str(b_path)]


def run_deploy(args: argparse.Namespace) -> int:
    plan: list[dict[str, Any]] = []
    started = time.time()
    prep_a = _prepare_host(args, 'host_a', plan)
    prep_b = _prepare_host(args, 'host_b', plan)
    emitted_units: list[str] = []
    if args.emit_systemd_dir:
        emitted_units = _emit_systemd_units(args, python_a=prep_a['python_exec'], python_b=prep_b['python_exec'])
    deploy_report: dict[str, Any] = {
        'kind': 'two_host_deploy_report',
        'action': args.action,
        'dry_run': bool(args.dry_run),
        'prepared': {
            'host_a': {'python_exec': prep_a['python_exec'], 'doctor': prep_a['doctor']},
            'host_b': {'python_exec': prep_b['python_exec'], 'doctor': prep_b['doctor']},
        },
        'systemd_units': emitted_units,
        'plan': plan,
        'result': None,
        'ok': False,
    }
    if args.dry_run:
        deploy_report['ok'] = True
        deploy_report['duration_s'] = round(time.time() - started, 3)
        if args.report_out:
            write_json(args.report_out, deploy_report)
        print(json.dumps(deploy_report, indent=2, sort_keys=True, default=_json_default))
        return 0

    stage_dir = Path(args.stage_dir) if args.stage_dir else Path(tempfile.mkdtemp(prefix='decentnet-deploy-'))
    stage_dir.mkdir(parents=True, exist_ok=True)
    result_rc = 0
    if args.action in {'validate', 'full'}:
        report_out = Path(args.report_out) if args.report_out else stage_dir / 'orchestrated-report.json'
        cmd = [
            sys.executable, str(Path(__file__).resolve()), 'orchestrate',
            '--host-a-runner', args.host_a_runner, '--host-b-runner', args.host_b_runner,
            '--host-a-repo', str(args.host_a_repo or _REPO), '--host-b-repo', str(args.host_b_repo or _REPO),
            '--host-a-python', prep_a['python_exec'], '--host-b-python', prep_b['python_exec'],
            '--ssh-bin', args.ssh_bin, '--scp-bin', args.scp_bin,
            '--host-a-root', str(args.host_a_root), '--host-b-root', str(args.host_b_root),
            '--host-a-udp-port', str(args.host_a_udp_port), '--host-b-udp-port', str(args.host_b_udp_port),
            '--host-a-public-address', args.host_a_public_address, '--host-b-public-address', args.host_b_public_address,
            '--stage-dir', str(stage_dir / 'orchestrate'), '--report-out', str(report_out),
            '--duration', str(args.duration), '--hello-delay', str(args.hello_delay), '--hello-timeout', str(args.hello_timeout),
            '--ring-timeout', str(args.ring_timeout), '--keepalive-timeout', str(args.keepalive_timeout), '--audit-wait', str(args.audit_wait),
        ]
        if args.send_ring: cmd.append('--send-ring')
        if args.send_keepalive: cmd.append('--send-keepalive')
        if args.host_a_target: cmd.extend(['--host-a-target', args.host_a_target])
        if args.host_b_target: cmd.extend(['--host-b-target', args.host_b_target])
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=args.deploy_timeout + args.duration + args.extra_wait_s)
        deploy_report['result'] = {'mode': 'orchestrate', 'returncode': proc.returncode, 'report_out': str(report_out), 'stdout_tail': (proc.stdout or '')[-1000:], 'stderr_tail': (proc.stderr or '')[-1000:]}
        result_rc = proc.returncode
    elif args.action == 'matrix':
        report_out = Path(args.report_out) if args.report_out else stage_dir / 'matrix.json'
        html_out = Path(args.html_out) if args.html_out else stage_dir / 'matrix.html'
        cmd = [
            sys.executable, str(Path(__file__).resolve()), 'matrix',
            '--host-a-runner', args.host_a_runner, '--host-b-runner', args.host_b_runner,
            '--host-a-repo', str(args.host_a_repo or _REPO), '--host-b-repo', str(args.host_b_repo or _REPO),
            '--host-a-python', prep_a['python_exec'], '--host-b-python', prep_b['python_exec'],
            '--ssh-bin', args.ssh_bin, '--scp-bin', args.scp_bin,
            '--host-a-root-prefix', str(args.host_a_root_prefix or args.host_a_root), '--host-b-root-prefix', str(args.host_b_root_prefix or args.host_b_root),
            '--host-a-public-host', args.host_a_public_host or parse_host_port(args.host_a_public_address)[0], '--host-b-public-host', args.host_b_public_host or parse_host_port(args.host_b_public_address)[0],
            '--base-port', str(args.base_port), '--trials', str(args.trials), '--stage-dir', str(stage_dir / 'matrix'), '--report-out', str(report_out), '--html-out', str(html_out)
        ]
        for scenario in (args.scenario or ['direct']): cmd.extend(['--scenario', scenario])
        if args.host_a_target: cmd.extend(['--host-a-target', args.host_a_target])
        if args.host_b_target: cmd.extend(['--host-b-target', args.host_b_target])
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=max(args.deploy_timeout, 300.0))
        deploy_report['result'] = {'mode': 'matrix', 'returncode': proc.returncode, 'report_out': str(report_out), 'html_out': str(html_out)}
        result_rc = proc.returncode
    elif args.action == 'soak':
        report_out = Path(args.report_out) if args.report_out else stage_dir / 'soak.json'
        html_out = Path(args.html_out) if args.html_out else stage_dir / 'soak.html'
        cmd = [
            sys.executable, str(Path(__file__).resolve()), 'soak',
            '--host-a-runner', args.host_a_runner, '--host-b-runner', args.host_b_runner,
            '--host-a-repo', str(args.host_a_repo or _REPO), '--host-b-repo', str(args.host_b_repo or _REPO),
            '--host-a-python', prep_a['python_exec'], '--host-b-python', prep_b['python_exec'],
            '--ssh-bin', args.ssh_bin, '--scp-bin', args.scp_bin,
            '--host-a-root-prefix', str(args.host_a_root_prefix or args.host_a_root), '--host-b-root-prefix', str(args.host_b_root_prefix or args.host_b_root),
            '--host-a-public-host', args.host_a_public_host or parse_host_port(args.host_a_public_address)[0], '--host-b-public-host', args.host_b_public_host or parse_host_port(args.host_b_public_address)[0],
            '--base-port', str(args.base_port), '--trials', str(args.trials), '--stage-dir', str(stage_dir / 'soak'), '--rolling-out', str(report_out), '--html-out', str(html_out), '--rounds', str(args.rounds)
        ]
        for scenario in (args.scenario or ['direct']): cmd.extend(['--scenario', scenario])
        if args.host_a_target: cmd.extend(['--host-a-target', args.host_a_target])
        if args.host_b_target: cmd.extend(['--host-b-target', args.host_b_target])
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=max(args.deploy_timeout, 600.0))
        deploy_report['result'] = {'mode': 'soak', 'returncode': proc.returncode, 'report_out': str(report_out), 'html_out': str(html_out)}
        result_rc = proc.returncode
    if args.run_pack and deploy_report.get('result'):
        pack_archive = Path(args.pack_archive_out) if args.pack_archive_out else stage_dir / 'operator-bundle.zip'
        pack_dir = Path(args.pack_out_dir) if args.pack_out_dir else stage_dir / 'operator-bundle'
        pack_cmd = [sys.executable, str(Path(__file__).resolve()), 'pack', '--watch-root', str(args.host_a_root), '--watch-root', str(args.host_b_root), '--out-dir', str(pack_dir), '--archive-out', str(pack_archive)]
        result_report = deploy_report['result'].get('report_out')
        if result_report:
            suffix = Path(result_report).suffix.lower()
            if 'soak' in str(result_report) or 'matrix' in str(result_report):
                pack_cmd.extend(['--soak-report', str(result_report)])
            else:
                pack_cmd.extend(['--operator-report', str(result_report)])
        pack_proc = subprocess.run(pack_cmd, capture_output=True, text=True, timeout=max(args.deploy_timeout, 120.0))
        deploy_report['pack'] = {'returncode': pack_proc.returncode, 'archive_out': str(pack_archive), 'out_dir': str(pack_dir)}
        if pack_proc.returncode != 0 and result_rc == 0:
            result_rc = pack_proc.returncode
    deploy_report['ok'] = bool(result_rc == 0)
    deploy_report['duration_s'] = round(time.time() - started, 3)
    if args.report_out and args.action == 'validate':
        # preserve orchestrated report path already used by operator result; write deploy metadata beside it
        meta_out = str(Path(args.report_out).with_suffix('.deploy.json'))
        write_json(meta_out, deploy_report)
        deploy_report['deploy_report_out'] = meta_out
    elif args.report_out:
        write_json(args.report_out, deploy_report)
    print(json.dumps(deploy_report, indent=2, sort_keys=True, default=_json_default))
    return 0 if deploy_report['ok'] else 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="mode", required=True)

    a = sub.add_parser("host-a")
    a.add_argument("--root", required=True)
    a.add_argument("--udp-port", type=int, default=0)
    a.add_argument("--public-address", default=None, help="Reachable HOST:PORT for host A")
    a.add_argument("--bundle-out", default=None, help="Where to write host A's exported bundle")
    a.add_argument("--peer-bundle-in", default=None, help="Optional path to host B's bundle for explicit pre-seeding")
    a.add_argument("--summary-out", default=None, help="Where to write host A's machine-readable summary")
    a.add_argument("--duration", type=float, default=60.0)
    a.add_argument("--stop-on-success", action="store_true", help="Stop early after observing the expected hello/ring success events")
    a.add_argument("--expect-ring", action="store_true", help="Require ring activity in the host A success summary")

    b = sub.add_parser("host-b")
    b.add_argument("--root", required=True)
    b.add_argument("--udp-port", type=int, default=0)
    b.add_argument("--public-address", default=None, help="Reachable HOST:PORT for host B")
    b.add_argument("--peer-bundle", required=True, help="Path to host A's bundle JSON")
    b.add_argument("--self-bundle-out", default=None, help="Where to write host B's exported bundle")
    b.add_argument("--summary-out", default=None, help="Where to write host B's machine-readable summary")
    b.add_argument("--hello-delay", type=float, default=0.0)
    b.add_argument("--hello-timeout", type=float, default=5.0)
    b.add_argument("--ring-timeout", type=float, default=5.0)
    b.add_argument("--keepalive-timeout", type=float, default=3.0)
    b.add_argument("--audit-wait", type=float, default=2.0)
    b.add_argument("--send-ring", action="store_true", help="Send a ring after hello succeeds")
    b.add_argument("--send-keepalive", action="store_true", help="Send a keepalive after hello/ring")

    o = sub.add_parser("orchestrate", help="Run the two-host flow from one operator machine using local or SSH runners.")
    o.add_argument("--host-a-runner", choices=["local", "ssh"], default="local")
    o.add_argument("--host-b-runner", choices=["local", "ssh"], default="local")
    o.add_argument("--host-a-target", default=None, help="SSH target for host A, e.g. user@vm-a")
    o.add_argument("--host-b-target", default=None, help="SSH target for host B, e.g. user@vm-b")
    o.add_argument("--host-a-repo", default=str(_REPO))
    o.add_argument("--host-b-repo", default=str(_REPO))
    o.add_argument("--host-a-python", default=sys.executable)
    o.add_argument("--host-b-python", default=sys.executable)
    o.add_argument("--ssh-bin", default="ssh")
    o.add_argument("--scp-bin", default="scp")
    o.add_argument("--host-a-root", required=True)
    o.add_argument("--host-b-root", required=True)
    o.add_argument("--host-a-udp-port", type=int, default=41234)
    o.add_argument("--host-b-udp-port", type=int, default=41235)
    o.add_argument("--host-a-public-address", required=True)
    o.add_argument("--host-b-public-address", required=True)
    o.add_argument("--host-a-bundle-remote", default=None)
    o.add_argument("--host-b-peer-bundle-remote", default=None)
    o.add_argument("--host-b-bundle-remote", default=None)
    o.add_argument("--host-a-summary-remote", default=None)
    o.add_argument("--host-b-summary-remote", default=None)
    o.add_argument("--host-a-peer-bundle-in", default=None)
    o.add_argument("--stage-dir", default=None)
    o.add_argument("--host-a-summary-local", default=None)
    o.add_argument("--host-b-summary-local", default=None)
    o.add_argument("--host-a-log-local", default=None)
    o.add_argument("--host-b-log-local", default=None)
    o.add_argument("--report-out", default=None)
    o.add_argument("--duration", type=float, default=60.0)
    o.add_argument("--bundle-wait-timeout", type=float, default=15.0)
    o.add_argument("--extra-wait-s", type=float, default=15.0)
    o.add_argument("--hello-delay", type=float, default=0.0)
    o.add_argument("--hello-timeout", type=float, default=5.0)
    o.add_argument("--ring-timeout", type=float, default=5.0)
    o.add_argument("--keepalive-timeout", type=float, default=3.0)
    o.add_argument("--audit-wait", type=float, default=2.0)
    o.add_argument("--send-ring", action="store_true")
    o.add_argument("--send-keepalive", action="store_true")

    m = sub.add_parser("matrix", help="Run multiple orchestrated two-host scenarios and emit an aggregate report.")
    m.add_argument("--host-a-runner", choices=["local", "ssh"], default="local")
    m.add_argument("--host-b-runner", choices=["local", "ssh"], default="local")
    m.add_argument("--host-a-target", default=None)
    m.add_argument("--host-b-target", default=None)
    m.add_argument("--host-a-repo", default=str(_REPO))
    m.add_argument("--host-b-repo", default=str(_REPO))
    m.add_argument("--host-a-python", default=sys.executable)
    m.add_argument("--host-b-python", default=sys.executable)
    m.add_argument("--ssh-bin", default="ssh")
    m.add_argument("--scp-bin", default="scp")
    m.add_argument("--host-a-root-prefix", required=True)
    m.add_argument("--host-b-root-prefix", required=True)
    m.add_argument("--host-a-public-host", required=True)
    m.add_argument("--host-b-public-host", required=True)
    m.add_argument("--base-port", type=int, default=42000)
    m.add_argument("--scenario", choices=["direct", "ring", "full"], action="append", default=None, help="Can be repeated")
    m.add_argument("--trials", type=int, default=1)
    m.add_argument("--stage-dir", default=None)
    m.add_argument("--report-out", default=None)
    m.add_argument("--html-out", default=None)
    m.add_argument("--duration", type=float, default=60.0)
    m.add_argument("--bundle-wait-timeout", type=float, default=15.0)
    m.add_argument("--extra-wait-s", type=float, default=15.0)
    m.add_argument("--hello-delay", type=float, default=0.0)
    m.add_argument("--hello-timeout", type=float, default=5.0)
    m.add_argument("--ring-timeout", type=float, default=5.0)
    m.add_argument("--keepalive-timeout", type=float, default=3.0)
    m.add_argument("--audit-wait", type=float, default=2.0)
    m.add_argument("--sleep-between", type=float, default=0.0)
    m.add_argument("--host-a-bundle-remote", default=None)
    m.add_argument("--host-b-peer-bundle-remote", default=None)
    m.add_argument("--host-b-bundle-remote", default=None)
    m.add_argument("--host-a-summary-remote", default=None)
    m.add_argument("--host-b-summary-remote", default=None)
    m.add_argument("--host-a-peer-bundle-in", default=None)

    s = sub.add_parser("soak", help="Run repeated matrix campaigns with rolling trend reports.")
    s.add_argument("--host-a-runner", choices=["local", "ssh"], default="local")
    s.add_argument("--host-b-runner", choices=["local", "ssh"], default="local")
    s.add_argument("--host-a-target", default=None)
    s.add_argument("--host-b-target", default=None)
    s.add_argument("--host-a-repo", default=str(_REPO))
    s.add_argument("--host-b-repo", default=str(_REPO))
    s.add_argument("--host-a-python", default=sys.executable)
    s.add_argument("--host-b-python", default=sys.executable)
    s.add_argument("--ssh-bin", default="ssh")
    s.add_argument("--scp-bin", default="scp")
    s.add_argument("--host-a-root-prefix", required=True)
    s.add_argument("--host-b-root-prefix", required=True)
    s.add_argument("--host-a-public-host", required=True)
    s.add_argument("--host-b-public-host", required=True)
    s.add_argument("--base-port", type=int, default=43000)
    s.add_argument("--port-stride", type=int, default=100)
    s.add_argument("--scenario", choices=["direct", "ring", "full"], action="append", default=None, help="Can be repeated")
    s.add_argument("--trials", type=int, default=1)
    s.add_argument("--rounds", type=int, default=None, help="Number of matrix campaigns to run")
    s.add_argument("--max-wall-time-s", type=float, default=None, help="Optional wall-clock budget for the whole soak")
    s.add_argument("--campaign-timeout-s", type=float, default=None)
    s.add_argument("--stage-dir", default=None)
    s.add_argument("--rolling-out", default=None)
    s.add_argument("--html-out", default=None)
    s.add_argument("--duration", type=float, default=60.0)
    s.add_argument("--bundle-wait-timeout", type=float, default=15.0)
    s.add_argument("--extra-wait-s", type=float, default=15.0)
    s.add_argument("--hello-delay", type=float, default=0.0)
    s.add_argument("--hello-timeout", type=float, default=5.0)
    s.add_argument("--ring-timeout", type=float, default=5.0)
    s.add_argument("--keepalive-timeout", type=float, default=3.0)
    s.add_argument("--audit-wait", type=float, default=2.0)
    s.add_argument("--sleep-between-runs", type=float, default=0.0)
    s.add_argument("--sleep-between-campaigns", type=float, default=0.0)
    s.add_argument("--fail-fast", action="store_true")
    s.add_argument("--host-a-bundle-remote", default=None)
    s.add_argument("--host-b-peer-bundle-remote", default=None)
    s.add_argument("--host-b-bundle-remote", default=None)
    s.add_argument("--host-a-summary-remote", default=None)
    s.add_argument("--host-b-summary-remote", default=None)
    s.add_argument("--host-a-peer-bundle-in", default=None)

    d = sub.add_parser("deploy", help="Prepare remote hosts, run doctor, optionally validate/matrix/soak, and collect outputs.")
    d.add_argument("--host-a-runner", choices=["local", "ssh"], default="local")
    d.add_argument("--host-b-runner", choices=["local", "ssh"], default="local")
    d.add_argument("--host-a-target", default=None)
    d.add_argument("--host-b-target", default=None)
    d.add_argument("--host-a-repo", default=str(_REPO))
    d.add_argument("--host-b-repo", default=str(_REPO))
    d.add_argument("--host-a-python", default=sys.executable)
    d.add_argument("--host-b-python", default=sys.executable)
    d.add_argument("--host-a-root", required=True)
    d.add_argument("--host-b-root", required=True)
    d.add_argument("--host-a-venv", default="/tmp/decentnet-host-a-venv")
    d.add_argument("--host-b-venv", default="/tmp/decentnet-host-b-venv")
    d.add_argument("--install-mode", choices=["skip", "editable", "source"], default="skip")
    d.add_argument("--sync-repo", action="store_true", help="Copy the operator repo to the remote/local repo paths before preparing hosts")
    d.add_argument("--skip-init", action="store_true")
    d.add_argument("--doctor-bind-udp-port", type=int, default=0)
    d.add_argument("--doctor-stun-server", action="append", default=[])
    d.add_argument("--host-a-udp-port", type=int, default=41234)
    d.add_argument("--host-b-udp-port", type=int, default=41235)
    d.add_argument("--host-a-public-address", required=True)
    d.add_argument("--host-b-public-address", required=True)
    d.add_argument("--host-a-public-host", default=None)
    d.add_argument("--host-b-public-host", default=None)
    d.add_argument("--host-a-root-prefix", default=None)
    d.add_argument("--host-b-root-prefix", default=None)
    d.add_argument("--base-port", type=int, default=42000)
    d.add_argument("--trials", type=int, default=1)
    d.add_argument("--rounds", type=int, default=1)
    d.add_argument("--scenario", choices=["direct", "ring", "full"], action="append", default=None)
    d.add_argument("--action", choices=["prepare", "validate", "matrix", "soak", "full"], default="validate")
    d.add_argument("--send-ring", action="store_true")
    d.add_argument("--send-keepalive", action="store_true")
    d.add_argument("--duration", type=float, default=60.0)
    d.add_argument("--extra-wait-s", type=float, default=15.0)
    d.add_argument("--hello-delay", type=float, default=0.0)
    d.add_argument("--hello-timeout", type=float, default=5.0)
    d.add_argument("--ring-timeout", type=float, default=5.0)
    d.add_argument("--keepalive-timeout", type=float, default=3.0)
    d.add_argument("--audit-wait", type=float, default=2.0)
    d.add_argument("--deploy-timeout", type=float, default=120.0)
    d.add_argument("--ssh-bin", default="ssh")
    d.add_argument("--scp-bin", default="scp")
    d.add_argument("--stage-dir", default=None)
    d.add_argument("--report-out", default=None)
    d.add_argument("--html-out", default=None)
    d.add_argument("--emit-systemd-dir", default=None)
    d.add_argument("--run-pack", action="store_true")
    d.add_argument("--pack-out-dir", default=None)
    d.add_argument("--pack-archive-out", default=None)
    d.add_argument("--dry-run", action="store_true")

    p = sub.add_parser("pack", help="Collect reports, logs, dashboard snapshots, and a manifest into one archive.")
    p.add_argument("--watch-root", action="append", default=[], help="Live node root to include in the snapshot (repeatable)")
    p.add_argument("--roots-dir", action="append", default=[], help="Directory containing node roots (repeatable)")
    p.add_argument("--operator-report", action="append", default=[], help="Merged/operator report JSON (repeatable)")
    p.add_argument("--operator-report-dir", action="append", default=[], help="Directory containing merged/operator reports")
    p.add_argument("--matrix-report", action="append", default=[], help="Matrix report JSON (repeatable)")
    p.add_argument("--matrix-dir", action="append", default=[], help="Directory containing matrix reports")
    p.add_argument("--soak-report", action="append", default=[], help="Soak report JSON (repeatable)")
    p.add_argument("--soak-dir", action="append", default=[], help="Directory containing soak reports")
    p.add_argument("--log-file", action="append", default=[], help="Log file to include (repeatable)")
    p.add_argument("--extra-file", action="append", default=[], help="Extra file to include (repeatable)")
    p.add_argument("--out-dir", required=True, help="Directory to populate with the operator bundle contents")
    p.add_argument("--archive-out", default=None, help="Zip archive path to write (default: <out-dir>.zip)")
    p.add_argument("--manifest-out", default=None, help="Manifest JSON path (default: <out-dir>/manifest.json)")
    p.add_argument("--index-html-out", default=None, help="Index HTML path (default: <out-dir>/index.html)")
    p.add_argument("--snapshot-json-name", default="dashboard-snapshot.json")
    p.add_argument("--snapshot-html-name", default="dashboard-snapshot.html")
    p.add_argument("--audit-tail", type=int, default=400)
    p.add_argument("--event-limit", type=int, default=200)

    r = sub.add_parser("report")
    r.add_argument("--host-a-summary", required=True)
    r.add_argument("--host-b-summary", required=True)
    r.add_argument("--out", default=None)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if args.mode == "host-a":
        raise SystemExit(run_host_a(args))
    if args.mode == "host-b":
        raise SystemExit(run_host_b(args))
    if args.mode == "orchestrate":
        raise SystemExit(run_orchestrate(args))
    if args.mode == "matrix":
        raise SystemExit(run_matrix(args))
    if args.mode == "soak":
        raise SystemExit(run_soak(args))
    if args.mode == "pack":
        raise SystemExit(run_pack(args))
    if args.mode == "deploy":
        raise SystemExit(run_deploy(args))
    raise SystemExit(run_report(args))


if __name__ == "__main__":
    main()
