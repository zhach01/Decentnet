# Changelog

All notable changes to `decentnet` are documented in this file.

## [0.2.0] - 2026-04-17

### Added
- Automatic ICE startup after `hello` / `hello_ack`.
- Selected-path persistence, keepalive-driven health checks, and ICE restart.
- Relay fallback, relay lifecycle hardening, and per-peer/operator safety budgets.
- Automatic peer-record bootstrap inside the signaling path.
- Runtime candidate refresh / trickle-style locator updates.
- Multi-node mesh, churn, rebind, partition, restart, and soak-style integration coverage.
- Live HTML dashboard with snapshot export/import and soak/operator report visibility.
- Two-host harness with orchestrate, matrix, soak, and pack modes.

### Changed
- Unified networking, operator tooling, and dashboard work into one release candidate.
- Updated `README.md` and runbooks to reflect the current signaling/bootstrap model.
- Release metadata bumped from `0.1.0` to `0.2.0`.

### Known limits
- Real-network STUN/NAT tests are still opt-in and depend on external DNS and UDP reachability.
- Relay support is cooperative and production-hardening work remains policy-oriented rather than service-grade TURN compatibility.
- Long-duration public-internet soak automation still depends on operator environment and provisioning.

## [0.1.0]

Initial alpha package metadata and early phased framework documentation.
