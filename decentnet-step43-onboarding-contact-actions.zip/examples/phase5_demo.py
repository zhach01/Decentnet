"""Phase 5 demo: external-address discovery via STUN and publishing
the mapped endpoint into a signed LocatorRecord.

Runs entirely on 127.0.0.1 against a mock STUN server — no external
network. In a real deployment, replace the mock with a real STUN
server (e.g. stun.l.google.com:19302).

Run with:   python examples/phase5_demo.py
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

_REPO = Path(__file__).resolve().parent.parent
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from decentnet.nat import MockSTUNServer, NATType
from decentnet.node import Node, NodeConfig
from decentnet.records.endpoints import Endpoint
from decentnet.transport.inproc import InProcessNetwork
from decentnet.transport.udp import UDPTransport


def banner(msg: str) -> None:
    print("\n" + "=" * 72)
    print(msg)
    print("=" * 72)


def main() -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)

        banner("1. Start two mock STUN servers on loopback")
        with MockSTUNServer() as s1, MockSTUNServer() as s2:
            print(f"  STUN A: {s1.bind_host}:{s1.bind_port}")
            print(f"  STUN B: {s2.bind_host}:{s2.bind_port}")

            banner("2. Start a Node with a standalone UDPTransport")
            net = InProcessNetwork()
            node = Node(NodeConfig.at(root / "node"), network=net)
            udp = UDPTransport(node.peer_id.value)
            print(f"  peer_id:       {node.peer_id}")
            print(f"  udp bind:      {udp.bind_host}:{udp.bind_port}")

            banner("3. Enable NAT discovery against both STUN servers")
            node.enable_nat_discovery(
                [
                    (s1.bind_host, s1.bind_port),
                    (s2.bind_host, s2.bind_port),
                ],
                udp_transport=udp,
            )
            print("  NAT discovery enabled on the UDP socket")

            banner("4. Probe — learn external (host, port)")
            mapped = node.refresh_external_address(timeout_s=1.0)
            print(f"  mapped = {mapped}")

            banner("5. Classify NAT from the two servers' agreement")
            nat = node.classify_nat(timeout_s=1.0)
            print(f"  NAT type: {nat.value}")
            if nat == NATType.OPEN_INTERNET:
                print("  → directly reachable (mock on loopback matches bind)")
            elif nat == NATType.CONE_LIKE:
                print("  → cone-like NAT; same mapping for different destinations")
            elif nat == NATType.SYMMETRIC:
                print("  → symmetric NAT; requires relay for inbound (Phase 6)")
            else:
                print("  → unknown; insufficient data to classify")

            banner("6. Publish a record with the STUN-learned endpoint")
            rec = node.publish_with_external_address(
                extra_endpoints=[
                    Endpoint(type="lan_udp", address="192.168.1.42:41234"),
                ]
            )
            print(f"  seq={rec.seq}")
            for e in rec.endpoints:
                tag = f" via {e.discovered_by}" if e.discovered_by else ""
                print(f"  • {e.type:<12} {e.address:<25} prio={e.priority}{tag}")

            banner("7. Audit tail showing STUN events")
            nat_events = [
                e for e in node.audit.tail(20)
                if e.get("kind", "").startswith("nat.")
            ]
            for e in nat_events:
                print(f"  {json.dumps(e, sort_keys=True)}")

            udp.close()
            node.close()


if __name__ == "__main__":
    main()
