"""Phase 2 demo: build a small network, watch a record propagate,
take the publisher offline, confirm replicas still serve the record,
partition + merge, and observe anti-entropy repair.

Run with:   python examples/network_demo.py
"""
from __future__ import annotations

import sys
from pathlib import Path

_REPO = Path(__file__).resolve().parent.parent
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from decentnet.records.endpoints import Endpoint
from decentnet.sim.network import SimNetwork


def banner(s: str) -> None:
    print("\n" + "=" * 72 + "\n" + s + "\n" + "=" * 72)


def main() -> None:
    with SimNetwork.build(10) as sim:
        banner(f"Built a network of {len(sim)} nodes")
        for i, n in enumerate(sim.nodes):
            print(f"  node[{i}] = {n.peer_id.short()}..  "
                  f"rt_size={n.routing_table().size()}")

        banner("Node 0 publishes record v1 and pushes to k closest")
        rec = sim.publish(
            sim[0],
            [Endpoint(type="public_udp", address="203.0.113.5:41234")],
        )
        print(f"seq={rec.seq}, endpoints={[e.address for e in rec.endpoints]}")
        holders = [
            i for i, n in enumerate(sim.nodes)
            if n.directory.store.peek(sim[0].peer_id.value) is not None
        ]
        print(f"replicas holding the record (by node index): {holders}")

        banner("Node 9 resolves via the DHT")
        got = sim[9].resolve(sim[0].peer_id.value, force_network=True)
        print(f"hit={got is not None}, seq={got.seq if got else None}, "
              f"endpoints={[e.address for e in got.endpoints] if got else []}")

        banner("Publisher goes offline; a fresh node still resolves")
        sim.go_offline(sim[0])
        got = sim[9].resolve(sim[0].peer_id.value, force_network=True)
        print(f"after offline: hit={got is not None}, "
              f"seq={got.seq if got else None}")
        sim.come_online(sim[0])

        banner("Node 0 rotates its endpoint → publishes v2")
        rec2 = sim.publish(
            sim[0],
            [Endpoint(type="public_udp", address="203.0.113.5:55555")],
        )
        print(f"new seq={rec2.seq}")

        banner("Partition {0..4} vs {5..9}; node 0 publishes v3 on its side")
        sim.partition({0, 1, 2, 3, 4}, {5, 6, 7, 8, 9})
        sim.publish(
            sim[0],
            [Endpoint(type="public_udp", address="203.0.113.5:66666")],
        )
        got_a = sim[4].resolve(sim[0].peer_id.value, force_network=True)
        got_b = sim[9].resolve(sim[0].peer_id.value, force_network=True)
        print(f"side A (node 4) sees seq={got_a.seq if got_a else 'miss'}")
        print(f"side B (node 9) sees seq={got_b.seq if got_b else 'miss'} "
              f"(stuck on pre-partition view)")

        banner("Heal the partition; side B resolves again, catches up")
        sim.heal()
        got_b = sim[9].resolve(sim[0].peer_id.value, force_network=True)
        print(f"side B now sees seq={got_b.seq if got_b else 'miss'}")

        banner("Anti-entropy: node 9 syncs with node 0 and pulls fresher data")
        result = sim[9].sync_with(sim[0].peer_id.value)
        print(f"received {result.received} records "
              f"(accepted or skipped-stale) from {result.contacted[:8]}..")

        banner("Final cache stats for each node")
        for i, n in enumerate(sim.nodes):
            dht_size = n.directory.store.size()
            l1_size = n.cache.stats()["records"]
            print(f"  node[{i}] {n.peer_id.short()}..  "
                  f"L1={l1_size}  DHT={dht_size}  "
                  f"rt={n.routing_table().size()}")


if __name__ == "__main__":
    main()
