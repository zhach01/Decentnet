"""Final demo: exercise every gap-list feature end-to-end.

Covers rotation, selective disclosure, multi-source confidence,
deferred writes, topic-scoped replication, snapshot+reconstruction,
reputation, CBOR encoding, audit rotation, encrypted keystore,
background refresh + keepalive schedulers.

Runs on loopback in-process. Prints a narrative trace.
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

_REPO = Path(__file__).resolve().parent.parent
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from decentnet.identity import keystore as _ks
from decentnet.identity.keypair import Keypair
from decentnet.limits.reputation import ReputationTracker
from decentnet.node import Node, NodeConfig
from decentnet.records.endpoints import Endpoint
from decentnet.repair.digests import build_bloom_for_peers, MerkleBucketSummary
from decentnet.transport.inproc import InProcessNetwork
from decentnet.utils.cbor import canonical_cbor, decode_cbor


def banner(msg: str) -> None:
    print("\n" + "=" * 72)
    print(msg)
    print("=" * 72)


def main() -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        net = InProcessNetwork()

        banner("1. Three nodes: publisher, alice, eve")
        pub = Node(NodeConfig.at(root / "pub"), network=net)
        alice = Node(NodeConfig.at(root / "alice"), network=net)
        eve = Node(NodeConfig.at(root / "eve"), network=net)
        print(f"  pub   = {pub.peer_id}")
        print(f"  alice = {alice.peer_id}")
        print(f"  eve   = {eve.peer_id}")
        for src in (pub, alice, eve):
            src.join_network([
                (p.peer_id.value, "") for p in (pub, alice, eve)
                if p is not src
            ])

        banner("2. Selective disclosure: publish with a private endpoint for alice")
        rec = pub.publish_with_disclosure(
            public_endpoints=[Endpoint(type="lan_udp", address="192.168.1.5:4000")],
            disclosed_endpoints=[
                Endpoint(type="public_udp", address="203.0.113.9:55555"),
            ],
            recipients=[alice.keypair.public_key_bytes],
        )
        pub.publish_to_network()
        print(f"  record seq={rec.seq}, "
              f"public={len(rec.endpoints)}, encrypted envelopes={len(rec.encrypted_endpoints)}")
        alice.resolve(pub.peer_id.value, force_network=True)
        eve.resolve(pub.peer_id.value, force_network=True)
        got = alice.cache.peek(pub.peer_id.value)
        alice_private = alice.decrypt_disclosed(got)
        eve_private = eve.decrypt_disclosed(eve.cache.peek(pub.peer_id.value))
        print(f"  alice decrypts: {[e.address for e in alice_private]}")
        print(f"  eve   decrypts: {eve_private}  (empty — she's not a recipient)")

        banner("3. Multi-source confidence")
        score = alice.confidence.confidence(pub.peer_id.value)
        sources = alice.confidence.sources_for(pub.peer_id.value)
        print(f"  alice's confidence in pub: {score:.3f} "
              f"from {len(sources)} source(s): "
              f"{[s.source for s in sources]}")

        banner("4. Deferred writes: offline publish queues, then drains")
        solo = Node(NodeConfig.at(root / "solo"), network=net)  # isolated
        solo.publish_own_record(endpoints=[Endpoint(type="public_udp", address="9.9.9.9:9")])
        solo.queue_publish_deferred()
        print(f"  solo.deferred.size() before drain: {solo.deferred.size()}")
        result = solo.drain_deferred()
        print(f"  drain result: {result}")
        solo.close()

        banner("5. Topic-scoped replication")
        tid = alice.subscribe_topic("friends")
        print(f"  alice subscribed to 'friends' -> topic_hash={tid[:20]}...")
        print(f"  alice.replicate_all now = {alice.topic_policy.replicate_all}")

        banner("6. Global snapshotting + reconstruction")
        snap = pub.take_snapshot()
        snap_path = root / "pub-snap.json"
        snap_path.write_bytes(snap.to_bytes())
        print(f"  snapshot: record_count={snap.record_count}, bytes={len(snap.to_bytes())}")
        fresh = Node(NodeConfig.at(root / "fresh"), network=InProcessNetwork())
        outcome = fresh.import_snapshot(snap.to_bytes())
        print(f"  fresh node reconstructed: accepted={outcome['records_accepted']}")
        fresh.close()

        banner("7. Reputation tracker + success events")
        # pub publishes again to populate reputation on alice.
        pub.publish_own_record(endpoints=[Endpoint(type="public_udp", address="7.7.7.7:7")])
        pub.publish_to_network()
        rep_score = alice.reputation.score(pub.peer_id.value)
        print(f"  alice's reputation for pub: {rep_score:+.3f}")

        banner("8. Key rotation")
        old_pid = pub.peer_id.value
        rec2, receipt = pub.rotate_identity(
            endpoints=[Endpoint(type="public_udp", address="10.0.0.5:5000")],
        )
        print(f"  rotated: {old_pid[:12]}... -> {pub.peer_id.value[:12]}...")
        print(f"  looking up old pid on alice still works (ledger forwards):")
        # Publish new identity record via the net so alice's DHT knows.
        pub.publish_to_network()
        alice.cache.put(rec2, source="manual")
        alice.rotation_ledger.record_rotation(receipt)
        got_via_old = alice.lookup(old_pid)
        print(f"  alice.lookup(old_pid) -> peer_id={got_via_old.peer_id[:12]}... "
              f"endpoint={got_via_old.endpoints[0].address}")

        banner("9. CBOR canonical encoding")
        body = {"peer_id": "xyz", "seq": 42, "endpoints": [{"addr": "1.2.3.4:5"}]}
        cbor_bytes = canonical_cbor(body)
        roundtripped = decode_cbor(cbor_bytes)
        print(f"  JSON size:  {len(json.dumps(body))} bytes")
        print(f"  CBOR size:  {len(cbor_bytes)} bytes  (-{100 * (1 - len(cbor_bytes) / len(json.dumps(body))):.0f}%)")
        print(f"  roundtrip ok: {roundtripped == body}")

        banner("10. Bloom + Merkle digest for anti-entropy")
        pids = [n.peer_id.value for n in (pub, alice, eve)]
        bloom = build_bloom_for_peers(pids)
        print(f"  bloom: {bloom.size_bits} bits, {bloom.n_hashes} hashes")
        print(f"  contains(alice) -> {bloom.contains(alice.peer_id.value)}")
        print(f"  contains('ghost') -> {bloom.contains('ghost')}")
        entries = [(pid, 1) for pid in pids]
        merkle = MerkleBucketSummary.build(entries)
        nonempty = sum(1 for c in merkle.bucket_counts if c > 0)
        print(f"  merkle: {nonempty} of 256 buckets populated")

        banner("11. Background refresh + keepalive schedulers")
        alice.enable_background_refresh(interval_s=60, start=False)
        alice.enable_keepalive(interval_s=30, start=False)
        print("  schedulers installed (not started in demo)")

        banner("12. Encrypted keystore (scrypt + AES-GCM)")
        kp = Keypair.generate()
        tmp_key = root / "test-id.key.json"
        kp.save(tmp_key)
        print(f"  unencrypted: {_ks.is_encrypted_keyfile(tmp_key)}")
        _ks.wrap_keyfile(tmp_key, "demo-passphrase", scrypt_n=2**12)
        print(f"  encrypted:   {_ks.is_encrypted_keyfile(tmp_key)}")
        kp2 = Keypair.load(tmp_key, passphrase="demo-passphrase")
        print(f"  decrypts with right passphrase: {kp2.public_key_bytes == kp.public_key_bytes}")

        banner("Cleanup")
        pub.close(); alice.close(); eve.close()
        print("All done.")


if __name__ == "__main__":
    main()
