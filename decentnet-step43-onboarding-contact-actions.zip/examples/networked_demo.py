"""Phase 2 demo: a small DHT with publish, resolve, churn, partition,
corruption, and anti-entropy reconstruction — all on the in-process
transport so you can run it as-is.

Run with:   python examples/networked_demo.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

_REPO = Path(__file__).resolve().parent.parent
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from decentnet.records.endpoints import Endpoint
from decentnet.records.locator import LocatorRecord
from decentnet.sim import SimNetwork


def banner(msg: str) -> None:
    print("\n" + "=" * 72)
    print(msg)
    print("=" * 72)


def summarize(sim: SimNetwork, pid: str) -> None:
    print(f"  DHT replicas holding {pid[:10]}..:")
    for i, n in enumerate(sim.nodes):
        rec = n.dht_store().peek(pid)
        if rec is not None:
            addr = rec.endpoints[0].address if rec.endpoints else "?"
            print(f"    node[{i}] {n.peer_id.short()}  seq={rec.seq}  endpoint={addr}")


def main() -> None:
    with SimNetwork.build(n=6, k=4) as sim:
        pub = sim[0]

        banner("Phase 2: 6-node in-process DHT")
        print("node ids (short):")
        for i, n in enumerate(sim.nodes):
            print(f"  [{i}] {n.peer_id.short()}")

        banner("Publisher = node[0] publishes v1, broadcast to DHT")
        sim.publish(pub, [Endpoint(type="public_udp", address="1.1.1.1:1111")])
        summarize(sim, pub.peer_id.value)

        banner("node[3] resolves publisher via the DHT (no local cache hit)")
        rec = sim[3].resolve(pub.peer_id.value, force_network=True)
        print(f"  found: seq={rec.seq} endpoints={[e.address for e in rec.endpoints]}")

        banner("Publisher republishes v2 (IP change)")
        sim.publish(pub, [Endpoint(type="public_udp", address="2.2.2.2:2222")])
        summarize(sim, pub.peer_id.value)

        banner("Attacker tampers with exported v2 and injects into node[2]")
        wire = pub.export_own_record()
        obj = json.loads(wire)
        obj["endpoints"][0]["address"] = "9.9.9.9:9999"
        corrupted = json.dumps(obj).encode()
        r = sim[2].ingest_record_bytes(corrupted, source="attacker")
        print(f"  accepted={r.accepted}  reason={r.reason!r}")

        banner("Partition network into {0,1,2} and {3,4,5}; publish v3 on A-side")
        sim.partition({0, 1, 2}, {3, 4, 5})
        rec_v3 = sim.publish(pub, [Endpoint(type="public_udp", address="3.3.3.3:3333")])
        print(f"  published v3 (seq={rec_v3.seq}) within A-side only")

        # B-side view
        b_view = sim[4].resolve(pub.peer_id.value, force_network=True)
        if b_view is None:
            print("  node[4] (B-side): cannot resolve publisher at all")
        else:
            print(f"  node[4] (B-side): sees seq={b_view.seq} (pre-partition)")

        banner("Heal partition and run anti-entropy sync from A-holder → B-side")
        sim.heal()
        # Find an A-side holder of v3.
        a_holder = None
        for i in {0, 1, 2}:
            cached = sim[i].dht_store().peek(pub.peer_id.value)
            if cached is not None and cached.seq == rec_v3.seq:
                a_holder = sim[i]
                break
        assert a_holder is not None
        result = sim[4].sync_with(a_holder.peer_id.value)
        print(f"  sync: received={result.received}, skipped_stale={result.skipped_stale}")
        summarize(sim, pub.peer_id.value)

        banner("Primary goes offline. Late joiner (node[5]) evicts + re-learns.")
        sim.go_offline(pub)
        sim[5].dht_store().evict(pub.peer_id.value)
        print(f"  node[5] store size before sync = {sim[5].dht_store().size()}")

        # Pick any surviving holder.
        holder = None
        for i in range(1, 6):
            if i != 5 and sim[i].dht_store().peek(pub.peer_id.value) is not None:
                holder = sim[i]
                break
        assert holder is not None
        sim[5].sync_with(holder.peer_id.value)
        relearned = sim[5].dht_store().peek(pub.peer_id.value)
        print(f"  node[5] after sync: "
              f"{'seq=' + str(relearned.seq) if relearned else 'still missing'}")

        banner("Audit tail from node[4]")
        for entry in sim[4].audit.tail(10):
            print("  " + json.dumps(entry, sort_keys=True))


if __name__ == "__main__":
    main()
