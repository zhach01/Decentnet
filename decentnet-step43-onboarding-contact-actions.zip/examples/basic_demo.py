"""Phase 1 demo: two nodes, one publishes, the other ingests,
then we exercise the rejection paths the cache is meant to catch.

Run with:   python examples/basic_demo.py
        or: python -m examples.basic_demo   (from repo root)
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

# Allow running as `python examples/basic_demo.py` from the repo root
# without needing a pip install.
_REPO = Path(__file__).resolve().parent.parent
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from decentnet.node import Node, NodeConfig
from decentnet.records.endpoints import Endpoint
from decentnet.records.locator import LocatorRecord


def banner(msg: str) -> None:
    print("\n" + "=" * 72)
    print(msg)
    print("=" * 72)


def main() -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        alice_cfg = NodeConfig.at(root / "alice")
        bob_cfg = NodeConfig.at(root / "bob")

        with Node(alice_cfg) as alice, Node(bob_cfg) as bob:
            banner("Nodes initialized with stable cryptographic identities")
            print(f"alice peer_id: {alice.peer_id}")
            print(f"bob   peer_id: {bob.peer_id}")

            banner("Alice publishes a record with two endpoint candidates")
            rec_v1 = alice.publish_own_record(
                endpoints=[
                    Endpoint(
                        type="public_udp",
                        address="203.0.113.5:41234",
                        priority=10,
                        discovered_by="self",
                    ),
                    Endpoint(
                        type="lan_udp",
                        address="192.168.1.42:41234",
                        priority=5,
                        discovered_by="self",
                    ),
                ],
                capabilities=["signaling-v1", "chat-v1"],
            )
            print(f"published seq={rec_v1.seq}, {len(rec_v1.endpoints)} endpoint(s)")
            print(f"signed record size on wire: {len(rec_v1.to_wire_bytes())} bytes")

            banner("Bob ingests Alice's record")
            result = bob.ingest_record_bytes(
                alice.export_own_record(), source="demo-exchange"
            )
            print(f"accepted={result.accepted}  "
                  f"prev_seq={result.previous_seq}  new_seq={result.new_seq}")

            banner("Bob looks Alice up in his L1 cache")
            got = bob.lookup(alice.peer_id.value)
            assert got is not None
            print(f"found: seq={got.seq}, endpoints:")
            for e in got.endpoints:
                print(f"  {e.type:<12} {e.address}  "
                      f"prio={e.priority} conf={e.confidence}")

            banner("Adversary tampers with the record and re-submits it")
            wire = alice.export_own_record()
            obj = json.loads(wire)
            obj["endpoints"][0]["address"] = "198.51.100.99:9999"  # evil
            tampered = json.dumps(obj).encode()
            r = bob.ingest_record_bytes(tampered, source="adversary")
            print(f"accepted={r.accepted}  reason={r.reason!r}")

            banner("Alice publishes v2 (rotates her public endpoint)")
            rec_v2 = alice.publish_own_record(
                endpoints=[
                    Endpoint(type="public_udp",
                             address="203.0.113.5:55555", priority=10),
                    Endpoint(type="lan_udp",
                             address="192.168.1.42:41234", priority=5),
                ],
                capabilities=["signaling-v1", "chat-v1"],
            )
            r = bob.ingest_record_bytes(
                alice.export_own_record(), source="demo-exchange"
            )
            print(f"v2 accepted={r.accepted}  "
                  f"prev_seq={r.previous_seq}  new_seq={r.new_seq}")

            banner("Replay of old v1 should be rejected (rollback protection)")
            old_wire = rec_v1.to_wire_bytes()
            r = bob.ingest_record_bytes(old_wire, source="adversary-replay")
            print(f"accepted={r.accepted}  reason={r.reason!r}")

            banner("Bob reports a failed connection to Alice's public endpoint")
            bob.report_endpoint_failure(
                alice.peer_id.value, "203.0.113.5:55555"
            )
            bob.report_endpoint_failure(
                alice.peer_id.value, "203.0.113.5:55555"
            )
            print("negative cache:",
                  bob.cache.failed_endpoints(alice.peer_id.value))

            banner("Bob's cache stats + tail of audit log")
            print("stats:", bob.cache.stats())
            for entry in bob.audit.tail(6):
                print(" ", json.dumps(entry, sort_keys=True))


if __name__ == "__main__":
    main()
