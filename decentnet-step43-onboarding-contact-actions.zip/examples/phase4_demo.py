"""Phase 4 demo: two Nodes talk directly over real UDP sockets on
loopback. No in-process transport, no simulator. What you see is what
a real deployment does between two connected devices on the open
internet (modulo NAT — that's Phase 5/6 territory).

Run with:   python examples/phase4_demo.py

Flow:
    1. Both nodes start on UDP sockets on 127.0.0.1.
    2. They "resolve" each other by exchanging LocatorRecords directly
       (in a real deployment this step would happen via the DHT;
       here we shortcut by importing records over stdio to keep the
       demo self-contained).
    3. A sends HELLO → B replies HELLO_ACK → session ESTABLISHED.
    4. A sends RING → B's app callback accepts → RING_ACK → IN_CALL.
    5. A sends an OFFER pass-through; B drains its inbox and replies
       with an ANSWER.
    6. BYE closes the session cleanly.
    7. Audit log prints the per-step events.
"""
from __future__ import annotations

import json
import sys
import tempfile
import time
from pathlib import Path

_REPO = Path(__file__).resolve().parent.parent
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from decentnet.audit.log import AuditLog
from decentnet.cache.local import LocalCache
from decentnet.identity.keypair import Keypair
from decentnet.identity.peer_id import PeerId
from decentnet.records.endpoints import Endpoint
from decentnet.records.locator import LocatorRecord
from decentnet.signaling import SignalType
from decentnet.signaling.engine import SignalingEngine
from decentnet.transport.udp import UDPTransport


def banner(msg: str) -> None:
    print("\n" + "=" * 72)
    print(msg)
    print("=" * 72)


class DemoNode:
    """Minimal Node-like wrapper for the demo.

    We don't use the full `Node` class here because the full Node
    wires up a DHT/Directory that needs a shared InProcessNetwork;
    this demo is explicitly about UDP, so we assemble the pieces
    directly.
    """

    def __init__(self, label: str, tmp_root: Path):
        self.label = label
        self.root = tmp_root / label
        self.root.mkdir(parents=True, exist_ok=True)
        self.keypair = Keypair.load_or_create(self.root / "id.json")
        self.peer_id = PeerId.from_public_key(self.keypair.public_key_bytes)
        self.audit = AuditLog(self.root / "audit.jsonl")
        self.cache = LocalCache(self.root / "cache.sqlite3", audit=self.audit)
        self.transport = UDPTransport(self.peer_id.value)
        self.signaling = SignalingEngine(
            local_peer_id=self.peer_id.value,
            keypair=self.keypair,
            transport=self.transport,
            local_cache=self.cache,
            audit=self.audit,
        )

    def publish_own(self, host: str, port: int) -> LocatorRecord:
        rec = LocatorRecord.build_and_sign(
            self.keypair,
            endpoints=[Endpoint(type="public_udp", address=f"{host}:{port}")],
            seq=1,
        )
        self.cache.put(rec, source="self")
        return rec

    def import_peer(self, other: "DemoNode") -> None:
        """Directly install the other node's signed LocatorRecord into
        our L1. Also tell our UDP transport where that peer lives."""
        rec = other.cache.peek(other.peer_id.value)
        assert rec is not None, "peer must have published first"
        r = self.cache.put(rec, source="demo_import")
        assert r.accepted, r.reason
        self.transport.register_endpoint(
            other.peer_id.value,
            other.transport.bind_host,
            other.transport.bind_port,
        )

    def close(self) -> None:
        self.transport.close()
        self.cache.close()


def main() -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)

        banner("1. Start two UDP nodes on loopback")
        alice = DemoNode("alice", root)
        bob = DemoNode("bob", root)
        print(f"  alice peer_id: {alice.peer_id}")
        print(f"  alice udp:     {alice.transport.bind_host}:{alice.transport.bind_port}")
        print(f"  bob   peer_id: {bob.peer_id}")
        print(f"  bob   udp:     {bob.transport.bind_host}:{bob.transport.bind_port}")

        banner("2. Each publishes a LocatorRecord and they import each other")
        alice.publish_own(alice.transport.bind_host, alice.transport.bind_port)
        bob.publish_own(bob.transport.bind_host, bob.transport.bind_port)
        alice.import_peer(bob)
        bob.import_peer(alice)
        print("  records imported; both sides know the other's pubkey + endpoint")

        banner("3. Alice initiates hello/hello_ack handshake")
        r = alice.signaling.hello(bob.peer_id.value, timeout_s=2.0)
        print(f"  result: ok={r.ok} session_state={r.session_state}")
        # Let B's engine finish processing any trailing handler work.
        time.sleep(0.05)

        banner("4. Bob registers an on_ring callback that accepts offers about 'chat'")
        def on_ring(peer_id: str, body: dict) -> bool:
            print(f"  [bob] ring arrived from {peer_id[:8]}..: {body}")
            return body.get("topic") == "chat"
        bob.signaling.on_ring(on_ring)

        banner("5. Alice rings bob with topic=chat")
        r = alice.signaling.ring(
            bob.peer_id.value, body={"topic": "chat"}, timeout_s=2.0
        )
        print(f"  result: ok={r.ok} session_state={r.session_state}")

        banner("6. Alice sends an OFFER pass-through; bob drains and replies")
        r = alice.signaling.send_passthrough(
            bob.peer_id.value,
            SignalType.OFFER,
            {"sdp": "fake-sdp=v0\r\no=alice 42 2 IN IP4 127.0.0.1\r\n"},
        )
        print(f"  offer sent: ok={r.ok}")
        time.sleep(0.1)
        inbox = bob.signaling.drain_inbox()
        print(f"  bob inbox has {len(inbox)} pass-through message(s)")
        for sender, msg in inbox:
            kind = msg.type
            body = msg.payload.get("body")
            print(f"    • {kind} from {sender[:8]}..: {body}")
            # Reply with an ANSWER.
            if msg.type == SignalType.OFFER.value:
                bob.signaling.send_passthrough(
                    sender,
                    SignalType.ANSWER,
                    {"sdp": "fake-sdp=a0\r\no=bob 7 3 IN IP4 127.0.0.1\r\n"},
                )
        time.sleep(0.1)
        alice_inbox = alice.signaling.drain_inbox()
        print(f"  alice inbox has {len(alice_inbox)} message(s) — "
              f"{[m.type for _, m in alice_inbox]}")

        banner("7. Alice says bye; session closes on both sides")
        alice.signaling.bye(bob.peer_id.value)
        time.sleep(0.05)
        s_a = alice.signaling.session(bob.peer_id.value)
        s_b = bob.signaling.session(alice.peer_id.value)
        print(f"  alice→bob state: {s_a.state.value}")
        print(f"  bob→alice state: {s_b.state.value}")

        banner("8. Bob's audit tail")
        for e in bob.audit.tail(10):
            print("  " + json.dumps(e, sort_keys=True))

        alice.close()
        bob.close()


if __name__ == "__main__":
    main()
