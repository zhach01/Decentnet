"""Phase 3 demo: run every built-in scenario and write SVG + HTML + JSON
timelines. Also shows the virtual clock driving deterministic time
without touching the system clock.

Run with:   python examples/phase3_demo.py

Output goes to /tmp/decentnet-sim/ — open the index.html in each
subdirectory in a browser to step through the snapshots.
"""
from __future__ import annotations

import sys
from pathlib import Path

_REPO = Path(__file__).resolve().parent.parent
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from decentnet.sim import (
    REGISTRY,
    VirtualClock,
    get_scenario,
    run_scenario,
)
from decentnet.utils.time import now_s


def banner(msg: str) -> None:
    print("\n" + "=" * 72)
    print(msg)
    print("=" * 72)


def main() -> None:
    out_root = Path("/tmp/decentnet-sim")
    out_root.mkdir(parents=True, exist_ok=True)

    banner("Virtual clock controls now_s()")
    clock = VirtualClock(start=1_700_000_000.0)
    with clock.install():
        print(f"  inside virtual clock: now_s() = {now_s()}")
        clock.advance(3600)
        print(f"  after advance(3600):  now_s() = {now_s()}")
    print(f"  outside virtual clock: now_s() = {now_s()} (real time)")

    for name in sorted(REGISTRY.keys()):
        banner(f"Running scenario: {name}")
        scenario = get_scenario(name)
        out_dir = out_root / name
        result = run_scenario(scenario, output_dir=out_dir)
        print(f"  snapshots: {len(result.snapshots)}")
        print(f"  artifacts: {out_dir}")
        print(f"    • {out_dir / 'index.html'}  (single-page timeline viewer)")
        print(f"    • {out_dir / 'report.md'}   (human summary)")
        print(f"    • {out_dir / 'report.json'} (machine-readable)")
        # Walk the final snapshot and tally states.
        tally: dict[str, int] = {}
        for n in result.snapshots[-1].nodes:
            tally[n.record_state] = tally.get(n.record_state, 0) + 1
        pretty = "  ".join(f"{k}={v}" for k, v in sorted(tally.items()))
        print(f"  final state tally: {pretty}")

    banner("Done")
    print(f"All scenarios written under {out_root}")
    print("Open any scenario's index.html in a browser to step through its SVGs.")


if __name__ == "__main__":
    main()
