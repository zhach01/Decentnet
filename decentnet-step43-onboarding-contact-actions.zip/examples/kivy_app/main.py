"""Minimal Kivy app demonstrating decentnet mobile integration.

Run (desktop):
    pip install kivy
    python examples/kivy_app/main.py

On Android (via buildozer), see examples/kivy_app/buildozer.spec.

This is a skeleton — it shows:

    * Wiring `MobileNode` to `App.on_start`, `App.on_pause`,
      `App.on_resume`.
    * Listening for network-state changes and reporting them to
      the node (the real hooks live in plyer / pyjnius bindings;
      here we model them with buttons for local testing).
    * A contacts screen that lists cached peers + their confidence.
    * A "ring" button that initiates a signaling session.

Without Kivy installed the module still imports — the Kivy parts
are guarded by `KIVY_AVAILABLE`.
"""
from __future__ import annotations

import sys
from pathlib import Path

# Ensure the decentnet package is on sys.path when running from a
# source checkout.
_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from decentnet.mobile import MobileNode, MobilePolicy, NetworkKind
from decentnet.node import NodeConfig
from decentnet.records.endpoints import Endpoint


try:
    from kivy.app import App
    from kivy.clock import Clock
    from kivy.uix.boxlayout import BoxLayout
    from kivy.uix.button import Button
    from kivy.uix.label import Label
    from kivy.uix.scrollview import ScrollView
    KIVY_AVAILABLE = True
except ImportError:
    KIVY_AVAILABLE = False


def build_node(config_path: str = "./decentnet-data") -> MobileNode:
    """Factory used by the Kivy app and also importable headlessly."""
    cfg = NodeConfig.at(config_path)
    return MobileNode(cfg, policy=MobilePolicy.DEFAULT_MOBILE)


if KIVY_AVAILABLE:

    class DecentnetApp(App):
        def build(self):
            self.mnode = build_node()
            root = BoxLayout(orientation="vertical", padding=10, spacing=6)

            self.status_label = Label(
                text=self._status_text(),
                size_hint_y=None, height=160,
            )
            root.add_widget(self.status_label)

            # Buttons row — simulated lifecycle events for local test.
            row = BoxLayout(size_hint_y=None, height=44, spacing=6)
            for label, fn in [
                ("Foreground", self.mnode.on_enter_foreground),
                ("Background", self.mnode.on_enter_background),
                ("Low Power", self.mnode.on_enter_low_power),
            ]:
                b = Button(text=label)
                b.bind(on_press=lambda _inst, f=fn: self._do(f))
                row.add_widget(b)
            root.add_widget(row)

            net_row = BoxLayout(size_hint_y=None, height=44, spacing=6)
            for label, kind in [
                ("Wi-Fi",    NetworkKind.WIFI),
                ("Cellular", NetworkKind.CELLULAR),
                ("Offline",  NetworkKind.NONE),
            ]:
                b = Button(text=label)
                b.bind(
                    on_press=lambda _inst, k=kind:
                        self._do(lambda: self.mnode.on_network_changed(kind=k))
                )
                net_row.add_widget(b)
            root.add_widget(net_row)

            # Publish button (demo endpoint).
            pub = Button(text="Publish own record", size_hint_y=None, height=44)
            pub.bind(on_press=self._publish)
            root.add_widget(pub)

            # Contacts list.
            self.contacts = BoxLayout(orientation="vertical", size_hint_y=None)
            self.contacts.bind(minimum_height=self.contacts.setter("height"))
            sv = ScrollView()
            sv.add_widget(self.contacts)
            root.add_widget(sv)

            Clock.schedule_interval(self._refresh_ui, 1.5)
            return root

        # ---- lifecycle callbacks ----

        def on_pause(self):
            self.mnode.on_enter_background()
            return True

        def on_resume(self):
            self.mnode.on_enter_foreground()

        def on_stop(self):
            self.mnode.close()

        # ---- actions ----

        def _do(self, fn):
            fn()
            self._refresh_ui(0)

        def _publish(self, *_):
            self.mnode.node.publish_own_record(endpoints=[
                Endpoint(type="public_udp", address="127.0.0.1:1"),
            ])
            self._refresh_ui(0)

        def _status_text(self) -> str:
            s = self.mnode.status()
            return (
                "decentnet (mobile)\n"
                f"peer_id: {s['peer_id'][:16]}…\n"
                f"power:   {s['power_mode']}\n"
                f"network: {s['network_kind']}  paused={s['paused']}\n"
                f"refresh: every {s['refresh_interval_s']}s   "
                f"keepalive: every {s['keepalive_interval_s']}s\n"
                f"deferred queue size: {s['deferred_queue']}"
            )

        def _refresh_ui(self, _dt):
            self.status_label.text = self._status_text()
            self.contacts.clear_widgets()
            for rec, _ in self.mnode.node.cache.entries():
                score = self.mnode.node.confidence.confidence(
                    rec.peer_id, current_seq=rec.seq,
                )
                line = (
                    f"{rec.peer_id[:16]}…  "
                    f"seq={rec.seq}  conf={score:.2f}  "
                    f"{', '.join(e.address for e in rec.endpoints[:2])}"
                )
                self.contacts.add_widget(Label(
                    text=line, size_hint_y=None, height=26,
                    halign="left", valign="middle",
                ))


if __name__ == "__main__":
    if not KIVY_AVAILABLE:
        print("Kivy is not installed. Install with: pip install kivy")
        print("Running a headless demo instead…")
        m = build_node("/tmp/decentnet-kivy-demo")
        print("Initial status:", m.status())
        m.on_enter_background()
        print("Background:   ", m.status())
        m.on_network_changed(kind=NetworkKind.CELLULAR)
        print("On cellular:  ", m.status())
        m.on_enter_low_power()
        print("Low power:    ", m.status())
        m.on_enter_foreground()
        print("Foreground:   ", m.status())
        m.close()
    else:
        DecentnetApp().run()
