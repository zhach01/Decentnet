[app]

title = decentnet
package.name = decentnet
package.domain = org.decentnet

source.dir = .
source.include_exts = py,kv
source.main = main.py

version = 0.1.0

requirements = python3,kivy,cryptography

orientation = portrait
fullscreen = 0

# Android
android.permissions = INTERNET,ACCESS_NETWORK_STATE,ACCESS_WIFI_STATE,CHANGE_WIFI_STATE,WAKE_LOCK
android.api = 33
android.minapi = 24
android.ndk_api = 24
android.archs = arm64-v8a, armeabi-v7a

# iOS
ios.kivy_ios_branch = master
ios.ios_deploy_branch = 1.12.2

[buildozer]
log_level = 2
warn_on_root = 1
