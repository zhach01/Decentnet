"""Tests for production modules: config_file, log, metrics."""
import io
import json
import logging
import tempfile
from pathlib import Path

import pytest

from decentnet.config_file import DecentnetConfig
from decentnet.log import (
    JsonFormatter,
    get_logger,
    reset_logging_for_tests,
    setup_logging,
)
from decentnet.metrics import MetricsRegistry, start_metrics_server


# --------------- config_file ---------------


def test_config_loads_defaults_without_file():
    cfg = DecentnetConfig.load(path=None, env={})
    assert cfg.policies.replicate_all is True
    assert cfg.metrics.enabled is False
    assert cfg.logging.level == "info"


def test_config_loads_from_toml(tmp_path):
    p = tmp_path / "config.toml"
    p.write_text(
        '[node]\n'
        'dht_k = 16\n'
        '[policies]\n'
        'replicate_all = false\n'
        '[logging]\n'
        'level = "debug"\n'
        '[metrics]\n'
        'enabled = true\n'
        'port = 9999\n'
    )
    cfg = DecentnetConfig.load(path=p, env={})
    assert cfg.node.dht_k == 16
    assert cfg.policies.replicate_all is False
    assert cfg.logging.level == "debug"
    assert cfg.metrics.enabled is True
    assert cfg.metrics.port == 9999


def test_config_env_overrides_toml(tmp_path):
    p = tmp_path / "config.toml"
    p.write_text('[logging]\nlevel = "info"\n')
    cfg = DecentnetConfig.load(
        path=p, env={"DECENTNET_LOGGING_LEVEL": "debug"}
    )
    assert cfg.logging.level == "debug"


def test_config_env_type_coercion():
    cfg = DecentnetConfig.load(path=None, env={
        "DECENTNET_NODE_DHT_K": "32",
        "DECENTNET_POLICIES_REPLICATE_ALL": "false",
        "DECENTNET_MOBILE_CELLULAR_MULTIPLIER": "3.5",
    })
    assert cfg.node.dht_k == 32
    assert cfg.policies.replicate_all is False
    assert cfg.mobile.cellular_multiplier == 3.5


def test_config_env_ignores_unknown_sections():
    cfg = DecentnetConfig.load(path=None, env={
        "DECENTNET_SILLY_UNKNOWN": "value",
        "DECENTNET_LOGGING_NOTHING": "x",
    })
    assert cfg.logging.level == "info"  # unchanged


# --------------- log ---------------


def test_setup_logging_idempotent():
    reset_logging_for_tests()
    setup_logging("info")
    n1 = len(logging.getLogger("decentnet").handlers)
    setup_logging("info")  # should be no-op
    n2 = len(logging.getLogger("decentnet").handlers)
    assert n1 == n2
    reset_logging_for_tests()


def test_json_formatter_emits_well_formed_json():
    fmt = JsonFormatter()
    rec = logging.LogRecord(
        name="decentnet.test", level=logging.INFO, pathname="f.py",
        lineno=1, msg="hello", args=(), exc_info=None,
    )
    rec.peer_id = "PID123"
    out = fmt.format(rec)
    d = json.loads(out)
    assert d["level"] == "info"
    assert d["message"] == "hello"
    assert d["peer_id"] == "PID123"


def test_logger_writes_to_stream():
    reset_logging_for_tests()
    buf = io.StringIO()
    setup_logging("debug", stream=buf, structured=True)
    get_logger("probe").info("hello world", extra={"peer_id": "abc"})
    reset_logging_for_tests()
    line = buf.getvalue().strip()
    d = json.loads(line)
    assert d["message"] == "hello world"
    assert d["peer_id"] == "abc"


# --------------- metrics ---------------


def test_metrics_registry_counters_and_gauges():
    r = MetricsRegistry()
    r.counter_inc("http_requests_total", {"code": "200"})
    r.counter_inc("http_requests_total", {"code": "200"})
    r.counter_inc("http_requests_total", {"code": "500"})
    r.gauge_set("pressure_psi", 42.5)
    text = r.prometheus_text()
    assert 'http_requests_total{code="200"} 2' in text
    assert 'http_requests_total{code="500"} 1' in text
    assert "pressure_psi 42.5" in text
    assert "# TYPE http_requests_total counter" in text
    assert "# TYPE pressure_psi gauge" in text


def test_metrics_snapshot_from_node(tmp_path):
    from decentnet.node import Node, NodeConfig
    cfg = NodeConfig.at(tmp_path)
    node = Node(cfg)
    try:
        r = MetricsRegistry()
        r.snapshot_from_node(node)
        text = r.prometheus_text()
        assert "decentnet_cache_records_total" in text
        assert "decentnet_deferred_queue_size" in text
        assert "decentnet_uptime_seconds" in text
    finally:
        node.close()


def test_metrics_http_server_serves_text(tmp_path):
    import urllib.request
    r = MetricsRegistry()
    r.counter_inc("probe_total")
    srv = start_metrics_server(r, "127.0.0.1", 0)
    try:
        url = f"http://{srv.host}:{srv.port}/metrics"
        with urllib.request.urlopen(url, timeout=2.0) as resp:
            body = resp.read().decode("utf-8")
            assert "probe_total 1" in body
            assert resp.status == 200
    finally:
        srv.close()


def test_metrics_http_server_404s_other_paths():
    import urllib.request
    import urllib.error
    r = MetricsRegistry()
    srv = start_metrics_server(r, "127.0.0.1", 0)
    try:
        url = f"http://{srv.host}:{srv.port}/nope"
        with pytest.raises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(url, timeout=2.0)
        assert ctx.value.code == 404
    finally:
        srv.close()
