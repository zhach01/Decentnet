"""Real-UDP transport tests on 127.0.0.1.

These tests use actual OS sockets. Each test creates a pair of
transports on ephemeral ports, exercises send / send_and_wait /
opportunistic-endpoint-learning, and tears them down. Timeouts are
kept small (≤1s) so the suite stays fast.
"""
import threading
import time

import pytest

from decentnet.identity.keypair import Keypair
from decentnet.identity.peer_id import PeerId
from decentnet.transport.messages import (
    Message,
    MsgType,
    TransportTimeoutError,
    UnreachableError,
)
from decentnet.transport.udp import UDPTransport


def _new_pid():
    return PeerId.from_public_key(Keypair.generate().public_key_bytes).value


def test_udp_send_and_wait_ping_pong():
    a_id, b_id = _new_pid(), _new_pid()
    a = UDPTransport(a_id)
    b = UDPTransport(b_id)
    try:
        # A needs to know B's endpoint before first send.
        a.register_endpoint(b_id, b.bind_host, b.bind_port)

        def b_handler(src, msg):
            if msg.type == MsgType.PING.value:
                b.send(src, msg.reply(MsgType.PONG, sender=b_id))
        b.set_receive_handler(b_handler)

        ping = Message.make(MsgType.PING, sender=a_id)
        reply = a.send_and_wait(b_id, ping, timeout_s=1.0)
        assert reply.type == MsgType.PONG.value
        assert reply.in_reply_to == ping.msg_id
    finally:
        a.close()
        b.close()


def test_udp_send_to_unknown_peer_raises():
    a_id = _new_pid()
    a = UDPTransport(a_id)
    try:
        with pytest.raises(UnreachableError):
            a.send("some-unknown-peer-id", Message.make(MsgType.PING, sender=a_id))
    finally:
        a.close()


def test_udp_timeout_when_no_reply():
    a_id, b_id = _new_pid(), _new_pid()
    a = UDPTransport(a_id)
    b = UDPTransport(b_id)
    try:
        a.register_endpoint(b_id, b.bind_host, b.bind_port)
        # B doesn't reply (no handler installed).
        with pytest.raises(TransportTimeoutError):
            a.send_and_wait(
                b_id,
                Message.make(MsgType.PING, sender=a_id),
                timeout_s=0.3,
            )
    finally:
        a.close()
        b.close()


def test_udp_opportunistic_endpoint_learning():
    """B receives from A without A's endpoint being pre-registered on B.
    B should learn A's (host, port) from the first recv and be able to
    reply successfully."""
    a_id, b_id = _new_pid(), _new_pid()
    a = UDPTransport(a_id)
    b = UDPTransport(b_id)
    try:
        a.register_endpoint(b_id, b.bind_host, b.bind_port)

        reply_event = threading.Event()
        received = []

        def b_handler(src, msg):
            received.append((src, msg.type))
            # Reply back — must work without b.register_endpoint(a_id, ...)
            # because the reader learned A's address from the first recv.
            try:
                b.send(src, msg.reply(MsgType.PONG, sender=b_id))
                reply_event.set()
            except Exception:
                pass

        b.set_receive_handler(b_handler)

        def a_handler(src, msg):
            if msg.type == MsgType.PONG.value:
                received.append(("a_got_pong", msg.sender))

        a.set_receive_handler(a_handler)

        # Fire-and-forget send to trigger the reverse path.
        a.send(b_id, Message.make(MsgType.PING, sender=a_id))
        assert reply_event.wait(timeout=1.0), "B never sent a reply"
        # Give A's handler a moment to process the pong.
        time.sleep(0.1)
        assert any(r[0] == "a_got_pong" for r in received)
    finally:
        a.close()
        b.close()


def test_udp_garbage_datagrams_dont_kill_reader():
    """Someone sending raw garbage at our port should be ignored, not
    crash the reader thread."""
    import socket

    b_id = _new_pid()
    b = UDPTransport(b_id)
    try:
        # Send junk.
        junk_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        junk_sock.sendto(b"not-json-at-all", (b.bind_host, b.bind_port))
        junk_sock.sendto(b'{"partial": ', (b.bind_host, b.bind_port))
        junk_sock.close()
        time.sleep(0.1)
        # Transport should still be responsive.
        a_id = _new_pid()
        a = UDPTransport(a_id)
        try:
            a.register_endpoint(b_id, b.bind_host, b.bind_port)

            def b_handler(src, msg):
                b.send(src, msg.reply(MsgType.PONG, sender=b_id))

            b.set_receive_handler(b_handler)
            reply = a.send_and_wait(
                b_id,
                Message.make(MsgType.PING, sender=a_id),
                timeout_s=1.0,
            )
            assert reply.type == MsgType.PONG.value
        finally:
            a.close()
    finally:
        b.close()
