import json
import threading
import urllib.request
from pathlib import Path

from decentnet.cli.main import main, _create_invite_http_server


def test_bundle_export_inspect_import_roundtrip(tmp_path, capsys):
    a = tmp_path / "a"
    b = tmp_path / "b"
    assert main(["--root", str(a), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(a), "publish", "--endpoint", "public_udp:10.0.0.1:45001"]) == 0
    capsys.readouterr()
    bundle = tmp_path / "peer-a-bundle.json"
    assert main(["--root", str(a), "bundle", "export", "--out", str(bundle)]) == 0
    export_out = json.loads(capsys.readouterr().out)
    assert Path(export_out["out"]).exists()

    assert main(["bundle", "inspect", str(bundle), "--json"]) == 0
    inspect_out = json.loads(capsys.readouterr().out)
    assert inspect_out["peer_id"]
    assert "10.0.0.1:45001" in inspect_out["endpoint_addresses"]

    assert main(["--root", str(b), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(b), "bundle", "import", str(bundle), "--json"]) == 0
    import_out = json.loads(capsys.readouterr().out)
    assert import_out["accepted"] is True
    peer_id = inspect_out["peer_id"]
    assert main(["--root", str(b), "show", peer_id, "--json"]) == 0
    shown = json.loads(capsys.readouterr().out)
    assert shown["peer_id"] == peer_id
    assert shown["endpoints"][0]["address"] == "10.0.0.1:45001"


def test_connect_import_only_without_daemon(tmp_path, capsys):
    a = tmp_path / "a"
    b = tmp_path / "b"
    assert main(["--root", str(a), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(a), "publish", "--endpoint", "public_udp:10.0.0.1:45001"]) == 0
    capsys.readouterr()
    bundle = tmp_path / "peer-a-bundle.json"
    assert main(["--root", str(a), "bundle", "export", "--out", str(bundle)]) == 0
    capsys.readouterr()

    assert main(["--root", str(b), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(b), "connect", str(bundle), "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["import_accepted"] is True
    assert out["hello"] is None


def test_join_imports_multiple_bundles_from_args_and_dir(tmp_path, capsys):
    a = tmp_path / "a"
    b = tmp_path / "b"
    c = tmp_path / "c"
    j = tmp_path / "joiner"
    bundles = tmp_path / "bundles"
    bundles.mkdir()
    for root, addr in ((a, '10.0.0.1:45001'), (b, '10.0.0.2:45002'), (c, '10.0.0.3:45003')):
        assert main(["--root", str(root), "init"]) == 0
        capsys.readouterr()
        assert main(["--root", str(root), "publish", "--endpoint", f"public_udp:{addr}"]) == 0
        capsys.readouterr()
    bundle_a = tmp_path / "peer-a-bundle.json"
    assert main(["--root", str(a), "bundle", "export", "--out", str(bundle_a)]) == 0
    capsys.readouterr()
    assert main(["--root", str(b), "bundle", "export", "--out", str(bundles / "peer-b-bundle.json")]) == 0
    capsys.readouterr()
    assert main(["--root", str(c), "bundle", "export", "--out", str(bundles / "peer-c-bundle.json")]) == 0
    capsys.readouterr()

    assert main(["--root", str(j), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(j), "join", str(bundle_a), "--dir", str(bundles), "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["imported"] == 3
    assert out["accepted"] == 3
    peer_ids = {p["peer_id"] for p in out["peers"]}
    assert len(peer_ids) == 3


def test_join_errors_when_no_bundles_found(tmp_path, capsys):
    j = tmp_path / "joiner"
    assert main(["--root", str(j), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(j), "join", "--dir", str(tmp_path / "missing"), "--json"]) == 1


def test_meshpack_export_inspect_import_roundtrip(tmp_path, capsys):
    a = tmp_path / "a"
    b = tmp_path / "b"
    c = tmp_path / "c"
    joiner = tmp_path / "joiner"
    for root, addr in ((a, '10.0.0.1:45001'), (b, '10.0.0.2:45002')):
        assert main(["--root", str(root), "init"]) == 0
        capsys.readouterr()
        assert main(["--root", str(root), "publish", "--endpoint", f"public_udp:{addr}"]) == 0
        capsys.readouterr()
    bundle_b = tmp_path / "peer-b-bundle.json"
    assert main(["--root", str(b), "bundle", "export", "--out", str(bundle_b)]) == 0
    capsys.readouterr()

    meshpack = tmp_path / "starter-mesh.json"
    assert main(["--root", str(a), "meshpack", "export", "--include-self", str(bundle_b), "--out", str(meshpack)]) == 0
    export_out = json.loads(capsys.readouterr().out)
    assert export_out["peer_count"] == 2
    assert Path(export_out["out"]).exists()

    assert main(["meshpack", "inspect", str(meshpack), "--json"]) == 0
    inspect_out = json.loads(capsys.readouterr().out)
    assert inspect_out["peer_count"] == 2
    peer_ids = {p["peer_id"] for p in inspect_out["peers"]}
    assert len(peer_ids) == 2

    assert main(["--root", str(joiner), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(joiner), "meshpack", "import", str(meshpack), "--json"]) == 0
    imported = json.loads(capsys.readouterr().out)
    assert imported["accepted"] == 2
    assert imported["meshpack_peer_count"] == 2


def test_meshpack_export_errors_when_no_bundles_found(tmp_path, capsys):
    root = tmp_path / "a"
    assert main(["--root", str(root), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(root), "meshpack", "export"]) == 1


def test_invite_export_inspect_import_roundtrip(tmp_path, capsys):
    a = tmp_path / "a"
    b = tmp_path / "b"
    assert main(["--root", str(a), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(a), "publish", "--endpoint", "public_udp:10.0.0.1:45001"]) == 0
    capsys.readouterr()
    invite = tmp_path / "peer-a-invite.json"
    assert main(["--root", str(a), "invite", "export", "--out", str(invite), "--print-token"]) == 0
    export_out = json.loads(capsys.readouterr().out)
    assert Path(export_out["out"]).exists()
    token = export_out["invite_token"]
    assert token

    assert main(["invite", "inspect", "--file", str(invite), "--json"]) == 0
    inspect_file = json.loads(capsys.readouterr().out)
    assert inspect_file["peer_id"]
    assert "10.0.0.1:45001" in inspect_file["endpoint_addresses"]

    assert main(["invite", "inspect", "--token", token, "--json"]) == 0
    inspect_token = json.loads(capsys.readouterr().out)
    assert inspect_token["peer_id"] == inspect_file["peer_id"]

    assert main(["--root", str(b), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(b), "invite", "import", "--file", str(invite), "--json"]) == 0
    imported = json.loads(capsys.readouterr().out)
    assert imported["accepted"] is True
    peer_id = inspect_file["peer_id"]
    assert main(["--root", str(b), "show", peer_id, "--json"]) == 0
    shown = json.loads(capsys.readouterr().out)
    assert shown["peer_id"] == peer_id
    assert shown["endpoints"][0]["address"] == "10.0.0.1:45001"


def test_invite_import_from_token(tmp_path, capsys):
    a = tmp_path / "a"
    b = tmp_path / "b"
    assert main(["--root", str(a), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(a), "publish", "--endpoint", "public_udp:10.0.0.1:45001"]) == 0
    capsys.readouterr()
    assert main(["--root", str(a), "invite", "export", "--print-token"]) == 0
    export_out = json.loads(capsys.readouterr().out)
    token = export_out["invite_token"]

    assert main(["--root", str(b), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(b), "invite", "import", "--token", token, "--json"]) == 0
    imported = json.loads(capsys.readouterr().out)
    assert imported["accepted"] is True


def test_invite_export_url_and_html_roundtrip(tmp_path, capsys):
    a = tmp_path / "a"
    b = tmp_path / "b"
    assert main(["--root", str(a), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(a), "publish", "--endpoint", "public_udp:10.0.0.1:45001"]) == 0
    capsys.readouterr()
    invite = tmp_path / "peer-a-invite.json"
    url_txt = tmp_path / "peer-a-invite.url.txt"
    html_path = tmp_path / "peer-a-invite.html"
    assert main(["--root", str(a), "invite", "export", "--out", str(invite), "--url-out", str(url_txt), "--html-out", str(html_path), "--print-url"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["invite_url"].startswith("decentnet://invite?token=")
    assert out["invite_url_printed"] == out["invite_url"]
    assert Path(out["url_out"]).read_text(encoding="utf-8").strip() == out["invite_url"]
    html_text = Path(out["html_out"]).read_text(encoding="utf-8")
    assert "DecentNet Peer Invite" in html_text
    assert out["invite_url"] in html_text

    assert main(["invite", "inspect", "--url", out["invite_url"], "--json"]) == 0
    inspected = json.loads(capsys.readouterr().out)
    assert inspected["peer_id"]

    assert main(["--root", str(b), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(b), "invite", "import", "--url", out["invite_url"], "--json"]) == 0
    imported = json.loads(capsys.readouterr().out)
    assert imported["accepted"] is True


def test_invite_serve_info_and_import_endpoint(tmp_path, capsys):
    a = tmp_path / "a"
    b = tmp_path / "b"
    assert main(["--root", str(a), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(a), "publish", "--endpoint", "public_udp:10.0.0.1:45001"]) == 0
    capsys.readouterr()
    assert main(["--root", str(a), "invite", "export", "--print-token"]) == 0
    invite_out = json.loads(capsys.readouterr().out)
    token = invite_out["invite_token"]

    assert main(["--root", str(b), "init"]) == 0
    capsys.readouterr()

    server = _create_invite_http_server(str(b), None, "127.0.0.1", 0)
    thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True)
    thread.start()
    try:
        host, port = server.server_address[:2]
        with urllib.request.urlopen(f"http://{host}:{port}/api/info", timeout=3) as resp:
            info = json.loads(resp.read().decode("utf-8"))
        assert info["ok"] is True
        assert info["has_self_bundle"] is False

        req = urllib.request.Request(
            f"http://{host}:{port}/api/import",
            data=json.dumps({"token": token}).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=3) as resp:
            imported = json.loads(resp.read().decode("utf-8"))
        assert imported["accepted"] is True
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)

    peer_id = invite_out["peer_id"]
    assert main(["--root", str(b), "show", peer_id, "--json"]) == 0
    shown = json.loads(capsys.readouterr().out)
    assert shown["peer_id"] == peer_id
    assert shown["endpoints"][0]["address"] == "10.0.0.1:45001"


def test_invite_export_qr_outputs_and_serve_qr_svg(tmp_path, capsys):
    a = tmp_path / "a"
    assert main(["--root", str(a), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(a), "publish", "--endpoint", "public_udp:10.0.0.1:45001"]) == 0
    capsys.readouterr()
    invite = tmp_path / "peer-a-invite.json"
    svg_path = tmp_path / "peer-a-invite-qr.svg"
    png_path = tmp_path / "peer-a-invite-qr.png"
    html_path = tmp_path / "peer-a-invite.html"
    assert main(["--root", str(a), "invite", "export", "--out", str(invite), "--qr-svg-out", str(svg_path), "--qr-png-out", str(png_path), "--html-out", str(html_path), "--print-url"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert Path(out["qr_svg_out"]).exists()
    assert Path(out["qr_png_out"]).exists()
    assert Path(out["qr_svg_out"]).read_text(encoding="utf-8").lstrip().startswith("<?xml") or "<svg" in Path(out["qr_svg_out"]).read_text(encoding="utf-8")
    assert Path(out["qr_png_out"]).read_bytes().startswith(bytes([137, 80, 78, 71]))
    html_text = Path(out["html_out"]).read_text(encoding="utf-8")
    assert "data:image/svg+xml;base64," in html_text

    server = _create_invite_http_server(str(a), None, "127.0.0.1", 0)
    thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True)
    thread.start()
    try:
        host, port = server.server_address[:2]
        with urllib.request.urlopen(f"http://{host}:{port}/qr.svg", timeout=3) as resp:
            svg = resp.read().decode("utf-8")
        assert "<svg" in svg
        with urllib.request.urlopen(f"http://{host}:{port}/api/info", timeout=3) as resp:
            info = json.loads(resp.read().decode("utf-8"))
        assert info["qr_svg_url"].endswith("/qr.svg")
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)



def test_invite_server_lists_nearby_peers_and_page_mentions_refresh(tmp_path, capsys):
    a = tmp_path / "a"
    b = tmp_path / "b"
    assert main(["--root", str(a), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(a), "publish", "--endpoint", "public_udp:10.0.0.1:45001"]) == 0
    capsys.readouterr()
    bundle = tmp_path / "a.bundle.json"
    assert main(["--root", str(a), "bundle", "export", "--out", str(bundle)]) == 0
    capsys.readouterr()

    assert main(["--root", str(b), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(b), "bundle", "import", str(bundle), "--json"]) == 0
    capsys.readouterr()

    server = _create_invite_http_server(str(b), None, "127.0.0.1", 0)
    thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True)
    thread.start()
    try:
        host, port = server.server_address[:2]
        with urllib.request.urlopen(f"http://{host}:{port}/api/peers", timeout=3) as resp:
            peers = json.loads(resp.read().decode("utf-8"))
        assert peers["ok"] is True
        assert len(peers["peers"]) >= 1
        assert peers["peers"][0]["invite_url"]
        with urllib.request.urlopen(f"http://{host}:{port}/", timeout=3) as resp:
            page = resp.read().decode("utf-8")
        assert "Nearby known peers" in page
        assert "auto refresh every 5s" in page
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


def test_invite_server_nearby_peers_include_session_status(tmp_path, capsys, monkeypatch):
    import importlib
    cli_main = importlib.import_module("decentnet.cli.main")
    a = tmp_path / "a"
    b = tmp_path / "b"
    assert main(["--root", str(a), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(a), "publish", "--endpoint", "public_udp:10.0.0.1:45001"]) == 0
    out = capsys.readouterr().out
    peer_id = out.strip().split()[-1]

    bundle = tmp_path / "a.bundle.json"
    assert main(["--root", str(a), "bundle", "export", "--out", str(bundle)]) == 0
    capsys.readouterr()
    assert main(["--root", str(b), "init"]) == 0
    capsys.readouterr()
    assert main(["--root", str(b), "bundle", "import", str(bundle), "--json"]) == 0
    capsys.readouterr()

    def fake_daemon_json_call(_socket_path, body):
        if body.get("cmd") == "signaling.sessions":
            return {"ok": True, "sessions": [{
                "peer_id": peer_id,
                "trusted": True,
                "state": "established",
                "last_seen": 4102444800,
                "selected_pair_kind": "srflx/srflx",
                "selected_path_failures": 0,
            }]}
        return {"ok": False, "error": "unexpected"}

    monkeypatch.setattr(cli_main, "_daemon_json_call", fake_daemon_json_call)

    server = _create_invite_http_server(str(b), None, "127.0.0.1", 0)
    thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True)
    thread.start()
    try:
        host, port = server.server_address[:2]
        with urllib.request.urlopen(f"http://{host}:{port}/api/peers", timeout=3) as resp:
            peers = json.loads(resp.read().decode("utf-8"))
        assert peers["ok"] is True
        row = peers["peers"][0]
        assert row["trusted"] is True
        assert row["session_state"] == "established"
        assert row["selected_pair_kind"] == "srflx/srflx"
        with urllib.request.urlopen(f"http://{host}:{port}/", timeout=3) as resp:
            page = resp.read().decode("utf-8")
        assert "trusted" in page
        assert "session:" in page
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


def test_invite_server_contact_endpoint_and_page_actions(tmp_path, capsys, monkeypatch):
    import importlib
    cli_main = importlib.import_module("decentnet.cli.main")
    b = tmp_path / "b"
    assert main(["--root", str(b), "init"]) == 0
    capsys.readouterr()

    calls = []
    def fake_daemon_json_call(_socket_path, body):
        calls.append(body)
        if body.get("cmd") == "signaling.hello":
            return {"ok": True, "state": "established", "peer_id": body.get("peer_id")}
        if body.get("cmd") == "signaling.ring":
            return {"ok": True, "state": "in_call", "peer_id": body.get("peer_id")}
        if body.get("cmd") == "signaling.sessions":
            return {"ok": True, "sessions": []}
        return {"ok": False, "error": "unexpected"}

    monkeypatch.setattr(cli_main, "_daemon_json_call", fake_daemon_json_call)

    server = _create_invite_http_server(str(b), None, "127.0.0.1", 0)
    thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True)
    thread.start()
    try:
        host, port = server.server_address[:2]
        with urllib.request.urlopen(f"http://{host}:{port}/", timeout=3) as resp:
            page = resp.read().decode("utf-8")
        assert "Hello" in page
        assert "Ring" in page

        req = urllib.request.Request(
            f"http://{host}:{port}/api/contact",
            data=json.dumps({"peer_id": "peer-x", "ring": True, "body": {"msg": "hi"}}).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=3) as resp:
            out = json.loads(resp.read().decode("utf-8"))
        assert out["ok"] is True
        assert out["hello"]["ok"] is True
        assert out["ring"]["ok"] is True
        cmd_calls = [c["cmd"] for c in calls if c.get("cmd") != "signaling.sessions"]
        assert cmd_calls[:2] == ["signaling.hello", "signaling.ring"]
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)
