"""Fuzz / property-based tests for every wire-format parser.

Every parser in the system that consumes attacker-controllable
bytes gets stress-tested here. The property is simple: for any
byte string, the parser either (a) returns a valid parsed object
or (b) raises a documented exception type — but never crashes
the interpreter and never returns a half-parsed object.

Uses `hypothesis` (optional dep, skip if absent).
"""
import pytest

pytest.importorskip("hypothesis")

import json
from hypothesis import given, settings, strategies as st

from decentnet.nat.stun import (
    is_stun_packet,
    parse_stun_message,
    build_binding_request,
    build_binding_success_response,
    find_change_request,
)
from decentnet.utils.cbor import canonical_cbor, decode_cbor
from decentnet.signaling.messages import verify_envelope


# ------------------------- STUN --------------------------


@given(st.binary(min_size=0, max_size=1600))
@settings(max_examples=200, deadline=None)
def test_fuzz_stun_parse_never_crashes(data):
    """Any byte string either parses or raises ValueError. Nothing else."""
    try:
        if is_stun_packet(data):
            parse_stun_message(data)
    except ValueError:
        pass
    # Any other exception is a bug.


@given(st.binary(min_size=0, max_size=1600))
@settings(max_examples=200, deadline=None)
def test_fuzz_find_change_request_never_crashes(data):
    try:
        find_change_request(data)
    except ValueError:
        pass


@given(
    host_bytes=st.sampled_from([b"\x7f\x00\x00\x01", b"\x01\x02\x03\x04"]),
    port=st.integers(min_value=0, max_value=65535),
)
@settings(max_examples=50, deadline=None)
def test_fuzz_stun_response_roundtrip(host_bytes, port):
    """Any valid (host, port) builds a response we can re-parse."""
    _, tid = build_binding_request()
    host = ".".join(str(b) for b in host_bytes)
    data = build_binding_success_response(tid, (host, port))
    resp = parse_stun_message(data)
    assert resp.mapped_address is not None
    assert resp.mapped_address[0] == host
    assert resp.mapped_address[1] == port


@given(st.binary(min_size=20, max_size=1500))
@settings(max_examples=100, deadline=None)
def test_fuzz_stun_bit_flips(data):
    """Bit-flipping a well-formed STUN message should degrade
    gracefully, not crash."""
    if not is_stun_packet(data):
        return
    # Flip every byte once.
    for i in range(min(len(data), 64)):
        flipped = bytearray(data)
        flipped[i] ^= 0xFF
        try:
            parse_stun_message(bytes(flipped))
        except (ValueError, IndexError):
            pass


# ------------------------- CBOR --------------------------


cbor_value = st.recursive(
    st.one_of(
        st.none(),
        st.booleans(),
        st.integers(min_value=-(2 ** 40), max_value=2 ** 40),
        st.floats(allow_nan=False, allow_infinity=False, width=64),
        st.text(max_size=64),
        st.binary(max_size=64),
    ),
    lambda children: st.one_of(
        st.lists(children, max_size=5),
        st.dictionaries(st.text(max_size=16), children, max_size=5),
    ),
    max_leaves=8,
)


@given(cbor_value)
@settings(max_examples=300, deadline=None)
def test_cbor_roundtrip_any_value(v):
    """encode/decode is the identity on supported types."""
    data = canonical_cbor(v)
    decoded = decode_cbor(data)
    assert decoded == v


@given(st.binary(min_size=0, max_size=512))
@settings(max_examples=300, deadline=None)
def test_cbor_decode_never_crashes(data):
    try:
        decode_cbor(data)
    except (ValueError, UnicodeDecodeError, OverflowError, RecursionError):
        pass


@given(cbor_value)
@settings(max_examples=100, deadline=None)
def test_cbor_canonical_deterministic(v):
    """Same input → exactly identical bytes."""
    assert canonical_cbor(v) == canonical_cbor(v)


# ------------------------- Signaling envelope ---------------


@given(st.binary(min_size=0, max_size=1024))
@settings(max_examples=200, deadline=None)
def test_fuzz_signaling_envelope_never_crashes(data):
    """`verify_envelope` parses attacker bytes and either returns a
    verdict (bool) or raises ValueError. No other exception type."""
    try:
        # Use a dummy public key — we're testing the parser's
        # robustness, not the crypto.
        dummy_pub = b"\x00" * 32
        verify_envelope(data, dummy_pub)
    except (ValueError, json.JSONDecodeError, KeyError, TypeError):
        pass


# ------------------------- LocatorRecord --------------------


@given(st.binary(min_size=0, max_size=1024))
@settings(max_examples=100, deadline=None)
def test_fuzz_locator_record_parse_never_crashes(data):
    from decentnet.records.locator import LocatorRecord
    try:
        LocatorRecord.from_wire_bytes(data)
    except (ValueError, json.JSONDecodeError, KeyError, TypeError):
        pass


# ------------------------- Snapshot -----------------------


@given(st.binary(min_size=0, max_size=2048))
@settings(max_examples=100, deadline=None)
def test_fuzz_snapshot_parse_never_crashes(data):
    from decentnet.repair.snapshot import GlobalSnapshot
    try:
        GlobalSnapshot.from_bytes(data)
    except (ValueError, json.JSONDecodeError, KeyError, TypeError):
        pass
