import pytest

from decentnet.identity.keypair import Keypair, verify_with_public_key
from decentnet.identity.peer_id import PeerId


def test_keypair_generate_and_sign_verify():
    kp = Keypair.generate()
    msg = b"hello"
    sig = kp.sign(msg)
    assert kp.verify(msg, sig)
    assert not kp.verify(b"other", sig)


def test_keypair_roundtrip_to_disk(tmp_path):
    kp1 = Keypair.generate()
    path = tmp_path / "id.json"
    kp1.save(path)
    kp2 = Keypair.load(path)
    assert kp1.public_key_bytes == kp2.public_key_bytes
    assert kp1.private_key_bytes == kp2.private_key_bytes
    msg = b"test"
    sig = kp2.sign(msg)
    assert kp1.verify(msg, sig)


def test_load_or_create_is_stable(tmp_path):
    path = tmp_path / "id.json"
    kp1 = Keypair.load_or_create(path)
    kp2 = Keypair.load_or_create(path)
    assert kp1.public_key_bytes == kp2.public_key_bytes


def test_public_only_keypair_cannot_sign():
    kp = Keypair.generate()
    pub_only = Keypair.from_public_bytes(kp.public_key_bytes)
    with pytest.raises(ValueError):
        pub_only.sign(b"x")


def test_verify_with_public_key_rejects_bad_sig():
    kp = Keypair.generate()
    sig = kp.sign(b"hello")
    # Flip a bit.
    bad = bytearray(sig)
    bad[0] ^= 0x01
    assert not verify_with_public_key(
        kp.public_key_bytes, b"hello", bytes(bad)
    )


def test_peer_id_from_public_key_stable():
    kp = Keypair.generate()
    p1 = PeerId.from_public_key(kp.public_key_bytes)
    p2 = PeerId.from_public_key(kp.public_key_bytes)
    assert p1 == p2


def test_peer_id_roundtrip_string():
    kp = Keypair.generate()
    pid = PeerId.from_public_key(kp.public_key_bytes)
    assert PeerId.from_string(str(pid)) == pid
    assert pid.matches_public_key(kp.public_key_bytes)


def test_peer_id_rejects_garbage():
    with pytest.raises(Exception):
        PeerId.from_string("")
    with pytest.raises(Exception):
        PeerId.from_string("not-valid-base32!!!")


def test_different_keys_give_different_peer_ids():
    ids = {
        PeerId.from_public_key(Keypair.generate().public_key_bytes).value
        for _ in range(20)
    }
    assert len(ids) == 20
