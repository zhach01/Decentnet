"""Tests for the MobileNode lifecycle wrapper."""
import tempfile
from pathlib import Path

import pytest

from decentnet.mobile import (
    MobileNode,
    MobilePolicy,
    NetworkKind,
    PowerMode,
)
from decentnet.node import NodeConfig
from decentnet.records.endpoints import Endpoint


def test_mobile_node_lifecycle(tmp_path):
    cfg = NodeConfig.at(tmp_path / "m")
    m = MobileNode(cfg, policy=MobilePolicy.DEFAULT_DESKTOP)
    try:
        assert m.power_mode == PowerMode.FOREGROUND
        m.on_enter_background()
        assert m.power_mode == PowerMode.BACKGROUND
        m.on_enter_foreground()
        assert m.power_mode == PowerMode.FOREGROUND
        m.on_enter_low_power()
        assert m.power_mode == PowerMode.LOW_POWER
    finally:
        m.close()


def test_mobile_node_policy_affects_intervals(tmp_path):
    cfg = NodeConfig.at(tmp_path / "m")
    m = MobileNode(cfg, policy=MobilePolicy.DEFAULT_MOBILE)
    try:
        fg = m._current_refresh_interval()
        m.on_enter_background()
        bg = m._current_refresh_interval()
        m.on_enter_low_power()
        lp = m._current_refresh_interval()
        assert fg < bg < lp
    finally:
        m.close()


def test_mobile_node_cellular_scales_intervals(tmp_path):
    cfg = NodeConfig.at(tmp_path / "m")
    m = MobileNode(cfg, policy=MobilePolicy.DEFAULT_MOBILE)
    try:
        wifi_i = m._current_refresh_interval()
        m.on_network_changed(kind=NetworkKind.CELLULAR)
        cell_i = m._current_refresh_interval()
        assert cell_i >= wifi_i * 2
    finally:
        m.close()


def test_mobile_node_offline_pauses(tmp_path):
    cfg = NodeConfig.at(tmp_path / "m")
    m = MobileNode(cfg)
    try:
        assert not m.is_paused
        m.on_network_changed(kind=NetworkKind.NONE)
        assert m.is_paused
        m.on_network_changed(kind=NetworkKind.WIFI)
        assert not m.is_paused
    finally:
        m.close()


def test_mobile_node_coming_online_drains_deferred(tmp_path):
    from decentnet.transport.inproc import InProcessNetwork
    net = InProcessNetwork()
    cfg = NodeConfig.at(tmp_path / "m")
    m = MobileNode(cfg, policy=MobilePolicy.DEFAULT_DESKTOP, network=net)
    try:
        m.node.publish_own_record(endpoints=[
            Endpoint(type="public_udp", address="1.1.1.1:1"),
        ])
        m.node.queue_publish_deferred()
        assert m.node.deferred.size() == 1
        # Go offline then back online.
        m.on_network_changed(kind=NetworkKind.NONE)
        m.on_network_changed(kind=NetworkKind.WIFI)
        # Deferred queue should have been drained (self counts as a peer).
        assert m.node.deferred.size() == 0
    finally:
        m.close()


def test_mobile_status_snapshot(tmp_path):
    cfg = NodeConfig.at(tmp_path / "m")
    m = MobileNode(cfg)
    try:
        s = m.status()
        assert "peer_id" in s
        assert s["power_mode"] == "foreground"
        assert s["network_kind"] == "wifi"
        assert "refresh_interval_s" in s
        assert "keepalive_interval_s" in s
    finally:
        m.close()


def test_mobile_low_power_policy_disables_keepalive(tmp_path):
    cfg = NodeConfig.at(tmp_path / "m")
    m = MobileNode(cfg, policy=MobilePolicy.DEFAULT_LOW_POWER)
    try:
        m.on_enter_low_power()
        assert m._current_keepalive_interval() == 0
    finally:
        m.close()
