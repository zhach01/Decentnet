import pytest

from decentnet.dht.distance import (
    ID_BITS,
    bucket_index,
    sort_by_distance,
    xor_distance,
)
from decentnet.dht.routing import Contact, KBucket, RoutingTable
from decentnet.dht.storage import DHTStore
from decentnet.identity.keypair import Keypair
from decentnet.identity.peer_id import PeerId
from decentnet.records.endpoints import Endpoint
from decentnet.records.locator import LocatorRecord


def new_peer_id() -> str:
    return PeerId.from_public_key(Keypair.generate().public_key_bytes).value


# ---------------- distance ----------------


def test_xor_distance_self_is_zero():
    p = new_peer_id()
    assert xor_distance(p, p) == 0


def test_xor_distance_symmetric():
    a, b = new_peer_id(), new_peer_id()
    assert xor_distance(a, b) == xor_distance(b, a)


def test_bucket_index_range():
    a, b = new_peer_id(), new_peer_id()
    idx = bucket_index(a, b)
    assert -1 <= idx < ID_BITS
    # For two distinct random 256-bit ids, index is almost always high;
    # but all we can guarantee is non-negative.
    assert idx >= 0


def test_sort_by_distance_orders_correctly():
    t = new_peer_id()
    ids = [new_peer_id() for _ in range(10)]
    ordered = sort_by_distance(t, ids)
    distances = [xor_distance(i, t) for i in ordered]
    assert distances == sorted(distances)


# ---------------- k-bucket ----------------


def test_kbucket_insert_under_cap():
    b = KBucket(k=3)
    for i in range(3):
        b.touch_or_insert(Contact(peer_id=new_peer_id()))
    assert len(b) == 3


def test_kbucket_full_no_ping_evicts_lru():
    b = KBucket(k=2)
    c1 = Contact(peer_id=new_peer_id())
    c2 = Contact(peer_id=new_peer_id())
    b.touch_or_insert(c1)
    b.touch_or_insert(c2)
    # Full. Add new without ping_cb → default: evict oldest (c1).
    c3 = Contact(peer_id=new_peer_id())
    b.touch_or_insert(c3)
    ids = {c.peer_id for c in b.contacts()}
    assert c1.peer_id not in ids
    assert c3.peer_id in ids


def test_kbucket_full_ping_alive_keeps_old():
    b = KBucket(k=1)
    old = Contact(peer_id=new_peer_id())
    b.touch_or_insert(old)
    new = Contact(peer_id=new_peer_id())
    # ping_cb says "alive" → keep old, drop new.
    inserted = b.touch_or_insert(new, ping_cb=lambda c: True)
    assert not inserted
    assert [c.peer_id for c in b.contacts()] == [old.peer_id]


def test_kbucket_refresh_moves_to_most_recent():
    b = KBucket(k=2)
    c1 = Contact(peer_id=new_peer_id())
    c2 = Contact(peer_id=new_peer_id())
    b.touch_or_insert(c1)
    b.touch_or_insert(c2)
    # Refresh c1 — it should now be youngest.
    b.touch_or_insert(Contact(peer_id=c1.peer_id))
    assert b.contacts()[-1].peer_id == c1.peer_id


# ---------------- routing table ----------------


def test_routing_table_ignores_self():
    self_id = new_peer_id()
    rt = RoutingTable(self_id, k=4)
    assert not rt.observe(self_id)
    assert rt.size() == 0


def test_routing_table_closest_returns_k():
    self_id = new_peer_id()
    rt = RoutingTable(self_id, k=4)
    for _ in range(20):
        rt.observe(new_peer_id())
    target = new_peer_id()
    closest = rt.closest(target, 4)
    assert len(closest) == 4
    # Verify ordering.
    ds = [xor_distance(c.peer_id, target) for c in closest]
    assert ds == sorted(ds)


# ---------------- DHT store ----------------


def test_dht_store_accepts_and_returns():
    store = DHTStore()
    kp = Keypair.generate()
    rec = LocatorRecord.build_and_sign(
        kp, endpoints=[Endpoint(type="public_udp", address="1.1.1.1:1")], seq=1,
    )
    assert store.put(rec).accepted
    got = store.get(rec.peer_id)
    assert got is not None
    assert got.seq == 1


def test_dht_store_rejects_rollback():
    store = DHTStore()
    kp = Keypair.generate()
    r1 = LocatorRecord.build_and_sign(
        kp, endpoints=[Endpoint(type="public_udp", address="1.1.1.1:1")], seq=5,
    )
    r2 = LocatorRecord.build_and_sign(
        kp, endpoints=[Endpoint(type="public_udp", address="1.1.1.1:2")], seq=3,
    )
    assert store.put(r1).accepted
    r = store.put(r2)
    assert not r.accepted
    assert r.reason == "not_newer"


def test_dht_store_rejects_future_issued_at():
    import decentnet.records.validation as v

    store = DHTStore(max_future_skew_s=60)
    kp = Keypair.generate()
    # Far future.
    rec = LocatorRecord.build_and_sign(
        kp,
        endpoints=[Endpoint(type="public_udp", address="1.1.1.1:1")],
        seq=1,
        issued_at=10**11,   # ~ year 5138
    )
    r = store.put(rec)
    assert not r.accepted
    assert r.reason == "issued_in_future"


def test_dht_store_summary_shape():
    store = DHTStore()
    for i in range(3):
        kp = Keypair.generate()
        rec = LocatorRecord.build_and_sign(
            kp,
            endpoints=[Endpoint(type="public_udp", address=f"1.1.1.{i}:1")],
            seq=i + 1,
        )
        assert store.put(rec).accepted
    summary = store.summary()
    assert len(summary) == 3
    for entry in summary:
        assert len(entry) == 3
        pid, seq, issued = entry
        assert isinstance(pid, str) and isinstance(seq, int) and isinstance(issued, int)
