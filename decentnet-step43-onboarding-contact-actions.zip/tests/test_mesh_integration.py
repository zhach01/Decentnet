import time

from decentnet.testing import LocalUDPMeshLab
from decentnet.transport.messages import UnreachableError



def _wait_until(predicate, *, timeout_s: float = 2.0, step_s: float = 0.02):
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        if predicate():
            return True
        time.sleep(step_s)
    return predicate()



def test_three_node_udp_mesh_establishes_and_carries_calls(tmp_path):
    with LocalUDPMeshLab(tmp_path / "mesh3", with_relay=False) as lab:
        for name in ("a", "b", "c"):
            lab.add_node(name)
        lab.publish_all()
        lab.bootstrap_full_mesh()

        assert lab.hello("a", "b").ok
        assert lab.hello("b", "c").ok
        assert lab.hello("c", "a").ok
        assert lab.ring("a", "b", body={"topic": "ab"}).ok
        assert lab.ring("b", "c", body={"topic": "bc"}).ok
        assert lab.ring("c", "a", body={"topic": "ca"}).ok

        for src, dst in (("a", "b"), ("b", "c"), ("c", "a")):
            sess = lab.nodes[src].node.signaling.session(lab.nodes[dst].peer_id)
            assert sess is not None
            assert sess.selected_remote_addr is not None
            assert sess.selected_pair_kind is not None
            assert sess.state.value in ("established", "in_call")



def test_three_node_mesh_rebind_and_candidate_refresh_recovers_path(tmp_path):
    with LocalUDPMeshLab(tmp_path / "mesh-rebind", with_relay=False) as lab:
        for name in ("a", "b", "c"):
            lab.add_node(name)
        lab.publish_all()
        lab.bootstrap_full_mesh()

        assert lab.hello("a", "b").ok
        assert lab.hello("c", "b").ok
        old_rec = lab.nodes["a"].node.cache.peek(lab.nodes["b"].peer_id)
        assert old_rec is not None
        old_seq = old_rec.seq

        _, new_port = lab.rebind_node("b")
        assert lab.hello("b", "a", timeout_s=1.0).ok
        assert lab.hello("b", "c", timeout_s=1.0).ok
        assert lab.refresh_candidates("b", "a", reason="b_rebind").ok
        assert lab.refresh_candidates("b", "c", reason="b_rebind").ok

        def updated_on_a():
            rec = lab.nodes["a"].node.cache.peek(lab.nodes["b"].peer_id)
            return rec is not None and rec.seq > old_seq and rec.endpoints[0].address == f"127.0.0.1:{new_port}"

        assert _wait_until(updated_on_a)
        assert lab.keepalive("a", "b").ok
        assert lab.keepalive("c", "b").ok
        assert lab.ring("a", "b", body={"topic": "rebind"}, timeout_s=0.6).ok



def test_mixed_relay_and_direct_paths_can_coexist_in_same_mesh(tmp_path, monkeypatch):
    with LocalUDPMeshLab(tmp_path / "mesh-mixed", with_relay=True) as lab:
        for name in ("a", "b", "c"):
            lab.add_node(name)
        lab.publish_all()
        lab.bootstrap_full_mesh()

        a_addr = lab.nodes["a"].bind_addr
        b_addr = lab.nodes["b"].bind_addr
        # Force A<->B to have no direct route entry, so relay fallback can kick in.
        lab.clear_route("a", "b")
        lab.clear_route("b", "a")

        original_a_send_raw = lab.nodes["a"].transport.send_raw
        original_b_send_raw = lab.nodes["b"].transport.send_raw

        def a_send_raw_block_direct(data, addr):
            if addr == b_addr:
                raise UnreachableError("blocked a->b direct")
            return original_a_send_raw(data, addr)

        def b_send_raw_block_direct(data, addr):
            if addr == a_addr:
                raise UnreachableError("blocked b->a direct")
            return original_b_send_raw(data, addr)

        monkeypatch.setattr(lab.nodes["a"].transport, "send_raw", a_send_raw_block_direct)
        monkeypatch.setattr(lab.nodes["b"].transport, "send_raw", b_send_raw_block_direct)
        assert lab.ensure_relay_pair("a", "b") is not None
        assert lab.ensure_relay_pair("b", "a") is not None

        res_ab = lab.hello("a", "b", timeout_s=1.0)
        assert res_ab.ok, res_ab.reason
        assert lab.hello("b", "c", timeout_s=0.8).ok

        sess_ab = lab.nodes["a"].node.signaling.session(lab.nodes["b"].peer_id)
        sess_bc = lab.nodes["b"].node.signaling.session(lab.nodes["c"].peer_id)
        assert sess_ab is not None and sess_ab.selected_pair_kind == "relay/relay"
        assert sess_bc is not None and sess_bc.selected_pair_kind != "relay/relay"
        assert lab.keepalive("a", "b", timeout_s=0.6).ok
        assert lab.keepalive("b", "c", timeout_s=0.6).ok



def test_mesh_soak_keepalive_rounds_do_not_degrade_healthy_paths(tmp_path):
    with LocalUDPMeshLab(tmp_path / "mesh-soak", with_relay=False) as lab:
        for name in ("a", "b", "c"):
            lab.add_node(name)
        lab.publish_all()
        lab.bootstrap_full_mesh()

        for src, dst in (("a", "b"), ("b", "c"), ("c", "a")):
            assert lab.hello(src, dst).ok

        for _ in range(4):
            for src, dst in (("a", "b"), ("b", "c"), ("c", "a")):
                assert lab.keepalive(src, dst).ok
                assert lab.ring(src, dst, body={"round": _}, timeout_s=0.5).ok

        for src, dst in (("a", "b"), ("b", "c"), ("c", "a")):
            sess = lab.nodes[src].node.signaling.session(lab.nodes[dst].peer_id)
            assert sess is not None
            assert sess.selected_path_failures == 0
            assert sess.ice_restart_count == 0



def test_mesh_node_restart_preserves_identity_and_recovers_calls(tmp_path):
    with LocalUDPMeshLab(tmp_path / "mesh-restart", with_relay=False) as lab:
        for name in ("a", "b", "c"):
            lab.add_node(name)
        lab.publish_all()
        lab.bootstrap_full_mesh()

        assert lab.hello("a", "b").ok
        assert lab.hello("c", "b").ok
        old_peer_id = lab.nodes["b"].peer_id
        old_bind = lab.nodes["b"].bind_addr

        restarted = lab.restart_node("b")
        assert restarted.peer_id == old_peer_id
        assert restarted.bind_addr != old_bind
        lab.publish_node("b")
        assert lab.hello("b", "a", timeout_s=1.0).ok
        assert lab.hello("b", "c", timeout_s=1.0).ok
        assert lab.refresh_candidates("b", "a", reason="restart").ok
        assert lab.refresh_candidates("b", "c", reason="restart").ok

        def a_updated():
            rec = lab.nodes["a"].node.cache.peek(old_peer_id)
            return rec is not None and rec.endpoints[0].address == f"127.0.0.1:{restarted.bind_addr[1]}"

        def c_updated():
            rec = lab.nodes["c"].node.cache.peek(old_peer_id)
            return rec is not None and rec.endpoints[0].address == f"127.0.0.1:{restarted.bind_addr[1]}"

        assert _wait_until(a_updated)
        assert _wait_until(c_updated)
        assert lab.keepalive("a", "b").ok
        assert lab.keepalive("c", "b").ok
        assert lab.ring("a", "b", body={"topic": "after_restart"}, timeout_s=0.8).ok


def test_mesh_partition_can_fallback_to_relay_then_return_to_direct(tmp_path):
    with LocalUDPMeshLab(tmp_path / "mesh-partition", with_relay=True) as lab:
        for name in ("a", "b", "c"):
            lab.add_node(name)
        lab.publish_all()
        lab.bootstrap_full_mesh()

        assert lab.hello("a", "b", timeout_s=0.8).ok
        sess = lab.nodes["a"].node.signaling.session(lab.nodes["b"].peer_id)
        assert sess is not None and sess.selected_pair_kind != "relay/relay"

        lab.partition_pair("a", "b")
        assert lab.ensure_relay_pair("a", "b") is not None
        assert lab.ensure_relay_pair("b", "a") is not None
        assert lab.keepalive("a", "b", timeout_s=0.3).ok

        def relay_selected():
            sess = lab.nodes["a"].node.signaling.session(lab.nodes["b"].peer_id)
            return sess is not None and sess.selected_pair_kind == "relay/relay"

        assert _wait_until(relay_selected, timeout_s=2.0)

        lab.heal_pair("a", "b")
        assert lab.refresh_candidates("a", "b", reason="heal").ok
        assert lab.refresh_candidates("b", "a", reason="heal").ok

        def direct_again():
            session = lab.nodes["a"].node.signaling.session(lab.nodes["b"].peer_id)
            return session is not None and session.selected_pair_kind != "relay/relay"

        assert _wait_until(direct_again, timeout_s=2.5)
        assert lab.keepalive("a", "b", timeout_s=0.6).ok
        assert lab.ring("a", "b", body={"topic": "healed"}, timeout_s=0.8).ok


def test_mesh_chaos_rounds_survive_flaps_rebinds_and_restart(tmp_path):
    with LocalUDPMeshLab(tmp_path / "mesh-chaos", with_relay=True) as lab:
        for name in ("a", "b", "c", "d"):
            lab.add_node(name)
        lab.publish_all()
        lab.bootstrap_full_mesh()

        pairs = (("a", "b"), ("b", "c"), ("c", "d"), ("d", "a"))
        for src, dst in pairs:
            assert lab.hello(src, dst, timeout_s=0.8).ok

        lab.partition_pair("b", "c")
        assert lab.ensure_relay_pair("b", "c") is not None
        assert lab.ensure_relay_pair("c", "b") is not None
        assert lab.keepalive("b", "c", timeout_s=0.4).ok

        _, new_port = lab.rebind_node("c")
        assert lab.hello("c", "b", timeout_s=1.0).ok
        assert lab.hello("c", "d", timeout_s=1.0).ok
        assert lab.refresh_candidates("c", "b", reason="chaos_rebind").ok
        assert lab.refresh_candidates("c", "d", reason="chaos_rebind").ok

        def b_updated():
            rec = lab.nodes["b"].node.cache.peek(lab.nodes["c"].peer_id)
            return rec is not None and rec.endpoints and rec.endpoints[0].address == f"127.0.0.1:{new_port}"

        assert _wait_until(b_updated)

        lab.heal_pair("b", "c")
        assert lab.refresh_candidates("b", "c", reason="heal_after_rebind").ok
        assert lab.refresh_candidates("c", "b", reason="heal_after_rebind").ok
        restarted_d = lab.restart_node("d")
        assert lab.hello("d", "a", timeout_s=1.0).ok
        assert lab.hello("d", "c", timeout_s=1.0).ok
        assert lab.refresh_candidates("d", "a", reason="restart_d").ok
        assert lab.refresh_candidates("d", "c", reason="restart_d").ok
        assert restarted_d.peer_id == lab.nodes["d"].peer_id

        for src, dst in pairs:
            assert lab.keepalive(src, dst, timeout_s=0.7).ok
            assert lab.ring(src, dst, body={"final": f"{src}->{dst}"}, timeout_s=0.9).ok
            sess = lab.nodes[src].node.signaling.session(lab.nodes[dst].peer_id)
            assert sess is not None
            assert sess.selected_path_failures <= 1
