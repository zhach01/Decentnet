from __future__ import annotations

import json
import time
import urllib.request
from pathlib import Path

from decentnet.cli.main import _build_parser
from decentnet.dashboard import (
    collect_dashboard_state,
    export_dashboard_snapshot,
    load_dashboard_snapshot,
    run_dashboard,
)
from decentnet.node import Node, NodeConfig
from decentnet.records.endpoints import Endpoint


def _make_node(root: Path):
    cfg = NodeConfig.at(root)
    cfg.ensure()
    return Node(cfg)


def _write_operator_report(path: Path, *, ok: bool = True) -> None:
    payload = {
        "kind": "two_host_report",
        "ok": ok,
        "checked_at": int(time.time()),
        "verdict": {
            "hello_completed": True,
            "ring_completed": ok,
            "relay_used": not ok,
            "selected_pair_kind_b": "srflx/srflx" if ok else "relay/relay",
        },
        "host_a": {"ok": ok},
        "host_b": {"ok": ok},
    }
    path.write_text(json.dumps(payload), encoding="utf-8")


def _write_soak_report(path: Path) -> None:
    payload = {
        "kind": "two_host_soak_report",
        "ok": True,
        "checked_at": int(time.time()),
        "total_runs": 3,
        "passed_runs": 3,
        "failed_runs": 0,
        "relay_runs": 1,
    }
    path.write_text(json.dumps(payload), encoding="utf-8")


def test_collect_dashboard_state_includes_operator_report_summary(tmp_path: Path):
    a_root = tmp_path / "node-a"
    b_root = tmp_path / "node-b"
    report_dir = tmp_path / "reports"
    report_dir.mkdir()
    report = report_dir / "operator.json"
    soak = report_dir / "soak.json"

    with _make_node(a_root) as a, _make_node(b_root) as b:
        a.publish_own_record([Endpoint(type="public_udp", address="127.0.0.1:41001")])
        b.publish_own_record([Endpoint(type="public_udp", address="127.0.0.1:41002")])
        b.ingest_record_bytes(a.export_own_record(), source="bootstrap")
        a.ingest_record_bytes(b.export_own_record(), source="bootstrap")
        a.audit.record("signal.established", peer=b.peer_id.value)
        a.audit.record("ice.path_selected", peer=b.peer_id.value, path_kind="srflx/srflx")
        b.audit.record("relay.path_selected", peer=a.peer_id.value, relay="127.0.0.1:49999")

    _write_operator_report(report, ok=True)
    _write_soak_report(soak)

    state = collect_dashboard_state(
        [a_root, b_root],
        audit_tail=100,
        event_limit=50,
        operator_reports=[report],
        soak_reports=[soak],
    )

    assert state["global"]["node_count"] == 2
    assert state["operator"]["report_count"] == 2
    assert state["operator"]["ok_count"] == 2
    assert state["operator"]["relay_used_count"] >= 1
    assert any(r["kind"] == "two_host_report" for r in state["operator"]["recent_reports"])
    assert any(r["kind"] == "two_host_soak_report" for r in state["operator"]["recent_reports"])


def test_export_and_load_dashboard_snapshot(tmp_path: Path):
    root = tmp_path / "node-a"
    report = tmp_path / "report.json"
    json_out = tmp_path / "snapshot.json"
    html_out = tmp_path / "snapshot.html"

    with _make_node(root) as node:
        node.publish_own_record([Endpoint(type="public_udp", address="127.0.0.1:42001")])
        node.audit.record("ice.restart", peer=node.peer_id.value)

    _write_operator_report(report, ok=False)
    state = export_dashboard_snapshot([root], operator_reports=[report], json_out=json_out, html_out=html_out)
    loaded = load_dashboard_snapshot(json_out)

    assert state["operator"]["report_count"] == 1
    assert loaded["operator"]["report_count"] == 1
    assert html_out.exists()
    html = html_out.read_text(encoding="utf-8")
    assert "snapshot dashboard" in html
    assert "Operator reports" in html


def test_dashboard_server_serves_snapshot_and_json(tmp_path: Path):
    snapshot = {
        "generated_at": time.time(),
        "roots": [],
        "global": {
            "node_count": 0,
            "online_count": 0,
            "groups_count": 0,
            "known_peer_count": 0,
            "recent_event_count": 0,
            "recent_kind_counts": {"signal": 0, "relay": 0, "ice": 0, "cache": 0, "other": 0},
            "global_registry": [],
        },
        "nodes": [],
        "events": [],
        "layout": {"width": 1100, "height": 660, "nodes": {}, "edges": []},
        "operator": {"report_count": 1, "ok_count": 1, "failed_count": 0, "pass_rate": 1.0, "relay_used_count": 0, "total_runs": 1, "passed_runs": 1, "failed_runs": 0, "by_kind": {"two_host_report": {"total": 1, "ok": 1, "failed": 0}}, "recent_reports": [{"kind": "two_host_report", "label": "r.json", "ok": True, "relay_used": False, "total_runs": 1, "passed_runs": 1, "failed_runs": 0, "selected_pair_kind": "srflx/srflx", "checked_at": time.time(), "path": "/tmp/r.json"}]},
    }
    server = run_dashboard([], host="127.0.0.1", port=0, snapshot_state=snapshot)
    try:
        time.sleep(0.2)
        host, port = server.server_address
        with urllib.request.urlopen(f"http://{host}:{port}/") as resp:
            html = resp.read().decode("utf-8")
        assert "snapshot dashboard" in html
        with urllib.request.urlopen(f"http://{host}:{port}/api/state") as resp:
            payload = json.loads(resp.read().decode("utf-8"))
        assert payload["operator"]["report_count"] == 1
        with urllib.request.urlopen(f"http://{host}:{port}/api/config") as resp:
            cfg = json.loads(resp.read().decode("utf-8"))
        assert cfg["snapshot_mode"] is True
    finally:
        server.shutdown()
        server.server_close()


def test_cli_parser_accepts_dashboard_snapshot_options():
    parser = _build_parser()
    args = parser.parse_args([
        "dashboard",
        "--watch-root", "/tmp/node-a",
        "--operator-report", "/tmp/r.json",
        "--snapshot-json-out", "/tmp/snapshot.json",
        "--snapshot-html-out", "/tmp/snapshot.html",
        "--once",
    ])
    assert args.cmd == "dashboard"
    assert args.watch_root == ["/tmp/node-a"]
    assert args.operator_report == ["/tmp/r.json"]
    assert args.snapshot_json_out.endswith("snapshot.json")
    assert args.snapshot_html_out.endswith("snapshot.html")
    assert args.once is True
