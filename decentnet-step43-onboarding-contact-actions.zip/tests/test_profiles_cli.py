import json
from pathlib import Path

from decentnet.cli.main import main
from decentnet.config_file import list_profiles, render_profile_toml


def test_profile_list_contains_expected(capsys):
    rc = main(["profile", "list"])
    assert rc == 0
    out = capsys.readouterr().out.strip().splitlines()
    assert {"laptop", "rpi", "phone", "helper"}.issubset(set(out))


def test_profile_show_renders_toml(capsys):
    rc = main(["profile", "show", "rpi", "--root-override", "/srv/decentnet"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "[transport]" in out
    assert 'bind_host = "0.0.0.0"' in out
    assert 'root = "/srv/decentnet"' in out


def test_config_init_writes_profile(tmp_path, capsys):
    rc = main(["--root", str(tmp_path), "config", "init", "--profile", "phone"])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    path = Path(out["out"])
    assert path.exists()
    text = path.read_text()
    assert "# DecentNet peer profile: phone" in text
    assert 'mode = "auto"' in text
    assert f'root = "{tmp_path}"' in text


def test_config_init_refuses_overwrite_without_force(tmp_path, capsys):
    path = tmp_path / "config.toml"
    path.write_text("x=1\n")
    rc = main(["--root", str(tmp_path), "config", "init"])
    assert rc == 1
    err = capsys.readouterr().err
    assert "--force" in err


def test_render_profile_toml_all_profiles():
    for name in list_profiles():
        text = render_profile_toml(name)
        assert text.startswith(f"# DecentNet peer profile: {name}")
        assert "[advertise]" in text


def test_setup_writes_config_noninteractive_yes(tmp_path, capsys):
    rc = main(["--root", str(tmp_path), "setup", "--profile", "rpi", "--yes"])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    path = Path(out["config"])
    assert path.exists()
    text = path.read_text()
    assert "# DecentNet peer profile: rpi" in text
    assert out["profile"] == "rpi"
    assert "doctor_config_validation" in out


def test_setup_refuses_overwrite_without_force(tmp_path, capsys):
    path = tmp_path / "config.toml"
    path.write_text("x=1\n")
    rc = main(["--root", str(tmp_path), "setup", "--yes"])
    assert rc == 1
    err = capsys.readouterr().err
    assert "--force" in err
