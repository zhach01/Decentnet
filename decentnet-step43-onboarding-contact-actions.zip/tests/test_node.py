from decentnet.node import Node, NodeConfig
from decentnet.records.endpoints import Endpoint


def test_node_init_and_whoami(tmp_path):
    cfg = NodeConfig.at(tmp_path / "n")
    with Node(cfg) as n:
        assert n.peer_id.value
        # Key file and audit log exist.
        assert cfg.keyfile.exists()


def test_node_publish_then_lookup(tmp_path):
    cfg = NodeConfig.at(tmp_path / "n")
    with Node(cfg) as n:
        rec = n.publish_own_record(
            endpoints=[Endpoint(type="public_udp", address="203.0.113.5:41234")]
        )
        assert rec.seq == 1
        got = n.lookup(n.peer_id.value)
        assert got is not None
        assert got.seq == 1


def test_node_publish_increments_seq(tmp_path):
    cfg = NodeConfig.at(tmp_path / "n")
    with Node(cfg) as n:
        r1 = n.publish_own_record(
            endpoints=[Endpoint(type="public_udp", address="1.1.1.1:1")]
        )
        r2 = n.publish_own_record(
            endpoints=[Endpoint(type="public_udp", address="1.1.1.1:2")]
        )
        assert r2.seq == r1.seq + 1


def test_two_nodes_exchange_records(tmp_path):
    """End-to-end: A publishes, B ingests, B can look A up."""
    cfg_a = NodeConfig.at(tmp_path / "a")
    cfg_b = NodeConfig.at(tmp_path / "b")
    with Node(cfg_a) as a, Node(cfg_b) as b:
        a.publish_own_record(
            endpoints=[Endpoint(type="public_udp", address="203.0.113.5:41234")]
        )
        wire = a.export_own_record()
        result = b.ingest_record_bytes(wire, source="test")
        assert result.accepted, result.reason
        got = b.lookup(a.peer_id.value)
        assert got is not None
        assert got.peer_id == a.peer_id.value


def test_ingest_rejects_garbage(tmp_path):
    cfg = NodeConfig.at(tmp_path / "n")
    with Node(cfg) as n:
        r = n.ingest_record_bytes(b"this is not a record")
        assert not r.accepted
        assert "parse_error" in r.reason


def test_ingest_rejects_rollback(tmp_path):
    cfg_a = NodeConfig.at(tmp_path / "a")
    cfg_b = NodeConfig.at(tmp_path / "b")
    with Node(cfg_a) as a, Node(cfg_b) as b:
        a.publish_own_record(
            endpoints=[Endpoint(type="public_udp", address="1.1.1.1:1")]
        )
        old_wire = a.export_own_record()
        a.publish_own_record(
            endpoints=[Endpoint(type="public_udp", address="1.1.1.1:2")]
        )
        new_wire = a.export_own_record()
        assert b.ingest_record_bytes(new_wire).accepted
        r = b.ingest_record_bytes(old_wire)
        assert not r.accepted
        assert r.reason == "not_newer"
