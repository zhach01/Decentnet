from decentnet.interfaces import parse_interface_addresses, detect_lan_endpoints


IP_OUTPUT = """
1: lo    inet 127.0.0.1/8 scope host lo
2: eth0    inet 192.168.1.50/24 brd 192.168.1.255 scope global dynamic eth0
3: docker0    inet 172.17.0.1/16 brd 172.17.255.255 scope global docker0
4: tailscale0    inet 100.88.10.4/32 scope global tailscale0
5: wlan0    inet6 fd00::1234/64 scope global dynamic wlan0
"""


def test_parse_interface_addresses_filters_allow_and_deny():
    addrs = parse_interface_addresses(IP_OUTPUT, allow=["eth0", "wlan0"], deny=["docker0"])
    got = {(a.name, a.address) for a in addrs}
    assert ("eth0", "192.168.1.50") in got
    assert ("wlan0", "fd00::1234") in got
    assert all(name != "docker0" for name, _ in got)
    assert all(name != "lo" for name, _ in got)


def test_detect_lan_endpoints_uses_filters_and_port():
    eps = detect_lan_endpoints(45001, allow=["eth0"], deny=["docker0"], ip_output=IP_OUTPUT)
    got = {(e.type, e.address) for e in eps}
    assert ("lan_udp", "192.168.1.50:45001") in got
    assert all("172.17.0.1" not in addr for _, addr in got)
    assert all("100.88.10.4" not in addr for _, addr in got)
