"""Phase 5: STUN codec, mock server, NAT discovery, Node integration."""
import socket
import tempfile
import threading
import time
from pathlib import Path

import pytest

from decentnet.identity.keypair import Keypair
from decentnet.identity.peer_id import PeerId
from decentnet.nat import (
    MockSTUNServer,
    NATDiscovery,
    NATType,
    build_binding_request,
    build_binding_success_response,
    is_stun_packet,
    parse_stun_message,
)
from decentnet.nat.stun import (
    ATTR_XOR_MAPPED_ADDRESS,
    BINDING_REQUEST,
    BINDING_SUCCESS,
    STUN_MAGIC_COOKIE_BYTES,
)
from decentnet.node import Node, NodeConfig
from decentnet.records.endpoints import Endpoint
from decentnet.transport.inproc import InProcessNetwork
from decentnet.transport.udp import UDPTransport


def _new_pid():
    return PeerId.from_public_key(Keypair.generate().public_key_bytes).value


# ------------------- STUN codec unit tests -------------------


def test_is_stun_packet_detects_binding_request():
    packet, _ = build_binding_request()
    assert is_stun_packet(packet)


def test_is_stun_packet_rejects_json():
    assert not is_stun_packet(b'{"type": "ping"}')
    assert not is_stun_packet(b"random bytes not stun at all")


def test_build_and_parse_binding_request():
    packet, tid = build_binding_request()
    assert len(packet) == 20       # header only, no attributes
    assert packet[0:2] == b"\x00\x01"  # BINDING_REQUEST
    assert packet[4:8] == STUN_MAGIC_COOKIE_BYTES
    resp = parse_stun_message(packet)
    assert resp.msg_type == BINDING_REQUEST
    assert resp.transaction_id == tid
    assert resp.mapped_address is None


def test_build_and_parse_success_response_ipv4_roundtrip():
    _, tid = build_binding_request()
    packet = build_binding_success_response(tid, ("203.0.113.7", 41234))
    resp = parse_stun_message(packet)
    assert resp.msg_type == BINDING_SUCCESS
    assert resp.transaction_id == tid
    assert resp.mapped_address == ("203.0.113.7", 41234)


def test_parse_rejects_bad_magic():
    bad = b"\x00\x01\x00\x00" + b"\xde\xad\xbe\xef" + b"\x00" * 12
    with pytest.raises(ValueError):
        parse_stun_message(bad)


def test_parse_rejects_short_buffer():
    with pytest.raises(ValueError):
        parse_stun_message(b"too short")


# ------------------- mock server -------------------


def test_mock_stun_server_answers_binding_request():
    with MockSTUNServer() as stun:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind(("127.0.0.1", 0))
        local_host, local_port = sock.getsockname()
        try:
            packet, tid = build_binding_request()
            sock.sendto(packet, (stun.bind_host, stun.bind_port))
            sock.settimeout(1.0)
            data, _ = sock.recvfrom(1500)
            resp = parse_stun_message(data)
            assert resp.msg_type == BINDING_SUCCESS
            assert resp.transaction_id == tid
            # Mock server reflects the client's observed source.
            assert resp.mapped_address == (local_host, local_port)
        finally:
            sock.close()
    # Server stats.
    assert stun.request_count >= 1


def test_mock_stun_server_ignores_non_stun_traffic():
    with MockSTUNServer() as stun:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind(("127.0.0.1", 0))
        try:
            sock.sendto(b"hello not stun", (stun.bind_host, stun.bind_port))
            sock.sendto(b'{"type": "json"}', (stun.bind_host, stun.bind_port))
            time.sleep(0.1)
            # Then a real STUN request still works.
            packet, _ = build_binding_request()
            sock.sendto(packet, (stun.bind_host, stun.bind_port))
            sock.settimeout(1.0)
            data, _ = sock.recvfrom(1500)
            resp = parse_stun_message(data)
            assert resp.msg_type == BINDING_SUCCESS
        finally:
            sock.close()


# ------------------- discovery -------------------


def test_nat_discovery_over_udp_transport():
    pid = _new_pid()
    tx = UDPTransport(pid)
    try:
        with MockSTUNServer() as stun:
            disc = NATDiscovery(tx, [(stun.bind_host, stun.bind_port)])
            mapped = disc.discover(timeout_s=1.0)
            assert mapped is not None
            # Mock echoes our bind address.
            assert mapped[0] == tx.bind_host
            assert mapped[1] == tx.bind_port
            assert disc.last_mapped == mapped
    finally:
        tx.close()


def test_nat_discovery_timeout_when_server_unreachable():
    pid = _new_pid()
    tx = UDPTransport(pid)
    try:
        # Bind a socket just to reserve a port, then close so it's dead.
        dead = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        dead.bind(("127.0.0.1", 0))
        dead_addr = dead.getsockname()
        dead.close()
        disc = NATDiscovery(tx, [dead_addr])
        mapped = disc.discover(timeout_s=0.3)
        assert mapped is None
    finally:
        tx.close()


def test_nat_classify_open_internet_from_single_server():
    """When the mock echoes our actual bind host/port and we only have
    one server configured, we classify as OPEN_INTERNET."""
    pid = _new_pid()
    tx = UDPTransport(pid)
    try:
        with MockSTUNServer() as stun:
            disc = NATDiscovery(tx, [(stun.bind_host, stun.bind_port)])
            nat = disc.classify(timeout_s=1.0)
            # On loopback with a simple mock reflecting source addr,
            # mapping host == bind host and mapping port == bind port.
            assert nat == NATType.OPEN_INTERNET
    finally:
        tx.close()


def test_nat_classify_cone_like_with_two_servers_agreeing():
    """Two mock servers both see the same source host+port → cone-like."""
    pid = _new_pid()
    tx = UDPTransport(pid)
    try:
        with MockSTUNServer() as s1, MockSTUNServer() as s2:
            disc = NATDiscovery(
                tx,
                [(s1.bind_host, s1.bind_port),
                 (s2.bind_host, s2.bind_port)],
            )
            nat = disc.classify(timeout_s=1.0)
            # Both see (tx.bind_host, tx.bind_port), so mapping equals
            # bind addr → OPEN_INTERNET (the stronger case).
            # If mapping differed from bind but was stable → CONE_LIKE.
            assert nat in (NATType.OPEN_INTERNET, NATType.CONE_LIKE)
    finally:
        tx.close()


# ------------------- Node integration -------------------


def test_node_publishes_stun_learned_endpoint():
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        with MockSTUNServer() as stun:
            net = InProcessNetwork()
            node = Node(NodeConfig.at(tmp / "a"), network=net)
            try:
                # We need a standalone UDP transport because this Node
                # runs over the in-process bus for its DHT.
                udp = UDPTransport(node.peer_id.value)
                try:
                    node.enable_nat_discovery(
                        [(stun.bind_host, stun.bind_port)],
                        udp_transport=udp,
                    )
                    rec = node.publish_with_external_address(
                        extra_endpoints=[
                            Endpoint(type="lan_udp", address="10.0.0.1:41234"),
                        ],
                        stun_timeout_s=1.0,
                    )
                    # Record has our STUN-learned endpoint as the first
                    # entry plus the LAN hint we provided.
                    types = [(e.type, e.address, e.discovered_by) for e in rec.endpoints]
                    stun_eps = [t for t in types if t[2] == "stun"]
                    assert len(stun_eps) == 1
                    stun_ep = stun_eps[0]
                    assert stun_ep[0] == "public_udp"
                    assert stun_ep[1] == f"{udp.bind_host}:{udp.bind_port}"
                    lan_eps = [t for t in types if t[0] == "lan_udp"]
                    assert len(lan_eps) == 1
                finally:
                    udp.close()
            finally:
                node.close()


def test_node_publish_with_disabled_nat_no_stun_endpoint():
    """If NAT discovery was never enabled, publish_with_external_address
    still works and simply uses whatever extras were passed."""
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        net = InProcessNetwork()
        node = Node(NodeConfig.at(tmp / "a"), network=net)
        try:
            rec = node.publish_with_external_address(
                extra_endpoints=[
                    Endpoint(type="lan_udp", address="192.168.1.2:41234"),
                ]
            )
            # No STUN endpoints; only the LAN hint.
            assert all(e.discovered_by != "stun" for e in rec.endpoints)
            assert any(e.type == "lan_udp" for e in rec.endpoints)
        finally:
            node.close()


def test_node_refresh_external_address_updates_cache():
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        with MockSTUNServer() as stun:
            net = InProcessNetwork()
            node = Node(NodeConfig.at(tmp / "a"), network=net)
            try:
                udp = UDPTransport(node.peer_id.value)
                try:
                    node.enable_nat_discovery(
                        [(stun.bind_host, stun.bind_port)],
                        udp_transport=udp,
                    )
                    mapped = node.refresh_external_address(timeout_s=1.0)
                    assert mapped is not None
                    assert node.nat.last_mapped == mapped
                    assert node.nat.last_observed_at > 0
                finally:
                    udp.close()
            finally:
                node.close()
