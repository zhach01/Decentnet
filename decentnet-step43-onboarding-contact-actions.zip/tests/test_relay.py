"""Phase 6 relay tests: tokens, allocate, forward between two clients."""
import json
import socket
import time

import pytest

from decentnet.identity.keypair import Keypair
from decentnet.identity.peer_id import PeerId
from decentnet.relay import (
    RelayServer,
    RelayToken,
    TAG_ALLOCATE_OK,
    TAG_ALLOCATE_REJECT,
    TAG_FORWARDED,
    build_allocate_request,
    build_forward_request,
    issue_relay_token,
    parse_forwarded,
    parse_response,
)


def _client_socket():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(("127.0.0.1", 0))
    s.settimeout(1.0)
    return s


# -------- tokens --------


def test_relay_token_sign_and_verify_roundtrip():
    relay_kp = Keypair.generate()
    tok = issue_relay_token(relay_kp, "peer-abc", ttl_s=60)
    ok, reason = tok.verify(expected_relay_key=relay_kp.public_key_bytes)
    assert ok, reason


def test_relay_token_rejects_wrong_key():
    relay_kp = Keypair.generate()
    other_kp = Keypair.generate()
    tok = issue_relay_token(relay_kp, "peer-abc", ttl_s=60)
    ok, reason = tok.verify(expected_relay_key=other_kp.public_key_bytes)
    assert not ok
    assert "wrong relay key" in reason


def test_relay_token_rejects_tampered_claim():
    relay_kp = Keypair.generate()
    tok = issue_relay_token(relay_kp, "peer-abc", ttl_s=60)
    # Mutate the client_peer_id; signature no longer valid.
    tok.client_peer_id = "peer-zzz"
    ok, reason = tok.verify(expected_relay_key=relay_kp.public_key_bytes)
    assert not ok


def test_relay_token_expires():
    relay_kp = Keypair.generate()
    tok = issue_relay_token(relay_kp, "peer-abc", ttl_s=0)
    time.sleep(0.01)  # Let the expiry elapse.
    # The relay checks expiry with now_s(); but since ttl_s=0, issued_at==expires_at.
    # `verify` rejects expires_at <= now.
    ok, reason = tok.verify(expected_relay_key=relay_kp.public_key_bytes)
    assert not ok
    assert reason == "expired"


# -------- server --------


def test_relay_rejects_unsigned_allocate():
    with RelayServer() as relay:
        # Build a token then strip its signature.
        pid = PeerId.from_public_key(Keypair.generate().public_key_bytes).value
        tok = relay.issue_token(pid)
        tok.signature = None
        # We can't call tok.to_json() without signature — craft manually.
        bogus_json = json.dumps({
            "relay_pubkey": "AAAA",
            "client_peer_id": pid,
            "issued_at": 0,
            "expires_at": 999999999999,
            # no signature
        })
        body = json.dumps({"peer_id": pid, "token": bogus_json}).encode()
        req = bytes([0x01]) + body
        sock = _client_socket()
        try:
            sock.sendto(req, (relay.bind_host, relay.bind_port))
            data, _ = sock.recvfrom(4096)
        finally:
            sock.close()
        tag, rbody = parse_response(data)
        assert tag == TAG_ALLOCATE_REJECT


def test_relay_allocate_forwards_between_two_clients():
    with RelayServer() as relay:
        pid_a = PeerId.from_public_key(Keypair.generate().public_key_bytes).value
        pid_b = PeerId.from_public_key(Keypair.generate().public_key_bytes).value
        tok_a = relay.issue_token(pid_a)
        tok_b = relay.issue_token(pid_b)

        sock_a = _client_socket()
        sock_b = _client_socket()
        try:
            # Allocate both.
            for sock, pid, tok in ((sock_a, pid_a, tok_a), (sock_b, pid_b, tok_b)):
                sock.sendto(
                    build_allocate_request(pid, tok),
                    (relay.bind_host, relay.bind_port),
                )
                data, _ = sock.recvfrom(4096)
                tag, body = parse_response(data)
                assert tag == TAG_ALLOCATE_OK, f"allocate failed: {body!r}"

            # A forwards to B.
            payload = b"\x00hello-world\x00"
            sock_a.sendto(
                build_forward_request(pid_b, payload),
                (relay.bind_host, relay.bind_port),
            )
            # B should receive it.
            data, _ = sock_b.recvfrom(4096)
            tag, body = parse_response(data)
            assert tag == TAG_FORWARDED
            from_pid, got_payload = parse_forwarded(body)
            assert from_pid == pid_a
            assert got_payload == payload

            assert relay.forward_count == 1
            assert relay.allocate_count == 2
        finally:
            sock_a.close()
            sock_b.close()


def test_relay_rejects_forward_to_unknown_peer():
    with RelayServer() as relay:
        pid_a = PeerId.from_public_key(Keypair.generate().public_key_bytes).value
        tok_a = relay.issue_token(pid_a)
        sock_a = _client_socket()
        try:
            sock_a.sendto(
                build_allocate_request(pid_a, tok_a),
                (relay.bind_host, relay.bind_port),
            )
            data, _ = sock_a.recvfrom(4096)
            tag, _ = parse_response(data)
            assert tag == TAG_ALLOCATE_OK

            unknown = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
            sock_a.sendto(
                build_forward_request(unknown, b"payload"),
                (relay.bind_host, relay.bind_port),
            )
            # No forward should arrive anywhere; relay silently drops.
            sock_a.settimeout(0.2)
            with pytest.raises(socket.timeout):
                sock_a.recvfrom(4096)
            assert relay.forward_count == 0
        finally:
            sock_a.close()


def test_relay_allocate_rate_limit_rejects_excess_requests():
    with RelayServer(max_allocate_per_window=1, allocate_window_s=60) as relay:
        pid = PeerId.from_public_key(Keypair.generate().public_key_bytes).value
        tok = relay.issue_token(pid)
        sock = _client_socket()
        try:
            sock.sendto(build_allocate_request(pid, tok), (relay.bind_host, relay.bind_port))
            data, _ = sock.recvfrom(4096)
            tag, _ = parse_response(data)
            assert tag == TAG_ALLOCATE_OK

            sock.sendto(build_allocate_request(pid, tok), (relay.bind_host, relay.bind_port))
            data, _ = sock.recvfrom(4096)
            tag, body = parse_response(data)
            assert tag == TAG_ALLOCATE_REJECT
            assert b"rate_limited" in body
            stats = relay.stats()
            assert stats["rate_limited_allocations"] >= 1
        finally:
            sock.close()


def test_relay_forward_rate_limit_drops_excess_requests():
    with RelayServer(max_forward_per_window=1, forward_window_s=60) as relay:
        pid_a = PeerId.from_public_key(Keypair.generate().public_key_bytes).value
        pid_b = PeerId.from_public_key(Keypair.generate().public_key_bytes).value
        tok_a = relay.issue_token(pid_a)
        tok_b = relay.issue_token(pid_b)
        sock_a = _client_socket()
        sock_b = _client_socket()
        try:
            for sock, pid, tok in ((sock_a, pid_a, tok_a), (sock_b, pid_b, tok_b)):
                sock.sendto(build_allocate_request(pid, tok), (relay.bind_host, relay.bind_port))
                data, _ = sock.recvfrom(4096)
                tag, _ = parse_response(data)
                assert tag == TAG_ALLOCATE_OK

            sock_a.sendto(build_forward_request(pid_b, b"one"), (relay.bind_host, relay.bind_port))
            data, _ = sock_b.recvfrom(4096)
            tag, body = parse_response(data)
            assert tag == TAG_FORWARDED
            assert parse_forwarded(body)[1] == b"one"

            sock_a.sendto(build_forward_request(pid_b, b"two"), (relay.bind_host, relay.bind_port))
            sock_b.settimeout(0.2)
            with pytest.raises(socket.timeout):
                sock_b.recvfrom(4096)
            stats = relay.stats()
            assert stats["rate_limited_forwards"] >= 1
            assert stats["forward_drop_count"] >= 1
        finally:
            sock_a.close()
            sock_b.close()
