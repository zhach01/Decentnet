from __future__ import annotations

import importlib.util
import json
import socket
import subprocess
import sys
import time
from pathlib import Path




def _free_port_pair() -> tuple[int, int]:
    while True:
        s1 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s1.bind(("127.0.0.1", 0))
        p1 = s1.getsockname()[1]
        s1.close()
        p2 = p1 + 1
        s2 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s2.bind(("127.0.0.1", p2))
        except OSError:
            s2.close()
            continue
        s2.close()
        return p1, p2

def _load_harness_module():
    repo = Path(__file__).resolve().parent.parent
    script = repo / "scripts" / "two_host_test.py"
    spec = importlib.util.spec_from_file_location("two_host_test_mod", script)
    assert spec is not None and spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_merge_summaries_marks_success_and_relay_flag():
    mod = _load_harness_module()
    a = {
        "ok": True,
        "peer": {"selected_pair_kind": "relay/relay", "relay_selected": True},
        "observed": {"hello": True, "ring": True},
    }
    b = {
        "ok": True,
        "hello": {"ok": True},
        "ring": {"ok": True},
        "peer": {"selected_pair_kind": "relay/relay", "relay_selected": True},
    }
    merged = mod.merge_summaries(a, b)
    assert merged["ok"] is True
    assert merged["verdict"]["hello_completed"] is True
    assert merged["verdict"]["ring_completed"] is True
    assert merged["verdict"]["relay_used"] is True


def test_local_two_host_harness_generates_ok_summaries(tmp_path: Path):
    repo = Path(__file__).resolve().parent.parent
    script = repo / "scripts" / "two_host_test.py"

    a_root = tmp_path / "a"
    b_root = tmp_path / "b"
    a_bundle = tmp_path / "a.bundle.json"
    a_summary = tmp_path / "a.summary.json"
    b_summary = tmp_path / "b.summary.json"
    report_out = tmp_path / "report.json"

    a_port, b_port = _free_port_pair()

    a_proc = subprocess.Popen(
        [
            sys.executable,
            str(script),
            "host-a",
            "--root",
            str(a_root),
            "--udp-port",
            str(a_port),
            "--public-address",
            f"127.0.0.1:{a_port}",
            "--bundle-out",
            str(a_bundle),
            "--summary-out",
            str(a_summary),
            "--duration",
            "20",
            "--stop-on-success",
            "--expect-ring",
        ],
        cwd=str(repo),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )

    try:
        deadline = time.time() + 10.0
        while time.time() < deadline and not a_bundle.exists():
            time.sleep(0.1)
        assert a_bundle.exists(), "host A did not export its bundle in time"

        b_run = subprocess.run(
            [
                sys.executable,
                str(script),
                "host-b",
                "--root",
                str(b_root),
                "--udp-port",
                str(b_port),
                "--public-address",
                f"127.0.0.1:{b_port}",
                "--peer-bundle",
                str(a_bundle),
                "--self-bundle-out",
                str(tmp_path / "b.bundle.json"),
                "--summary-out",
                str(b_summary),
                "--send-ring",
            ],
            cwd=str(repo),
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert b_run.returncode == 0, b_run.stdout + "\n" + b_run.stderr

        a_out, a_err = a_proc.communicate(timeout=30)
        assert a_proc.returncode == 0, a_out + "\n" + a_err

        report_run = subprocess.run(
            [
                sys.executable,
                str(script),
                "report",
                "--host-a-summary",
                str(a_summary),
                "--host-b-summary",
                str(b_summary),
                "--out",
                str(report_out),
            ],
            cwd=str(repo),
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert report_run.returncode == 0, report_run.stdout + "\n" + report_run.stderr

        merged = json.loads(report_out.read_text(encoding="utf-8"))
        assert merged["ok"] is True
        assert merged["verdict"]["hello_completed"] is True
        assert merged["verdict"]["ring_completed"] is True

        a_data = json.loads(a_summary.read_text(encoding="utf-8"))
        b_data = json.loads(b_summary.read_text(encoding="utf-8"))
        assert a_data["ok"] is True
        assert b_data["ok"] is True
        assert b_data["peer"]["session_state"] in {"established", "in_call"}
    finally:
        if a_proc.poll() is None:
            a_proc.terminate()
            try:
                a_proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                a_proc.kill()


def test_host_runner_build_invocation_for_ssh():
    mod = _load_harness_module()
    runner = mod.HostRunner(
        mode="ssh",
        target="user@example",
        repo="/opt/decentnet",
        python_bin="python3",
    )
    cmd = runner.build_invocation("scripts/two_host_test.py", ["report", "--out", "/tmp/x.json"])
    assert cmd[0] == "ssh"
    assert cmd[1] == "user@example"
    assert "cd /opt/decentnet" in cmd[2]
    assert "python3" in cmd[2]
    assert "scripts/two_host_test.py" in cmd[2]
    assert "report" in cmd[2]



def test_orchestrate_removes_stale_bundle_before_waiting(tmp_path: Path):
    repo = Path(__file__).resolve().parent.parent
    script = repo / "scripts" / "two_host_test.py"

    host_a_root = tmp_path / "a"
    host_b_root = tmp_path / "b"
    host_a_root.mkdir(parents=True, exist_ok=True)
    host_b_root.mkdir(parents=True, exist_ok=True)

    stale_bundle = host_a_root / "published_record.json"
    stale_bundle.write_text(json.dumps({
        "peer_id": "stale-peer",
        "peer_addr": "127.0.0.1:1",
        "record_wire": "stale",
        "written_at": 1,
        "format": 2,
    }), encoding="utf-8")

    a_port, b_port = _free_port_pair()
    out = tmp_path / "report.json"

    orch_run = subprocess.run(
        [
            sys.executable,
            str(script),
            "orchestrate",
            "--host-a-runner",
            "local",
            "--host-b-runner",
            "local",
            "--host-a-repo",
            str(repo),
            "--host-b-repo",
            str(repo),
            "--host-a-root",
            str(host_a_root),
            "--host-b-root",
            str(host_b_root),
            "--host-a-udp-port",
            str(a_port),
            "--host-b-udp-port",
            str(b_port),
            "--host-a-public-address",
            f"127.0.0.1:{a_port}",
            "--host-b-public-address",
            f"127.0.0.1:{b_port}",
            "--stage-dir",
            str(tmp_path / "stage"),
            "--report-out",
            str(out),
        ],
        cwd=str(repo),
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert orch_run.returncode == 0, orch_run.stdout + "\n" + orch_run.stderr

    transferred = json.loads((tmp_path / "stage" / "host_a.bundle.json").read_text(encoding="utf-8"))
    assert transferred["peer_addr"] == f"127.0.0.1:{a_port}"

    merged = json.loads(out.read_text(encoding="utf-8"))
    assert merged["ok"] is True
    assert merged["verdict"]["hello_completed"] is True


def test_orchestrate_local_generates_ok_report(tmp_path: Path):
    repo = Path(__file__).resolve().parent.parent
    script = repo / "scripts" / "two_host_test.py"

    a_port, b_port = _free_port_pair()

    orch_run = subprocess.run(
        [
            sys.executable,
            str(script),
            "orchestrate",
            "--host-a-runner",
            "local",
            "--host-b-runner",
            "local",
            "--host-a-repo",
            str(repo),
            "--host-b-repo",
            str(repo),
            "--host-a-root",
            str(tmp_path / "a"),
            "--host-b-root",
            str(tmp_path / "b"),
            "--host-a-udp-port",
            str(a_port),
            "--host-b-udp-port",
            str(b_port),
            "--host-a-public-address",
            f"127.0.0.1:{a_port}",
            "--host-b-public-address",
            f"127.0.0.1:{b_port}",
            "--stage-dir",
            str(tmp_path / "stage"),
            "--report-out",
            str(tmp_path / "orchestrated-report.json"),
            "--send-ring",
        ],
        cwd=str(repo),
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert orch_run.returncode == 0, orch_run.stdout + "\n" + orch_run.stderr

    merged = json.loads((tmp_path / "orchestrated-report.json").read_text(encoding="utf-8"))
    assert merged["ok"] is True
    assert merged["verdict"]["hello_completed"] is True
    assert merged["verdict"]["ring_completed"] is True
    assert Path(merged["host_a_log"]).exists()
    assert Path(merged["host_b_log"]).exists()


def test_render_matrix_html_contains_run_rows():
    mod = _load_harness_module()
    report = {
        "ok": True,
        "total_runs": 2,
        "passed_runs": 2,
        "failed_runs": 0,
        "relay_runs": 1,
        "avg_duration_s": 1.23,
        "by_scenario": {"direct": {"total": 1, "passed": 1, "failed": 0}},
        "runs": [
            {
                "scenario": "direct",
                "trial": 1,
                "ok": True,
                "relay_used": False,
                "duration_s": 1.0,
                "selected_pair_kind": "srflx/srflx",
                "report_path": "/tmp/x.json",
            }
        ],
    }
    html = mod.render_matrix_html(report)
    assert "DecentNet two-host matrix report" in html
    assert "srflx/srflx" in html
    assert "/tmp/x.json" in html


def test_matrix_local_generates_ok_report(tmp_path: Path):
    repo = Path(__file__).resolve().parent.parent
    script = repo / "scripts" / "two_host_test.py"

    base_port, _ = _free_port_pair()

    matrix_run = subprocess.run(
        [
            sys.executable,
            str(script),
            "matrix",
            "--host-a-runner",
            "local",
            "--host-b-runner",
            "local",
            "--host-a-repo",
            str(repo),
            "--host-b-repo",
            str(repo),
            "--host-a-root-prefix",
            str(tmp_path / "a"),
            "--host-b-root-prefix",
            str(tmp_path / "b"),
            "--host-a-public-host",
            "127.0.0.1",
            "--host-b-public-host",
            "127.0.0.1",
            "--base-port",
            str(base_port),
            "--scenario",
            "direct",
            "--scenario",
            "full",
            "--trials",
            "1",
            "--stage-dir",
            str(tmp_path / "stage"),
            "--report-out",
            str(tmp_path / "matrix.json"),
            "--html-out",
            str(tmp_path / "matrix.html"),
        ],
        cwd=str(repo),
        capture_output=True,
        text=True,
        timeout=120,
    )
    assert matrix_run.returncode == 0, matrix_run.stdout + "\n" + matrix_run.stderr

    report = json.loads((tmp_path / "matrix.json").read_text(encoding="utf-8"))
    assert report["ok"] is True
    assert report["total_runs"] == 2
    assert report["passed_runs"] == 2
    assert report["by_scenario"]["direct"]["passed"] == 1
    assert report["by_scenario"]["full"]["passed"] == 1
    assert (tmp_path / "matrix.html").exists()


def test_render_soak_html_contains_campaign_rows():
    mod = _load_harness_module()
    report = {
        "ok": True,
        "total_campaigns": 2,
        "successful_campaigns": 2,
        "failed_campaigns": 0,
        "total_runs": 4,
        "passed_runs": 4,
        "failed_runs": 0,
        "relay_runs": 1,
        "avg_campaign_duration_s": 2.5,
        "avg_run_duration_s": 1.25,
        "max_ok_streak": 2,
        "max_fail_streak": 0,
        "by_scenario": {"direct": {"total": 2, "passed": 2, "failed": 0}},
        "campaigns": [
            {"campaign": 1, "ok": True, "scenario_list": ["direct"], "trials": 1, "total_runs": 1, "passed_runs": 1, "relay_runs": 0, "duration_s": 1.0, "report_path": "/tmp/c1.json"}
        ],
    }
    html = mod.render_soak_html(report)
    assert "DecentNet two-host soak report" in html
    assert "/tmp/c1.json" in html
    assert "Max success streak" in html


def test_soak_local_generates_ok_report(tmp_path: Path):
    repo = Path(__file__).resolve().parent.parent
    script = repo / "scripts" / "two_host_test.py"

    base_port, _ = _free_port_pair()

    soak_run = subprocess.run(
        [
            sys.executable,
            str(script),
            "soak",
            "--host-a-runner",
            "local",
            "--host-b-runner",
            "local",
            "--host-a-repo",
            str(repo),
            "--host-b-repo",
            str(repo),
            "--host-a-root-prefix",
            str(tmp_path / "a"),
            "--host-b-root-prefix",
            str(tmp_path / "b"),
            "--host-a-public-host",
            "127.0.0.1",
            "--host-b-public-host",
            "127.0.0.1",
            "--base-port",
            str(base_port),
            "--scenario",
            "direct",
            "--trials",
            "1",
            "--rounds",
            "1",
            "--stage-dir",
            str(tmp_path / "stage"),
            "--rolling-out",
            str(tmp_path / "soak.json"),
            "--html-out",
            str(tmp_path / "soak.html"),
        ],
        cwd=str(repo),
        capture_output=True,
        text=True,
        timeout=180,
    )
    assert soak_run.returncode == 0, soak_run.stdout + "\n" + soak_run.stderr
    assert soak_run.returncode == 0, soak_run.stdout + "\n" + soak_run.stderr

    report = json.loads((tmp_path / "soak.json").read_text(encoding="utf-8"))
    assert report["ok"] is True
    assert report["total_campaigns"] == 1
    assert report["successful_campaigns"] == 1
    assert report["total_runs"] == 1
    assert (tmp_path / "soak.html").exists()



def test_pack_collects_reports_logs_and_snapshots(tmp_path: Path):
    repo = Path(__file__).resolve().parent.parent
    script = repo / "scripts" / "two_host_test.py"

    operator_report = tmp_path / "operator.json"
    operator_report.write_text(json.dumps({
        "kind": "two_host_orchestrated_report",
        "ok": True,
        "checked_at": int(time.time()),
        "verdict": {"hello_completed": True, "ring_completed": True, "relay_used": False},
    }), encoding="utf-8")
    matrix_report = tmp_path / "matrix.json"
    matrix_report.write_text(json.dumps({
        "kind": "two_host_matrix_report",
        "ok": True,
        "total_runs": 2,
        "passed_runs": 2,
        "failed_runs": 0,
        "relay_runs": 0,
        "avg_duration_s": 1.0,
        "by_scenario": {"direct": {"total": 2, "passed": 2, "failed": 0}},
        "runs": [],
    }), encoding="utf-8")
    soak_report = tmp_path / "soak.json"
    soak_report.write_text(json.dumps({
        "kind": "two_host_soak_report",
        "ok": True,
        "total_campaigns": 1,
        "successful_campaigns": 1,
        "failed_campaigns": 0,
        "total_runs": 2,
        "passed_runs": 2,
        "failed_runs": 0,
        "relay_runs": 0,
        "avg_campaign_duration_s": 2.0,
        "avg_run_duration_s": 1.0,
        "max_ok_streak": 1,
        "max_fail_streak": 0,
        "by_scenario": {"full": {"total": 2, "passed": 2, "failed": 0}},
        "campaigns": [],
    }), encoding="utf-8")
    log_file = tmp_path / "host-a.log"
    log_file.write_text("hello\nworld\n", encoding="utf-8")

    out_dir = tmp_path / "bundle"
    archive = tmp_path / "bundle.zip"

    pack_run = subprocess.run(
        [
            sys.executable,
            str(script),
            "pack",
            "--operator-report",
            str(operator_report),
            "--matrix-report",
            str(matrix_report),
            "--soak-report",
            str(soak_report),
            "--log-file",
            str(log_file),
            "--out-dir",
            str(out_dir),
            "--archive-out",
            str(archive),
        ],
        cwd=str(repo),
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert pack_run.returncode == 0, pack_run.stdout + "\n" + pack_run.stderr

    manifest = json.loads((out_dir / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["kind"] == "decentnet_operator_bundle"
    assert manifest["counts"]["operator_reports"] == 1
    assert manifest["counts"]["soak_reports"] == 2
    assert (out_dir / "dashboard-snapshot.json").exists()
    assert (out_dir / "dashboard-snapshot.html").exists()
    assert (out_dir / "index.html").exists()
    assert archive.exists()

    import zipfile
    with zipfile.ZipFile(archive, 'r') as zf:
        names = set(zf.namelist())
    assert "manifest.json" in names
    assert "dashboard-snapshot.json" in names
    assert "dashboard-snapshot.html" in names
    assert any(name.startswith("reports/operator/") for name in names)
    assert any(name.startswith("reports/soak/") for name in names)
    assert any(name.startswith("logs/") for name in names)


def test_render_daemon_unit_contains_execstart():
    mod = _load_harness_module()
    unit = mod.render_daemon_unit(
        service_name="host-a",
        repo="/opt/decentnet",
        root="/var/lib/decentnet/a",
        python_bin="/opt/decentnet/.venv/bin/python",
        udp_port=41234,
        socket_path="/var/lib/decentnet/a/control.sock",
    )
    assert "Description=DecentNet daemon (host-a)" in unit
    assert "WorkingDirectory=/opt/decentnet" in unit
    assert "python" in unit and "daemon --udp-port 41234" in unit
    assert "/var/lib/decentnet/a/control.sock" in unit


def test_deploy_dry_run_emits_plan(tmp_path: Path):
    repo = Path(__file__).resolve().parent.parent
    script = repo / "scripts" / "two_host_test.py"
    report_out = tmp_path / "deploy-plan.json"
    run = subprocess.run(
        [
            sys.executable,
            str(script),
            "deploy",
            "--host-a-runner", "local",
            "--host-b-runner", "local",
            "--host-a-repo", str(repo),
            "--host-b-repo", str(repo),
            "--host-a-root", str(tmp_path / "a"),
            "--host-b-root", str(tmp_path / "b"),
            "--host-a-public-address", "127.0.0.1:41234",
            "--host-b-public-address", "127.0.0.1:41235",
            "--report-out", str(report_out),
            "--dry-run",
            "--install-mode", "skip",
        ],
        cwd=str(repo),
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert run.returncode == 0, run.stdout + "\n" + run.stderr
    data = json.loads(report_out.read_text(encoding="utf-8"))
    assert data["ok"] is True
    assert data["dry_run"] is True
    assert len(data["plan"]) >= 2
    stages = {item["stage"] for item in data["plan"]}
    assert "host_a:doctor" in stages
    assert "host_b:doctor" in stages


def test_deploy_local_validate_with_repo_sync_generates_report(tmp_path: Path):
    repo = Path(__file__).resolve().parent.parent
    script = repo / "scripts" / "two_host_test.py"
    remote_parent = tmp_path / "remote"
    a_repo = remote_parent / "a_repo"
    b_repo = remote_parent / "b_repo"
    a_port, b_port = _free_port_pair()
    report_out = tmp_path / "deploy-report.json"
    run = subprocess.run(
        [
            sys.executable,
            str(script),
            "deploy",
            "--host-a-runner", "local",
            "--host-b-runner", "local",
            "--host-a-repo", str(a_repo),
            "--host-b-repo", str(b_repo),
            "--host-a-root", str(tmp_path / "a_root"),
            "--host-b-root", str(tmp_path / "b_root"),
            "--host-a-udp-port", str(a_port),
            "--host-b-udp-port", str(b_port),
            "--host-a-public-address", f"127.0.0.1:{a_port}",
            "--host-b-public-address", f"127.0.0.1:{b_port}",
            "--report-out", str(report_out),
            "--install-mode", "skip",
            "--sync-repo",
            "--send-ring",
        ],
        cwd=str(repo),
        capture_output=True,
        text=True,
        timeout=180,
    )
    assert run.returncode == 0, run.stdout + "\n" + run.stderr
    deploy = json.loads(run.stdout)
    assert deploy["ok"] is True
    result = deploy["result"]
    assert result["mode"] == "orchestrate"
    orchestrated = json.loads(Path(result["report_out"]).read_text(encoding="utf-8"))
    assert orchestrated["ok"] is True
    assert orchestrated["verdict"]["hello_completed"] is True
    assert orchestrated["verdict"]["ring_completed"] is True
