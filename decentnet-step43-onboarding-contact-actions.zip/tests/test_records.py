import copy
import json

import pytest

from decentnet.identity.keypair import Keypair
from decentnet.records.endpoints import Endpoint
from decentnet.records.locator import (
    LocatorRecord,
    record_is_newer,
)


def _mk(ep_list=None, seq=1, ttl=3600, soft=900, t=1_700_000_000):
    kp = Keypair.generate()
    endpoints = ep_list if ep_list is not None else [
        Endpoint(type="public_udp", address="203.0.113.5:41234"),
    ]
    rec = LocatorRecord.build_and_sign(
        kp, endpoints=endpoints, seq=seq, ttl_s=ttl,
        soft_ttl_s=soft, issued_at=t,
    )
    return kp, rec


def test_record_build_and_verify():
    _, rec = _mk()
    ok, reason = rec.verify()
    assert ok, reason


def test_record_wire_roundtrip():
    _, rec = _mk()
    data = rec.to_wire_bytes()
    rec2 = LocatorRecord.from_wire_bytes(data)
    ok, reason = rec2.verify()
    assert ok, reason
    assert rec2.peer_id == rec.peer_id
    assert rec2.seq == rec.seq
    assert rec2.signature == rec.signature


def test_wire_bytes_deterministic():
    _, rec = _mk()
    a = rec.to_wire_bytes()
    b = rec.to_wire_bytes()
    assert a == b


def test_tampered_endpoint_fails_verification():
    _, rec = _mk()
    data = rec.to_wire_bytes()
    obj = json.loads(data)
    obj["endpoints"][0]["address"] = "198.51.100.9:9999"
    tampered = json.dumps(obj).encode()
    rec2 = LocatorRecord.from_wire_bytes(tampered)
    ok, reason = rec2.verify()
    assert not ok
    assert "signature" in reason


def test_tampered_peer_id_fails_verification():
    _, rec = _mk()
    obj = json.loads(rec.to_wire_bytes())
    # Swap peer_id to something else valid-looking.
    other_kp = Keypair.generate()
    from decentnet.identity.peer_id import PeerId
    obj["peer_id"] = PeerId.from_public_key(other_kp.public_key_bytes).value
    bad = json.dumps(obj).encode()
    rec2 = LocatorRecord.from_wire_bytes(bad)
    ok, reason = rec2.verify()
    assert not ok


def test_record_precedence_by_seq():
    kp = Keypair.generate()
    r1 = LocatorRecord.build_and_sign(
        kp, endpoints=[Endpoint(type="public_udp", address="1.1.1.1:1111")],
        seq=1, issued_at=1_700_000_000,
    )
    r2 = LocatorRecord.build_and_sign(
        kp, endpoints=[Endpoint(type="public_udp", address="2.2.2.2:2222")],
        seq=2, issued_at=1_700_000_000,
    )
    assert record_is_newer(r2, r1)
    assert not record_is_newer(r1, r2)


def test_record_precedence_same_seq_by_time():
    kp = Keypair.generate()
    r1 = LocatorRecord.build_and_sign(
        kp, endpoints=[Endpoint(type="public_udp", address="1.1.1.1:1111")],
        seq=5, issued_at=1_700_000_000,
    )
    r2 = LocatorRecord.build_and_sign(
        kp, endpoints=[Endpoint(type="public_udp", address="2.2.2.2:2222")],
        seq=5, issued_at=1_700_000_050,
    )
    assert record_is_newer(r2, r1)
    assert not record_is_newer(r1, r2)


def test_record_precedence_exact_duplicate_not_newer():
    _, rec = _mk()
    assert not record_is_newer(rec, rec)


def test_soft_ttl_bounds_enforced():
    kp = Keypair.generate()
    with pytest.raises(ValueError):
        LocatorRecord.build_and_sign(
            kp, endpoints=[Endpoint(type="public_udp", address="1.1.1.1:1")],
            seq=1, ttl_s=10, soft_ttl_s=100,
        )


def test_endpoint_rejects_unknown_type():
    with pytest.raises(ValueError):
        Endpoint(type="wormhole", address="x:1")


def test_endpoint_rejects_bad_confidence():
    with pytest.raises(ValueError):
        Endpoint(type="public_udp", address="1.1.1.1:1", confidence=2.0)


def test_freshness_predicates():
    _, rec = _mk(t=1000, ttl=100, soft=50)
    assert not rec.is_hard_expired(at=1050)
    assert rec.needs_soft_refresh(at=1060)
    assert rec.is_hard_expired(at=1100)
