"""Phase 4 signaling: hello/ring/bye, replay/spoof rejection, trust promotion."""
import tempfile
from pathlib import Path

import pytest

from decentnet.node import Node, NodeConfig
from decentnet.records.endpoints import Endpoint
from decentnet.relay import RelayServer, TAG_ALLOCATE_OK, build_allocate_request, parse_response
from decentnet.signaling import SignalType, SessionState
from decentnet.signaling.engine import SignalingEngine
import decentnet.signaling.engine as signaling_engine_mod
from decentnet.signaling.messages import build_and_sign, verify_envelope
from decentnet.transport.inproc import InProcessNetwork
from decentnet.transport.messages import UnreachableError
from decentnet.transport.udp import UDPTransport


@pytest.fixture
def tmp_root():
    with tempfile.TemporaryDirectory() as td:
        yield Path(td)


def _mk_pair(tmp_root):
    """Two networked Nodes that have resolved each other (L1 populated)."""
    net = InProcessNetwork()
    a = Node(NodeConfig.at(tmp_root / "a"), network=net)
    b = Node(NodeConfig.at(tmp_root / "b"), network=net)
    a.join_network([(b.peer_id.value, "")])
    b.join_network([(a.peer_id.value, "")])
    # Publish so each has the other's LocatorRecord (with public_key) in L1.
    a.publish_own_record(
        endpoints=[Endpoint(type="public_udp", address="1.1.1.1:1")]
    )
    a.publish_to_network()
    b.publish_own_record(
        endpoints=[Endpoint(type="public_udp", address="2.2.2.2:2")]
    )
    b.publish_to_network()
    # Each resolves the other so their L1 has the peer's record.
    a.resolve(b.peer_id.value, force_network=True)
    b.resolve(a.peer_id.value, force_network=True)
    return net, a, b


# ---------------- hello / hello_ack ----------------


def test_hello_handshake_establishes_session(tmp_root):
    net, a, b = _mk_pair(tmp_root)
    try:
        r = a.signaling.hello(b.peer_id.value)
        assert r.ok, r.reason
        # A's view of B.
        sess_a = a.signaling.session(b.peer_id.value)
        assert sess_a is not None
        assert sess_a.state == SessionState.ESTABLISHED
        # B's view of A.
        sess_b = b.signaling.session(a.peer_id.value)
        assert sess_b is not None
        assert sess_b.state == SessionState.ESTABLISHED
        # Trusted peers reported on both sides.
        assert b.peer_id.value in a.signaling.trusted_peers()
        assert a.peer_id.value in b.signaling.trusted_peers()
    finally:
        a.close()
        b.close()


def test_hello_to_unresolved_peer_fails(tmp_root):
    net = InProcessNetwork()
    a = Node(NodeConfig.at(tmp_root / "a"), network=net)
    # B exists but A has never resolved it; A's L1 has no record for B.
    b = Node(NodeConfig.at(tmp_root / "b"), network=net)
    try:
        r = a.signaling.hello(b.peer_id.value)
        assert not r.ok
        assert r.reason == "peer_unresolved"
    finally:
        a.close()
        b.close()


# ---------------- ring / ring_ack ----------------


def test_ring_requires_established_session(tmp_root):
    net, a, b = _mk_pair(tmp_root)
    try:
        r = a.signaling.ring(b.peer_id.value, body={"reason": "test"})
        assert not r.ok
        assert r.reason == "no_established_session"
    finally:
        a.close()
        b.close()


def test_ring_ack_transitions_to_in_call(tmp_root):
    net, a, b = _mk_pair(tmp_root)
    try:
        assert a.signaling.hello(b.peer_id.value).ok
        # B accepts rings by default (auto-ACK when no callback set).
        result = a.signaling.ring(b.peer_id.value, body={"topic": "greeting"})
        assert result.ok, result.reason
        assert a.signaling.session(b.peer_id.value).state == SessionState.IN_CALL
        assert b.signaling.session(a.peer_id.value).state == SessionState.IN_CALL
    finally:
        a.close()
        b.close()


def test_ring_rejected_by_app_callback(tmp_root):
    net, a, b = _mk_pair(tmp_root)
    try:
        b.signaling.on_ring(lambda peer, body: False)  # always decline
        assert a.signaling.hello(b.peer_id.value).ok
        result = a.signaling.ring(b.peer_id.value, timeout_s=1.0)
        assert not result.ok
        assert result.reason == "timeout"
    finally:
        a.close()
        b.close()


# ---------------- replay / spoof protection ----------------


def test_replay_of_hello_rejected(tmp_root):
    net, a, b = _mk_pair(tmp_root)
    try:
        # Build a valid HELLO but send it twice: first via normal flow
        # (which completes), then re-inject the same msg_id.
        hello = build_and_sign(
            a.keypair, SignalType.HELLO,
            sender=a.peer_id.value, target=b.peer_id.value,
            body={"hint": "first"},
        )
        # Deliver via transport directly (bypass send_and_wait).
        b._transport.deliver(a.peer_id.value, hello)
        # Re-deliver same msg_id: replay detector trips.
        b._transport.deliver(a.peer_id.value, hello)
        rejections = [
            e for e in b.audit.entries()
            if e.get("kind") == "signal.reject"
               and e.get("reason") == "replayed_msg_id"
        ]
        assert len(rejections) >= 1
    finally:
        a.close()
        b.close()


def test_spoofed_signature_rejected(tmp_root):
    net, a, b = _mk_pair(tmp_root)
    try:
        # Build a HELLO claiming to be from a third peer (attacker
        # signs with their own key but claims A's peer_id).
        # Since A's public_key won't verify the attacker's signature,
        # the envelope check rejects.
        from decentnet.identity.keypair import Keypair
        attacker = Keypair.generate()

        from decentnet.utils.encoding import canonical_json_bytes, b64u_encode
        from decentnet.transport.messages import Message
        import uuid
        from decentnet import APP_MAGIC
        from decentnet.utils.time import now_s

        msg = Message(
            type=SignalType.HELLO.value,
            sender=a.peer_id.value,  # claim A
            msg_id=uuid.uuid4().hex,
            payload={
                "app_magic": APP_MAGIC,
                "sig_version": 1,
                "target": b.peer_id.value,
                "nonce": "deadbeef" * 4,
                "issued_at": now_s(),
                "body": {"hint": "spoof"},
            },
        )
        # Sign with attacker key instead of A's.
        from decentnet.signaling.messages import _signing_input_dict
        sig = attacker.sign(canonical_json_bytes(_signing_input_dict(msg)))
        msg.payload["signature"] = b64u_encode(sig)

        b._transport.deliver(a.peer_id.value, msg)
        rejections = [
            e for e in b.audit.entries()
            if e.get("kind") == "signal.reject"
               and e.get("reason") == "signature verification failed"
        ]
        assert len(rejections) >= 1
        # B did NOT promote A to trusted (no handshake completed).
        sess = b.signaling.session(a.peer_id.value)
        assert sess is None or sess.state != SessionState.ESTABLISHED
    finally:
        a.close()
        b.close()


def test_wrong_target_rejected(tmp_root):
    net, a, b = _mk_pair(tmp_root)
    c_cfg = NodeConfig.at(tmp_root / "c")
    c = Node(c_cfg, network=net)
    try:
        # A signs a HELLO addressed to C, but delivers it to B.
        hello = build_and_sign(
            a.keypair, SignalType.HELLO,
            sender=a.peer_id.value, target=c.peer_id.value,
            body={},
        )
        b._transport.deliver(a.peer_id.value, hello)
        rejections = [
            e for e in b.audit.entries()
            if e.get("kind") == "signal.reject"
               and e.get("reason") == "not addressed to me"
        ]
        assert len(rejections) >= 1
    finally:
        a.close()
        b.close()
        c.close()


# ---------------- pass-through ----------------


def test_offer_passthrough_after_established_session(tmp_root):
    net, a, b = _mk_pair(tmp_root)
    try:
        assert a.signaling.hello(b.peer_id.value).ok
        r = a.signaling.send_passthrough(
            b.peer_id.value,
            SignalType.OFFER,
            {"sdp": "fake-sdp-body"},
        )
        assert r.ok, r.reason
        inbox = b.signaling.drain_inbox()
        assert len(inbox) == 1
        from_peer, msg = inbox[0]
        assert from_peer == a.peer_id.value
        assert msg.type == SignalType.OFFER.value
        assert msg.payload["body"]["sdp"] == "fake-sdp-body"
    finally:
        a.close()
        b.close()


def test_passthrough_without_session_fails(tmp_root):
    net, a, b = _mk_pair(tmp_root)
    try:
        # No hello yet.
        r = a.signaling.send_passthrough(
            b.peer_id.value,
            SignalType.OFFER,
            {"sdp": "x"},
        )
        assert not r.ok
        assert r.reason == "no_established_session"
    finally:
        a.close()
        b.close()


# ---------------- bye + idle gc ----------------


def test_bye_closes_session(tmp_root):
    net, a, b = _mk_pair(tmp_root)
    try:
        assert a.signaling.hello(b.peer_id.value).ok
        a.signaling.bye(b.peer_id.value)
        assert a.signaling.session(b.peer_id.value).state == SessionState.CLOSED
        assert b.signaling.session(a.peer_id.value).state == SessionState.CLOSED
    finally:
        a.close()
        b.close()


def test_gc_idle_sessions_clears_closed(tmp_root):
    net, a, b = _mk_pair(tmp_root)
    try:
        assert a.signaling.hello(b.peer_id.value).ok
        a.signaling.bye(b.peer_id.value)
        removed = a.signaling.gc_idle_sessions(idle_timeout_s=0)
        assert removed >= 1
    finally:
        a.close()
        b.close()


# ---------------- negative cache ----------------


def test_negcache_blocks_after_repeated_failures(tmp_root):
    net = InProcessNetwork()
    a = Node(NodeConfig.at(tmp_root / "a"), network=net)
    # Peer that A resolves (so public_key is cached) but is offline.
    b = Node(NodeConfig.at(tmp_root / "b"), network=net)
    a.join_network([(b.peer_id.value, "")])
    b.publish_own_record(
        endpoints=[Endpoint(type="public_udp", address="2.2.2.2:2")]
    )
    b.publish_to_network()
    a.resolve(b.peer_id.value, force_network=True)
    try:
        net.set_offline(b.peer_id.value)
        # A series of failures.
        for _ in range(4):
            r = a.signaling.hello(b.peer_id.value, timeout_s=0.2)
            assert not r.ok
        # After enough failures, the next attempt short-circuits to negcache.
        r = a.signaling.hello(b.peer_id.value, timeout_s=0.2)
        assert not r.ok
        assert r.reason == "negcache"
    finally:
        a.close()
        b.close()


def test_hello_auto_starts_ice_and_nominates_pair(tmp_root):
    import time

    net, a, b = _mk_pair(tmp_root)
    try:
        assert a.signaling.hello(b.peer_id.value).ok
        deadline = time.time() + 2.0
        while time.time() < deadline:
            a_events = a.audit.entries()
            b_events = b.audit.entries()
            if any(e.get("kind") == "ice.nominated" for e in a_events + b_events):
                break
            time.sleep(0.05)
        assert any(e.get("kind") == "ice.pairs_enumerated" for e in a.audit.entries())
        assert any(e.get("kind") == "ice.pairs_enumerated" for e in b.audit.entries())
        assert any(e.get("kind") == "ice.nominated" for e in a.audit.entries() + b.audit.entries())
    finally:
        a.close()
        b.close()


def test_selected_ice_pair_persists_into_session_and_updates_preferred_endpoint(tmp_root):
    import time

    net, a, b = _mk_pair(tmp_root)
    register_calls = []

    def capture_register(peer_id, host, port):
        register_calls.append((peer_id, host, port))

    # Simulate transports that can learn a preferred endpoint from ICE.
    setattr(a.signaling._tx, "register_endpoint", capture_register)
    try:
        assert a.signaling.hello(b.peer_id.value).ok
        deadline = time.time() + 2.0
        while time.time() < deadline:
            sess = a.signaling.session(b.peer_id.value)
            if sess is not None and sess.selected_remote_addr is not None:
                break
            time.sleep(0.05)
        sess = a.signaling.session(b.peer_id.value)
        assert sess is not None
        assert sess.selected_local_addr == ("1.1.1.1", 1)
        assert sess.selected_remote_addr == ("2.2.2.2", 2)
        assert sess.selected_pair_kind == "srflx/srflx"
        assert sess.selected_at is not None
        assert any(e.get("kind") == "ice.path_selected" for e in a.audit.entries())
        assert (b.peer_id.value, "2.2.2.2", 2) in register_calls
        assert a.signaling.ring(b.peer_id.value, body={"topic": "path-check"}).ok
        assert register_calls[-1] == (b.peer_id.value, "2.2.2.2", 2)
    finally:
        a.close()
        b.close()


def test_keepalive_marks_selected_path_healthy(tmp_root):
    import time

    net, a, b = _mk_pair(tmp_root)
    try:
        assert a.signaling.hello(b.peer_id.value).ok
        deadline = time.time() + 2.0
        while time.time() < deadline:
            sess = a.signaling.session(b.peer_id.value)
            if sess is not None and sess.selected_remote_addr is not None:
                break
            time.sleep(0.05)
        sess = a.signaling.session(b.peer_id.value)
        assert sess is not None
        sess.mark_path_failure("synthetic")
        assert sess.selected_path_failures == 1
        result = a.signaling.keepalive(b.peer_id.value)
        assert result.ok, result.reason
        assert sess.selected_path_failures == 0
        assert sess.last_path_error is None
        assert sess.selected_path_ok_at is not None
        assert any(e.get("kind") == "signal.keepalive_ok" for e in a.audit.entries())
    finally:
        a.close()
        b.close()


def test_keepalive_failures_trigger_ice_restart_and_clear_selected_path(tmp_root):
    import time

    net, a, b = _mk_pair(tmp_root)
    try:
        assert a.signaling.hello(b.peer_id.value).ok
        deadline = time.time() + 2.0
        while time.time() < deadline:
            sess = a.signaling.session(b.peer_id.value)
            if sess is not None and sess.selected_remote_addr is not None:
                break
            time.sleep(0.05)
        sess = a.signaling.session(b.peer_id.value)
        assert sess is not None
        assert sess.selected_remote_addr is not None
        net.set_offline(b.peer_id.value)
        assert a.signaling.keepalive(b.peer_id.value, timeout_s=0.05).reason == "unreachable"
        assert sess.selected_path_failures == 1
        assert a.signaling.keepalive(b.peer_id.value, timeout_s=0.05).reason == "unreachable"
        deadline = time.time() + 2.0
        while time.time() < deadline and sess.ice_restart_count < 1:
            time.sleep(0.05)
        assert sess.ice_restart_count >= 1
        assert sess.selected_remote_addr is None
        kinds = [e.get("kind") for e in a.audit.entries()]
        assert "ice.path_degraded" in kinds
        assert "ice.restart" in kinds
    finally:
        a.close()
        b.close()


def _mk_udp_relay_pair(tmp_root):
    a = Node(NodeConfig.at(tmp_root / "ua"))
    b = Node(NodeConfig.at(tmp_root / "ub"))
    a._transport = UDPTransport(a.peer_id.value, bind_host="127.0.0.1", bind_port=0)
    b._transport = UDPTransport(b.peer_id.value, bind_host="127.0.0.1", bind_port=0)
    a.signaling = SignalingEngine(
        local_peer_id=a.peer_id.value,
        keypair=a.keypair,
        transport=a._transport,
        local_cache=a.cache,
        audit=a.audit,
    )
    b.signaling = SignalingEngine(
        local_peer_id=b.peer_id.value,
        keypair=b.keypair,
        transport=b._transport,
        local_cache=b.cache,
        audit=b.audit,
    )

    relay = RelayServer(bind_host="127.0.0.1", bind_port=0)
    relay_addr = (relay.bind_host, relay.bind_port)
    relay_addr_s = f"{relay.bind_host}:{relay.bind_port}"
    tok_a = relay.issue_token(a.peer_id.value, ttl_s=600)
    tok_b = relay.issue_token(b.peer_id.value, ttl_s=600)

    def allocate(node, tok):
        data, _ = node._transport.send_raw_and_wait(
            build_allocate_request(node.peer_id.value, tok),
            relay_addr,
            matcher=lambda d, addr: addr == relay_addr and bool(d) and d[0] == TAG_ALLOCATE_OK,
            timeout_s=1.0,
        )
        tag, body = parse_response(data)
        assert tag == TAG_ALLOCATE_OK
        assert relay_addr_s in body.decode("utf-8")

    allocate(a, tok_a)
    allocate(b, tok_b)

    a.publish_own_record(
        endpoints=[
            Endpoint(type="public_udp", address="127.0.0.1:9"),
            Endpoint(type="relay_candidate", address=relay_addr_s),
        ],
        nat_metadata={"relay_token": tok_a.to_json()},
    )
    b.publish_own_record(
        endpoints=[
            Endpoint(type="public_udp", address="127.0.0.1:10"),
            Endpoint(type="relay_candidate", address=relay_addr_s),
        ],
        nat_metadata={"relay_token": tok_b.to_json()},
    )
    a.ingest_record_bytes(b.export_own_record(), source="bootstrap")
    b.ingest_record_bytes(a.export_own_record(), source="bootstrap")
    return relay, a, b


def test_hello_falls_back_to_relay_when_direct_path_unreachable(tmp_root):
    relay, a, b = _mk_udp_relay_pair(tmp_root)
    try:
        result = a.signaling.hello(b.peer_id.value, timeout_s=0.15)
        assert result.ok, result.reason
        sess = a.signaling.session(b.peer_id.value)
        assert sess is not None
        assert sess.selected_pair_kind == "relay/relay"
        assert sess.relay_addr == (relay.bind_host, relay.bind_port)
        assert any(e.get("kind") == "relay.path_selected" for e in a.audit.entries())
        assert any(e.get("kind") == "signal.hello_ack_sent" for e in b.audit.entries())
    finally:
        a.close()
        b.close()
        relay.close()


def test_keepalive_uses_selected_relay_path(tmp_root):
    relay, a, b = _mk_udp_relay_pair(tmp_root)
    try:
        assert a.signaling.hello(b.peer_id.value, timeout_s=0.15).ok
        result = a.signaling.keepalive(b.peer_id.value, timeout_s=0.5)
        assert result.ok, result.reason
        sess = a.signaling.session(b.peer_id.value)
        assert sess is not None
        assert sess.selected_pair_kind == "relay/relay"
        assert sess.relay_last_used_at is not None
        assert relay.forward_count >= 2
        assert any(e.get("kind") == "signal.keepalive_ok" for e in a.audit.entries())
    finally:
        a.close()
        b.close()
        relay.close()


def test_relay_allocation_renews_when_own_token_changes(tmp_root):
    relay, a, b = _mk_udp_relay_pair(tmp_root)
    try:
        assert a.signaling.hello(b.peer_id.value, timeout_s=0.15).ok
        sess = a.signaling.session(b.peer_id.value)
        assert sess is not None
        old_fp = sess.relay_token_fingerprint
        relay_addr_s = f"{relay.bind_host}:{relay.bind_port}"
        fresh_token = relay.issue_token(a.peer_id.value, ttl_s=601)
        a.publish_own_record(
            endpoints=[
                Endpoint(type="public_udp", address="127.0.0.1:9"),
                Endpoint(type="relay_candidate", address=relay_addr_s),
            ],
            nat_metadata={"relay_token": fresh_token.to_json()},
        )
        result = a.signaling.keepalive(b.peer_id.value, timeout_s=0.5)
        assert result.ok, result.reason
        sess = a.signaling.session(b.peer_id.value)
        assert sess is not None
        assert sess.relay_token_fingerprint != old_fp
        kinds = [e.get("kind") for e in a.audit.entries()]
        assert "relay.cache_stale" in kinds
        assert any(k in kinds for k in ("relay.allocated", "relay.renewed"))
    finally:
        a.close()
        b.close()
        relay.close()


def test_relay_path_failure_invalidates_and_can_recover(tmp_root, monkeypatch):
    relay, a, b = _mk_udp_relay_pair(tmp_root)
    try:
        assert a.signaling.hello(b.peer_id.value, timeout_s=0.15).ok
        original_send_raw = a._transport.send_raw

        def broken_send_raw(data, addr):
            raise UnreachableError("forced relay failure")

        monkeypatch.setattr(a._transport, "send_raw", broken_send_raw)
        r1 = a.signaling.keepalive(b.peer_id.value, timeout_s=0.1)
        r2 = a.signaling.keepalive(b.peer_id.value, timeout_s=0.1)
        assert not r1.ok
        assert not r2.ok
        sess = a.signaling.session(b.peer_id.value)
        assert sess is not None
        assert sess.selected_remote_addr is None
        assert sess.relay_addr is None
        assert any(e.get("kind") == "relay.invalidated" for e in a.audit.entries())

        monkeypatch.setattr(a._transport, "send_raw", original_send_raw)
        r3 = a.signaling.hello(b.peer_id.value, timeout_s=0.3)
        assert r3.ok, r3.reason
        sess = a.signaling.session(b.peer_id.value)
        assert sess is not None
        assert sess.selected_pair_kind == "relay/relay"
        assert sess.relay_addr == (relay.bind_host, relay.bind_port)
    finally:
        a.close()
        b.close()
        relay.close()


def test_hello_inline_bootstraps_unresolved_peer_over_inproc(tmp_root):
    net = InProcessNetwork()
    a = Node(NodeConfig.at(tmp_root / "ia"), network=net)
    b = Node(NodeConfig.at(tmp_root / "ib"), network=net)
    try:
        a.publish_own_record(endpoints=[Endpoint(type="public_udp", address="1.1.1.1:1")])
        b.publish_own_record(endpoints=[Endpoint(type="public_udp", address="2.2.2.2:2")])
        result = a.signaling.hello(b.peer_id.value)
        assert result.ok, result.reason
        assert a.cache.peek(b.peer_id.value) is not None
        assert b.cache.peek(a.peer_id.value) is not None
        kinds_a = [e.get("kind") for e in a.audit.entries()]
        kinds_b = [e.get("kind") for e in b.audit.entries()]
        assert "signal.bootstrap_record" in kinds_a
        assert "signal.bootstrap_record" in kinds_b
    finally:
        a.close()
        b.close()





def test_candidate_refresh_updates_cached_record_and_restarts_ice(tmp_root):
    net, a, b = _mk_pair(tmp_root)
    try:
        assert a.signaling.hello(b.peer_id.value).ok
        old_rec = a.cache.peek(b.peer_id.value)
        assert old_rec is not None
        old_seq = old_rec.seq

        b.publish_own_record(endpoints=[Endpoint(type="public_udp", address="9.9.9.9:9")])
        result = b.signaling.refresh_candidates(a.peer_id.value, reason="endpoint_change")
        assert result.ok, result.reason

        import time
        deadline = time.time() + 1.5
        while time.time() < deadline:
            refreshed = a.cache.peek(b.peer_id.value)
            sess = a.signaling.session(b.peer_id.value)
            if refreshed is not None and refreshed.seq > old_seq and sess is not None and sess.selected_remote_addr == ("9.9.9.9", 9):
                break
            time.sleep(0.02)

        refreshed = a.cache.peek(b.peer_id.value)
        sess = a.signaling.session(b.peer_id.value)
        assert refreshed is not None and refreshed.seq > old_seq
        assert sess is not None and sess.selected_remote_addr == ("9.9.9.9", 9)
        assert any(e.get("kind") == "signal.candidate_update_sent" for e in b.audit.entries())
        assert any(e.get("kind") == "signal.candidate_update_received" for e in a.audit.entries())
        inbox = a.signaling.drain_inbox()
        assert any(msg.type == SignalType.CANDIDATE.value for _, msg in inbox)
    finally:
        a.close(); b.close()


def test_candidate_refresh_attaches_sender_record_for_runtime_bootstrap(tmp_root):
    net = InProcessNetwork()
    a = Node(NodeConfig.at(tmp_root / "cra"), network=net)
    b = Node(NodeConfig.at(tmp_root / "crb"), network=net)
    try:
        a.publish_own_record(endpoints=[Endpoint(type="public_udp", address="1.1.1.1:1")])
        b.publish_own_record(endpoints=[Endpoint(type="public_udp", address="2.2.2.2:2")])
        assert a.signaling.hello(b.peer_id.value).ok
        a.cache._store.delete_record(b.peer_id.value)
        assert a.cache.peek(b.peer_id.value) is None
        result = b.signaling.refresh_candidates(a.peer_id.value, reason="runtime_bootstrap")
        assert result.ok, result.reason
        import time
        deadline = time.time() + 1.0
        while time.time() < deadline and a.cache.peek(b.peer_id.value) is None:
            time.sleep(0.02)
        assert a.cache.peek(b.peer_id.value) is not None
        kinds = [e.get("kind") for e in a.audit.entries()]
        assert "signal.bootstrap_record" in kinds or "signal.candidate_record" in kinds
    finally:
        a.close(); b.close()

def test_hello_inline_bootstraps_unresolved_peer_over_udp(tmp_root):
    a = Node(NodeConfig.at(tmp_root / "uautoa"))
    b = Node(NodeConfig.at(tmp_root / "uautob"))
    a._transport = UDPTransport(a.peer_id.value, bind_host="127.0.0.1", bind_port=0)
    b._transport = UDPTransport(b.peer_id.value, bind_host="127.0.0.1", bind_port=0)
    a.signaling = SignalingEngine(
        local_peer_id=a.peer_id.value,
        keypair=a.keypair,
        transport=a._transport,
        local_cache=a.cache,
        audit=a.audit,
    )
    b.signaling = SignalingEngine(
        local_peer_id=b.peer_id.value,
        keypair=b.keypair,
        transport=b._transport,
        local_cache=b.cache,
        audit=b.audit,
    )
    try:
        a.publish_own_record(endpoints=[Endpoint(type="public_udp", address=f"127.0.0.1:{a._transport.bind_port}")])
        b.publish_own_record(endpoints=[Endpoint(type="public_udp", address=f"127.0.0.1:{b._transport.bind_port}")])
        a._transport.register_endpoint(b.peer_id.value, "127.0.0.1", b._transport.bind_port)
        b._transport.register_endpoint(a.peer_id.value, "127.0.0.1", a._transport.bind_port)
        result = a.signaling.hello(b.peer_id.value, timeout_s=0.5)
        assert result.ok, result.reason
        assert a.cache.peek(b.peer_id.value) is not None
        assert b.cache.peek(a.peer_id.value) is not None
        assert a.signaling.ring(b.peer_id.value, body={"topic": "bootstrap"}).ok
    finally:
        a.close()
        b.close()


def test_signal_send_rate_limit_blocks_excess_burst(tmp_root, monkeypatch):
    net, a, b = _mk_pair(tmp_root)
    try:
        assert a.signaling.hello(b.peer_id.value).ok
        monkeypatch.setattr(signaling_engine_mod, "SignalSendBudgetLimit", 1)
        monkeypatch.setattr(signaling_engine_mod, "SignalSendBudgetWindowS", 60)
        a.signaling._signal_send_budget.pop(b.peer_id.value, None)
        first = a.signaling.refresh_candidates(b.peer_id.value, reason="burst1")
        second = a.signaling.refresh_candidates(b.peer_id.value, reason="burst2")
        assert first.ok
        assert not second.ok
        assert second.reason == "signal_rate_limited"
        assert any(e.get("kind") == "signal.rate_limited" for e in a.audit.entries())
    finally:
        a.close()
        b.close()


def test_ice_restart_budget_suppresses_excess_restarts(tmp_root, monkeypatch):
    net, a, b = _mk_pair(tmp_root)
    try:
        assert a.signaling.hello(b.peer_id.value).ok
        monkeypatch.setattr(signaling_engine_mod, "IceRestartBudgetLimit", 1)
        monkeypatch.setattr(signaling_engine_mod, "IceRestartBudgetWindowS", 60)
        a.signaling._restart_ice(b.peer_id.value, reason="forced1")
        sess = a.signaling.session(b.peer_id.value)
        assert sess is not None
        assert sess.ice_restart_count == 1
        a.signaling._restart_ice(b.peer_id.value, reason="forced2")
        assert sess.ice_restart_count == 1
        assert any(e.get("kind") == "ice.restart_suppressed" for e in a.audit.entries())
    finally:
        a.close()
        b.close()


def test_signaling_stats_include_metrics_and_budgets(tmp_root):
    relay, a, b = _mk_udp_relay_pair(tmp_root)
    try:
        assert a.signaling.hello(b.peer_id.value, timeout_s=0.2).ok
        stats = a.signaling.stats()
        assert stats["sessions"]["trusted"] >= 1
        assert "metrics" in stats
        assert stats["metrics"].get("signal.request_reply_attempt", 0) >= 1
        assert stats["relay"]["active_allocations"] >= 1
        assert b.peer_id.value in stats["budgets"]["signal_send"]
    finally:
        a.close()
        b.close()
        relay.close()


def test_force_restart_queues_followup_when_ice_thread_is_running(tmp_root):
    import threading
    import time

    net, a, b = _mk_pair(tmp_root)
    try:
        assert a.signaling.hello(b.peer_id.value).ok

        entered = threading.Event()
        release = threading.Event()
        starts = []

        class DummyAgent:
            def nominated(self):
                return None

            def gather_and_probe(self, timeout_s=1.0):
                starts.append(time.time())
                entered.set()
                release.wait(1.0)
                return None

        a.signaling._ensure_ice_agent = lambda peer_id: DummyAgent()  # type: ignore[method-assign]
        a.signaling._activate_relay_fallback = lambda peer_id, reason: True  # type: ignore[method-assign]

        a.signaling._start_ice(b.peer_id.value, force_restart=True)
        assert entered.wait(0.3)
        a.signaling._start_ice(b.peer_id.value, force_restart=True)
        assert b.peer_id.value in a.signaling._ice_restart_pending

        release.set()

        deadline = time.time() + 1.0
        while time.time() < deadline and len(starts) < 2:
            time.sleep(0.02)

        assert len(starts) >= 2
        assert b.peer_id.value not in a.signaling._ice_restart_pending
    finally:
        a.close()
        b.close()
