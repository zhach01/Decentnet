"""Tests for the expanded CLI and the daemon control socket."""
import json
import os
import socket as _sock
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

import pytest

from decentnet.cli.main import main


@pytest.fixture
def tmp_home(monkeypatch, tmp_path):
    """Isolated HOME-style directory for each test."""
    monkeypatch.setenv("HOME", str(tmp_path))
    return tmp_path


def _run_cli(args, capsys=None, tmp_home=None):
    """Invoke the CLI main() with args; return (rc, stdout, stderr)."""
    full_args = ["--root", str(tmp_home)] + list(args) if tmp_home else list(args)
    # Use capsys to capture output.
    rc = main(full_args)
    return rc


# ---------------- CLI subcommand smoke tests ----------------


def test_cli_init_whoami(tmp_path, capsys):
    rc = main(["--root", str(tmp_path), "init"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "peer_id:" in out
    rc = main(["--root", str(tmp_path), "whoami"])
    assert rc == 0
    out = capsys.readouterr().out.strip()
    # peer_id is 52 chars base32 (sha256 → 32 bytes → 52 base32 chars no pad).
    assert len(out) > 30


def test_cli_topic_list_subscribe(tmp_path, capsys):
    main(["--root", str(tmp_path), "init"])
    capsys.readouterr()
    rc = main(["--root", str(tmp_path), "topic", "list"])
    assert rc == 0
    out = capsys.readouterr().out
    d = json.loads(out)
    assert d["replicate_all"] is True
    assert d["subscribed_topics"] == []
    rc = main(["--root", str(tmp_path), "topic", "subscribe", "urgent"])
    assert rc == 0
    capsys.readouterr()
    rc = main(["--root", str(tmp_path), "topic", "list"])
    out = capsys.readouterr().out
    d = json.loads(out)
    assert len(d["subscribed_topics"]) == 1


def test_cli_rotate_roundtrip(tmp_path, capsys):
    main(["--root", str(tmp_path), "init"])
    capsys.readouterr()
    # Initial publish needed so there's state in the cache.
    main([
        "--root", str(tmp_path), "publish",
        "--endpoint", "public_udp:1.1.1.1:1",
    ])
    capsys.readouterr()
    rc = main([
        "--root", str(tmp_path), "rotate",
        "--endpoint", "public_udp:2.2.2.2:2",
    ])
    assert rc == 0
    out = capsys.readouterr().out
    d = json.loads(out)
    assert d["old_peer_id"] != d["new_peer_id"]
    assert d["receipt_signed_by_old_key"] is True


def test_cli_snapshot_take_and_import(tmp_path, capsys):
    main(["--root", str(tmp_path), "init"])
    main([
        "--root", str(tmp_path), "publish",
        "--endpoint", "public_udp:7.7.7.7:7",
    ])
    capsys.readouterr()
    snap_file = tmp_path / "snap.json"
    rc = main([
        "--root", str(tmp_path), "snapshot", "take",
        "--out", str(snap_file),
    ])
    assert rc == 0
    capsys.readouterr()
    # New fresh root imports it.
    import_root = tmp_path / "imported"
    main(["--root", str(import_root), "init"])
    capsys.readouterr()
    rc = main([
        "--root", str(import_root), "snapshot", "import",
        str(snap_file),
    ])
    assert rc == 0
    out = capsys.readouterr().out
    d = json.loads(out)
    assert d["records_accepted"] >= 1


def test_cli_confidence(tmp_path, capsys):
    main(["--root", str(tmp_path), "init"])
    main([
        "--root", str(tmp_path), "publish",
        "--endpoint", "public_udp:1.1.1.1:1",
    ])
    capsys.readouterr()
    # No peer arg: lists all confidence scores.
    rc = main(["--root", str(tmp_path), "confidence"])
    assert rc == 0
    out = capsys.readouterr().out
    items = json.loads(out)
    # We published ourselves, so there's at least one entry.
    assert isinstance(items, list)


def test_cli_nat_probe_against_mock(tmp_path, capsys):
    from decentnet.nat import MockSTUNServer
    with MockSTUNServer() as stun:
        main(["--root", str(tmp_path), "init"])
        capsys.readouterr()
        rc = main([
            "--root", str(tmp_path), "nat", "probe",
            "--server", f"{stun.bind_host}:{stun.bind_port}",
            "--timeout", "1.0",
        ])
        assert rc == 0
        out = capsys.readouterr().out
        d = json.loads(out)
        assert d["mapped_host"]
        assert isinstance(d["mapped_port"], int)


def test_cli_relay_issue_token(tmp_path, capsys):
    main(["--root", str(tmp_path), "init"])
    capsys.readouterr()
    rc = main([
        "--root", str(tmp_path), "relay", "issue-token",
        "ej7abcde" * 6 + "aaaa",   # 52-char dummy base32
    ])
    assert rc == 0
    out = capsys.readouterr().out.strip()
    tok = json.loads(out)
    assert "signature" in tok
    assert tok["client_peer_id"].startswith("ej7abcde")


def test_cli_deferred_list_empty(tmp_path, capsys):
    main(["--root", str(tmp_path), "init"])
    capsys.readouterr()
    rc = main(["--root", str(tmp_path), "deferred", "list"])
    assert rc == 0
    out = capsys.readouterr().out
    assert json.loads(out) == []


# ---------------- daemon ----------------


def test_daemon_status_and_shutdown(tmp_path):
    """Start the daemon in a subprocess, send status, then shutdown."""
    env = os.environ.copy()
    # Use a short, unique socket path.
    socket_path = tmp_path / "ctrl.sock"
    proc = subprocess.Popen(
        [sys.executable, "-m", "decentnet",
         "--root", str(tmp_path),
         "daemon", "--socket", str(socket_path)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        env=env,
    )
    try:
        # Wait for socket to appear.
        deadline = time.time() + 5.0
        while time.time() < deadline:
            if socket_path.exists():
                break
            time.sleep(0.1)
        assert socket_path.exists(), (
            f"daemon never created socket; stdout:\n"
            f"{proc.stdout.read().decode() if proc.stdout else ''}\n"
            f"stderr:\n"
            f"{proc.stderr.read().decode() if proc.stderr else ''}"
        )

        # Send status.
        s = _sock.socket(_sock.AF_UNIX, _sock.SOCK_STREAM)
        s.settimeout(3.0)
        s.connect(str(socket_path))
        s.sendall(b'{"cmd": "status"}\n')
        chunks = []
        while True:
            b = s.recv(4096)
            if not b:
                break
            chunks.append(b)
        s.close()
        reply = json.loads(b"".join(chunks).decode("utf-8").strip())
        assert reply["ok"] is True
        assert "peer_id" in reply
        assert "udp" in reply

        # Send shutdown.
        s = _sock.socket(_sock.AF_UNIX, _sock.SOCK_STREAM)
        s.settimeout(3.0)
        s.connect(str(socket_path))
        s.sendall(b'{"cmd": "shutdown"}\n')
        s.recv(4096)
        s.close()

        # Process should exit cleanly.
        rc = proc.wait(timeout=5.0)
        assert rc == 0
    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=3.0)
            except subprocess.TimeoutExpired:
                proc.kill()








def test_daemon_auto_publishes_lan_endpoints_from_config(tmp_path, monkeypatch):
    monkeypatch.setenv("DECENTNET_IP_OUTPUT", "2: eth0    inet 10.10.0.5/24 brd 10.10.0.255 scope global eth0\n3: docker0    inet 172.17.0.1/16 brd 172.17.255.255 scope global docker0\n")
    cfg = tmp_path / "config.toml"
    cfg.write_text("\n".join([
        "[transport]",
        'bind_host = "0.0.0.0"',
        'bind_port = 45041',
        "",
        "[advertise]",
        'mode = "auto"',
        'auto_publish = true',
        'auto_vpn = false',
        'auto_lan = true',
        "",
        "[interfaces]",
        'allow = ["eth0"]',
        'deny = ["docker0"]',
    ]))
    socket_path = tmp_path / "ctrl.sock"
    proc = subprocess.Popen(
        [sys.executable, "-m", "decentnet", "--root", str(tmp_path), "daemon", "--socket", str(socket_path), "--config", str(cfg)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    try:
        deadline = time.time() + 5.0
        while time.time() < deadline:
            if socket_path.exists():
                break
            time.sleep(0.1)
        assert socket_path.exists()
        s = _sock.socket(_sock.AF_UNIX, _sock.SOCK_STREAM)
        s.settimeout(3.0)
        s.connect(str(socket_path))
        s.sendall(b'{"cmd": "status"}\n')
        chunks = []
        while True:
            b = s.recv(4096)
            if not b:
                break
            chunks.append(b)
        s.close()
        reply = json.loads(b"".join(chunks).decode("utf-8").strip())
        assert reply["ok"] is True
        assert "10.10.0.5:45041" in reply["advertised_endpoints"]
        assert reply["bind_host"] == "0.0.0.0"
    finally:
        try:
            s = _sock.socket(_sock.AF_UNIX, _sock.SOCK_STREAM)
            s.settimeout(1.0)
            s.connect(str(socket_path))
            s.sendall(b'{"cmd": "shutdown"}\n')
            s.close()
        except Exception:
            pass
        proc.wait(timeout=5)
def test_daemon_status_includes_config_published_endpoints(tmp_path):
    cfg = tmp_path / "config.toml"
    cfg.write_text("\n".join([
        "[transport]",
        'bind_host = "0.0.0.0"',
        'bind_port = 45031',
        "",
        "[advertise]",
        'auto_publish = true',
        'auto_vpn = false',
        "",
        "[[advertise.manual_endpoints]]",
        'type = "lan_udp"',
        'address = "10.10.0.1:45031"',
        'priority = 80',
    ]))
    socket_path = tmp_path / "ctrl.sock"
    proc = subprocess.Popen(
        [sys.executable, "-m", "decentnet", "--root", str(tmp_path), "daemon", "--socket", str(socket_path), "--config", str(cfg)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    try:
        deadline = time.time() + 5.0
        while time.time() < deadline:
            if socket_path.exists():
                break
            time.sleep(0.1)
        assert socket_path.exists()
        s = _sock.socket(_sock.AF_UNIX, _sock.SOCK_STREAM)
        s.settimeout(3.0)
        s.connect(str(socket_path))
        s.sendall(b'{"cmd": "status"}\n')
        chunks = []
        while True:
            b = s.recv(4096)
            if not b:
                break
            chunks.append(b)
        s.close()
        reply = json.loads(b"".join(chunks).decode("utf-8").strip())
        assert reply["ok"] is True
        assert "10.10.0.1:45031" in reply["advertised_endpoints"]
    finally:
        try:
            s = _sock.socket(_sock.AF_UNIX, _sock.SOCK_STREAM)
            s.settimeout(1.0)
            s.connect(str(socket_path))
            s.sendall(b'{"cmd": "shutdown"}\n')
            s.close()
        except Exception:
            pass
        proc.wait(timeout=5)


def test_cli_up_status_down_lifecycle(tmp_path, capsys):
    socket_path = tmp_path / "lifecycle.sock"
    rc = main(["--root", str(tmp_path), "up", "--socket", str(socket_path)])
    assert rc == 0
    info = json.loads(capsys.readouterr().out)
    assert info["ok"] is True
    assert Path(info["socket"]).exists()

    rc = main(["--root", str(tmp_path), "status", "--socket", str(socket_path), "--json"])
    assert rc == 0
    status = json.loads(capsys.readouterr().out)
    assert status["running"] is True
    assert status["daemon_status"]["ok"] is True

    rc = main(["--root", str(tmp_path), "down", "--socket", str(socket_path)])
    assert rc == 0
    capsys.readouterr()


def test_daemon_status_includes_strategy_and_profile(tmp_path):
    cfg = tmp_path / "config.toml"
    cfg.write_text("\n".join([
        "[transport]",
        'bind_host = "0.0.0.0"',
        'bind_port = 45051',
        "",
        "[advertise]",
        'mode = "hybrid"',
        'auto_publish = true',
        'auto_vpn = false',
        'auto_lan = false',
        "",
        "[capabilities]",
        'relay = true',
        'bootstrap_assist = true',
        'observer = true',
    ]))
    socket_path = tmp_path / "ctrl.sock"
    proc = subprocess.Popen(
        [sys.executable, "-m", "decentnet", "--root", str(tmp_path), "daemon", "--socket", str(socket_path), "--config", str(cfg)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    try:
        deadline = time.time() + 5.0
        while time.time() < deadline:
            if socket_path.exists():
                break
            time.sleep(0.1)
        assert socket_path.exists()
        s = _sock.socket(_sock.AF_UNIX, _sock.SOCK_STREAM)
        s.settimeout(3.0)
        s.connect(str(socket_path))
        s.sendall(b'{"cmd": "status"}\n')
        chunks=[]
        while True:
            b=s.recv(4096)
            if not b:
                break
            chunks.append(b)
        s.close()
        reply = json.loads(b"".join(chunks).decode("utf-8").strip())
        assert reply["profile_hint"] == "helper"
        assert "hybrid" in reply["endpoint_strategy"]
        assert "config_validation" in reply
    finally:
        if socket_path.exists():
            try:
                s = _sock.socket(_sock.AF_UNIX, _sock.SOCK_STREAM)
                s.settimeout(1.0)
                s.connect(str(socket_path))
                s.sendall(b'{"cmd": "shutdown"}\n')
                s.close()
            except Exception:
                pass
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=3.0)
            except subprocess.TimeoutExpired:
                proc.kill()


class _FakeProc:
    def __init__(self, pid=43210):
        self.pid = pid


def test_up_refuses_obviously_broken_peer_config(tmp_path, capsys):
    cfg = tmp_path / "peer.toml"
    cfg.write_text(
        """
[transport]
bind_host = "127.0.0.1"
bind_port = 45001

[advertise]
auto_lan = true
auto_vpn = false
mode = "hybrid"

[[advertise.manual_endpoints]]
type = "lan_udp"
address = "10.10.0.1:45001"
""",
        encoding="utf-8",
    )
    rc = main(["--root", str(tmp_path), "up", "--config", str(cfg)])
    assert rc == 1
    out = json.loads(capsys.readouterr().out)
    assert out["startup_refused"] is True
    assert out["summary"]["startup_blockers"]


def test_up_prints_profile_aware_startup_summary(tmp_path, capsys, monkeypatch):
    cfg = tmp_path / "peer.toml"
    cfg.write_text(
        """
[transport]
bind_host = "0.0.0.0"
bind_port = 45001

[advertise]
mode = "hybrid"
auto_lan = true
auto_vpn = false
exclude_loopback = true

[capabilities]
relay = true
bootstrap_assist = true
""",
        encoding="utf-8",
    )
    import importlib, subprocess
    cli_mod = importlib.import_module("decentnet.cli.main")
    monkeypatch.setattr(cli_mod, "preview_advertised_endpoints", lambda **kwargs: {"endpoints": [{"address": "10.0.0.5:45001"}]})
    monkeypatch.setattr(subprocess, "Popen", lambda *a, **k: _FakeProc())
    root = tmp_path / "root"
    root.mkdir()
    (root / "control.sock").write_text("ready", encoding="utf-8")
    rc = main(["--root", str(root), "up", "--config", str(cfg)])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    assert out["summary"]["profile_hint"] == "rpi"
    assert out["summary"]["bind_host"] == "0.0.0.0"
    assert isinstance(out["summary"]["advertised_endpoints"], list)
