"""Directory-level tests: Node + Directory + InProcessNetwork as a whole."""
import tempfile
from pathlib import Path

import pytest

from decentnet.node import Node, NodeConfig
from decentnet.records.endpoints import Endpoint
from decentnet.transport.inproc import InProcessNetwork


def _new_node(tmp_root, i, net, k=4):
    cfg = NodeConfig.at(tmp_root / f"n{i}")
    return Node(cfg, network=net, dht_k=k)


@pytest.fixture
def tmp_root():
    with tempfile.TemporaryDirectory() as td:
        yield Path(td)


def test_two_node_publish_and_resolve(tmp_root):
    net = InProcessNetwork()
    a = _new_node(tmp_root, "a", net)
    b = _new_node(tmp_root, "b", net)

    # B knows A and vice versa (minimal seed).
    a.join_network([(b.peer_id.value, "")])
    b.join_network([(a.peer_id.value, "")])

    a.publish_own_record(
        endpoints=[Endpoint(type="public_udp", address="1.1.1.1:1")]
    )
    a.publish_to_network()

    # B resolves A — no L1 entry yet, must go through the DHT.
    # But with only 2 nodes the "DHT" is effectively direct.
    rec = b.resolve(a.peer_id.value)
    assert rec is not None
    assert rec.peer_id == a.peer_id.value
    assert rec.seq == 1
    # Write-through: second call should hit L1.
    rec2 = b.lookup(a.peer_id.value)
    assert rec2 is not None and rec2.seq == 1

    a.close()
    b.close()


def test_five_node_network_publish_and_resolve(tmp_root):
    net = InProcessNetwork()
    nodes = [_new_node(tmp_root, i, net) for i in range(5)]
    # Daisy-chain bootstrap: each new node is seeded with the first.
    seed = [(nodes[0].peer_id.value, "")]
    for n in nodes[1:]:
        n.join_network(seed)
    # And node 0 learns about all the others via backflow.
    nodes[0].join_network([(n.peer_id.value, "") for n in nodes[1:]])

    # Node 1 publishes.
    nodes[1].publish_own_record(
        endpoints=[Endpoint(type="public_udp", address="2.2.2.2:2")]
    )
    nodes[1].publish_to_network()

    # Every other node can resolve node 1.
    for other in nodes[:1] + nodes[2:]:
        rec = other.resolve(nodes[1].peer_id.value)
        assert rec is not None, f"{other.peer_id.short()} failed to resolve"
        assert rec.peer_id == nodes[1].peer_id.value

    for n in nodes:
        n.close()


def test_resolve_prefers_fresher_record_across_replicas(tmp_root):
    """Set up a network where different replicas hold different seq for
    the same peer — the resolver must return the highest (quorum)."""
    net = InProcessNetwork()
    nodes = [_new_node(tmp_root, i, net) for i in range(4)]
    for i, n in enumerate(nodes):
        seeds = [(other.peer_id.value, "") for j, other in enumerate(nodes) if j != i]
        n.join_network(seeds)

    pub = nodes[0]
    # v1 published broadly
    pub.publish_own_record(endpoints=[Endpoint(type="public_udp", address="1.1.1.1:1")])
    pub.publish_to_network()

    # v2: publish a new record, but this time manually place ONLY on node 3
    # (simulating one replica being ahead).
    rec_v2 = pub.publish_own_record(endpoints=[Endpoint(type="public_udp", address="1.1.1.1:2")])
    # Manually inject into node 3's DHT store only.
    result = nodes[3].dht_store().put(rec_v2)
    assert result.accepted

    # Now ask node 1 to resolve pub. It will contact multiple replicas
    # (node 2 has v1, node 3 has v2). Quorum-merge picks v2.
    resolver = nodes[1]
    rec = resolver.resolve(pub.peer_id.value, force_network=True)
    assert rec is not None
    assert rec.seq == rec_v2.seq

    for n in nodes:
        n.close()


def test_replay_of_old_record_rejected_at_dht_store(tmp_root):
    net = InProcessNetwork()
    a = _new_node(tmp_root, "a", net)
    b = _new_node(tmp_root, "b", net)
    a.join_network([(b.peer_id.value, "")])
    b.join_network([(a.peer_id.value, "")])

    # v1 and v2
    a.publish_own_record(endpoints=[Endpoint(type="public_udp", address="1.1.1.1:1")])
    wire_v1 = a.export_own_record()
    a.publish_own_record(endpoints=[Endpoint(type="public_udp", address="1.1.1.1:2")])
    a.publish_to_network()

    # Attacker pushes v1 back into B's DHT store via ingest.
    result = b.ingest_record_bytes(wire_v1, source="attacker")
    # Either not_newer (if v2 was already in L1 via observer) or accepted
    # (if L1 was empty) — but the DHT replica view should reject directly:
    from decentnet.records.locator import LocatorRecord
    v1 = LocatorRecord.from_wire_bytes(wire_v1)
    dht_result = b.dht_store().put(v1)
    assert not dht_result.accepted
    assert dht_result.reason == "not_newer"

    a.close()
    b.close()


def test_future_issued_at_rejected(tmp_root):
    net = InProcessNetwork()
    a = _new_node(tmp_root, "a", net)

    from decentnet.records.endpoints import Endpoint as _E
    from decentnet.records.locator import LocatorRecord

    # Build a far-future record using A's own key.
    rec = LocatorRecord.build_and_sign(
        a.keypair,
        endpoints=[_E(type="public_udp", address="1.1.1.1:1")],
        seq=999,
        issued_at=10**11,  # year 5138
    )
    wire = rec.to_wire_bytes()

    # B is a separate node.
    b = _new_node(tmp_root, "b", net)
    result = b.ingest_record_bytes(wire, source="attacker")
    assert not result.accepted
    assert result.reason == "issued_in_future"

    a.close()
    b.close()


def test_rate_limiting_drops_flood(tmp_root):
    net = InProcessNetwork()
    a = _new_node(
        tmp_root, "a", net
    )
    # Lower the bucket so we can blow it in a test loop.
    from decentnet.limits.rates import RateLimiter
    a._limiter = RateLimiter(burst=5, refill_per_s=0.0)  # no refill

    b = _new_node(tmp_root, "b", net)
    b.publish_own_record(endpoints=[Endpoint(type="public_udp", address="9.9.9.9:9")])
    wire = b.export_own_record()

    # First few accepted or rejected-not-newer (duplicate); but beyond
    # burst we hit rate-limit.
    accepted = 0
    rate_limited = 0
    for i in range(20):
        r = a.ingest_record_bytes(wire, source="spammer")
        if r.reason == "rate_limited":
            rate_limited += 1
        else:
            accepted += 1
    assert rate_limited > 0, "expected some rate-limited rejections"

    a.close()
    b.close()
