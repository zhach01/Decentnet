"""Tests for the Phase Final scenarios + adversary primitives."""
import tempfile
from pathlib import Path

import pytest

from decentnet.sim.builtin_scenarios import get_scenario, REGISTRY
from decentnet.sim.scenario import run_scenario


NEW_SCENARIOS = [
    "ip_change_without_refresh",
    "endpoint_remap",
    "concurrent_updates_seq_conflict",
    "symmetric_nat_relay_path",
    "cache_warming",
    "mass_churn",
    "popularity_eviction_multi_node",
    "burst_lookups",
    "adversary_corrupt_replica",
    "adversary_noisy_neighbor",
    "adversary_silent_node",
]


@pytest.mark.parametrize("name", NEW_SCENARIOS)
def test_new_scenario_runs(name, tmp_path):
    sc = get_scenario(name)
    result = run_scenario(sc, output_dir=str(tmp_path))
    # Every scenario must produce at least an initial + final snapshot.
    assert hasattr(result, "snapshots")
    assert len(result.snapshots) >= 2


def test_all_new_scenarios_registered():
    for name in NEW_SCENARIOS:
        assert name in REGISTRY


def test_corrupt_replica_rejected_by_validation():
    """The corrupted-replica adversary scenario must NOT contaminate
    a third-party honest resolver's cache."""
    from decentnet.sim.network import SimNetwork
    sim = SimNetwork.build(5, k=4)
    try:
        from decentnet.records.endpoints import Endpoint
        sim.publish(sim[0], [Endpoint(type="public_udp", address="8.8.8.8:8")])
        sim.inject_corrupt_replica(
            sim[2], sim[0].peer_id.value, fake_address="6.6.6.6:6",
        )
        # node[3] resolves through DHT — should NOT pick the forged record.
        rec = sim[3].resolve(sim[0].peer_id.value, force_network=True)
        assert rec is not None
        assert rec.endpoints[0].address == "8.8.8.8:8"
    finally:
        sim.shutdown()


def test_noisy_neighbor_does_not_break_resolve():
    from decentnet.sim.network import SimNetwork
    from decentnet.records.endpoints import Endpoint
    sim = SimNetwork.build(4, k=3)
    try:
        sim.publish(sim[0], [Endpoint(type="public_udp", address="1.1.1.1:1")])
        sim.start_noisy_neighbor(sim[2], sim[1], rate_per_step=10)
        sent = sim.step_noisy_neighbors()
        assert sent == 10
        # node[1] still resolves successfully.
        rec = sim[1].resolve(sim[0].peer_id.value, force_network=True)
        assert rec is not None
    finally:
        sim.shutdown()


def test_silent_node_does_not_break_lookup():
    from decentnet.sim.network import SimNetwork
    from decentnet.records.endpoints import Endpoint
    sim = SimNetwork.build(5, k=4)
    try:
        sim.publish(sim[0], [Endpoint(type="public_udp", address="1.1.1.1:1")])
        sim.make_silent(sim[2])
        # node[3] still resolves via remaining replicas.
        rec = sim[3].resolve(sim[0].peer_id.value, force_network=True)
        assert rec is not None
    finally:
        sim.shutdown()
