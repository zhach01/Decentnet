from __future__ import annotations

import json

from decentnet.cli.main import main
from decentnet.ice import candidates_from_endpoints
from decentnet.node import Node, NodeConfig
from decentnet.records.endpoints import Endpoint
from decentnet.vpn import detect_vpn_endpoints, detect_vpn_interfaces


def test_detect_vpn_interfaces_from_env_and_ip_dump():
    env = {
        "TAILSCALE_IP": "100.70.0.7",
        "WIREGUARD_IP": "10.99.0.2",
    }
    ip_dump = """
1: lo    inet 127.0.0.1/8 scope host lo
2: eth0  inet 192.168.1.10/24 scope global eth0
3: tailscale0    inet 100.64.0.1/32 scope global tailscale0
4: wg0   inet 10.8.0.3/24 scope global wg0
5: utun4 inet6 fd7a:115c:a1e0::22/128 scope global
"""
    items = detect_vpn_interfaces(env=env, ip_output=ip_dump)
    kinds = {(i.kind, i.address) for i in items}
    assert ("tailscale", "100.70.0.7") in kinds
    assert ("wireguard", "10.99.0.2") in kinds
    assert ("tailscale", "100.64.0.1") in kinds
    assert ("wireguard", "10.8.0.3") in kinds
    assert ("vpn", "fd7a:115c:a1e0::22") in kinds


def test_detect_vpn_endpoints_and_ice_prefer_overlay():
    env = {
        "TAILSCALE_IP": "100.70.0.7",
        "DECENTNET_VPN_ENDPOINTS": "wireguard_udp:10.9.0.3:5555,100.80.0.9",
    }
    eps = detect_vpn_endpoints(4242, env=env, ip_output="")
    addrs = {(e.type, e.address) for e in eps}
    assert ("tailscale_udp", "100.70.0.7:4242") in addrs
    assert ("wireguard_udp", "10.9.0.3:5555") in addrs
    assert ("vpn_udp", "100.80.0.9:4242") in addrs

    cands = candidates_from_endpoints([
        Endpoint(type="lan_udp", address="192.168.1.2:4242"),
        Endpoint(type="public_udp", address="203.0.113.5:4242"),
        Endpoint(type="tailscale_udp", address="100.70.0.7:4242"),
    ])
    by_host = {c.host: c for c in cands}
    assert by_host["100.70.0.7"].priority() > by_host["192.168.1.2"].priority()
    assert by_host["192.168.1.2"].priority() > by_host["203.0.113.5"].priority()


def test_node_publish_with_external_address_include_vpn(monkeypatch, tmp_path):
    root = tmp_path / "node"
    node = Node(NodeConfig.at(root))
    try:
        monkeypatch.setattr(
            "decentnet.vpn.detect_vpn_endpoints",
            lambda port, **kwargs: [Endpoint(type="tailscale_udp", address=f"100.70.0.7:{port}", priority=120, confidence=0.95)],
        )
        rec = node.publish_with_external_address(include_vpn=True, vpn_port=5151, extra_endpoints=[Endpoint(type="public_udp", address="203.0.113.5:5151")])
        kinds = {e.type for e in rec.endpoints}
        assert "tailscale_udp" in kinds
        assert "public_udp" in kinds
    finally:
        node.close()


def test_cli_publish_auto_vpn_and_doctor_vpn(monkeypatch, tmp_path, capsys):
    rc = main(["--root", str(tmp_path), "init"])
    assert rc == 0
    capsys.readouterr()

    monkeypatch.setattr(
        "decentnet.vpn.detect_vpn_endpoints",
        lambda port, **kwargs: [Endpoint(type="tailscale_udp", address=f"100.70.0.7:{port}", priority=120, confidence=0.95)],
    )

    rc = main([
        "--root", str(tmp_path),
        "publish",
        "--endpoint", "public_udp:203.0.113.5:41234",
        "--auto-vpn",
    ])
    assert rc == 0
    capsys.readouterr()

    rc = main(["--root", str(tmp_path), "show", "--json"])
    assert rc == 0
    rec = json.loads(capsys.readouterr().out)
    assert {e["type"] for e in rec["endpoints"]} >= {"public_udp", "tailscale_udp"}

    rc = main([
        "--root", str(tmp_path),
        "doctor",
        "--json",
        "--vpn-port", "41234",
    ])
    assert rc == 0
    report = json.loads(capsys.readouterr().out)
    assert report["vpn"]["endpoint_count"] >= 1
    assert report["vpn"]["endpoints"][0]["type"] == "tailscale_udp"
