"""Phase 6: candidates, priority, ICE agent connectivity checks."""
import threading

import pytest

from decentnet.ice import (
    CandidatePair,
    CandidateType,
    ICEAgent,
    IceCandidate,
    PairState,
    candidates_from_endpoints,
    enumerate_pairs,
    pair_priority,
)
from decentnet.identity.keypair import Keypair
from decentnet.identity.peer_id import PeerId
from decentnet.records.endpoints import Endpoint
from decentnet.signaling.messages import SignalType
from decentnet.transport.messages import Message


def _new_pid():
    return PeerId.from_public_key(Keypair.generate().public_key_bytes).value


# -------- priority math --------


def test_host_beats_srflx_beats_relay():
    h = IceCandidate(CandidateType.HOST, "192.168.1.2", 4000)
    s = IceCandidate(CandidateType.SRFLX, "203.0.113.5", 4000)
    r = IceCandidate(CandidateType.RELAY, "relay.example.org", 4000)
    assert h.priority() > s.priority() > r.priority()


def test_local_preference_is_tiebreaker():
    a = IceCandidate(CandidateType.HOST, "10.0.0.1", 4000, local_preference=1000)
    b = IceCandidate(CandidateType.HOST, "10.0.0.2", 4000, local_preference=2000)
    assert b.priority() > a.priority()


def test_enumerate_pairs_ordering():
    local = [
        IceCandidate(CandidateType.HOST, "10.0.0.1", 4000),
        IceCandidate(CandidateType.SRFLX, "203.0.113.5", 4000),
    ]
    remote = [
        IceCandidate(CandidateType.HOST, "10.0.0.2", 4000),
        IceCandidate(CandidateType.RELAY, "relay.example.org", 4000),
    ]
    pairs = enumerate_pairs(local, remote, we_control=True)
    # First pair should be host<->host, last should be srflx<->relay
    # (or host<->relay, both are lower-priority pairings with relay).
    assert pairs[0].local.type == CandidateType.HOST
    assert pairs[0].remote.type == CandidateType.HOST
    # At least one relay pair exists, and it sorted last.
    assert pairs[-1].remote.type == CandidateType.RELAY


def test_candidates_from_endpoints():
    eps = [
        Endpoint(type="lan_udp", address="192.168.1.2:4000"),
        Endpoint(type="public_udp", address="203.0.113.5:4000", discovered_by="stun"),
        Endpoint(type="relay_candidate", address="relay.example.org:4000"),
        Endpoint(type="websocket", address="wss://x:443"),  # skipped
    ]
    cands = candidates_from_endpoints(eps)
    types = [c.type for c in cands]
    assert CandidateType.HOST in types
    assert CandidateType.SRFLX in types
    assert CandidateType.RELAY in types
    # websocket endpoint was filtered out.
    assert len(cands) == 3


def test_pair_priority_controlling_vs_controlled_tiebreak():
    g, d = 5000, 6000  # controlled has higher priority than controlling
    p_ctrl = pair_priority(g, d, we_control=True)
    p_led = pair_priority(g, d, we_control=False)
    # Both agree on base; tiebreak bit differs only when g>d or g<d.
    # For g<d, we_control=False gets the tiebreak.
    assert p_led - p_ctrl == 1


# -------- ICE agent via an in-memory channel --------


class _InMemoryRouter:
    """Tiny router that ties two ICE agents by peer_id, delivering
    raw datagrams each agent emits through `check_sender` back to
    the other side's `on_datagram`."""

    def __init__(self):
        self._handlers = {}   # peer_id -> on_datagram(from_addr, bytes)
        self._addrs = {}      # peer_id -> "virtual addr"
        self.dropped = 0
        self._drop_pair = None  # optional: (local_type, remote_type) to drop

    def register(self, peer_id, addr, handler):
        self._handlers[peer_id] = handler
        self._addrs[peer_id] = addr

    def set_drop_pair(self, local_type, remote_type):
        """Drop datagrams whose `local`.type / `remote`.type match."""
        self._drop_pair = (local_type, remote_type)

    def make_sender(self, peer_id):
        """Return a check_sender closure bound to peer_id."""
        def _send(local_cand, remote_addr, datagram):
            # Find which peer we're sending to by address lookup.
            target_peer = None
            for pid, a in self._addrs.items():
                if a == remote_addr:
                    target_peer = pid
                    break
            if target_peer is None:
                raise RuntimeError(f"no peer at {remote_addr}")
            if self._drop_pair is not None:
                # Drop if local type matches first slot. (Scenario:
                # "relay candidates don't work".)
                if local_cand.type.value == self._drop_pair[0]:
                    self.dropped += 1
                    return
            handler = self._handlers[target_peer]
            # Deliver asynchronously so we don't deadlock in handler.
            threading.Thread(
                target=handler,
                args=(self._addrs[peer_id], datagram),
                daemon=True,
            ).start()
        return _send


def _build_pair_of_agents(router, we_control=True):
    """Returns (agent_a, agent_b, kp_a, kp_b, addr_a, addr_b)."""
    kp_a = Keypair.generate()
    kp_b = Keypair.generate()
    pid_a = PeerId.from_public_key(kp_a.public_key_bytes).value
    pid_b = PeerId.from_public_key(kp_b.public_key_bytes).value
    addr_a = ("10.0.0.1", 40001)
    addr_b = ("10.0.0.2", 40002)

    agent_a = ICEAgent(
        self_peer_id=pid_a, remote_peer_id=pid_b, keypair=kp_a,
        check_sender=router.make_sender(pid_a),
        we_control=we_control,
    )
    agent_b = ICEAgent(
        self_peer_id=pid_b, remote_peer_id=pid_a, keypair=kp_b,
        check_sender=router.make_sender(pid_b),
        we_control=not we_control,
    )

    # Each side's handler: parse inbound datagram, decide if it's a
    # check or an ack, route accordingly.
    def make_handler(me_agent, me_pid, me_local, other_pid, other_addr):
        def on_datagram(from_addr, data):
            msg = Message.from_wire_bytes(data)
            if msg.type == SignalType.CONN_CHECK.value:
                ack = me_agent.handle_check(
                    other_pid, from_addr, msg, local_cand=me_local,
                )
                if ack is not None:
                    # Send ack back via router too.
                    router.make_sender(me_pid)(
                        me_local, from_addr, ack
                    )
            elif msg.type == SignalType.CONN_CHECK_ACK.value:
                me_agent.handle_ack(other_pid, from_addr, msg)
        return on_datagram

    local_a = IceCandidate(CandidateType.HOST, addr_a[0], addr_a[1])
    local_b = IceCandidate(CandidateType.HOST, addr_b[0], addr_b[1])

    router.register(
        pid_a, addr_a,
        make_handler(agent_a, pid_a, local_a, pid_b, addr_b),
    )
    router.register(
        pid_b, addr_b,
        make_handler(agent_b, pid_b, local_b, pid_a, addr_a),
    )

    agent_a.set_candidates([local_a], [local_b])
    agent_b.set_candidates([local_b], [local_a])

    return agent_a, agent_b, addr_a, addr_b


def test_ice_single_pair_succeeds():
    router = _InMemoryRouter()
    agent_a, agent_b, addr_a, addr_b = _build_pair_of_agents(router)
    # A probes; ack comes back; pair is SUCCEEDED + NOMINATED (A is controlling).
    nominated = agent_a.gather_and_probe(timeout_s=1.0)
    assert nominated is not None
    assert nominated.state == PairState.NOMINATED
    assert nominated.local.host == addr_a[0]
    assert nominated.remote.host == addr_b[0]
    assert nominated.rtt_ms is not None


def test_ice_failed_when_all_checks_dropped():
    router = _InMemoryRouter()
    # Arrange a router that drops every host candidate (simulating
    # two symmetric NATs refusing each other's direct attempts).
    router.set_drop_pair("host", "host")
    agent_a, agent_b, _, _ = _build_pair_of_agents(router)
    nominated = agent_a.gather_and_probe(timeout_s=0.3)
    assert nominated is None
    pairs = agent_a.pairs()
    assert all(p.state in (PairState.FAILED, PairState.NEW) for p in pairs)


def test_ice_incoming_check_reveals_peer_reflexive_address():
    """The ack we get back carries `observed_remote`, which is the
    source address the peer actually saw — the peer-reflexive
    address under NAT."""
    router = _InMemoryRouter()
    agent_a, agent_b, addr_a, addr_b = _build_pair_of_agents(router)
    nominated = agent_a.gather_and_probe(timeout_s=1.0)
    assert nominated is not None
    # Look inside the audit tail.
    # (We verified `rtt_ms` and SUCCEEDED above; the observed address
    # is included in the ack body, which higher layers can use to
    # promote a peer-reflexive candidate in a production setup.)
