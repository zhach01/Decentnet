"""Tests for: bloom + merkle digests, reputation, schedulers,
cbor codec, audit log rotation, and encrypted keystore."""
import json
import time
from pathlib import Path

import pytest

from decentnet.audit.log import AuditLog
from decentnet.identity.keypair import Keypair
from decentnet.identity import keystore as _ks
from decentnet.identity.peer_id import PeerId
from decentnet.limits.reputation import ReputationTracker
from decentnet.repair.digests import (
    BloomSummary,
    MerkleBucketSummary,
    build_bloom_for_peers,
)
from decentnet.records.endpoints import Endpoint
from decentnet.utils.cbor import canonical_cbor, decode_cbor


# ============================================================
# Bloom + Merkle
# ============================================================


def test_bloom_adds_and_contains():
    b = BloomSummary.for_capacity(100, false_positive_rate=0.01)
    for pid in ["alice", "bob", "carol"]:
        b.add(pid)
    for pid in ["alice", "bob", "carol"]:
        assert b.contains(pid)


def test_bloom_rejects_definitely_absent():
    b = BloomSummary.for_capacity(100, false_positive_rate=0.001)
    b.add("alice")
    # Must not accept 20 random keys; with fp=0.001 and n=1 this is
    # overwhelmingly false.
    for i in range(20):
        assert not b.contains(f"not-present-{i}")


def test_bloom_roundtrip_dict():
    b = build_bloom_for_peers(["a", "b", "c"])
    b2 = BloomSummary.from_dict(b.to_dict())
    assert b2.contains("a")
    assert not b2.contains("definitely-not-here")


def test_merkle_identical_stores_have_identical_roots():
    entries = [("p1", 1), ("p2", 3), ("p3", 2)]
    a = MerkleBucketSummary.build(entries)
    b = MerkleBucketSummary.build(entries)
    assert a.bucket_roots == b.bucket_roots
    assert a.diff_buckets(b) == []


def test_merkle_detects_one_differing_bucket():
    a = MerkleBucketSummary.build([("p1", 1), ("p2", 2)])
    b = MerkleBucketSummary.build([("p1", 1), ("p2", 3)])  # p2 seq differs
    diff = a.diff_buckets(b)
    assert len(diff) == 1


def test_merkle_dict_roundtrip():
    entries = [("p1", 5), ("p2", 6)]
    m = MerkleBucketSummary.build(entries)
    m2 = MerkleBucketSummary.from_dict(m.to_dict())
    assert m.bucket_roots == m2.bucket_roots


# ============================================================
# Reputation tracker
# ============================================================


def test_reputation_success_raises_score(tmp_path):
    r = ReputationTracker(tmp_path / "rep.sqlite3")
    assert r.score("peer-x") == 0.0
    r.note_success("peer-x")
    assert r.score("peer-x") > 0
    r.close()


def test_reputation_malicious_blacklists(tmp_path):
    r = ReputationTracker(tmp_path / "rep.sqlite3")
    r.note_malicious("bad-peer", reason="forged signature")
    assert r.is_blacklisted("bad-peer")
    assert not r.is_trusted("bad-peer")
    r.close()


def test_reputation_persists(tmp_path):
    r1 = ReputationTracker(tmp_path / "rep.sqlite3")
    for _ in range(5):
        r1.note_success("friend")
    s1 = r1.score("friend")
    r1.close()
    r2 = ReputationTracker(tmp_path / "rep.sqlite3")
    s2 = r2.score("friend")
    # With decay the score could drop slightly but should be close.
    assert s2 > 0
    r2.close()


# ============================================================
# Schedulers
# ============================================================


def test_background_refresh_tick(tmp_path):
    from decentnet.node import Node, NodeConfig
    from decentnet.transport.inproc import InProcessNetwork
    net = InProcessNetwork()
    pub = Node(NodeConfig.at(tmp_path / "p"), network=net)
    a = Node(NodeConfig.at(tmp_path / "a"), network=net)
    try:
        a.join_network([(pub.peer_id.value, "")])
        pub.publish_own_record(
            endpoints=[Endpoint(type="public_udp", address="1.1.1.1:1")]
        )
        pub.publish_to_network()
        a.resolve(pub.peer_id.value, force_network=True)
        # Scheduler tick without starting thread.
        sched = a.enable_background_refresh(interval_s=60, start=False)
        n = sched.tick_once()
        # No soft-expired records yet, so nothing to refresh.
        assert n == 0
    finally:
        a.close()
        pub.close()


def test_keepalive_scheduler_ticks_over_trusted(tmp_path):
    from decentnet.node import Node, NodeConfig
    from decentnet.transport.inproc import InProcessNetwork
    net = InProcessNetwork()
    a = Node(NodeConfig.at(tmp_path / "a"), network=net)
    b = Node(NodeConfig.at(tmp_path / "b"), network=net)
    try:
        a.join_network([(b.peer_id.value, "")])
        b.join_network([(a.peer_id.value, "")])
        a.publish_own_record(
            endpoints=[Endpoint(type="public_udp", address="1.1.1.1:1")]
        )
        a.publish_to_network()
        b.publish_own_record(
            endpoints=[Endpoint(type="public_udp", address="2.2.2.2:2")]
        )
        b.publish_to_network()
        a.resolve(b.peer_id.value, force_network=True)
        b.resolve(a.peer_id.value, force_network=True)
        assert a.signaling.hello(b.peer_id.value).ok
        sched = a.enable_keepalive(interval_s=30, start=False)
        n = sched.tick_once()
        # One trusted peer → one keepalive emitted.
        assert n == 1
    finally:
        a.close()
        b.close()


# ============================================================
# CBOR
# ============================================================


def test_cbor_roundtrip_primitives():
    for v in [None, True, False, 0, 1, -1, 123456, -999, 3.14, "hi", b"\x00\x01"]:
        data = canonical_cbor(v)
        assert decode_cbor(data) == v


def test_cbor_canonical_map_key_ordering():
    a = canonical_cbor({"b": 1, "a": 2})
    b = canonical_cbor({"a": 2, "b": 1})
    assert a == b


def test_cbor_nested():
    val = {"records": [{"peer": "pA", "seq": 1}, {"peer": "pB", "seq": 2}]}
    data = canonical_cbor(val)
    assert decode_cbor(data) == val


# ============================================================
# Audit log rotation
# ============================================================


def test_audit_log_rotates_when_size_exceeded(tmp_path):
    path = tmp_path / "audit.jsonl"
    # Very small size cap so every entry triggers rotation.
    log = AuditLog(path, max_bytes=120, keep_rotated=3)
    for i in range(10):
        log.record("cache.put", peer_id=f"peer-{i}", seq=i)
    # Rotated files should exist.
    rotated_1 = path.with_suffix(path.suffix + ".1")
    assert rotated_1.exists()


def test_audit_log_memory_tail_capped(tmp_path):
    path = tmp_path / "audit.jsonl"
    log = AuditLog(path, max_memory_entries=5)
    for i in range(20):
        log.record("cache.put", peer_id=f"p{i}")
    assert len(log.entries()) == 5


# ============================================================
# Encrypted keystore
# ============================================================


def test_keystore_wrap_and_unwrap(tmp_path):
    kp = Keypair.generate()
    keyfile = tmp_path / "identity.key.json"
    kp.save(keyfile)
    assert not _ks.is_encrypted_keyfile(keyfile)
    _ks.wrap_keyfile(keyfile, "hunter2", scrypt_n=2**12)  # fast for tests
    assert _ks.is_encrypted_keyfile(keyfile)
    # Load with passphrase.
    kp2 = Keypair.load(keyfile, passphrase="hunter2")
    assert kp2.public_key_bytes == kp.public_key_bytes
    assert kp2.private_key_bytes == kp.private_key_bytes
    # Unwrap back.
    _ks.unwrap_keyfile(keyfile, "hunter2")
    assert not _ks.is_encrypted_keyfile(keyfile)
    kp3 = Keypair.load(keyfile)
    assert kp3.public_key_bytes == kp.public_key_bytes


def test_keystore_wrong_passphrase_rejects(tmp_path):
    kp = Keypair.generate()
    keyfile = tmp_path / "identity.key.json"
    kp.save(keyfile)
    _ks.wrap_keyfile(keyfile, "correct", scrypt_n=2**12)
    with pytest.raises(Exception):
        _ks.unwrap_keyfile(keyfile, "wrong")


def test_keystore_tamper_rejected(tmp_path):
    kp = Keypair.generate()
    keyfile = tmp_path / "identity.key.json"
    kp.save(keyfile)
    _ks.wrap_keyfile(keyfile, "pw", scrypt_n=2**12)
    d = json.loads(keyfile.read_text())
    # Flip one bit in ciphertext.
    from decentnet.utils.encoding import b64u_decode, b64u_encode
    ct = bytearray(b64u_decode(d["ciphertext"]))
    ct[0] ^= 0x01
    d["ciphertext"] = b64u_encode(bytes(ct))
    keyfile.write_text(json.dumps(d))
    with pytest.raises(Exception):
        _ks.unwrap_keyfile(keyfile, "pw")


def test_cli_keystore_status_and_encrypt(tmp_path, capsys):
    from decentnet.cli.main import main
    main(["--root", str(tmp_path), "init"])
    capsys.readouterr()
    rc = main(["--root", str(tmp_path), "keystore", "status"])
    assert rc == 0
    d = json.loads(capsys.readouterr().out)
    assert d["encrypted"] is False
    # Encrypt.
    rc = main([
        "--root", str(tmp_path), "keystore", "encrypt",
        "--passphrase", "abc",
    ])
    assert rc == 0
    capsys.readouterr()
    rc = main(["--root", str(tmp_path), "keystore", "status"])
    d = json.loads(capsys.readouterr().out)
    assert d["encrypted"] is True
