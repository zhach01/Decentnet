from __future__ import annotations

import json
import zipfile
from pathlib import Path

from decentnet.cli.main import main
from decentnet.nat import MockSTUNServer


def _read_json_out(capsys):
    return json.loads(capsys.readouterr().out)


def test_cli_doctor_reports_root_and_udp_bind(tmp_path, capsys):
    rc = main(["--root", str(tmp_path), "init"])
    assert rc == 0
    capsys.readouterr()

    rc = main([
        "--root", str(tmp_path),
        "doctor",
        "--json",
        "--bind-udp-port", "0",
    ])
    assert rc == 0
    d = _read_json_out(capsys)
    assert d["ok"] is True
    assert d["root"]["files"]["keyfile"] is True
    assert d["udp_bind"]["ok"] is True
    assert d["root"]["peer_id"]


def test_cli_doctor_stun_probe_with_mock(tmp_path, capsys):
    main(["--root", str(tmp_path), "init"])
    capsys.readouterr()
    with MockSTUNServer() as stun:
        rc = main([
            "--root", str(tmp_path),
            "doctor",
            "--json",
            "--stun-server", f"{stun.bind_host}:{stun.bind_port}",
            "--bind-udp-port", "0",
        ])
        assert rc == 0
        d = _read_json_out(capsys)
        assert d["stun"][0]["ok"] is True
        assert d["stun"][0]["mapped_host"]
        assert isinstance(d["stun"][0]["mapped_port"], int)


def test_cli_doctor_verifies_operator_pack_zip(tmp_path, capsys):
    root = tmp_path / "node"
    main(["--root", str(root), "init"])
    capsys.readouterr()

    bundle = tmp_path / "bundle"
    bundle.mkdir()
    snap_json = bundle / "dashboard-snapshot.json"
    snap_html = bundle / "dashboard-snapshot.html"
    report = bundle / "reports.json"
    snap_json.write_text(json.dumps({"kind": "snapshot"}), encoding="utf-8")
    snap_html.write_text("<html>ok</html>", encoding="utf-8")
    report.write_text(json.dumps({"ok": True}), encoding="utf-8")

    import hashlib
    h = hashlib.sha256(report.read_bytes()).hexdigest()
    manifest = {
        "kind": "decentnet_operator_bundle",
        "generated_at": 1,
        "snapshot": {"json": snap_json.name, "html": snap_html.name},
        "files": [
            {
                "category": "operator_report",
                "source_path": "ignored",
                "bundle_path": report.name,
                "size": report.stat().st_size,
                "sha256": h,
            }
        ],
    }
    (bundle / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    archive = tmp_path / "bundle.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(bundle.rglob("*")):
            if path.is_file():
                zf.write(path, path.relative_to(bundle))

    rc = main([
        "--root", str(root),
        "doctor",
        "--json",
        "--pack", str(archive),
    ])
    assert rc == 0
    d = _read_json_out(capsys)
    assert d["pack"]["ok"] is True
    assert d["pack"]["verified_files"] == 1
    assert d["pack"]["snapshot_json_exists"] is True
    assert d["pack"]["snapshot_html_exists"] is True


def test_cli_doctor_advertise_preview_warns_on_loopback_bind(tmp_path, capsys):
    cfg = tmp_path / "peer.toml"
    cfg.write_text(
        """
[transport]
bind_host = "127.0.0.1"
bind_port = 45001

[advertise]
mode = "manual"

[[advertise.manual_endpoints]]
type = "lan_udp"
address = "10.10.0.1:45001"
""",
        encoding="utf-8",
    )
    rc = main(["--root", str(tmp_path), "doctor", "--json", "--config", str(cfg)])
    assert rc == 0
    d = _read_json_out(capsys)
    assert d["advertise_preview"]["endpoints"][0]["address"] == "10.10.0.1:45001"
    assert d["advertise_preview"]["validation_warnings"]


def test_cli_doctor_reports_profile_and_guidance(tmp_path, capsys):
    cfg = tmp_path / "peer.toml"
    cfg.write_text(
        """
[transport]
bind_host = "127.0.0.1"
bind_port = 45001

[advertise]
mode = "auto"
auto_lan = true
auto_vpn = true

[capabilities]
relay = true
bootstrap_assist = true
""",
        encoding="utf-8",
    )
    rc = main(["--root", str(tmp_path), "doctor", "--json", "--config", str(cfg)])
    assert rc == 0
    d = _read_json_out(capsys)
    assert d["profile_hint"] == "rpi"
    assert "hybrid" not in d["endpoint_strategy"]
    assert d["config_validation"]["warnings"]
    assert d["doctor_guidance"]
