from pathlib import Path

from decentnet.config_file import DecentnetConfig


def test_config_loads_transport_and_advertise_sections(tmp_path: Path):
    cfg_path = tmp_path / 'config.toml'
    cfg_path.write_text(
        '\n'.join([
            '[transport]',
            'bind_host = "0.0.0.0"',
            'bind_port = 45001',
            '',
            '[advertise]',
            'mode = "hybrid"',
            'auto_publish = true',
            'auto_vpn = false',
            '',
            '[[advertise.manual_endpoints]]',
            'type = "lan_udp"',
            'address = "10.10.0.1:45001"',
            'priority = 80',
            '',
            '[capabilities]',
            'relay = true',
        ])
    )
    cfg = DecentnetConfig.load(cfg_path)
    assert cfg.transport.bind_host == '0.0.0.0'
    assert cfg.transport.bind_port == 45001
    assert cfg.advertise.mode == 'hybrid'
    assert cfg.advertise.auto_publish is True
    assert cfg.advertise.auto_vpn is False
    assert cfg.capabilities.relay is True
    assert cfg.advertise.manual_endpoints == [
        {'type': 'lan_udp', 'address': '10.10.0.1:45001', 'priority': 80}
    ]
