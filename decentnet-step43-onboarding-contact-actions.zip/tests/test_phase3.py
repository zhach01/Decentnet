"""Phase 3: virtual clock, DHT persistence, snapshot, scenarios."""
import json
import tempfile
from pathlib import Path

import pytest

from decentnet.dht.storage import DHTStore
from decentnet.identity.keypair import Keypair
from decentnet.node import Node, NodeConfig
from decentnet.records.endpoints import Endpoint
from decentnet.records.locator import LocatorRecord
from decentnet.sim import (
    REGISTRY,
    SimNetwork,
    VirtualClock,
    get_scenario,
    render_index_html,
    render_snapshot_svg,
    run_scenario,
    take_snapshot,
    STATE_FRESH,
    STATE_MISSING,
    STATE_PUBLISHER,
)
from decentnet.transport.inproc import InProcessNetwork
from decentnet.utils.time import now_s


# ---------------- virtual clock ----------------


def test_virtual_clock_controls_now_s():
    clock = VirtualClock(start=1_000_000.0)
    with clock.install():
        assert now_s() == 1_000_000
        clock.advance(42)
        assert now_s() == 1_000_042
    # Restored afterwards — real clock should be wildly different.
    assert now_s() != 1_000_042


def test_virtual_clock_timers_fire_in_order():
    clock = VirtualClock(start=0.0)
    fired: list[str] = []
    clock.after(5.0, lambda: fired.append("b"))
    clock.after(1.0, lambda: fired.append("a"))
    clock.after(3.0, lambda: fired.append("mid"))
    clock.advance(10)
    assert fired == ["a", "mid", "b"]
    assert clock.pending_timer_count() == 0


def test_virtual_clock_advance_does_not_skip_timers():
    clock = VirtualClock(start=0.0)
    fired: list[float] = []
    clock.after(2.5, lambda: fired.append(clock.time()))
    clock.advance(1)
    assert fired == []  # not yet
    clock.advance(2)
    assert fired == [2.5]


# ---------------- DHT store persistence ----------------


def test_dht_store_persistence_roundtrip(tmp_path):
    path = tmp_path / "dht.sqlite3"
    store1 = DHTStore(persist_path=path)
    kp = Keypair.generate()
    rec = LocatorRecord.build_and_sign(
        kp,
        endpoints=[Endpoint(type="public_udp", address="1.2.3.4:5")],
        seq=1,
    )
    assert store1.put(rec).accepted
    store1.close()

    # New instance reading the same file must rehydrate.
    store2 = DHTStore(persist_path=path)
    got = store2.peek(rec.peer_id)
    assert got is not None
    assert got.seq == 1
    assert got.endpoints[0].address == "1.2.3.4:5"
    store2.close()


def test_dht_store_persistence_rehydration_drops_expired(tmp_path):
    """A record hard-expired by the time we rehydrate must not load."""
    clock = VirtualClock(start=1_000_000.0)
    path = tmp_path / "dht.sqlite3"
    with clock.install():
        store1 = DHTStore(persist_path=path)
        kp = Keypair.generate()
        rec = LocatorRecord.build_and_sign(
            kp,
            endpoints=[Endpoint(type="public_udp", address="1.2.3.4:5")],
            seq=1,
            ttl_s=60,
            soft_ttl_s=30,
        )
        assert store1.put(rec).accepted
        store1.close()
        # Move the clock past expiry, then reopen.
        clock.advance(3600)
        store2 = DHTStore(persist_path=path)
        assert store2.peek(rec.peer_id) is None
        store2.close()


def test_node_dht_store_persists_across_restart(tmp_path):
    """Full integration: Node A DHT-stores a record; restart A; record survives."""
    net1 = InProcessNetwork()
    cfg = NodeConfig.at(tmp_path / "a")
    a1 = Node(cfg, network=net1)

    kp = Keypair.generate()
    rec = LocatorRecord.build_and_sign(
        kp,
        endpoints=[Endpoint(type="public_udp", address="5.5.5.5:5")],
        seq=1,
    )
    assert a1.dht_store().put(rec).accepted
    a1.close()

    # New network, new Node with same on-disk config.
    net2 = InProcessNetwork()
    a2 = Node(cfg, network=net2)
    got = a2.dht_store().peek(rec.peer_id)
    assert got is not None
    assert got.seq == 1
    a2.close()


# ---------------- snapshot + render ----------------


def _mk_sim_with_published(n=4):
    sim = SimNetwork.build(n=n)
    pub = sim[0]
    sim.publish(pub, [Endpoint(type="public_udp", address="1.1.1.1:1")])
    return sim


def test_snapshot_labels_states_correctly():
    sim = _mk_sim_with_published(n=4)
    try:
        pub_id = sim[0].peer_id.value
        snap = take_snapshot(sim, pub_id, "test")
        # Publisher node is labelled as such.
        pubs = [n for n in snap.nodes if n.is_publisher]
        assert len(pubs) == 1 and pubs[0].record_state == STATE_PUBLISHER

        # At least one non-publisher holds a fresh replica.
        fresh = [
            n for n in snap.nodes if not n.is_publisher and n.record_state == STATE_FRESH
        ]
        assert len(fresh) >= 1

        # Every snapshot node has a reasonable record_state (never unknown).
        for n in snap.nodes:
            assert n.record_state in {
                STATE_PUBLISHER, STATE_FRESH, STATE_MISSING,
                "stale", "expired", "corrupted",
            }
    finally:
        sim.shutdown()


def test_snapshot_to_json_is_serializable():
    sim = _mk_sim_with_published(n=3)
    try:
        pub_id = sim[0].peer_id.value
        snap = take_snapshot(sim, pub_id, "json-serial")
        blob = snap.to_json()
        # Round-trip parse.
        obj = json.loads(blob)
        assert obj["subject_peer_id"] == pub_id
        assert len(obj["nodes"]) == 3
    finally:
        sim.shutdown()


def test_render_produces_valid_svg():
    sim = _mk_sim_with_published(n=4)
    try:
        pub_id = sim[0].peer_id.value
        snap = take_snapshot(sim, pub_id, "render-test")
        svg = render_snapshot_svg(snap)
        assert svg.startswith("<svg")
        assert svg.rstrip().endswith("</svg>")
        # State colors present.
        assert "#60a5fa" in svg   # publisher blue
        assert "#4ade80" in svg   # at least one fresh
    finally:
        sim.shutdown()


def test_render_index_html_produces_valid_document():
    sim = _mk_sim_with_published(n=3)
    try:
        pub_id = sim[0].peer_id.value
        snaps = [
            take_snapshot(sim, pub_id, "snap 1"),
            take_snapshot(sim, pub_id, "snap 2"),
        ]
        html = render_index_html(snaps, ["a.svg", "b.svg"])
        assert "<!doctype html>" in html.lower()
        assert "snap 1" in html
        assert "snap 2" in html
        assert "a.svg" in html and "b.svg" in html
    finally:
        sim.shutdown()


# ---------------- scenario runner ----------------


def test_scenario_runner_in_memory():
    """Run a scenario without --output and verify snapshot progression."""
    sc = get_scenario("partition_then_merge")
    result = run_scenario(sc)
    # Enough checkpoints.
    assert len(result.snapshots) >= 5

    # The last snapshot should have at least as many fresh replicas as
    # the partitioned snapshot (anti-entropy propagated v2).
    first_fresh = sum(
        1 for n in result.snapshots[-1].nodes if n.record_state == STATE_FRESH
    )
    assert first_fresh >= 2


def test_scenario_runner_writes_outputs(tmp_path):
    sc = get_scenario("stale_vs_fresh")
    result = run_scenario(sc, output_dir=tmp_path)
    # Expected artifacts.
    assert (tmp_path / "report.json").exists()
    assert (tmp_path / "report.md").exists()
    assert (tmp_path / "index.html").exists()
    svgs = sorted(tmp_path.glob("*.svg"))
    assert len(svgs) == len(result.snapshots)
    # JSON parses.
    data = json.loads((tmp_path / "report.json").read_text())
    assert data["scenario"]["name"] == "stale_vs_fresh"
    assert len(data["snapshots"]) == len(result.snapshots)


@pytest.mark.parametrize("name", sorted(REGISTRY.keys()))
def test_every_builtin_scenario_runs(name):
    """Sanity: every listed scenario must execute without error."""
    sc = get_scenario(name)
    result = run_scenario(sc)
    assert len(result.snapshots) >= 2
