"""Real-network integration tests.

These tests talk to actual public servers (Google's STUN, etc.) and
are **opt-in only** — they are skipped by default.

To enable:

    DECENTNET_ENABLE_REAL_NETWORK=1 pytest tests/test_real_network.py -v

Why opt-in:
    - CI runners may be offline or behind restrictive NATs.
    - Public STUN servers rate-limit.
    - We don't want the default test run to depend on external systems.

What we verify:
    - Our STUN client can bind, send a Binding Request to a real
      STUN server, and parse the response into a plausible
      (ipv4, port) mapping.
    - The classifier heuristic produces some result (we can't assert
      *which* class, since that depends on the NAT the CI runner is
      behind).
"""
import os
import socket

import pytest

from decentnet.identity.keypair import Keypair
from decentnet.identity.peer_id import PeerId
from decentnet.nat import NATDiscovery, NATType
from decentnet.transport.udp import UDPTransport


REAL_NETWORK_ENABLED = os.environ.get("DECENTNET_ENABLE_REAL_NETWORK") == "1"

# A handful of well-known public STUN servers. We try them in order
# until one responds — any one suffices for a smoke test.
PUBLIC_STUN_SERVERS = [
    ("stun.l.google.com", 19302),
    ("stun1.l.google.com", 19302),
    ("stun.cloudflare.com", 3478),
    ("stun.nextcloud.com", 443),
]


pytestmark = pytest.mark.skipif(
    not REAL_NETWORK_ENABLED,
    reason="real-network tests disabled (set DECENTNET_ENABLE_REAL_NETWORK=1)",
)


def _resolve_ipv4(host: str) -> str | None:
    try:
        return socket.gethostbyname(host)
    except OSError:
        return None


def _first_reachable_stun():
    """Return the first STUN server we can resolve, or None."""
    for host, port in PUBLIC_STUN_SERVERS:
        ip = _resolve_ipv4(host)
        if ip is not None:
            return (ip, port)
    return None


def test_real_stun_probe_returns_mapping():
    """Send a Binding Request to a real STUN server. Expect a
    plausible IPv4:port tuple back."""
    from decentnet.transport.messages import UnreachableError
    server = _first_reachable_stun()
    if server is None:
        pytest.skip("no DNS resolution for any STUN server")
    pid = PeerId.from_public_key(Keypair.generate().public_key_bytes).value
    tx = UDPTransport(pid)
    try:
        disc = NATDiscovery(tx, [server])
        try:
            mapping = disc.discover(timeout_s=4.0)
        except UnreachableError as e:
            pytest.skip(f"no outbound UDP to {server}: {e}")
        if mapping is None:
            pytest.skip(f"STUN server {server} didn't reply in time")
        host, port = mapping
        assert isinstance(host, str) and host.count(".") == 3
        assert 0 < port < 65536
    finally:
        tx.close()


def test_real_stun_classify_produces_a_verdict():
    """Full RFC 5780 classification against a real server."""
    from decentnet.transport.messages import UnreachableError
    server = _first_reachable_stun()
    if server is None:
        pytest.skip("no DNS resolution for any STUN server")
    pid = PeerId.from_public_key(Keypair.generate().public_key_bytes).value
    tx = UDPTransport(pid)
    try:
        disc = NATDiscovery(tx, [server])
        try:
            behaviour = disc.classify_behaviour(timeout_s=4.0)
        except UnreachableError as e:
            pytest.skip(f"no outbound UDP to {server}: {e}")
        assert isinstance(behaviour.nat_type, NATType)
        if behaviour.mapped_primary is not None:
            host, port = behaviour.mapped_primary
            assert isinstance(host, str)
            assert 0 < port < 65536
    finally:
        tx.close()


def test_real_stun_two_servers_agree_on_external_ip():
    """If two different STUN servers report our external IP, they
    should agree."""
    from decentnet.transport.messages import UnreachableError
    servers = []
    for host, port in PUBLIC_STUN_SERVERS:
        ip = _resolve_ipv4(host)
        if ip is not None:
            servers.append((ip, port))
        if len(servers) == 2:
            break
    if len(servers) < 2:
        pytest.skip("couldn't resolve two STUN servers")
    pid = PeerId.from_public_key(Keypair.generate().public_key_bytes).value
    tx = UDPTransport(pid)
    try:
        disc = NATDiscovery(tx, servers)
        try:
            m1 = disc.discover(server=servers[0], timeout_s=4.0)
            m2 = disc.discover(server=servers[1], timeout_s=4.0)
        except UnreachableError as e:
            pytest.skip(f"no outbound UDP: {e}")
        if m1 is None or m2 is None:
            pytest.skip("one of the STUN servers didn't reply")
        assert m1[0] == m2[0]
    finally:
        tx.close()
