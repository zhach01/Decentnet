"""Transport + DHT end-to-end tests on the in-process network."""
import pytest

from decentnet.audit.log import AuditLog
from decentnet.dht.node import DHTEngine
from decentnet.dht.routing import RoutingTable
from decentnet.dht.storage import DHTStore
from decentnet.identity.keypair import Keypair
from decentnet.identity.peer_id import PeerId
from decentnet.records.endpoints import Endpoint
from decentnet.records.locator import LocatorRecord
from decentnet.transport.inproc import InProcessNetwork, InProcessTransport
from decentnet.transport.messages import (
    Message,
    MsgType,
    UnreachableError,
)


def _new_id():
    return PeerId.from_public_key(Keypair.generate().public_key_bytes).value


# -------------- transport --------------


def test_inproc_ping_pong():
    net = InProcessNetwork()
    a_id, b_id = _new_id(), _new_id()
    a = InProcessTransport(net, a_id)
    b = InProcessTransport(net, b_id)

    def b_handler(src, msg):
        assert msg.type == MsgType.PING.value
        b.send(src, msg.reply(MsgType.PONG, sender=b_id))

    b.set_receive_handler(b_handler)

    ping = Message.make(MsgType.PING, sender=a_id)
    reply = a.send_and_wait(b_id, ping)
    assert reply.type == MsgType.PONG.value
    assert reply.in_reply_to == ping.msg_id


def test_inproc_unreachable_raises():
    net = InProcessNetwork()
    a_id, ghost = _new_id(), _new_id()
    a = InProcessTransport(net, a_id)
    with pytest.raises(UnreachableError):
        a.send(ghost, Message.make(MsgType.PING, sender=a_id))


def test_inproc_offline_flag_partitions():
    net = InProcessNetwork()
    a_id, b_id = _new_id(), _new_id()
    a = InProcessTransport(net, a_id)
    b = InProcessTransport(net, b_id)
    b.set_receive_handler(
        lambda src, msg: b.send(src, msg.reply(MsgType.PONG, sender=b_id))
    )
    # Reachable.
    assert a.send_and_wait(
        b_id, Message.make(MsgType.PING, sender=a_id)
    ).type == MsgType.PONG.value
    # Take b offline.
    net.set_offline(b_id)
    with pytest.raises(UnreachableError):
        a.send_and_wait(b_id, Message.make(MsgType.PING, sender=a_id))


# -------------- DHT engine on a two-node network --------------


def _engine_for(net, pid):
    rt = RoutingTable(pid, k=4)
    store = DHTStore()
    transport = InProcessTransport(net, pid)
    audit = AuditLog(None)
    eng = DHTEngine(
        routing_table=rt, store=store, transport=transport, audit=audit, k=4,
    )
    return eng, rt, store, transport, audit


def test_dht_engine_ping_each_other():
    net = InProcessNetwork()
    a_id, b_id = _new_id(), _new_id()
    ea, rta, *_ = _engine_for(net, a_id)
    eb, rtb, *_ = _engine_for(net, b_id)
    # A learns about B and pings.
    rta.observe(b_id)
    from decentnet.dht.routing import Contact
    assert ea.ping(Contact(peer_id=b_id))


def test_dht_find_node_discovers_via_intermediary():
    """A knows only C. C knows B. A's FIND_NODE on B should discover B
    through iterative lookup."""
    net = InProcessNetwork()
    a_id, b_id, c_id = _new_id(), _new_id(), _new_id()
    ea, rta, *_ = _engine_for(net, a_id)
    eb, rtb, *_ = _engine_for(net, b_id)
    ec, rtc, *_ = _engine_for(net, c_id)

    rta.observe(c_id)      # A knows C
    rtc.observe(b_id)      # C knows B

    contacts = ea.find_node(b_id)
    found_ids = {c.peer_id for c in contacts}
    assert b_id in found_ids


def test_dht_store_and_find_value():
    net = InProcessNetwork()
    a_id, b_id = _new_id(), _new_id()
    ea, rta, store_a, *_ = _engine_for(net, a_id)
    eb, rtb, store_b, *_ = _engine_for(net, b_id)
    rta.observe(b_id)
    rtb.observe(a_id)

    # Build a record for some third peer.
    kp = Keypair.generate()
    rec = LocatorRecord.build_and_sign(
        kp,
        endpoints=[Endpoint(type="public_udp", address="1.2.3.4:5")],
        seq=1,
    )
    result = ea.store_on_network(rec)
    assert len(result["accepted"]) >= 1

    # Now B should be able to find it.
    lookup = eb.find_value(rec.peer_id)
    assert lookup.record is not None
    assert lookup.record.peer_id == rec.peer_id
    assert lookup.record.seq == 1


def test_dht_store_rejects_corrupted_record():
    net = InProcessNetwork()
    a_id, b_id = _new_id(), _new_id()
    ea, rta, store_a, tx_a, _ = _engine_for(net, a_id)
    eb, rtb, store_b, *_ = _engine_for(net, b_id)
    rta.observe(b_id)

    kp = Keypair.generate()
    rec = LocatorRecord.build_and_sign(
        kp,
        endpoints=[Endpoint(type="public_udp", address="1.2.3.4:5")],
        seq=1,
    )
    # Tamper with wire bytes: flip a char in the address.
    import json as _json
    wire = _json.loads(rec.to_wire_bytes())
    wire["endpoints"][0]["address"] = "9.9.9.9:9"
    tampered = _json.dumps(wire).encode()

    # Send a STORE with the tampered payload.
    from decentnet.transport.messages import Message
    msg = Message.make(
        MsgType.STORE,
        sender=a_id,
        payload={"record": tampered.decode()},
    )
    reply = tx_a.send_and_wait(b_id, msg)
    assert reply.type == MsgType.STORE_REJECT.value
    assert store_b.size() == 0
