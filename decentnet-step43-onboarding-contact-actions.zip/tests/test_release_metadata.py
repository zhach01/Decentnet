from __future__ import annotations

import tomllib
from pathlib import Path

from decentnet import __version__


ROOT = Path(__file__).resolve().parents[1]


def test_package_version_matches_pyproject() -> None:
    data = tomllib.loads((ROOT / 'pyproject.toml').read_text())
    assert data['project']['version'] == __version__


def test_release_docs_exist_and_reference_current_version() -> None:
    changelog = (ROOT / 'CHANGELOG.md').read_text()
    notes = (ROOT / 'docs' / 'RELEASE_NOTES_0.2.0.md').read_text()
    runbook = (ROOT / 'docs' / 'PRODUCTION_RUNBOOK.md').read_text()
    readme = (ROOT / 'README.md').read_text()

    assert '## [0.2.0]' in changelog
    assert 'Release `0.2.0`' in notes
    assert 'Production runbook' in runbook
    assert 'docs/RELEASE_NOTES_0.2.0.md' in readme
    assert 'docs/PRODUCTION_RUNBOOK.md' in readme
