import json
import time

import pytest

from decentnet.audit.log import AuditLog
from decentnet.cache.local import LocalCache
from decentnet.identity.keypair import Keypair
from decentnet.identity.peer_id import PeerId
from decentnet.records.endpoints import Endpoint
from decentnet.records.locator import LocatorRecord


def _fresh_cache(tmp_path=None, max_records=100):
    return LocalCache(
        tmp_path / "c.sqlite3" if tmp_path else None,
        audit=AuditLog(None),
        max_records=max_records,
    )


def _record(kp, seq, addr="1.1.1.1:1", t=None, ttl=3600, soft=1800):
    return LocatorRecord.build_and_sign(
        kp,
        endpoints=[Endpoint(type="public_udp", address=addr)],
        seq=seq,
        issued_at=t,
        ttl_s=ttl,
        soft_ttl_s=soft,
    )


def test_put_then_get():
    c = _fresh_cache()
    kp = Keypair.generate()
    rec = _record(kp, seq=1)
    r = c.put(rec, source="self")
    assert r.accepted
    got = c.get(rec.peer_id)
    assert got is not None
    assert got.peer_id == rec.peer_id
    assert got.seq == 1


def test_put_rejects_bad_signature():
    c = _fresh_cache()
    kp = Keypair.generate()
    rec = _record(kp, seq=1)
    # Tamper with signature.
    rec.signature = bytes(len(rec.signature))
    r = c.put(rec)
    assert not r.accepted
    assert "signature" in r.reason


def test_put_rejects_hard_expired():
    c = _fresh_cache()
    kp = Keypair.generate()
    rec = _record(kp, seq=1, t=1, ttl=2, soft=1)  # long in the past
    r = c.put(rec)
    assert not r.accepted
    assert r.reason == "hard_expired"


def test_put_rejects_rollback():
    c = _fresh_cache()
    kp = Keypair.generate()
    r1 = _record(kp, seq=5)
    r2 = _record(kp, seq=3)
    assert c.put(r1).accepted
    r = c.put(r2)
    assert not r.accepted
    assert r.reason == "not_newer"


def test_put_accepts_monotonic_updates():
    c = _fresh_cache()
    kp = Keypair.generate()
    for s in [1, 2, 5, 10]:
        r = c.put(_record(kp, seq=s, addr=f"1.1.1.{s}:1"))
        assert r.accepted


def test_put_rejects_duplicate_seq_same_time():
    c = _fresh_cache()
    kp = Keypair.generate()
    rec = _record(kp, seq=7)  # current time => still fresh
    assert c.put(rec).accepted
    assert not c.put(rec).accepted  # exact duplicate


def test_public_key_mismatch_rejected():
    """Same peer_id cannot change public key. (A genuine key rotation
    would produce a different peer_id.)"""
    c = _fresh_cache()
    kp1 = Keypair.generate()
    rec1 = _record(kp1, seq=1)
    assert c.put(rec1).accepted

    # Hand-craft a record claiming the same peer_id with a different key,
    # signed by that different key. It should verify cryptographically
    # (the signature is valid under its own pubkey), but the peer_id
    # field won't match the new key -> verify() fails first.
    # To specifically exercise the cache-level public_key check we
    # bypass verify() by feeding a record that both self-verifies and
    # asserts someone else's peer_id.
    # We do this by constructing a record whose peer_id matches kp1's
    # pubkey but whose signature-carrying public_key is kp2's -> verify
    # catches that and returns peer_id/public_key mismatch.
    kp2 = Keypair.generate()
    rec2 = _record(kp2, seq=2)
    # Force peer_id field to kp1's
    rec2.peer_id = PeerId.from_public_key(kp1.public_key_bytes).value
    r = c.put(rec2)
    assert not r.accepted


def test_persistence_across_restart(tmp_path):
    db = tmp_path / "cache.sqlite3"
    kp = Keypair.generate()
    rec = _record(kp, seq=1)

    c1 = LocalCache(db)
    assert c1.put(rec).accepted
    c1.close()

    c2 = LocalCache(db)
    got = c2.get(rec.peer_id)
    assert got is not None
    assert got.seq == 1
    c2.close()


def test_access_counters_update():
    c = _fresh_cache()
    kp = Keypair.generate()
    rec = _record(kp, seq=1)
    c.put(rec)
    c.get(rec.peer_id)
    c.get(rec.peer_id)
    c.get(rec.peer_id)
    for r, meta in c.entries():
        if r.peer_id == rec.peer_id:
            assert meta["access_count"] >= 3


def test_eviction_when_over_cap():
    c = _fresh_cache(max_records=3)
    # Put 5 different peers, all with seq 1. Oldest/least-accessed evicted.
    peers = []
    for i in range(5):
        kp = Keypair.generate()
        rec = _record(kp, seq=1, addr=f"1.1.1.{i}:1")
        c.put(rec)
        peers.append(rec.peer_id)
    assert c.stats()["records"] == 3


def test_negative_cache_roundtrip():
    c = _fresh_cache()
    c.mark_endpoint_failed("peer-x", "1.2.3.4:5")
    c.mark_endpoint_failed("peer-x", "1.2.3.4:5")
    failed = c.failed_endpoints("peer-x")
    assert failed["1.2.3.4:5"]["failure_count"] == 2
    c.mark_endpoint_success("peer-x", "1.2.3.4:5")
    assert c.failed_endpoints("peer-x") == {}


def test_gc_removes_expired(tmp_path, monkeypatch):
    import decentnet.cache.local as local_mod
    import decentnet.records.locator as loc_mod

    c = _fresh_cache(tmp_path)
    kp = Keypair.generate()

    # Record valid *now*.
    rec = _record(kp, seq=1, ttl=3600, soft=1800)
    assert c.put(rec).accepted
    assert c.stats()["records"] == 1

    # Jump the clock forward so everything is expired.
    future = int(time.time()) + 100_000
    monkeypatch.setattr(local_mod, "now_s", lambda: future)

    out = c.gc()
    assert out["removed"] == 1
    assert c.stats()["records"] == 0
