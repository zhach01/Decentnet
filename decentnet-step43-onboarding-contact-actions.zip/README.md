# decentnet

A decentralized peer-resolution and direct-connect framework in Python.

**Status: Release 0.2.0 candidate — networking, observability, operator tooling,
and release packaging are now unified in one codebase.** The stack now includes
cryptographic identity with key rotation, signed locator records with per-recipient
encrypted endpoint envelopes, multi-layer cache, Kademlia-style distributed
directory, direct signed peer-to-peer signaling, NAT discovery, automatic ICE
startup, selected-path persistence, keepalive-driven path health, relay fallback,
automatic record bootstrap, runtime candidate refresh, relay lifecycle hardening,
operator two-host/matrix/soak tooling, dashboard snapshots, and final export packs.

The validation surface now covers focused unit tests, mesh integration, relay and
ICE recovery, operator harness flows, dashboard export/import paths, and local
real-UDP smoke checks. Real-network STUN tests remain opt-in because they depend on
external DNS and outbound UDP reachability.

Core documentation entry points:
- `CHANGELOG.md` — release history
- `docs/RELEASE_NOTES_0.2.0.md` — release highlights, upgrade notes, known limits
- `docs/PRODUCTION_RUNBOOK.md` — operator checklist and deployment/run procedures
- `docs/REAL_NETWORK.md` — two-host, matrix, soak, and pack workflows
- `docs/THREAT_MODEL.md` — security model

## What decentnet is

Every online user device is a node. Nodes are both client and server.
The distributed network's job is to share **signed connection metadata
about peers** — not user messages, not voice, not files. After peers
resolve each other through the fabric, they connect **directly** via
a signed signaling handshake.

**Explicitly not a goal:** relaying user payloads, permanently storing
user content, or acting as a transport fabric.

## What's implemented

### Phase 1 (identity + local cache)

Ed25519 keypair with persistence · PeerId = base32(SHA-256(pubkey)) ·
signed `LocatorRecord` with seq + hard/soft TTL · SQLite-backed L1
cache with full validation pipeline · negative cache · GC ·
CLI: `init / whoami / publish / show / lookup / export / import /
peers / log / gc / stats`.

### Phase 2 (distributed directory)

Pluggable `Transport` + `InProcessTransport` · Kademlia-style DHT ·
iterative FIND_NODE / FIND_VALUE with quorum-merged reads · STORE
replicated to k-closest · anti-entropy via summary-exchange +
RECORD_PUSH · signed `BootstrapManifest` · per-source rate limit ·
clock-skew clamp · `SimNetwork` harness.

### Phase 3 (simulator + visualization)

`VirtualClock` · persistent DHT store · scheduled republish loop ·
`take_snapshot()` with per-node record state · zero-dep SVG renderer
with partition halos · `Scenario` DSL + `run_scenario()` emitting
JSON + Markdown + SVG + HTML timeline · 5 built-in scenarios · CLI:
`sim list`, `sim run <n> [-o DIR]`.

### Phase 4 (direct signaling)

Real `UDPTransport` (thread-driven, opportunistic endpoint learning,
timeout-safe) · signaling protocol with `sig.hello / hello_ack / ring
/ ring_ack / bye / keepalive` plus pass-through `sig.offer / answer /
candidate / chat_control` · every message signed, replay-protected
per-session, and target-checked · `SessionState` FSM (FRESH →
HANDSHAKING → ESTABLISHED → RINGING → IN_CALL → CLOSED) · explicit
trust promotion (`trusted_peers()` requires completed handshake) ·
`NegativeCache` with exponential backoff on repeated failures ·
`Node.signaling.hello / ring / send_passthrough / bye / drain_inbox`.

### Phase 5 (NAT discovery)

STUN codec (RFC 5389 subset: Binding Request/Response +
XOR-MAPPED-ADDRESS, IPv4 + IPv6) · `MockSTUNServer` for deterministic
tests · `NATDiscovery` sharing the node's UDP socket so learned
mappings are the ones peers actually hit · UDP transport demuxes
STUN vs decentnet JSON by magic cookie · NAT-type classifier
(`OPEN_INTERNET / CONE_LIKE / SYMMETRIC / UNKNOWN`) using one or two
servers · `Node.enable_nat_discovery / refresh_external_address /
classify_nat / publish_with_external_address` — auto-injects the
STUN-learned endpoint into the next signed `LocatorRecord`.

### Phase 6 (ICE + relay fallback)

`IceCandidate` with RFC 8445 priority math (host / srflx / prflx /
relay, single-component) · `candidates_from_endpoints(record)`
converts a LocatorRecord to an ICE candidate list ·
`ICEAgent.set_candidates` enumerates and priority-sorts pairs ·
`gather_and_probe` performs prioritized probing with implicit hole
punching via `sig.conn_check` / `sig.conn_check_ack` on the existing
signed envelope · pair states `NEW → IN_PROGRESS → SUCCEEDED /
FAILED → NOMINATED` · ack carries `observed_remote` for
peer-reflexive discovery · **cooperative UDP relay** with signed
`RelayToken` (Ed25519, TTL-bounded), allocate/forward protocol,
header-wrapped delivery, allocation table with expiry.

**Tests: 140 passing** — 39 (P1) + 36 (P2) + 17 (P3) + 18 (P4) +
15 (P5) + 15 (P6: 8 ICE + 7 relay), zero regressions.

Known limits and deferred work: `docs/ARCHITECTURE.md`,
`docs/DIRECTORY.md`, `docs/REPAIR.md`, `docs/SIMULATOR.md`,
`docs/SIGNALING.md`.

## Release and handoff docs

- `CHANGELOG.md` tracks release-level changes.
- `docs/RELEASE_NOTES_0.2.0.md` summarizes the unified 0.2.0 candidate.
- `docs/PRODUCTION_RUNBOOK.md` is the operator-facing deployment and validation guide.
- `docs/REAL_NETWORK.md` contains the concrete two-host, matrix, soak, and pack commands.

## Install & run

```bash
pip install cryptography pytest
python -m pytest tests/ -q                       # 140 passed

python examples/basic_demo.py                    # Phase 1
python examples/networked_demo.py                # Phase 2
python examples/phase3_demo.py                   # Phase 3
python examples/phase4_demo.py                   # Phase 4 — two UDP nodes
python examples/phase5_demo.py                   # Phase 5 — STUN + mapped publish
python examples/phase6_demo.py                   # Phase 6 — ICE + relay

python -m decentnet sim list
python -m decentnet sim run partition_then_merge -o /tmp/out
```

## Package layout

```
decentnet/
  # Phase 1
  identity/        Ed25519 keypair, PeerId derivation
  records/         Endpoint, LocatorRecord, shared validation
  cache/           SQLite storage + LocalCache
  node/            Node facade + config + seq counter
  audit/           JSONL event log
  utils/           Canonical JSON, encoding, virtual-clock hook

  # Phase 2
  transport/       Transport interface, InProcessTransport,
                   + UDPTransport (Phase 4), + STUN demux (Phase 5)
  dht/             Kademlia routing, replica store, engine, iterative lookup
  directory/       Directory facade + signed BootstrapManifest
  repair/          Anti-entropy summary exchange
  limits/          Per-source token-bucket rate limiter

  # Phase 3
  sim/             VirtualClock, snapshot, SVG renderer,
                   scenario DSL + runner, built-in scenarios

  # Phase 4
  signaling/       SignalingEngine, SignalType, Session, NegativeCache

  # Phase 5
  nat/             STUN codec, MockSTUNServer, NATDiscovery, NATType

  # Phase 6
  ice/             IceCandidate, CandidatePair, ICEAgent, priority math
  relay/           RelayServer, RelayToken, allocate/forward protocol

  cli/             argparse-based CLI
  __main__.py      `python -m decentnet`

tests/             140 tests (ICE + relay + NAT + signaling + UDP
                   + every earlier layer)
examples/          basic_demo.py, networked_demo.py, phase3_demo.py,
                   phase4_demo.py, phase5_demo.py, phase6_demo.py
docs/              ARCHITECTURE.md, PROTOCOL.md, DIRECTORY.md,
                   REPAIR.md, SIMULATOR.md, SIGNALING.md, NAT.md, ICE.md
```

## Key design decisions

1. **IP is never identity.** PeerId is derived from the public key.
2. **Every record is signed** and re-verified at every hop.
3. **Every signaling message is signed** and nonce-protected per session.
4. **Freshness is explicit** — TTL windows on records and signaling messages.
5. **Rollback refused** via strict `(seq, issued_at)` precedence.
6. **One validation pipeline** for records (`validate_for_storage`);
   one envelope check for signaling (`verify_envelope`).
7. **Layers are separable.** Transport swap (in-process ↔ UDP) is
   transparent to the DHT engine and the signaling engine both.
8. **Virtual clock, not monkey patching.** `install_clock` makes
   time-sensitive behaviour deterministic framework-wide.
9. **Explicit trust boundary.** DHT-resolved ≠ trusted. Promotion
   requires a successful hello/hello_ack exchange.
10. **Honest about limits.** WAN P2P needs rotating bootstrap and
    STUN; signaling datagrams need MTU discipline; see each doc's
    "honest notes" section.

See `docs/` for per-layer design.


## Peer deployment configuration

DecentNet now supports peer-first TOML configuration for real multi-device deployment. The most important distinction is between the UDP bind socket and the endpoints a peer advertises. Use `[transport]` for local listening and `[advertise]` for manual or hybrid endpoint publication. See `packaging/config.example.toml` for a Raspberry Pi / PC friendly template.

Example:

```toml
[transport]
bind_host = "0.0.0.0"
bind_port = 45001

[advertise]
mode = "hybrid"
auto_publish = true
auto_vpn = true

[[advertise.manual_endpoints]]
type = "lan_udp"
address = "192.168.1.50:45001"
priority = 80
```


## Peer lifecycle

```bash
decentnet up --config /etc/decentnet/config.toml
decentnet status --config /etc/decentnet/config.toml
decentnet down --config /etc/decentnet/config.toml
```
