"""Background maintenance loops.

Two schedulers live here:

    BackgroundRefresh
        Periodically walks the cache and triggers DHT re-resolves
        for records whose soft-TTL has expired but which are still
        being accessed. Keeps the cache fresh without the user
        having to manually `resolve()`.

    KeepaliveScheduler
        Sends `sig.keepalive` on each established signaling session
        every N seconds so both sides know the other is still up
        and no middlebox NAT has unmapped the flow.

Both are threads that can be cleanly started and stopped. They
respect the virtual clock for tests via `utils.time.now_s()`.
"""
from __future__ import annotations

import threading
from typing import Optional


DEFAULT_REFRESH_INTERVAL_S = 60
DEFAULT_KEEPALIVE_INTERVAL_S = 30


class BackgroundRefresh:
    """Walks the local cache every `interval_s` seconds and triggers
    `resolve(peer_id, force_network=True)` for any record past its
    soft-TTL."""

    def __init__(
        self,
        node,
        *,
        interval_s: int = DEFAULT_REFRESH_INTERVAL_S,
        max_refreshes_per_tick: int = 16,
    ) -> None:
        self._node = node
        self._interval = interval_s
        self._max_per_tick = max_refreshes_per_tick
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, name="decentnet-refresh", daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)

    def _run(self) -> None:
        while not self._stop.wait(self._interval):
            self._tick()

    def tick_once(self) -> int:
        """Run one pass immediately (useful for tests)."""
        return self._tick()

    def _tick(self) -> int:
        from .utils.time import now_s
        t = now_s()
        stale: list[str] = []
        for rec, meta in self._node.cache.entries():
            if rec.peer_id == self._node.peer_id.value:
                continue
            if rec.needs_soft_refresh(at=t):
                stale.append(rec.peer_id)
            if len(stale) >= self._max_per_tick:
                break
        if self._node.directory is None:
            return 0
        refreshed = 0
        for pid in stale:
            try:
                self._node.resolve(pid, force_network=True)
                refreshed += 1
            except Exception:
                continue
        if refreshed:
            self._node.audit.record(
                "node.background_refresh", count=refreshed,
            )
        return refreshed


class KeepaliveScheduler:
    """Fires `sig.keepalive` every `interval_s` seconds on each
    established session."""

    def __init__(
        self,
        node,
        *,
        interval_s: int = DEFAULT_KEEPALIVE_INTERVAL_S,
    ) -> None:
        self._node = node
        self._interval = interval_s
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, name="decentnet-keepalive", daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)

    def tick_once(self) -> int:
        return self._tick()

    def _run(self) -> None:
        while not self._stop.wait(self._interval):
            self._tick()

    def _tick(self) -> int:
        if self._node.signaling is None:
            return 0
        sent = 0
        for pid in self._node.signaling.trusted_peers():
            session = self._node.signaling.session(pid)
            if session is None:
                continue
            try:
                if self._node.signaling.keepalive(pid).ok:
                    sent += 1
            except Exception:
                continue
        if sent:
            self._node.audit.record("signal.keepalive_tick", count=sent)
        return sent
