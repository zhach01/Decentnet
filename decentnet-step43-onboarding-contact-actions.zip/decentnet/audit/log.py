"""Append-only JSONL audit log.

Every cache or signaling event that changes observable state should
get a line here. Lines are UTF-8 JSON objects with at least:
    ts:     UNIX seconds
    kind:   event kind ("cache.put", "cache.reject", "sig.verify_fail", ...)
    ...:    event-specific fields

We deliberately use plain JSONL so the log is grep-able and so
downstream tooling (the simulator, test assertions) can parse it
trivially.
"""
from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any, Iterable, Optional

from ..utils.time import now_s


class AuditLog:
    def __init__(
        self,
        path: Optional[str | Path] = None,
        *,
        max_bytes: int = 10 * 1024 * 1024,   # 10 MiB per file
        keep_rotated: int = 5,
        max_memory_entries: int = 10_000,
    ) -> None:
        """If path is None, log entries are kept in memory only.

        Rotation: when the active file exceeds `max_bytes`, it is
        renamed to `<path>.1`, `<path>.1 → <path>.2`, etc., keeping
        at most `keep_rotated` historical files. Old ones are
        deleted. In-memory tail is capped at `max_memory_entries`.
        """
        self._path: Optional[Path] = Path(path) if path else None
        self._max_bytes = int(max_bytes)
        self._keep_rotated = int(keep_rotated)
        self._max_memory = int(max_memory_entries)
        self._lock = threading.Lock()
        self._memory: list[dict[str, Any]] = []
        if self._path is not None:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            self._path.touch(exist_ok=True)

    def record(self, kind: str, **fields: Any) -> dict[str, Any]:
        entry = {"ts": now_s(), "kind": kind, **fields}
        line = json.dumps(entry, sort_keys=True, ensure_ascii=False)
        with self._lock:
            self._memory.append(entry)
            if len(self._memory) > self._max_memory:
                # Trim to the most recent entries.
                del self._memory[:-self._max_memory]
            if self._path is not None:
                self._maybe_rotate_locked()
                with self._path.open("a", encoding="utf-8") as f:
                    f.write(line + "\n")
        return entry

    def _maybe_rotate_locked(self) -> None:
        """Caller must hold `self._lock` and have `self._path`."""
        try:
            size = self._path.stat().st_size
        except OSError:
            return
        if size < self._max_bytes:
            return
        # Shift .N → .N+1, drop the oldest.
        for i in range(self._keep_rotated - 1, 0, -1):
            src = self._path.with_suffix(self._path.suffix + f".{i}")
            dst = self._path.with_suffix(self._path.suffix + f".{i + 1}")
            if src.exists():
                try:
                    src.replace(dst)
                except OSError:
                    pass
        # Current file → .1
        one = self._path.with_suffix(self._path.suffix + ".1")
        try:
            self._path.replace(one)
        except OSError:
            pass
        # Drop any file past the keep_rotated boundary.
        for i in range(self._keep_rotated + 1, self._keep_rotated + 10):
            extra = self._path.with_suffix(self._path.suffix + f".{i}")
            if extra.exists():
                try:
                    extra.unlink()
                except OSError:
                    pass
        # Re-touch the fresh log file.
        self._path.touch(exist_ok=True)

    def entries(self) -> list[dict[str, Any]]:
        with self._lock:
            return list(self._memory)

    def tail(self, n: int = 50) -> list[dict[str, Any]]:
        with self._lock:
            return list(self._memory[-n:])

    def iter_file(self) -> Iterable[dict[str, Any]]:
        """Yield entries from the on-disk log, for offline analysis."""
        if self._path is None or not self._path.exists():
            return []
        out: list[dict[str, Any]] = []
        with self._path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    out.append(json.loads(line))
        return out
