"""Simple token-bucket rate limiter, keyed by source.

Used to cap the rate at which any one source (peer_id or label)
can inject records through `Node.ingest_record_bytes`. Prevents
a single noisy/malicious neighbour from overwhelming the cache with
validation work.

Defaults: 10 tokens burst, 2 tokens/s refill. That's ample for an
honest peer pushing records, tight enough that a gossip storm gets
shed quickly.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from threading import Lock

from ..utils.time import monotonic_ms


@dataclass
class _Bucket:
    tokens: float
    last_refill_ms: int


class RateLimiter:
    def __init__(self, *, burst: float = 10.0, refill_per_s: float = 2.0) -> None:
        self._burst = float(burst)
        self._refill_per_ms = float(refill_per_s) / 1000.0
        self._buckets: dict[str, _Bucket] = {}
        self._lock = Lock()

    def allow(self, source: str, cost: float = 1.0) -> bool:
        now = monotonic_ms()
        with self._lock:
            b = self._buckets.get(source)
            if b is None:
                b = _Bucket(tokens=self._burst, last_refill_ms=now)
                self._buckets[source] = b
            # Refill.
            elapsed = max(0, now - b.last_refill_ms)
            b.tokens = min(self._burst, b.tokens + elapsed * self._refill_per_ms)
            b.last_refill_ms = now
            if b.tokens >= cost:
                b.tokens -= cost
                return True
            return False

    def reset(self, source: str | None = None) -> None:
        with self._lock:
            if source is None:
                self._buckets.clear()
            else:
                self._buckets.pop(source, None)

    def stats(self) -> dict:
        with self._lock:
            return {
                "sources": len(self._buckets),
                "burst": self._burst,
                "refill_per_s": self._refill_per_ms * 1000.0,
            }
