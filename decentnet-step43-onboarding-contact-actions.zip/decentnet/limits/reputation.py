"""Neighbour reputation & trust scoring.

Each peer we interact with gets a score in [0, 1] computed from:

    * successful DHT operations against them (ping, store, find)
    * failed operations (timeout, unreachable)
    * rejected content (signature fails, replay, bad records)
    * aging (recent behaviour weighted higher than old)

High score → prefer them for k-bucket placement + lookups.
Low score → deprioritized or evicted after a timeout.

Integration: the DHT engine calls `note_success` / `note_failure` /
`note_malicious` on this tracker; when selecting candidates for
k-bucket refresh or lookups, call `score(peer_id)` as a tiebreaker.

Persisted so a restart doesn't forget a malicious neighbour.
"""
from __future__ import annotations

import sqlite3
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from ..utils.time import now_s


# Scoring weights — conservative, easy to tune.
WEIGHT_SUCCESS = +1.0
WEIGHT_FAILURE = -0.5
WEIGHT_MALICIOUS = -10.0      # one bad sig can drop you a long way
DECAY_HALFLIFE_S = 3600 * 24  # 1 day


@dataclass
class PeerReputation:
    peer_id: str
    successes: int
    failures: int
    malicious: int
    last_event_at: int
    score_raw: float           # EMA-style accumulator


class ReputationTracker:
    def __init__(self, db_path: Path | str | None) -> None:
        if db_path is None:
            self._conn = sqlite3.connect(":memory:", check_same_thread=False)
        else:
            p = Path(db_path)
            p.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(p), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        with self._lock, self._conn:
            self._conn.executescript("""
                CREATE TABLE IF NOT EXISTS reputation (
                    peer_id TEXT PRIMARY KEY,
                    successes INTEGER NOT NULL DEFAULT 0,
                    failures INTEGER NOT NULL DEFAULT 0,
                    malicious INTEGER NOT NULL DEFAULT 0,
                    last_event_at INTEGER NOT NULL,
                    score_raw REAL NOT NULL DEFAULT 0
                );
            """)

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def _apply(self, peer_id: str, delta_event: dict, *, delta_score: float) -> None:
        t = now_s()
        with self._lock, self._conn:
            # Fetch current record (if any).
            row = self._conn.execute(
                "SELECT * FROM reputation WHERE peer_id = ?", (peer_id,),
            ).fetchone()
            if row is None:
                new = {
                    "peer_id": peer_id,
                    "successes": delta_event.get("successes", 0),
                    "failures": delta_event.get("failures", 0),
                    "malicious": delta_event.get("malicious", 0),
                    "last_event_at": t,
                    "score_raw": delta_score,
                }
            else:
                # Decay toward zero over half-life.
                age = max(0, t - row["last_event_at"])
                factor = 0.5 ** (age / DECAY_HALFLIFE_S)
                decayed = row["score_raw"] * factor
                new = {
                    "peer_id": peer_id,
                    "successes": row["successes"] + delta_event.get("successes", 0),
                    "failures": row["failures"] + delta_event.get("failures", 0),
                    "malicious": row["malicious"] + delta_event.get("malicious", 0),
                    "last_event_at": t,
                    "score_raw": decayed + delta_score,
                }
            self._conn.execute(
                """INSERT INTO reputation
                   (peer_id, successes, failures, malicious,
                    last_event_at, score_raw)
                   VALUES (:peer_id, :successes, :failures, :malicious,
                           :last_event_at, :score_raw)
                   ON CONFLICT(peer_id) DO UPDATE SET
                     successes = excluded.successes,
                     failures = excluded.failures,
                     malicious = excluded.malicious,
                     last_event_at = excluded.last_event_at,
                     score_raw = excluded.score_raw""",
                new,
            )

    # ---- events ----

    def note_success(self, peer_id: str) -> None:
        self._apply(peer_id, {"successes": 1}, delta_score=WEIGHT_SUCCESS)

    def note_failure(self, peer_id: str) -> None:
        self._apply(peer_id, {"failures": 1}, delta_score=WEIGHT_FAILURE)

    def note_malicious(self, peer_id: str, *, reason: str = "") -> None:
        self._apply(peer_id, {"malicious": 1}, delta_score=WEIGHT_MALICIOUS)

    # ---- queries ----

    def score(self, peer_id: str) -> float:
        """Return a normalised [-1, 1]-like score. Positive = good
        neighbour, negative = avoid."""
        with self._lock, self._conn:
            row = self._conn.execute(
                "SELECT score_raw, last_event_at FROM reputation "
                "WHERE peer_id = ?", (peer_id,),
            ).fetchone()
        if row is None:
            return 0.0
        t = now_s()
        age = max(0, t - row["last_event_at"])
        factor = 0.5 ** (age / DECAY_HALFLIFE_S)
        raw = row["score_raw"] * factor
        # Squash to (-1, 1) via tanh-like.
        return max(-1.0, min(1.0, raw / 10.0))

    def is_trusted(self, peer_id: str, *, threshold: float = 0.1) -> bool:
        return self.score(peer_id) >= threshold

    def is_blacklisted(self, peer_id: str, *, threshold: float = -0.5) -> bool:
        return self.score(peer_id) <= threshold

    def all_peers(self) -> list[PeerReputation]:
        with self._lock, self._conn:
            rows = self._conn.execute(
                "SELECT * FROM reputation ORDER BY peer_id"
            ).fetchall()
        return [
            PeerReputation(
                peer_id=r["peer_id"],
                successes=r["successes"],
                failures=r["failures"],
                malicious=r["malicious"],
                last_event_at=r["last_event_at"],
                score_raw=r["score_raw"],
            )
            for r in rows
        ]
