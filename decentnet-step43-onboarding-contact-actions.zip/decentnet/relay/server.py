"""Minimal cooperative UDP relay.

Scope
-----
This is a **cooperative forwarder**, not a full RFC 5766 TURN server.
It exists so two peers behind incompatible NATs (e.g. both symmetric)
can still hand off a few hundred signed signaling messages and
eventually tear down a TURN allocation. It is explicitly NOT:

    * a general-purpose VPN
    * a way to route user media at scale
    * a source of anonymity (the relay sees src/dst peer_ids)

Protocol
--------
The relay binds one UDP socket. It understands two message types
distinguished by the first byte of the datagram:

    0x01  ALLOCATE                — "please associate peer_id P with this addr"
          body: JSON { "peer_id", "token" }
          reply: 0x81 ALLOCATE_OK { "relay_addr": "host:port" }  or
                 0x82 ALLOCATE_REJECT { "reason" }

    0x02  FORWARD                 — "forward payload to peer_id T"
          body: JSON header { "target": T } + 0x00 + raw payload bytes
          The relay looks up T's allocated address and sends the
          payload to it with a small header prefix so the receiver
          knows who it came from.

A relay allocation requires a signed token issued by the target peer
(or, in the bootstrap case, by the relay operator) authorizing this
specific peer_id to use this relay. Clients who don't hold a valid
token are rejected.

Tokens are JSON:

    {
      "relay_pubkey": b64url(pubkey_of_relay),
      "client_peer_id": "<base32>",
      "issued_at": int,
      "expires_at": int,
      "signature": b64url(Ed25519 over the above minus signature)
    }

The relay checks the signature with its own public key (the
operator's). Users get a token from the operator via whatever
channel they use today (web UI, manifest, friend).

Honest notes
------------
- Tokens are bearer credentials; anyone who captures one can use the
  relay as that peer_id until it expires. Use short TTLs.
- The relay sees which peer_ids talk to which; it does NOT see
  plaintext content, because all decentnet signaling is end-to-end
  signed and payloads of the `sig.offer / answer / candidate` type
  are opaque to everyone but the two peers (and in real use those
  payloads would be encrypted by the application layer as well).
- One global allocation table per relay. No rate limiting yet.
  Production use needs both.
"""
from __future__ import annotations

import json
import socket
import struct
import threading
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from ..identity.keypair import Keypair, verify_with_public_key
from ..utils.encoding import b64u_decode, b64u_encode, canonical_json_bytes
from ..utils.time import now_s


# Message tags.
TAG_ALLOCATE = 0x01
TAG_FORWARD = 0x02
TAG_ALLOCATE_OK = 0x81
TAG_ALLOCATE_REJECT = 0x82
TAG_FORWARDED = 0x83


# -------- tokens --------


@dataclass
class RelayToken:
    relay_public_key: bytes
    client_peer_id: str
    issued_at: int
    expires_at: int
    signature: Optional[bytes] = None

    def signing_input(self) -> bytes:
        return canonical_json_bytes({
            "relay_pubkey": b64u_encode(self.relay_public_key),
            "client_peer_id": self.client_peer_id,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
        })

    def to_json(self) -> str:
        assert self.signature is not None
        return json.dumps({
            "relay_pubkey": b64u_encode(self.relay_public_key),
            "client_peer_id": self.client_peer_id,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
            "signature": b64u_encode(self.signature),
        })

    @classmethod
    def from_json(cls, s: str) -> "RelayToken":
        d = json.loads(s)
        return cls(
            relay_public_key=b64u_decode(d["relay_pubkey"]),
            client_peer_id=d["client_peer_id"],
            issued_at=int(d["issued_at"]),
            expires_at=int(d["expires_at"]),
            signature=b64u_decode(d["signature"]) if "signature" in d else None,
        )

    def verify(self, *, expected_relay_key: bytes) -> tuple[bool, Optional[str]]:
        if self.expires_at <= now_s():
            return False, "expired"
        if self.relay_public_key != expected_relay_key:
            return False, "wrong relay key"
        if self.signature is None:
            return False, "unsigned"
        if not verify_with_public_key(
            self.relay_public_key, self.signing_input(), self.signature
        ):
            return False, "bad signature"
        return True, None


def issue_relay_token(
    relay_keypair: Keypair,
    client_peer_id: str,
    *,
    ttl_s: int = 3600,
) -> RelayToken:
    t = now_s()
    tok = RelayToken(
        relay_public_key=relay_keypair.public_key_bytes,
        client_peer_id=client_peer_id,
        issued_at=t,
        expires_at=t + ttl_s,
    )
    tok.signature = relay_keypair.sign(tok.signing_input())
    return tok


# -------- server --------


@dataclass
class _Allocation:
    peer_id: str
    addr: tuple[str, int]
    expires_at: int


class _RateWindow:
    def __init__(self, *, limit: int, window_s: int) -> None:
        self.limit = int(limit)
        self.window_s = int(window_s)
        self.events: deque[int] = deque()

    def _prune(self, now: int) -> None:
        cutoff = now - self.window_s
        while self.events and self.events[0] <= cutoff:
            self.events.popleft()

    def allow(self, *, at: Optional[int] = None) -> bool:
        now = now_s() if at is None else int(at)
        self._prune(now)
        if len(self.events) >= self.limit:
            return False
        self.events.append(now)
        return True


class RelayServer:
    """Minimal cooperative UDP relay.

    Keep-it-simple reader: one thread, one socket, a dict of
    allocations. Not production-ready; correct for the scenarios
    we model in the test suite and the Phase 6 demo.
    """

    def __init__(
        self,
        keypair: Optional[Keypair] = None,
        *,
        bind_host: str = "127.0.0.1",
        bind_port: int = 0,
        max_allocate_per_window: int = 30,
        allocate_window_s: int = 60,
        max_forward_per_window: int = 300,
        forward_window_s: int = 60,
    ) -> None:
        self._kp = keypair or Keypair.generate()
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.bind((bind_host, bind_port))
        self._sock.settimeout(0.25)
        self.bind_host, self.bind_port = self._sock.getsockname()
        self._allocs: dict[str, _Allocation] = {}
        self._allocate_limit = int(max_allocate_per_window)
        self._allocate_window_s = int(allocate_window_s)
        self._forward_limit = int(max_forward_per_window)
        self._forward_window_s = int(forward_window_s)
        self._allocate_windows: dict[str, _RateWindow] = {}
        self._forward_windows: dict[str, _RateWindow] = {}
        self._lock = threading.Lock()
        self._running = threading.Event()
        self._running.set()
        self.forward_count = 0
        self.allocate_count = 0
        self.allocate_reject_count = 0
        self.rate_limited_allocations = 0
        self.rate_limited_forwards = 0
        self.forward_drop_count = 0
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    @property
    def public_key(self) -> bytes:
        return self._kp.public_key_bytes

    def issue_token(self, client_peer_id: str, *, ttl_s: int = 3600) -> RelayToken:
        return issue_relay_token(self._kp, client_peer_id, ttl_s=ttl_s)

    def allocations(self) -> dict[str, tuple[str, int]]:
        with self._lock:
            return {
                pid: alloc.addr
                for pid, alloc in self._allocs.items()
                if alloc.expires_at > now_s()
            }

    def stats(self) -> dict:
        with self._lock:
            active = {pid: alloc.addr for pid, alloc in self._allocs.items() if alloc.expires_at > now_s()}
        return {
            "allocations": len(active),
            "allocate_count": self.allocate_count,
            "allocate_reject_count": self.allocate_reject_count,
            "forward_count": self.forward_count,
            "forward_drop_count": self.forward_drop_count,
            "rate_limited_allocations": self.rate_limited_allocations,
            "rate_limited_forwards": self.rate_limited_forwards,
        }

    def _allow_allocate(self, peer_id: str) -> bool:
        with self._lock:
            w = self._allocate_windows.get(peer_id)
            if w is None:
                w = _RateWindow(limit=self._allocate_limit, window_s=self._allocate_window_s)
                self._allocate_windows[peer_id] = w
            ok = w.allow()
            if not ok:
                self.rate_limited_allocations += 1
            return ok

    def _allow_forward(self, src_peer_id: str) -> bool:
        with self._lock:
            w = self._forward_windows.get(src_peer_id)
            if w is None:
                w = _RateWindow(limit=self._forward_limit, window_s=self._forward_window_s)
                self._forward_windows[src_peer_id] = w
            ok = w.allow()
            if not ok:
                self.rate_limited_forwards += 1
            return ok

    # ---- main loop ----

    def _run(self) -> None:
        while self._running.is_set():
            try:
                data, addr = self._sock.recvfrom(65_536)
            except socket.timeout:
                continue
            except OSError:
                break
            if not data:
                continue
            tag = data[0]
            try:
                if tag == TAG_ALLOCATE:
                    self._handle_allocate(data[1:], addr)
                elif tag == TAG_FORWARD:
                    self._handle_forward(data[1:], addr)
            except Exception:
                continue

    def _handle_allocate(self, body: bytes, addr: tuple[str, int]) -> None:
        try:
            d = json.loads(body.decode("utf-8"))
            peer_id = d["peer_id"]
            tok = RelayToken.from_json(d["token"])
        except Exception as e:
            self._send_reject(addr, f"malformed: {e}")
            return
        ok, reason = tok.verify(expected_relay_key=self.public_key)
        if not ok:
            self._send_reject(addr, reason or "invalid")
            return
        if tok.client_peer_id != peer_id:
            self._send_reject(addr, "token/peer_id mismatch")
            return
        if not self._allow_allocate(peer_id):
            self._send_reject(addr, "rate_limited")
            return
        with self._lock:
            self._allocs[peer_id] = _Allocation(
                peer_id=peer_id, addr=addr, expires_at=tok.expires_at,
            )
        self.allocate_count += 1
        body_out = json.dumps(
            {"relay_addr": f"{self.bind_host}:{self.bind_port}"}
        ).encode()
        self._sock.sendto(bytes([TAG_ALLOCATE_OK]) + body_out, addr)

    def _handle_forward(self, body: bytes, from_addr: tuple[str, int]) -> None:
        # body = json_header_bytes + b"\x00" + raw_payload
        try:
            sep = body.index(b"\x00")
        except ValueError:
            return
        header_json = body[:sep]
        payload = body[sep + 1:]
        try:
            hdr = json.loads(header_json.decode("utf-8"))
            target = hdr["target"]
        except Exception:
            return
        # Determine source peer_id from the sender's allocation.
        with self._lock:
            src_peer_id: Optional[str] = None
            for pid, alloc in self._allocs.items():
                if alloc.addr == from_addr:
                    src_peer_id = pid
                    break
            target_alloc = self._allocs.get(target)
        if src_peer_id is None or target_alloc is None:
            self.forward_drop_count += 1
            return
        if target_alloc.expires_at <= now_s():
            self.forward_drop_count += 1
            return
        if not self._allow_forward(src_peer_id):
            self.forward_drop_count += 1
            return
        # Wrap with forwarded header so receiver knows the source.
        wrap_header = json.dumps({"from": src_peer_id}).encode()
        out = (
            bytes([TAG_FORWARDED])
            + struct.pack(">H", len(wrap_header))
            + wrap_header
            + payload
        )
        try:
            self._sock.sendto(out, target_alloc.addr)
            self.forward_count += 1
        except OSError:
            pass

    def _send_reject(self, addr: tuple[str, int], reason: str) -> None:
        self.allocate_reject_count += 1
        body = json.dumps({"reason": reason}).encode()
        try:
            self._sock.sendto(bytes([TAG_ALLOCATE_REJECT]) + body, addr)
        except OSError:
            pass

    def close(self) -> None:
        self._running.clear()
        try:
            self._sock.close()
        except Exception:
            pass
        self._thread.join(timeout=1.0)

    def __enter__(self) -> "RelayServer":
        return self

    def __exit__(self, *exc) -> None:
        self.close()


# -------- client helpers --------


def build_allocate_request(peer_id: str, token: RelayToken) -> bytes:
    body = json.dumps({"peer_id": peer_id, "token": token.to_json()}).encode()
    return bytes([TAG_ALLOCATE]) + body


def build_forward_request(target_peer_id: str, payload: bytes) -> bytes:
    header = json.dumps({"target": target_peer_id}).encode()
    return bytes([TAG_FORWARD]) + header + b"\x00" + payload


def parse_response(data: bytes) -> tuple[int, bytes]:
    """Return (tag, body_bytes). For FORWARDED, body_bytes is
    `header_len(2) || header || payload`."""
    if not data:
        raise ValueError("empty")
    return data[0], data[1:]


def parse_forwarded(body: bytes) -> tuple[str, bytes]:
    """Return (from_peer_id, payload)."""
    if len(body) < 2:
        raise ValueError("forwarded too short")
    (hlen,) = struct.unpack(">H", body[:2])
    header = json.loads(body[2:2 + hlen].decode("utf-8"))
    return header["from"], body[2 + hlen:]
