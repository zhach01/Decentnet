from __future__ import annotations

"""VPN / overlay endpoint discovery helpers."""

from dataclasses import dataclass
import ipaddress
import os
import re
import subprocess
from typing import Iterable, Mapping, Optional

from .records.endpoints import Endpoint


@dataclass(frozen=True)
class VPNInterface:
    name: str
    address: str
    family: str
    kind: str


_KIND_TO_ENDPOINT = {
    "tailscale": "tailscale_udp",
    "wireguard": "wireguard_udp",
    "vpn": "vpn_udp",
}

_ENV_TO_KIND = {
    "TAILSCALE_IP": "tailscale",
    "TAILSCALE_IPV6": "tailscale",
    "WIREGUARD_IP": "wireguard",
    "WIREGUARD_IPV6": "wireguard",
    "NETBIRD_IP": "vpn",
    "NETBIRD_IPV6": "vpn",
    "ZEROTIER_IP": "vpn",
    "ZEROTIER_IPV6": "vpn",
}


def _normalize_ip(value: str) -> Optional[str]:
    value = (value or "").strip()
    if not value:
        return None
    if value.startswith("[") and value.endswith("]"):
        value = value[1:-1]
    try:
        ip = ipaddress.ip_address(value)
    except ValueError:
        return None
    if ip.is_loopback or ip.is_link_local or ip.is_unspecified:
        return None
    return str(ip)


def _kind_from_ifname(name: str) -> Optional[str]:
    n = (name or "").lower()
    if not n:
        return None
    if "tailscale" in n or n.startswith("ts"):
        return "tailscale"
    if "wireguard" in n or n.startswith("wg"):
        return "wireguard"
    generic_prefixes = ("tun", "tap", "utun", "zt", "nb", "vpn")
    if any(n.startswith(p) for p in generic_prefixes) or "zerotier" in n or "netbird" in n:
        return "vpn"
    return None


def list_interface_output(*, command_runner=None) -> str:
    runner = command_runner or subprocess.run
    proc = runner(["ip", "-o", "addr", "show", "up"], capture_output=True, text=True, check=False)
    return proc.stdout or ""


_IP_LINE_RE = re.compile(r"^\d+:\s+([^\s]+)\s+([^\s]+)\s+([^\s/]+)/(\d+).*$")


def parse_vpn_interfaces(ip_output: str) -> list[VPNInterface]:
    out = []
    seen = set()
    for raw in (ip_output or "").splitlines():
        m = _IP_LINE_RE.match(raw.strip())
        if not m:
            continue
        ifname, fam, addr, _prefix = m.groups()
        if fam not in {"inet", "inet6"}:
            continue
        kind = _kind_from_ifname(ifname)
        if kind is None:
            continue
        ip = _normalize_ip(addr)
        if ip is None:
            continue
        key = (ifname, ip, kind)
        if key in seen:
            continue
        seen.add(key)
        out.append(VPNInterface(name=ifname, address=ip, family=fam, kind=kind))
    return out


def detect_vpn_interfaces(*, env: Optional[Mapping[str, str]] = None, ip_output: Optional[str] = None, command_runner=None) -> list[VPNInterface]:
    env_map = dict(os.environ if env is None else env)
    out = []
    seen = set()
    for env_key, kind in _ENV_TO_KIND.items():
        ip = _normalize_ip(env_map.get(env_key, ""))
        if ip is None:
            continue
        fam = "inet6" if ":" in ip else "inet"
        item = VPNInterface(name=env_key.lower(), address=ip, family=fam, kind=kind)
        key = (item.name, item.address, item.kind)
        if key not in seen:
            seen.add(key)
            out.append(item)
    text = ip_output if ip_output is not None else list_interface_output(command_runner=command_runner)
    for item in parse_vpn_interfaces(text):
        key = (item.name, item.address, item.kind)
        if key not in seen:
            seen.add(key)
            out.append(item)
    return out


_DEF_PRI = {"tailscale": 120, "wireguard": 110, "vpn": 100}


def _endpoint_kind(kind: str) -> str:
    return _KIND_TO_ENDPOINT.get(kind, "vpn_udp")


def _make_address(ip: str, port: int) -> str:
    if ":" in ip and not ip.startswith("["):
        return f"[{ip}]:{port}"
    return f"{ip}:{port}"


def _parse_explicit_endpoint(spec: str, *, default_port: int) -> Optional[Endpoint]:
    spec = (spec or "").strip()
    if not spec or "://" in spec or "," in spec:
        return None
    known = {"vpn_udp", "tailscale_udp", "wireguard_udp"}
    if ":" in spec and spec.split(":", 1)[0] in known:
        typ, addr = spec.split(":", 1)
    else:
        typ, addr = "vpn_udp", spec
    addr = addr.strip()
    if (addr.startswith("[") and "]:" in addr) or (addr.count(":") == 1 and addr.rpartition(":")[2].isdigit()):
        final_addr = addr
    else:
        ip = _normalize_ip(addr)
        if ip is None:
            return None
        final_addr = _make_address(ip, default_port)
    return Endpoint(type=typ, address=final_addr, discovered_by="env", confidence=0.95, priority=130)


def detect_vpn_endpoints(port: int, *, env: Optional[Mapping[str, str]] = None, ip_output: Optional[str] = None, command_runner=None) -> list[Endpoint]:
    env_map = dict(os.environ if env is None else env)
    out = []
    seen = set()
    explicit = env_map.get("DECENTNET_VPN_ENDPOINTS") or env_map.get("DECENTNET_VPN_ENDPOINT")
    if explicit:
        for part in re.split(r"[;,]", explicit):
            ep = _parse_explicit_endpoint(part, default_port=port)
            if ep is None:
                continue
            key = (ep.type, ep.address)
            if key not in seen:
                seen.add(key)
                out.append(ep)
    for iface in detect_vpn_interfaces(env=env_map, ip_output=ip_output, command_runner=command_runner):
        ep = Endpoint(type=_endpoint_kind(iface.kind), address=_make_address(iface.address, port), discovered_by=iface.name, confidence=0.95, priority=_DEF_PRI.get(iface.kind, 100))
        key = (ep.type, ep.address)
        if key not in seen:
            seen.add(key)
            out.append(ep)
    return out


def prefer_vpn_endpoint(endpoints: Iterable[Endpoint]):
    best = None
    for ep in endpoints:
        if ep.type not in {"tailscale_udp", "wireguard_udp", "vpn_udp"}:
            continue
        if best is None or (ep.priority, ep.confidence) > (best.priority, best.confidence):
            best = ep
    return best
