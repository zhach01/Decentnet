"""decentnet — a decentralized peer-resolution and direct-connect framework.

Phase 1 provides:
    * cryptographic identity (Ed25519)
    * signed locator records
    * a persistent local cache
    * a Node facade that ties the three together
    * a CLI entry point

Later phases add: a distributed directory, direct signaling, STUN/ICE,
and mobile/Kivy hooks. See docs/ARCHITECTURE.md and docs/PROTOCOL.md.
"""

__version__ = "0.2.0"
PROTOCOL_VERSION = 1
APP_MAGIC = "decentnet"
