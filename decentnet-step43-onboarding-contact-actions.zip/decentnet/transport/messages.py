"""Wire messages for the Phase 2 control plane.

Messages are plain Python dataclasses in memory; on the wire they are
canonical JSON. In Phase 2 only the in-process transport is live, so
we do not hit JSON on the hot path — but the serialization is defined
here so Phase 4's UDP transport and Phase 3's simulator can use it
without changes.

Records inside messages (STORE, RECORD_PUSH, VALUE) are always
canonical wire bytes — the same format `LocatorRecord.to_wire_bytes()`
emits — so a receiver validates them with the same code path used for
CLI `import`.
"""
from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Optional

from ..utils.time import now_s


class MsgType(str, Enum):
    # Liveness
    PING = "ping"
    PONG = "pong"
    # Routing
    FIND_NODE = "find_node"
    NODE_LIST = "node_list"
    # Storage
    STORE = "store"
    STORE_OK = "store_ok"
    STORE_REJECT = "store_reject"
    # Retrieval
    FIND_VALUE = "find_value"
    VALUE = "value"
    VALUE_MISS = "value_miss"
    # Anti-entropy
    DIGEST_REQUEST = "digest_request"
    DIGEST_RESPONSE = "digest_response"
    RECORD_PUSH = "record_push"
    RECORD_PUSH_ACK = "record_push_ack"


# Types whose payload is expected to include a "record" (wire bytes).
RECORD_CARRYING = {MsgType.STORE, MsgType.VALUE, MsgType.RECORD_PUSH}


@dataclass
class Message:
    type: str
    sender: str                                 # PeerID (base32)
    msg_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    in_reply_to: Optional[str] = None
    sent_at: int = field(default_factory=now_s)
    payload: dict[str, Any] = field(default_factory=dict)

    # ------------- helpers -------------

    @classmethod
    def make(
        cls,
        type_: MsgType | str,
        sender: str,
        payload: Optional[dict[str, Any]] = None,
        in_reply_to: Optional[str] = None,
    ) -> "Message":
        return cls(
            type=type_.value if isinstance(type_, MsgType) else type_,
            sender=sender,
            payload=dict(payload or {}),
            in_reply_to=in_reply_to,
        )

    def reply(
        self,
        type_: MsgType | str,
        sender: str,
        payload: Optional[dict[str, Any]] = None,
    ) -> "Message":
        return Message.make(
            type_=type_, sender=sender, payload=payload, in_reply_to=self.msg_id
        )

    # ------------- serialization -------------

    def to_wire_bytes(self) -> bytes:
        return json.dumps(asdict(self), sort_keys=True, ensure_ascii=False).encode("utf-8")

    @classmethod
    def from_wire_bytes(cls, data: bytes) -> "Message":
        d = json.loads(data.decode("utf-8"))
        return cls(**d)


class TransportError(Exception):
    """Base class for transport-layer errors."""


class UnreachableError(TransportError):
    """Destination peer is not reachable via this transport."""


class TransportTimeoutError(TransportError):
    """Request-reply RPC timed out."""
