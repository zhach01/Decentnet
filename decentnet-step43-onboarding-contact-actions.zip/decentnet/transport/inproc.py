"""In-process transport: synchronous message bus routing by peer_id.

Used by the Phase 2 tests and the Phase 3 simulator. It delivers every
`send()` call synchronously to the destination's receive handler.
That makes `send_and_wait` trivial: the reply has already landed by
the time the send stack unwinds.

This is deterministic and easy to reason about. It intentionally has
no timers, no async, and no threads. The simulator (Phase 3) layers
virtual delay and packet loss on top without changing the transport's
public surface.

Churn modelling
---------------
`InProcessNetwork.set_offline(peer_id)` makes future sends to that peer
raise `UnreachableError`. `set_online(peer_id)` restores delivery.
The node itself may still be "alive" in the process (its state is
preserved) — the model is "the network between us is partitioned".
Partitions of multiple peers are modelled by making a whole set
mutually unreachable via `partition({A, B, C}, {D, E, F})`.
"""
from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Optional

from .base import ReceiveHandler
from .messages import (
    Message,
    MsgType,
    TransportError,
    TransportTimeoutError,
    UnreachableError,
)


# --------------------------------------------------------------------


class InProcessNetwork:
    """Shared router. Transports register themselves here."""

    def __init__(self) -> None:
        self._nodes: dict[str, "InProcessTransport"] = {}
        self._offline: set[str] = set()
        # Partition model: each peer belongs to a partition group.
        # Peers in different non-zero groups cannot reach each other.
        # Group 0 is "unrestricted" (the default — everyone can reach
        # everyone not explicitly partitioned).
        self._partition: dict[str, int] = {}
        self._lock = threading.RLock()
        self._dropped_count = 0

    # ---- registration ----

    def register(self, transport: "InProcessTransport") -> None:
        with self._lock:
            self._nodes[transport.local_peer_id] = transport

    def unregister(self, peer_id: str) -> None:
        with self._lock:
            self._nodes.pop(peer_id, None)
            self._partition.pop(peer_id, None)

    # ---- churn / partition model ----

    def set_offline(self, peer_id: str) -> None:
        with self._lock:
            self._offline.add(peer_id)

    def set_online(self, peer_id: str) -> None:
        with self._lock:
            self._offline.discard(peer_id)

    def partition(self, *groups: set[str]) -> None:
        """Assign peers to numbered partitions. Peers in different
        groups cannot reach each other. Peers not listed remain in
        group 0 and can still reach group-0 peers and peers in
        non-zero groups (the "universal" side).
        """
        with self._lock:
            self._partition = {}
            for idx, group in enumerate(groups, start=1):
                for pid in group:
                    self._partition[pid] = idx

    def heal_partition(self) -> None:
        with self._lock:
            self._partition.clear()

    def _reachable(self, src: str, dst: str) -> bool:
        if dst in self._offline:
            return False
        if dst not in self._nodes:
            return False
        g_src = self._partition.get(src, 0)
        g_dst = self._partition.get(dst, 0)
        if g_src == 0 or g_dst == 0:
            return True
        return g_src == g_dst

    # ---- routing ----

    def deliver(self, from_peer: str, to_peer: str, msg: Message) -> None:
        with self._lock:
            if not self._reachable(from_peer, to_peer):
                self._dropped_count += 1
                raise UnreachableError(
                    f"{from_peer[:8]}.. → {to_peer[:8]}.. unreachable"
                )
            dst = self._nodes[to_peer]
        # Deliver outside the lock to avoid re-entrancy with handlers
        # that call back into send().
        dst.deliver(from_peer, msg)

    @property
    def dropped_count(self) -> int:
        return self._dropped_count

    @property
    def known_peers(self) -> list[str]:
        with self._lock:
            return sorted(self._nodes.keys())


# --------------------------------------------------------------------


@dataclass
class _PendingReply:
    result: Optional[Message] = None
    ready: bool = False


class InProcessTransport:
    """A per-node transport bound to an `InProcessNetwork`."""

    def __init__(
        self,
        network: InProcessNetwork,
        local_peer_id: str,
    ) -> None:
        self._network = network
        self._local_peer_id = local_peer_id
        self._handler: Optional[ReceiveHandler] = None
        self._pending: dict[str, _PendingReply] = {}
        self._lock = threading.RLock()
        network.register(self)

    @property
    def local_peer_id(self) -> str:
        return self._local_peer_id

    def set_receive_handler(self, handler: ReceiveHandler) -> None:
        self._handler = handler

    # ---- send ----

    def send(self, to_peer_id: str, msg: Message) -> None:
        self._network.deliver(self._local_peer_id, to_peer_id, msg)

    def send_and_wait(
        self,
        to_peer_id: str,
        msg: Message,
        *,
        timeout_s: float = 5.0,  # unused in sync mode; kept for API parity
    ) -> Message:
        pending = _PendingReply()
        with self._lock:
            self._pending[msg.msg_id] = pending
        try:
            try:
                self._network.deliver(self._local_peer_id, to_peer_id, msg)
            except UnreachableError:
                raise  # cleanup in finally
            # With synchronous delivery, the response — if one is
            # coming — has already landed in pending.
            if pending.ready:
                assert pending.result is not None
                return pending.result
            raise TransportTimeoutError(
                f"no reply from {to_peer_id[:8]}.. to msg_id={msg.msg_id}"
            )
        finally:
            with self._lock:
                self._pending.pop(msg.msg_id, None)

    # ---- receive ----

    def deliver(self, from_peer: str, msg: Message) -> None:
        """Called by the network router when a message arrives."""
        if msg.in_reply_to is not None:
            with self._lock:
                pending = self._pending.pop(msg.in_reply_to, None)
            if pending is not None:
                pending.result = msg
                pending.ready = True
                # Re-register under msg_id so a caller still waiting
                # (in nested scenarios) can find it. Simplest: do
                # nothing else — the waiter checks `ready`.
                return
            # Otherwise fall through: the reply arrived late or the
            # waiter gave up; treat as an unsolicited message.
        if self._handler is not None:
            self._handler(from_peer, msg)

    def close(self) -> None:
        self._network.unregister(self._local_peer_id)
