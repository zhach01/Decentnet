"""Real UDP transport over the OS socket layer.

Implements the same `Transport` interface as `InProcessTransport`,
so `DHTEngine` and signaling code work unchanged over either.

Design
------
* A single dedicated reader thread blocks on `recvfrom` and dispatches
  every incoming datagram to either the pending-reply table (for
  request/reply RPCs) or the registered receive handler.
* Sends are synchronous best-effort: `send()` just `sendto`s and
  returns.
* `send_and_wait()` registers a `_PendingReply` keyed by `msg_id`,
  does the `sendto`, and blocks on the reply's `threading.Event`
  until `timeout_s`.
* The transport opportunistically learns the `(host, port)` of any
  peer it receives a message from. That way, peers behind NATs
  advertise their externally-observed mapping naturally: the first
  DHT PING they send to a well-known seed establishes the return path.

Multi-protocol routing (Phase 5)
--------------------------------
The transport also accepts raw datagrams that are *not* decentnet
JSON messages. In particular, STUN responses (RFC 5389) share the
same socket so the mapping learned is the one other peers will
actually hit.

Incoming dispatch precedence:
    1. If the datagram is a STUN message (magic-cookie check) and
       a STUN handler is registered -> STUN handler.
    2. If the datagram matches a pending raw waiter -> wake it.
    3. If the datagram is a relay-forwarded packet -> unwrap and
       deliver the embedded decentnet `Message`.
    4. Otherwise try to JSON-decode as a `Message`.
         a. If it's a reply correlated to a pending send_and_wait,
            wake that waiter.
         b. Otherwise hand to the generic receive handler (the
            signaling/DHT router).

`send_raw(data, addr)` emits a datagram verbatim — used to send
STUN Binding Requests on this socket and relay control packets.
"""
from __future__ import annotations

import json
import socket
import threading
from dataclasses import dataclass, field
from typing import Callable, Optional

from ..nat import stun as _stun
from ..relay import TAG_ALLOCATE_OK, TAG_ALLOCATE_REJECT, TAG_FORWARDED, parse_forwarded
from .base import ReceiveHandler
from .messages import (
    Message,
    TransportError,
    TransportTimeoutError,
    UnreachableError,
)

MAX_DATAGRAM_BYTES = 60_000
RECV_BUF_BYTES = 65_536
READ_LOOP_TIMEOUT_S = 0.25

STUNHandler = Callable[[bytes, tuple[str, int]], None]
"""`(datagram, from_addr) -> None` — called for every STUN packet."""

RawMatcher = Callable[[bytes, tuple[str, int]], bool]


@dataclass
class _PendingReply:
    event: threading.Event = field(default_factory=threading.Event)
    result: Optional[Message] = None


@dataclass
class _PendingRaw:
    matcher: RawMatcher
    event: threading.Event = field(default_factory=threading.Event)
    result: Optional[tuple[bytes, tuple[str, int]]] = None


class UDPTransport:
    def __init__(
        self,
        local_peer_id: str,
        *,
        bind_host: str = "127.0.0.1",
        bind_port: int = 0,
    ) -> None:
        self._local_peer_id = local_peer_id
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.bind((bind_host, bind_port))
        self._bind_host, self._bind_port = self._sock.getsockname()
        self._peer_endpoints: dict[str, tuple[str, int]] = {}
        self._endpoints_lock = threading.Lock()
        self._handler: Optional[ReceiveHandler] = None
        self._stun_handler: Optional[STUNHandler] = None
        self._pending: dict[str, _PendingReply] = {}
        self._pending_lock = threading.Lock()
        self._raw_pending: list[_PendingRaw] = []
        self._raw_pending_lock = threading.Lock()
        self._running = threading.Event()
        self._running.set()
        self._reader = threading.Thread(
            target=self._read_loop,
            name=f"udp-reader-{local_peer_id[:8]}",
            daemon=True,
        )
        self._reader.start()

    @property
    def local_peer_id(self) -> str:
        return self._local_peer_id

    @property
    def bind_host(self) -> str:
        return self._bind_host

    @property
    def bind_port(self) -> int:
        return self._bind_port

    def endpoint_string(self) -> str:
        return f"udp:{self._bind_host}:{self._bind_port}"

    def set_receive_handler(self, handler: ReceiveHandler) -> None:
        self._handler = handler

    def set_stun_handler(self, handler: STUNHandler) -> None:
        self._stun_handler = handler

    def register_endpoint(self, peer_id: str, host: str, port: int) -> None:
        with self._endpoints_lock:
            self._peer_endpoints[peer_id] = (host, int(port))

    def lookup_endpoint(self, peer_id: str) -> Optional[tuple[str, int]]:
        with self._endpoints_lock:
            return self._peer_endpoints.get(peer_id)

    def send(self, to_peer_id: str, msg: Message) -> None:
        with self._endpoints_lock:
            addr = self._peer_endpoints.get(to_peer_id)
        if addr is None:
            raise UnreachableError(f"no endpoint for {to_peer_id[:8]}..")
        data = msg.to_wire_bytes()
        if len(data) > MAX_DATAGRAM_BYTES:
            raise TransportError(
                f"datagram too large: {len(data)} > {MAX_DATAGRAM_BYTES}"
            )
        try:
            self._sock.sendto(data, addr)
        except OSError as e:
            raise UnreachableError(str(e)) from e

    def send_raw(self, data: bytes, addr: tuple[str, int]) -> None:
        if len(data) > MAX_DATAGRAM_BYTES:
            raise TransportError(f"datagram too large: {len(data)}")
        try:
            self._sock.sendto(data, addr)
        except OSError as e:
            raise UnreachableError(str(e)) from e

    def send_raw_and_wait(
        self,
        data: bytes,
        addr: tuple[str, int],
        *,
        matcher: RawMatcher,
        timeout_s: float = 5.0,
    ) -> tuple[bytes, tuple[str, int]]:
        pending = _PendingRaw(matcher=matcher)
        with self._raw_pending_lock:
            self._raw_pending.append(pending)
        try:
            self.send_raw(data, addr)
            if not pending.event.wait(timeout_s):
                raise TransportTimeoutError("no matching raw reply")
            assert pending.result is not None
            return pending.result
        finally:
            with self._raw_pending_lock:
                if pending in self._raw_pending:
                    self._raw_pending.remove(pending)

    def send_and_wait(
        self,
        to_peer_id: str,
        msg: Message,
        *,
        timeout_s: float = 5.0,
    ) -> Message:
        pending = _PendingReply()
        with self._pending_lock:
            self._pending[msg.msg_id] = pending
        try:
            self.send(to_peer_id, msg)
            if not pending.event.wait(timeout_s):
                raise TransportTimeoutError(
                    f"no reply from {to_peer_id[:8]}.. to {msg.msg_id}"
                )
            assert pending.result is not None
            return pending.result
        finally:
            with self._pending_lock:
                self._pending.pop(msg.msg_id, None)

    def close(self) -> None:
        self._running.clear()
        try:
            self._sock.close()
        except Exception:
            pass
        self._reader.join(timeout=2.0)

    def _wake_raw_waiter(self, data: bytes, addr: tuple[str, int]) -> bool:
        with self._raw_pending_lock:
            waiters = list(self._raw_pending)
        for pending in waiters:
            try:
                matched = pending.matcher(data, addr)
            except Exception:
                matched = False
            if not matched:
                continue
            pending.result = (data, addr)
            pending.event.set()
            with self._raw_pending_lock:
                if pending in self._raw_pending:
                    self._raw_pending.remove(pending)
            return True
        return False

    def _deliver_message(
        self,
        msg: Message,
        addr: tuple[str, int],
        *,
        learned_sender: Optional[str] = None,
        learn_endpoint: bool = True,
    ) -> None:
        sender = learned_sender if learned_sender is not None else msg.sender
        if learn_endpoint and isinstance(sender, str) and sender:
            with self._endpoints_lock:
                self._peer_endpoints[sender] = addr

        if msg.in_reply_to is not None:
            with self._pending_lock:
                pending = self._pending.pop(msg.in_reply_to, None)
            if pending is not None:
                pending.result = msg
                pending.event.set()
                return

        if self._handler is not None:
            try:
                self._handler(sender, msg)
            except Exception:
                return

    def _read_loop(self) -> None:
        self._sock.settimeout(READ_LOOP_TIMEOUT_S)
        while self._running.is_set():
            try:
                data, addr = self._sock.recvfrom(RECV_BUF_BYTES)
            except socket.timeout:
                continue
            except OSError:
                break

            if _stun.is_stun_packet(data):
                if self._stun_handler is not None:
                    try:
                        self._stun_handler(data, addr)
                    except Exception:
                        pass
                continue

            if self._wake_raw_waiter(data, addr):
                continue

            if data and data[0] == TAG_FORWARDED:
                try:
                    from_peer, payload = parse_forwarded(data[1:])
                    msg = Message.from_wire_bytes(payload)
                except Exception:
                    continue
                self._deliver_message(msg, addr, learned_sender=from_peer, learn_endpoint=False)
                continue

            if data and data[0] in (TAG_ALLOCATE_OK, TAG_ALLOCATE_REJECT):
                # Unmatched relay responses are ignored.
                continue

            try:
                msg = Message.from_wire_bytes(data)
            except (json.JSONDecodeError, KeyError, TypeError, UnicodeDecodeError):
                continue

            self._deliver_message(msg, addr)
