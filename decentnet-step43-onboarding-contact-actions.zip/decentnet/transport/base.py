"""Transport abstraction.

Any transport (in-process for Phase 2, UDP for Phase 4+) implements
this interface. The DHT and repair layers talk to transports, never
directly to sockets.

Receive model
-------------
The transport pushes messages to a handler registered via
`set_receive_handler`. Synchronous request/reply is exposed via
`send_and_wait` for RPC-style calls (FIND_NODE → NODE_LIST). The
in-process transport delivers synchronously so `send_and_wait` returns
once the responder has replied, which keeps tests deterministic.

Real network transports will need actual async plumbing underneath
but can keep this surface.
"""
from __future__ import annotations

from typing import Callable, Optional, Protocol

from .messages import Message


ReceiveHandler = Callable[[str, Message], None]
"""`(from_peer_id, message) -> None`."""


class Transport(Protocol):
    @property
    def local_peer_id(self) -> str: ...

    def set_receive_handler(self, handler: ReceiveHandler) -> None: ...

    def send(self, to_peer_id: str, msg: Message) -> None:
        """Fire-and-forget delivery. May raise UnreachableError."""
        ...

    def send_and_wait(
        self,
        to_peer_id: str,
        msg: Message,
        *,
        timeout_s: float = 5.0,
    ) -> Message:
        """Request/reply. Raises TransportTimeoutError on timeout."""
        ...

    def close(self) -> None: ...
