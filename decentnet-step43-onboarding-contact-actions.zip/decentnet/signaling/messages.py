"""Signaling message types.

Each message type is a string with a ``sig.`` prefix so the DHT engine
can ignore them (it only claims ``ping``, ``find_node``, ``store``,
``find_value``, and friends) and the signaling engine can claim them
back.

Every signaling message carries:

    type        one of SignalType values
    sender      peer_id (base32)
    target      peer_id (base32) — who this message is for
    msg_id      uuid hex (for request/reply correlation)
    in_reply_to optional msg_id this answers
    nonce       fresh 128-bit random, hex-encoded
    issued_at   UNIX seconds
    app_magic   constant ``decentnet`` to reject cross-protocol replays
    sig_version protocol version for the signaling layer
    payload     application/type-specific fields
    signature   Ed25519 over the canonical JSON of everything above

On receive a validator:
    1. Decodes
    2. Checks ``app_magic`` and ``sig_version``
    3. Checks ``target == self``
    4. Checks ``issued_at`` is inside a skew window
    5. Looks up sender's public key (from the L1 cache — caller must
       have resolved them via DHT first)
    6. Verifies the signature
    7. Checks nonce / msg_id hasn't been seen before
    8. Dispatches

We reuse the existing transport `Message` class — signaling fields go
in ``payload`` — which keeps the UDP transport unaware of signaling
semantics and lets a single receive handler route by ``msg.type``.
"""
from __future__ import annotations

import os
import uuid
from enum import Enum
from typing import Optional

from .. import APP_MAGIC
from ..identity.keypair import Keypair, verify_with_public_key
from ..transport.messages import Message
from ..utils.encoding import b64u_decode, b64u_encode, canonical_json_bytes
from ..utils.time import now_s


SIG_PROTOCOL_VERSION = 1
NONCE_BYTES = 16


class SignalType(str, Enum):
    HELLO = "sig.hello"
    HELLO_ACK = "sig.hello_ack"
    RING = "sig.ring"
    RING_ACK = "sig.ring_ack"
    BYE = "sig.bye"
    KEEPALIVE = "sig.keepalive"
    # Pass-through types: the signaling engine verifies signatures and
    # replay protection but does not interpret the payload. An
    # application built on top (e.g., a WebRTC client) decides what the
    # bytes in these mean.
    OFFER = "sig.offer"
    ANSWER = "sig.answer"
    CANDIDATE = "sig.candidate"
    CHAT_CONTROL = "sig.chat_control"
    # Phase 6: ICE connectivity checks ride the signaling envelope.
    CONN_CHECK = "sig.conn_check"
    CONN_CHECK_ACK = "sig.conn_check_ack"
    # Hole-punch synchronization pulse — a request for the peer to
    # emit an outbound packet toward our address at approximately
    # the same time we emit one toward theirs.
    PUNCH = "sig.punch"
    PUNCH_ACK = "sig.punch_ack"


SIG_TYPES: set[str] = {t.value for t in SignalType}


def is_signaling_message(msg: Message) -> bool:
    return msg.type in SIG_TYPES


# --------------------------------------------------------------------
# Build / verify helpers


def make_nonce() -> str:
    return os.urandom(NONCE_BYTES).hex()


def _signing_input_dict(msg: Message) -> dict:
    """The dict signed by the sender. We include every envelope field
    except the signature itself."""
    return {
        "type": msg.type,
        "sender": msg.sender,
        "msg_id": msg.msg_id,
        "in_reply_to": msg.in_reply_to,
        "sent_at": msg.sent_at,
        "payload": {
            "app_magic": msg.payload.get("app_magic"),
            "sig_version": msg.payload.get("sig_version"),
            "target": msg.payload.get("target"),
            "nonce": msg.payload.get("nonce"),
            "issued_at": msg.payload.get("issued_at"),
            "body": msg.payload.get("body", {}),
        },
    }


def build_and_sign(
    keypair: Keypair,
    sig_type: SignalType,
    *,
    sender: str,
    target: str,
    body: Optional[dict] = None,
    in_reply_to: Optional[str] = None,
) -> Message:
    msg_id = uuid.uuid4().hex
    payload = {
        "app_magic": APP_MAGIC,
        "sig_version": SIG_PROTOCOL_VERSION,
        "target": target,
        "nonce": make_nonce(),
        "issued_at": now_s(),
        "body": dict(body or {}),
    }
    msg = Message(
        type=sig_type.value,
        sender=sender,
        msg_id=msg_id,
        in_reply_to=in_reply_to,
        payload=payload,
    )
    sig = keypair.sign(canonical_json_bytes(_signing_input_dict(msg)))
    msg.payload["signature"] = b64u_encode(sig)
    return msg


def verify_envelope(
    msg: Message,
    sender_public_key: bytes,
    *,
    self_peer_id: str,
    max_future_skew_s: int = 120,
    max_past_skew_s: int = 300,
) -> tuple[bool, Optional[str]]:
    """Return (ok, reason). Reason is None on success."""
    if msg.type not in SIG_TYPES:
        return False, "not a signaling message"
    p = msg.payload
    if not isinstance(p, dict):
        return False, "malformed payload"
    if p.get("app_magic") != APP_MAGIC:
        return False, "app_magic mismatch"
    if p.get("sig_version") != SIG_PROTOCOL_VERSION:
        return False, f"unsupported sig_version {p.get('sig_version')}"
    if p.get("target") != self_peer_id:
        return False, "not addressed to me"
    issued = p.get("issued_at")
    if not isinstance(issued, int):
        return False, "missing issued_at"
    t = now_s()
    if issued > t + max_future_skew_s:
        return False, "issued_in_future"
    if issued < t - max_past_skew_s:
        return False, "issued_too_long_ago"
    nonce = p.get("nonce")
    if not isinstance(nonce, str) or not nonce:
        return False, "missing nonce"
    sig_b64 = p.get("signature")
    if not isinstance(sig_b64, str):
        return False, "missing signature"
    try:
        sig = b64u_decode(sig_b64)
    except Exception:
        return False, "malformed signature"
    # Rebuild the signing input (exclude the signature field).
    check_msg = Message(
        type=msg.type,
        sender=msg.sender,
        msg_id=msg.msg_id,
        in_reply_to=msg.in_reply_to,
        sent_at=msg.sent_at,
        payload={
            k: v for k, v in p.items() if k != "signature"
        },
    )
    if not verify_with_public_key(
        sender_public_key,
        canonical_json_bytes(_signing_input_dict(check_msg)),
        sig,
    ):
        return False, "signature verification failed"
    return True, None
