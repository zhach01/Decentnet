"""SignalingEngine — the direct peer-to-peer signaling layer.

Responsibilities
----------------
* Register as a receive handler on the transport; process every
  message whose type starts with ``sig.``.
* Verify every incoming signaling message (app_magic, sig_version,
  target, issued_at, signature, replay check).
* Maintain per-peer `Session` state (FRESH → HANDSHAKING →
  ESTABLISHED → RINGING → IN_CALL → CLOSED).
* Maintain a negative cache of repeated signaling failures.
* Provide client-side methods for initiating handshakes, ring
  attempts, and pass-through messages (offer / answer / candidate).

Lookup of peer public keys
--------------------------
On receive we need the sender's public key to verify the signature.
We require the caller has already resolved the peer (so its
`LocatorRecord` — including `public_key` — is in L1). If we receive
a signaling message from a peer we've never resolved, we reject it
and log. A future enhancement: trigger an inline DHT resolve; for
Phase 4 the pattern is "resolve first, then signal".
"""
from __future__ import annotations

import json
import threading
from collections import Counter, deque
from dataclasses import dataclass, field
from typing import Callable, Optional

from ..audit.log import AuditLog
from ..cache.local import LocalCache
from ..records.locator import LocatorRecord
from ..utils.encoding import b64u_decode, b64u_encode
from ..relay import (
    RelayToken,
    TAG_ALLOCATE_OK,
    TAG_ALLOCATE_REJECT,
    build_allocate_request,
    build_forward_request,
    parse_response,
)
from ..transport.base import Transport
from ..transport.messages import (
    Message,
    TransportError,
    TransportTimeoutError,
    UnreachableError,
)
from ..utils.time import now_s
from .messages import (
    SignalType,
    SIG_TYPES,
    build_and_sign,
    is_signaling_message,
    verify_envelope,
)
from .session import NegativeCache, Session, SessionState


IdleTimeoutS = 600   # 10 minutes without traffic → mark session closed
PathFailureRestartThreshold = 2


RelayAllocateBudgetLimit = 4
RelayAllocateBudgetWindowS = 60
RelaySendBudgetLimit = 40
RelaySendBudgetWindowS = 30
SignalSendBudgetLimit = 80
SignalSendBudgetWindowS = 30
IceRestartBudgetLimit = 4
IceRestartBudgetWindowS = 60


class _WindowBudget:
    def __init__(self, *, limit: int, window_s: int) -> None:
        self.limit = int(limit)
        self.window_s = int(window_s)
        self._events: deque[int] = deque()
        self._lock = threading.Lock()

    def _prune_locked(self, now: int) -> None:
        cutoff = now - self.window_s
        while self._events and self._events[0] <= cutoff:
            self._events.popleft()

    def allow(self, *, at: Optional[int] = None) -> tuple[bool, int]:
        now = now_s() if at is None else int(at)
        with self._lock:
            self._prune_locked(now)
            used = len(self._events)
            if used >= self.limit:
                return False, max(0, self.limit - used)
            self._events.append(now)
            return True, max(0, self.limit - len(self._events))

    def remaining(self, *, at: Optional[int] = None) -> int:
        now = now_s() if at is None else int(at)
        with self._lock:
            self._prune_locked(now)
            return max(0, self.limit - len(self._events))

    def stats(self, *, at: Optional[int] = None) -> dict:
        now = now_s() if at is None else int(at)
        with self._lock:
            self._prune_locked(now)
            return {"limit": self.limit, "window_s": self.window_s, "used": len(self._events), "remaining": max(0, self.limit - len(self._events))}


RingCallback = Callable[[str, dict], bool]
"""`(from_peer_id, ring_body) → accept?`. Return True to auto-ACK."""


@dataclass
class SignalResult:
    ok: bool
    reason: Optional[str] = None
    session_state: Optional[str] = None


# --------------------------------------------------------------------


@dataclass
class _SignalReplyWaiter:
    peer_id: str
    expected_type: str
    event: threading.Event = field(default_factory=threading.Event)
    result: Optional[Message] = None


@dataclass
class _RelayAllocationState:
    relay_addr: tuple[str, int]
    expires_at: int
    token_fingerprint: str
    assumed: bool = False

    def is_valid(self, *, at: Optional[int] = None, min_remaining_s: int = 3) -> bool:
        now = now_s() if at is None else at
        return self.expires_at > now + min_remaining_s


class SignalingEngine:
    def __init__(
        self,
        *,
        local_peer_id: str,
        keypair,                 # Keypair
        transport: Transport,
        local_cache: LocalCache,
        audit: AuditLog,
    ) -> None:
        self._self = local_peer_id
        self._kp = keypair
        self._tx = transport
        self._cache = local_cache
        self._audit = audit
        self._sessions: dict[str, Session] = {}
        self._sessions_lock = threading.RLock()
        self._negcache = NegativeCache()
        self._ring_cb: Optional[RingCallback] = None
        self._inbox_lock = threading.Lock()
        self._pass_through_inbox: list[tuple[str, Message]] = []
        self._ice_lock = threading.RLock()
        self._ice_agents: dict[str, object] = {}
        self._ice_threads: dict[str, threading.Thread] = {}
        self._ice_restart_pending: set[str] = set()
        self._reply_waiters_lock = threading.Lock()
        self._reply_waiters: list[_SignalReplyWaiter] = []
        self._relay_lock = threading.RLock()
        self._relay_allocations: dict[str, _RelayAllocationState] = {}
        self._signal_send_budget: dict[str, _WindowBudget] = {}
        self._relay_allocate_budget: dict[str, _WindowBudget] = {}
        self._relay_send_budget: dict[str, _WindowBudget] = {}
        self._ice_restart_budget: dict[str, _WindowBudget] = {}
        self._budget_lock = threading.RLock()
        self._metrics = Counter()
        self._metrics_lock = threading.Lock()

        # Wrap the transport's existing handler so DHT keeps working
        # and we claim only signaling messages.
        existing = getattr(transport, "_handler", None)

        def router(from_peer: str, msg: Message) -> None:
            if is_signaling_message(msg):
                self._handle_incoming(from_peer, msg)
                return
            if existing is not None:
                existing(from_peer, msg)

        transport.set_receive_handler(router)

    # ---- registration ----

    def on_ring(self, cb: RingCallback) -> None:
        """Register a callback invoked when a RING arrives. The
        callback returns True to auto-ACK, False to ignore (the peer
        will time out waiting for an ack)."""
        self._ring_cb = cb

    # ---- session lookup ----

    def session(self, peer_id: str) -> Optional[Session]:
        with self._sessions_lock:
            return self._sessions.get(peer_id)

    def trusted_peers(self) -> list[str]:
        with self._sessions_lock:
            return [pid for pid, s in self._sessions.items() if s.is_trusted()]

    def session_summaries(self) -> list[dict]:
        with self._sessions_lock:
            sessions = []
            for pid, s in self._sessions.items():
                sessions.append({
                    "peer_id": pid,
                    "state": str(getattr(s.state, "value", s.state)),
                    "trusted": bool(s.is_trusted()),
                    "established_at": s.established_at,
                    "last_seen": s.last_seen,
                    "selected_pair_kind": s.selected_pair_kind,
                    "selected_remote_addr": list(s.selected_remote_addr) if s.selected_remote_addr else None,
                    "selected_at": s.selected_at,
                    "selected_nominated": bool(s.selected_nominated),
                    "selected_path_ok_at": s.selected_path_ok_at,
                    "selected_path_degraded_at": s.selected_path_degraded_at,
                    "selected_path_failures": int(s.selected_path_failures),
                    "relay_addr": list(s.relay_addr) if s.relay_addr else None,
                    "relay_last_used_at": s.relay_last_used_at,
                })
            sessions.sort(key=lambda item: (not item["trusted"], -(item.get("last_seen") or 0), item["peer_id"]))
            return sessions

    def _get_or_make_session(self, peer_id: str, pubkey: bytes) -> Session:
        with self._sessions_lock:
            s = self._sessions.get(peer_id)
            if s is None:
                s = Session(peer_id=peer_id, peer_public_key=pubkey)
                self._sessions[peer_id] = s
            elif s.peer_public_key != pubkey:
                # Same peer_id, different pubkey — identity spoofing;
                # refuse by returning a sentinel-less session but mark
                # closed so callers see it.
                s.state = SessionState.CLOSED
            return s

    # ---- peer key resolution ----

    def _metric_inc(self, key: str, amount: int = 1) -> None:
        with self._metrics_lock:
            self._metrics[key] += amount

    def _metrics_snapshot(self) -> dict[str, int]:
        with self._metrics_lock:
            return dict(self._metrics)

    def _budget_map(self, kind: str) -> tuple[dict[str, _WindowBudget], int, int]:
        if kind == "signal_send":
            return self._signal_send_budget, SignalSendBudgetLimit, SignalSendBudgetWindowS
        if kind == "relay_allocate":
            return self._relay_allocate_budget, RelayAllocateBudgetLimit, RelayAllocateBudgetWindowS
        if kind == "relay_send":
            return self._relay_send_budget, RelaySendBudgetLimit, RelaySendBudgetWindowS
        if kind == "ice_restart":
            return self._ice_restart_budget, IceRestartBudgetLimit, IceRestartBudgetWindowS
        raise KeyError(kind)

    def _consume_budget(self, kind: str, peer_id: str) -> tuple[bool, int]:
        mapping, limit, window_s = self._budget_map(kind)
        with self._budget_lock:
            budget = mapping.get(peer_id)
            if budget is None:
                budget = _WindowBudget(limit=limit, window_s=window_s)
                mapping[peer_id] = budget
        allowed, remaining = budget.allow()
        if not allowed:
            self._metric_inc(f"{kind}.rate_limited")
        return allowed, remaining

    def _budget_remaining(self, kind: str, peer_id: str) -> int:
        mapping, limit, window_s = self._budget_map(kind)
        with self._budget_lock:
            budget = mapping.get(peer_id)
        if budget is None:
            return limit
        return budget.remaining()

    def _audit_budget_block(self, event: str, *, peer_id: str, budget: str) -> None:
        self._audit.record(event, peer=peer_id, budget=budget, remaining=0)

    def _sender_record(self, peer_id: str) -> Optional[LocatorRecord]:
        # Use peek (no access-counter update) because the signaling
        # engine reads frequently.
        return self._cache.peek(peer_id)

    def _own_record(self) -> Optional[LocatorRecord]:
        return self._cache.peek(self._self)

    def _sender_record_attachment(self) -> Optional[str]:
        own = self._own_record()
        if own is None:
            return None
        try:
            return b64u_encode(own.to_wire_bytes())
        except Exception:
            return None

    def _with_sender_record(self, body: Optional[dict] = None) -> dict:
        out = dict(body or {})
        if "sender_record" not in out:
            attached = self._sender_record_attachment()
            if attached is not None:
                out["sender_record"] = attached
        return out

    def _extract_sender_record_bytes(self, msg: Message) -> Optional[bytes]:
        payload = msg.payload if isinstance(msg.payload, dict) else None
        if payload is None:
            return None
        body = payload.get("body")
        if not isinstance(body, dict):
            return None
        record_b64 = body.get("sender_record")
        if not isinstance(record_b64, str) or not record_b64:
            return None
        try:
            return b64u_decode(record_b64)
        except Exception:
            return None

    def _maybe_ingest_sender_record(self, msg: Message, *, source: str, audit_kind: str = "signal.bootstrap_record") -> Optional[LocatorRecord]:
        data = self._extract_sender_record_bytes(msg)
        if data is None:
            return None
        try:
            rec = LocatorRecord.from_wire_bytes(data)
        except Exception as e:
            self._audit.record("signal.bootstrap_reject", sender=msg.sender, reason=f"malformed_record:{e}")
            return None
        if rec.peer_id != msg.sender:
            self._audit.record("signal.bootstrap_reject", sender=msg.sender, reason="record_sender_mismatch")
            return None
        result = self._cache.put(rec, source=source)
        self._audit.record(
            audit_kind,
            sender=msg.sender,
            accepted=result.accepted,
            reason=result.reason,
            seq=rec.seq,
            source=source,
        )
        return self._cache.peek(rec.peer_id)

    def _record_endpoints_signature(self, record: Optional[LocatorRecord]) -> tuple[tuple[str, str, int, float], ...]:
        if record is None:
            return ()
        out = []
        for ep in getattr(record, "endpoints", []) or []:
            out.append((str(getattr(ep, "type", "")), str(getattr(ep, "address", "")), int(getattr(ep, "priority", 0)), float(getattr(ep, "confidence", 0.0))))
        return tuple(out)

    def _maybe_refresh_remote_candidates(self, peer_id: str, previous: Optional[LocatorRecord], current: Optional[LocatorRecord], *, trigger: str) -> None:
        session = self.session(peer_id)
        if session is None or not session.is_trusted() or current is None:
            return
        old_seq = previous.seq if previous is not None else None
        changed = previous is None or current.seq != previous.seq or self._record_endpoints_signature(previous) != self._record_endpoints_signature(current)
        if not changed:
            return
        self._audit.record("signal.candidate_update_received", peer=peer_id, trigger=trigger, previous_seq=old_seq, seq=current.seq, endpoints=[e.address for e in current.endpoints])
        self._start_ice(peer_id, force_restart=True)

    def _verify_with_inline_bootstrap(self, peer_id: str, msg: Message) -> tuple[Optional[LocatorRecord], bool, Optional[str]]:
        rec = self._cache.peek(peer_id)
        if rec is not None:
            ok, reason = verify_envelope(msg, rec.public_key, self_peer_id=self._self)
            if ok:
                return rec, True, None
        bootstrap = self._maybe_ingest_sender_record(msg, source="signal_inline")
        if bootstrap is None:
            if rec is None:
                return None, False, "peer_unresolved"
            ok, reason = verify_envelope(msg, rec.public_key, self_peer_id=self._self)
            return rec, ok, reason
        ok, reason = verify_envelope(msg, bootstrap.public_key, self_peer_id=self._self)
        return bootstrap, ok, reason

    def _parse_hostport(self, addr: str) -> tuple[str, int]:
        host, _, port_s = addr.rpartition(":")
        if host.startswith("[") and host.endswith("]"):
            host = host[1:-1]
        return host, int(port_s)

    def _relay_candidate_addr(self, record: Optional[LocatorRecord]) -> Optional[tuple[str, int]]:
        if record is None:
            return None
        for ep in record.endpoints:
            if getattr(ep, "type", None) == "relay_candidate":
                try:
                    return self._parse_hostport(ep.address)
                except Exception:
                    return None
        return None

    def _own_relay_token(self) -> Optional[RelayToken]:
        own = self._own_record()
        if own is None:
            return None
        meta = getattr(own, "nat_metadata", {}) or {}
        token_s = meta.get("relay_token")
        if token_s is None and isinstance(meta.get("relay"), dict):
            token_s = meta["relay"].get("token")
        if not token_s:
            return None
        try:
            return RelayToken.from_json(token_s)
        except Exception:
            return None

    def _relay_addr_for_peer(self, peer_id: str) -> Optional[tuple[str, int]]:
        rec = self._cache.peek(peer_id)
        if rec is None:
            return None
        return self._relay_candidate_addr(rec)

    def _relay_token_fingerprint(self, token: RelayToken) -> str:
        sig = getattr(token, "signature", None)
        if sig is None:
            return f"unsigned:{token.client_peer_id}:{token.expires_at}"
        return b64u_encode(sig)

    def _relay_cache_key(self, relay_addr: tuple[str, int]) -> str:
        return f"{relay_addr[0]}:{relay_addr[1]}"

    def _current_relay_meta(self, peer_id: str) -> Optional[tuple[tuple[str, int], RelayToken, str]]:
        relay_addr = self._relay_addr_for_peer(peer_id)
        token = self._own_relay_token()
        if relay_addr is None or token is None:
            return None
        return relay_addr, token, self._relay_token_fingerprint(token)

    def _has_relay_path(self, peer_id: str) -> bool:
        meta = self._current_relay_meta(peer_id)
        return meta is not None

    def _is_transport_reader_thread(self) -> bool:
        reader = getattr(self._tx, "_reader", None)
        ident = getattr(reader, "ident", None)
        return ident is not None and ident == threading.current_thread().ident

    def _relay_matcher(self, relay_addr: tuple[str, int]):
        def _match(data: bytes, addr: tuple[str, int]) -> bool:
            return addr == relay_addr and bool(data) and data[0] in (TAG_ALLOCATE_OK, TAG_ALLOCATE_REJECT)
        return _match

    def _wait_for_signal(self, peer_id: str, expected_type: SignalType, *, timeout_s: float) -> Message:
        waiter = _SignalReplyWaiter(peer_id=peer_id, expected_type=expected_type.value)
        with self._reply_waiters_lock:
            self._reply_waiters.append(waiter)
        try:
            if not waiter.event.wait(timeout_s):
                raise TransportTimeoutError(f"no {expected_type.value} reply from {peer_id[:8]}..")
            assert waiter.result is not None
            return waiter.result
        finally:
            with self._reply_waiters_lock:
                if waiter in self._reply_waiters:
                    self._reply_waiters.remove(waiter)

    def _notify_reply_waiters(self, from_peer: str, msg: Message) -> None:
        with self._reply_waiters_lock:
            waiters = list(self._reply_waiters)
        for waiter in waiters:
            if waiter.peer_id != from_peer or waiter.expected_type != msg.type:
                continue
            waiter.result = msg
            waiter.event.set()
            with self._reply_waiters_lock:
                if waiter in self._reply_waiters:
                    self._reply_waiters.remove(waiter)
            break

    def _invalidate_relay_allocation(self, peer_id: str, *, reason: str, clear_selected: bool = False) -> None:
        session = self.session(peer_id)
        relay_addr = session.relay_addr if session is not None and session.relay_addr is not None else self._relay_addr_for_peer(peer_id)
        if relay_addr is not None:
            key = self._relay_cache_key(relay_addr)
            with self._relay_lock:
                self._relay_allocations.pop(key, None)
        if session is not None:
            session.clear_relay_allocation()
            if clear_selected and session.selected_pair_kind == "relay/relay":
                session.clear_selected_path()
        self._audit.record("relay.invalidated", peer=peer_id, reason=reason)

    def _ensure_relay_allocation(self, peer_id: str) -> Optional[tuple[str, int]]:
        meta = self._current_relay_meta(peer_id)
        raw_wait = getattr(self._tx, "send_raw_and_wait", None)
        if meta is None:
            return None
        relay_addr, token, token_fp = meta
        key = self._relay_cache_key(relay_addr)
        now = now_s()
        with self._relay_lock:
            existing = self._relay_allocations.get(key)
        if existing is not None:
            if existing.token_fingerprint == token_fp and existing.is_valid(at=now):
                sess = self.session(peer_id)
                if sess is not None:
                    sess.mark_relay_allocated(existing.relay_addr, expires_at=existing.expires_at, token_fingerprint=token_fp, assumed=existing.assumed)
                return existing.relay_addr
            self._audit.record("relay.cache_stale", peer=peer_id, relay_addr=f"{relay_addr[0]}:{relay_addr[1]}", token_changed=existing.token_fingerprint != token_fp, expired=not existing.is_valid(at=now, min_remaining_s=0))
            self._invalidate_relay_allocation(peer_id, reason="stale_cached_allocation", clear_selected=False)

        allowed, remaining = self._consume_budget("relay_allocate", peer_id)
        if not allowed:
            self._audit.record("relay.rate_limited", peer=peer_id, action="allocate", remaining=remaining)
            return None
        self._metric_inc("relay.allocate_attempt")

        own_relay = self._relay_candidate_addr(self._own_record())
        if callable(raw_wait) and not self._is_transport_reader_thread():
            try:
                data, _ = raw_wait(
                    build_allocate_request(self._self, token),
                    relay_addr,
                    matcher=self._relay_matcher(relay_addr),
                    timeout_s=1.0,
                )
            except (TransportError, TransportTimeoutError) as e:
                self._metric_inc("relay.allocate_failed")
                self._audit.record("relay.allocate_failed", peer=peer_id, reason=type(e).__name__)
            else:
                tag, body = parse_response(data)
                if tag != TAG_ALLOCATE_OK:
                    try:
                        reason = json.loads(body.decode("utf-8")).get("reason")
                    except Exception:
                        reason = "allocate_rejected"
                    self._audit.record("relay.allocate_failed", peer=peer_id, reason=reason)
                    return None
                try:
                    relay_addr_s = json.loads(body.decode("utf-8"))["relay_addr"]
                    allocated = self._parse_hostport(relay_addr_s)
                except Exception:
                    return None
                state = _RelayAllocationState(relay_addr=allocated, expires_at=token.expires_at, token_fingerprint=token_fp, assumed=False)
                with self._relay_lock:
                    previous = self._relay_allocations.get(key)
                    self._relay_allocations[key] = state
                sess = self.session(peer_id)
                if sess is not None:
                    sess.mark_relay_allocated(allocated, expires_at=token.expires_at, token_fingerprint=token_fp, assumed=False)
                event = "relay.renewed" if previous is not None else "relay.allocated"
                self._metric_inc("relay.allocate_success")
                self._audit.record(event, peer=peer_id, relay_addr=f"{allocated[0]}:{allocated[1]}", expires_at=token.expires_at)
                return allocated

        if own_relay == relay_addr and (not callable(raw_wait) or self._is_transport_reader_thread()):
            state = _RelayAllocationState(relay_addr=relay_addr, expires_at=token.expires_at, token_fingerprint=token_fp, assumed=True)
            with self._relay_lock:
                self._relay_allocations[key] = state
            sess = self.session(peer_id)
            if sess is not None:
                sess.mark_relay_allocated(relay_addr, expires_at=token.expires_at, token_fingerprint=token_fp, assumed=True)
            self._metric_inc("relay.allocate_assumed")
            self._audit.record("relay.assumed_allocated", peer=peer_id, relay_addr=f"{relay_addr[0]}:{relay_addr[1]}", expires_at=token.expires_at)
            return relay_addr

        return None

    def _activate_relay_fallback(self, peer_id: str, *, reason: str) -> bool:
        relay_addr = self._ensure_relay_allocation(peer_id)
        rec = self._cache.peek(peer_id)
        if relay_addr is None or rec is None:
            return False
        session = self._get_or_make_session(peer_id, rec.public_key)
        session.mark_selected_path(
            local_addr=relay_addr,
            remote_addr=relay_addr,
            pair_kind="relay/relay",
            rtt_ms=None,
            nominated=True,
        )
        if session.relay_expires_at is None or session.relay_addr != relay_addr:
            token = self._own_relay_token()
            token_fp = self._relay_token_fingerprint(token) if token is not None else None
            expires_at = token.expires_at if token is not None else None
            session.mark_relay_allocated(relay_addr, expires_at=expires_at, token_fingerprint=token_fp, assumed=session.relay_assumed)
        self._metric_inc("relay.path_selected")
        self._audit.record(
            "relay.path_selected",
            peer=peer_id,
            relay_addr=f"{relay_addr[0]}:{relay_addr[1]}",
            reason=reason,
        )
        return True

    def _send_via_relay(self, peer_id: str, msg: Message) -> None:
        allowed, remaining = self._consume_budget("relay_send", peer_id)
        if not allowed:
            self._audit.record("relay.rate_limited", peer=peer_id, action="forward", remaining=remaining)
            raise UnreachableError("relay_rate_limited")
        relay_addr = self._ensure_relay_allocation(peer_id)
        raw_sender = getattr(self._tx, "send_raw", None)
        if relay_addr is None or not callable(raw_sender):
            raise UnreachableError("relay_unavailable")
        self._metric_inc("relay.forward_attempt")
        raw_sender(build_forward_request(peer_id, msg.to_wire_bytes()), relay_addr)
        self._metric_inc("relay.forward_sent")
        sess = self.session(peer_id)
        if sess is not None:
            sess.mark_relay_used()

    def _request_reply(self, peer_id: str, msg: Message, reply_type: SignalType, *, timeout_s: float) -> Message:
        allowed, remaining = self._consume_budget("signal_send", peer_id)
        if not allowed:
            self._audit.record("signal.rate_limited", peer=peer_id, type=msg.type, remaining=remaining)
            raise UnreachableError("signal_rate_limited")
        self._metric_inc("signal.request_reply_attempt")
        session = self.session(peer_id)
        relay_selected = session is not None and session.selected_pair_kind == "relay/relay"
        if relay_selected:
            self._send_via_relay(peer_id, msg)
            return self._wait_for_signal(peer_id, reply_type, timeout_s=timeout_s)
        try:
            self._refresh_selected_endpoint(peer_id)
            reply = self._tx.send_and_wait(peer_id, msg, timeout_s=timeout_s)
            self._metric_inc("signal.direct_request_reply_ok")
            return reply
        except (UnreachableError, TransportTimeoutError) as e:
            if not self._has_relay_path(peer_id):
                raise
            self._activate_relay_fallback(peer_id, reason=f"request_reply:{type(e).__name__}")
            self._send_via_relay(peer_id, msg)
            return self._wait_for_signal(peer_id, reply_type, timeout_s=timeout_s)

    def _send_best_effort(self, peer_id: str, msg: Message) -> None:
        allowed, remaining = self._consume_budget("signal_send", peer_id)
        if not allowed:
            self._audit.record("signal.rate_limited", peer=peer_id, type=msg.type, remaining=remaining)
            raise UnreachableError("signal_rate_limited")
        self._metric_inc("signal.best_effort_attempt")
        session = self.session(peer_id)
        relay_selected = session is not None and session.selected_pair_kind == "relay/relay"
        if relay_selected:
            self._send_via_relay(peer_id, msg)
            return
        try:
            self._refresh_selected_endpoint(peer_id)
            self._tx.send(peer_id, msg)
            self._metric_inc("signal.direct_best_effort_ok")
            return
        except TransportError:
            if not self._has_relay_path(peer_id):
                raise
        if not self._activate_relay_fallback(peer_id, reason="best_effort_fallback"):
            raise UnreachableError("relay_unavailable")
        self._send_via_relay(peer_id, msg)

    def _resolve_local_candidate(self, peer_id: str):
        from ..ice.candidates import candidates_from_endpoints

        own = self._own_record()
        if own is None:
            return None
        local = candidates_from_endpoints(own.endpoints)
        if not local:
            return None
        tx_lookup = getattr(self._tx, "lookup_endpoint", None)
        if callable(tx_lookup):
            observed = tx_lookup(peer_id)
            if observed is not None:
                host, port = observed
                for cand in local:
                    if cand.host == host and cand.port == port:
                        return cand
        return local[0]

    def _resolve_remote_addr(self, peer_id: str) -> Optional[tuple[str, int]]:
        from ..ice.candidates import candidates_from_endpoints

        tx_lookup = getattr(self._tx, "lookup_endpoint", None)
        if callable(tx_lookup):
            observed = tx_lookup(peer_id)
            if observed is not None:
                return observed
        rec = self._cache.peek(peer_id)
        if rec is None:
            return None
        remote = candidates_from_endpoints(rec.endpoints)
        if not remote:
            return None
        return remote[0].address_tuple()

    def _ice_send_raw(self, peer_id: str, local_cand, remote_addr: tuple[str, int], datagram: bytes) -> None:
        raw_sender = getattr(self._tx, "send_raw", None)
        if callable(raw_sender):
            raw_sender(datagram, remote_addr)
            return
        msg = Message.from_wire_bytes(datagram)
        self._tx.send(peer_id, msg)

    def _register_preferred_endpoint(self, peer_id: str, remote_addr: tuple[str, int]) -> None:
        register = getattr(self._tx, "register_endpoint", None)
        if callable(register):
            register(peer_id, remote_addr[0], int(remote_addr[1]))

    def _persist_selected_pair(self, peer_id: str, pair, *, nominated: bool) -> None:
        rec = self._cache.peek(peer_id)
        if rec is None:
            return
        session = self._get_or_make_session(peer_id, rec.public_key)
        local_addr = pair.local.address_tuple()
        remote_addr = pair.remote.address_tuple()
        pair_kind = f"{pair.local.type.value}/{pair.remote.type.value}"
        session.mark_selected_path(
            local_addr=local_addr,
            remote_addr=remote_addr,
            pair_kind=pair_kind,
            rtt_ms=pair.rtt_ms,
            nominated=nominated,
        )
        if pair_kind != "relay/relay":
            self._register_preferred_endpoint(peer_id, remote_addr)
        self._audit.record(
            "ice.path_selected",
            peer=peer_id,
            local=f"{local_addr[0]}:{local_addr[1]}",
            peer_addr=f"{remote_addr[0]}:{remote_addr[1]}",
            nominated=nominated,
            type_pair=pair_kind,
            rtt_ms=pair.rtt_ms,
        )

    def _refresh_selected_endpoint(self, peer_id: str) -> None:
        session = self.session(peer_id)
        if session is None or session.selected_remote_addr is None:
            return
        if session.selected_pair_kind == "relay/relay":
            return
        self._register_preferred_endpoint(peer_id, session.selected_remote_addr)

    def _handle_path_failure(self, peer_id: str, reason: str) -> int:
        session = self.session(peer_id)
        if session is None:
            return 0
        failures = session.mark_path_failure(reason)
        self._audit.record(
            "ice.path_degraded",
            peer=peer_id,
            failures=failures,
            error=reason,
            selected=session.selected_remote_addr is not None,
        )
        if session.selected_pair_kind == "relay/relay":
            if failures >= PathFailureRestartThreshold:
                self._invalidate_relay_allocation(peer_id, reason=reason, clear_selected=True)
                self._activate_relay_fallback(peer_id, reason=f"recovery:{reason}")
            return failures
        if session.selected_remote_addr is not None and failures >= PathFailureRestartThreshold:
            self._restart_ice(peer_id, reason=reason)
        return failures

    def _restart_ice(self, peer_id: str, *, reason: str) -> None:
        allowed, remaining = self._consume_budget("ice_restart", peer_id)
        if not allowed:
            self._audit.record("ice.restart_suppressed", peer=peer_id, reason=reason, remaining=remaining)
            return
        session = self.session(peer_id)
        if session is not None:
            session.note_ice_restart()
            session.clear_selected_path()
        with self._ice_lock:
            self._ice_agents.pop(peer_id, None)
            active = self._ice_threads.get(peer_id)
            if active is not None and active.is_alive():
                self._audit.record("ice.restart_pending", peer=peer_id, reason=reason)
                return
        self._metric_inc("ice.restart")
        self._audit.record("ice.restart", peer=peer_id, reason=reason)
        self._start_ice(peer_id, force_restart=True)

    def _ensure_ice_agent(self, peer_id: str):
        from ..ice.agent import ICEAgent
        from ..ice.candidates import candidates_from_endpoints

        with self._ice_lock:
            existing = self._ice_agents.get(peer_id)
            if existing is not None:
                return existing

        own = self._own_record()
        rec = self._cache.peek(peer_id)
        if own is None or rec is None:
            return None
        local = candidates_from_endpoints(own.endpoints)
        remote = candidates_from_endpoints(rec.endpoints)
        if not local or not remote:
            return None

        agent = ICEAgent(
            self_peer_id=self._self,
            remote_peer_id=peer_id,
            keypair=self._kp,
            check_sender=lambda lc, ra, dg: self._ice_send_raw(peer_id, lc, ra, dg),
            audit=self._audit,
            we_control=self._self < peer_id,
        )
        agent.set_candidates(local, remote)
        with self._ice_lock:
            existing = self._ice_agents.get(peer_id)
            if existing is not None:
                return existing
            self._ice_agents[peer_id] = agent
        return agent

    def _run_ice_for_peer(self, peer_id: str) -> None:
        try:
            agent = self._ensure_ice_agent(peer_id)
            if agent is None:
                try:
                    self._audit.record("ice.start_skipped", peer=peer_id, reason="missing_candidates")
                except Exception:
                    pass
                return
            if agent.nominated() is not None:
                return
            selected = agent.gather_and_probe(timeout_s=1.0)
            if selected is None:
                try:
                    self._audit.record("ice.failed", peer=peer_id)
                except Exception:
                    pass
                self._activate_relay_fallback(peer_id, reason="ice_failed")
            else:
                nominated = agent.nominated() is selected
                self._persist_selected_pair(peer_id, selected, nominated=nominated)
        except Exception as e:
            try:
                self._audit.record("ice.internal_error", peer=peer_id, error=str(e))
            except Exception:
                pass
        finally:
            restart_pending = False
            with self._ice_lock:
                self._ice_threads.pop(peer_id, None)
                restart_pending = peer_id in self._ice_restart_pending
                if restart_pending:
                    self._ice_restart_pending.discard(peer_id)
                    self._ice_agents.pop(peer_id, None)
            if restart_pending:
                try:
                    self._metric_inc("ice.restart_deferred")
                    self._audit.record("ice.restart_deferred", peer=peer_id)
                    self._start_ice(peer_id, force_restart=False)
                except Exception:
                    pass

    def _start_ice(self, peer_id: str, *, force_restart: bool = False) -> None:
        if force_restart:
            with self._ice_lock:
                active = self._ice_threads.get(peer_id)
                if active is not None and active.is_alive():
                    self._ice_restart_pending.add(peer_id)
                    self._audit.record("ice.restart_queued", peer=peer_id)
                    return
                self._ice_restart_pending.discard(peer_id)
                self._ice_agents.pop(peer_id, None)
        agent = self._ensure_ice_agent(peer_id)
        if agent is None:
            self._audit.record("ice.start_skipped", peer=peer_id, reason="missing_candidates")
            return
        if agent.nominated() is not None:
            return
        with self._ice_lock:
            thread = self._ice_threads.get(peer_id)
            if thread is not None and thread.is_alive():
                return
            thread = threading.Thread(
                target=self._run_ice_for_peer,
                args=(peer_id,),
                name=f"ice-{self._self[:6]}-{peer_id[:6]}",
                daemon=True,
            )
            self._ice_threads[peer_id] = thread
            thread.start()

    # =========================================================
    # inbound
    # =========================================================

    def _handle_incoming(self, from_peer: str, msg: Message) -> None:
        previous_rec = self._sender_record(from_peer)
        rec = previous_rec
        if rec is None:
            rec = self._maybe_ingest_sender_record(msg, source="signal_inline")
        elif msg.type in (SignalType.HELLO.value, SignalType.HELLO_ACK.value):
            # Opportunistically refresh the sender's signed locator record.
            refreshed = self._maybe_ingest_sender_record(msg, source="signal_inline")
            if refreshed is not None:
                rec = refreshed
        elif msg.type == SignalType.CANDIDATE.value:
            refreshed = self._maybe_ingest_sender_record(msg, source="signal_candidate", audit_kind="signal.candidate_record")
            if refreshed is not None:
                rec = refreshed
                self._maybe_refresh_remote_candidates(from_peer, previous_rec, refreshed, trigger="candidate")
        if rec is None:
            self._audit.record(
                "signal.reject",
                reason="unknown_sender",
                sender=from_peer,
                type=msg.type,
            )
            return
        ok, reason = verify_envelope(msg, rec.public_key, self_peer_id=self._self)
        if not ok:
            rec2 = self._maybe_ingest_sender_record(msg, source="signal_inline")
            if rec2 is not None:
                if msg.type == SignalType.CANDIDATE.value:
                    self._maybe_refresh_remote_candidates(from_peer, previous_rec, rec2, trigger="candidate_verify_retry")
                rec = rec2
                ok, reason = verify_envelope(msg, rec.public_key, self_peer_id=self._self)
        if not ok:
            self._audit.record(
                "signal.reject",
                reason=reason,
                sender=from_peer,
                type=msg.type,
            )
            return
        session = self._get_or_make_session(from_peer, rec.public_key)
        if session.state == SessionState.CLOSED and session.peer_public_key != rec.public_key:
            return
        if session.is_replay(msg.msg_id):
            self._audit.record(
                "signal.reject", reason="replayed_msg_id",
                sender=from_peer, type=msg.type,
            )
            return
        session.remember(msg.msg_id)
        session.touch()
        self._notify_reply_waiters(from_peer, msg)

        dispatch = {
            SignalType.HELLO.value: self._on_hello,
            SignalType.HELLO_ACK.value: self._on_hello_ack,
            SignalType.RING.value: self._on_ring,
            SignalType.RING_ACK.value: self._on_ring_ack,
            SignalType.KEEPALIVE.value: self._on_keepalive,
            SignalType.BYE.value: self._on_bye,
            SignalType.CONN_CHECK.value: self._on_conn_check,
            SignalType.CONN_CHECK_ACK.value: self._on_conn_check_ack,
        }
        handler = dispatch.get(msg.type)
        if handler is not None:
            handler(session, msg)
            return
        if msg.type in SIG_TYPES:
            with self._inbox_lock:
                self._pass_through_inbox.append((from_peer, msg))
            self._audit.record(
                "signal.passthrough",
                sender=from_peer, type=msg.type,
                state=session.state.value,
            )

    def _on_hello(self, session: Session, msg: Message) -> None:
        session.remote_nonce = msg.payload.get("nonce")
        if session.state == SessionState.FRESH:
            session.state = SessionState.HANDSHAKING
        ack = build_and_sign(
            self._kp,
            SignalType.HELLO_ACK,
            sender=self._self,
            target=session.peer_id,
            in_reply_to=msg.msg_id,
            body=self._with_sender_record({"echoed_nonce": msg.payload.get("nonce")}),
        )
        session.local_nonce = ack.payload.get("nonce")
        session.mark_established(
            local_nonce=session.local_nonce,
            remote_nonce=session.remote_nonce,
        )
        try:
            self._send_best_effort(session.peer_id, ack)
            self._audit.record("signal.hello_ack_sent", peer=session.peer_id)
            self._start_ice(session.peer_id)
        except TransportError as e:
            self._audit.record(
                "signal.hello_ack_send_failed",
                peer=session.peer_id, error=str(e),
            )

    def _on_hello_ack(self, session: Session, msg: Message) -> None:
        session.remote_nonce = msg.payload.get("nonce")
        if session.state in (SessionState.FRESH, SessionState.HANDSHAKING):
            session.mark_established(
                local_nonce=session.local_nonce or "",
                remote_nonce=session.remote_nonce or "",
            )
        self._audit.record("signal.established", peer=session.peer_id)
        self._start_ice(session.peer_id)

    def _on_ring(self, session: Session, msg: Message) -> None:
        if not session.is_trusted():
            self._audit.record("signal.ring_rejected_untrusted", peer=session.peer_id)
            return
        body = msg.payload.get("body", {})
        accept = True
        if self._ring_cb is not None:
            try:
                accept = bool(self._ring_cb(session.peer_id, dict(body)))
            except Exception:
                accept = False
        if not accept:
            self._audit.record("signal.ring_declined_by_app", peer=session.peer_id)
            return
        session.state = SessionState.RINGING
        ack = build_and_sign(
            self._kp,
            SignalType.RING_ACK,
            sender=self._self,
            target=session.peer_id,
            in_reply_to=msg.msg_id,
            body={"accept": True},
        )
        try:
            self._send_best_effort(session.peer_id, ack)
            self._audit.record("signal.ring_ack_sent", peer=session.peer_id)
            session.state = SessionState.IN_CALL
        except TransportError as e:
            self._audit.record(
                "signal.ring_ack_send_failed",
                peer=session.peer_id, error=str(e),
            )

    def _on_ring_ack(self, session: Session, msg: Message) -> None:
        if session.state == SessionState.RINGING:
            session.state = SessionState.IN_CALL
            self._audit.record("signal.in_call", peer=session.peer_id)

    def _on_keepalive(self, session: Session, msg: Message) -> None:
        if session.selected_remote_addr is not None:
            session.mark_path_healthy()
        if msg.in_reply_to is not None:
            return
        try:
            echo = build_and_sign(
                self._kp,
                SignalType.KEEPALIVE,
                sender=self._self,
                target=session.peer_id,
                in_reply_to=msg.msg_id,
                body={},
            )
            self._send_best_effort(session.peer_id, echo)
        except TransportError:
            pass

    def _on_bye(self, session: Session, msg: Message) -> None:
        session.state = SessionState.CLOSED
        self._audit.record("signal.bye", peer=session.peer_id)

    def _on_conn_check(self, session: Session, msg: Message) -> None:
        agent = self._ensure_ice_agent(session.peer_id)
        if agent is None:
            self._audit.record("ice.check_rejected", peer=session.peer_id, reason="missing_agent")
            return
        from_addr = self._resolve_remote_addr(session.peer_id)
        local_cand = self._resolve_local_candidate(session.peer_id)
        if from_addr is None or local_cand is None:
            self._audit.record("ice.check_rejected", peer=session.peer_id, reason="missing_path")
            return
        ack_bytes = agent.handle_check(session.peer_id, from_addr, msg, local_cand=local_cand)
        if ack_bytes is None:
            return
        try:
            self._ice_send_raw(session.peer_id, local_cand, from_addr, ack_bytes)
        except TransportError as e:
            self._audit.record("ice.check_ack_send_failed", peer=session.peer_id, error=str(e))

    def _on_conn_check_ack(self, session: Session, msg: Message) -> None:
        agent = self._ensure_ice_agent(session.peer_id)
        if agent is None:
            return
        from_addr = self._resolve_remote_addr(session.peer_id)
        if from_addr is None:
            return
        agent.handle_ack(session.peer_id, from_addr, msg)

    # =========================================================
    # outbound
    # =========================================================

    def _check_resolvable(self, peer_id: str) -> Optional[LocatorRecord]:
        rec = self._cache.peek(peer_id)
        if rec is None:
            self._audit.record(
                "signal.send_blocked",
                reason="peer_unresolved", peer=peer_id,
            )
            return None
        return rec

    def hello(self, peer_id: str, *, timeout_s: float = 3.0) -> SignalResult:
        if self._negcache.is_blocked(peer_id):
            return SignalResult(False, reason="negcache")
        rec = self._cache.peek(peer_id)
        if rec is None and self._own_record() is None:
            self._negcache.record_failure(peer_id)
            return SignalResult(False, reason="peer_unresolved")
        if rec is not None:
            session = self._get_or_make_session(peer_id, rec.public_key)
            if session.state == SessionState.CLOSED:
                return SignalResult(False, reason="session_closed")
        else:
            session = Session(peer_id=peer_id, peer_public_key=b"")
        session.state = SessionState.HANDSHAKING
        hello = build_and_sign(
            self._kp,
            SignalType.HELLO,
            sender=self._self,
            target=peer_id,
            body=self._with_sender_record({"hint": "hello"}),
        )
        session.local_nonce = hello.payload["nonce"]
        try:
            reply = self._request_reply(peer_id, hello, SignalType.HELLO_ACK, timeout_s=timeout_s)
        except UnreachableError as e:
            self._negcache.record_failure(peer_id)
            self._audit.record("signal.hello_unreachable", peer=peer_id, error=str(e))
            return SignalResult(False, reason="unreachable")
        except TransportTimeoutError:
            self._negcache.record_failure(peer_id)
            self._audit.record("signal.hello_timeout", peer=peer_id)
            return SignalResult(False, reason="timeout")
        if reply.type != SignalType.HELLO_ACK.value:
            self._audit.record("signal.hello_bad_reply", peer=peer_id, got=reply.type)
            self._negcache.record_failure(peer_id)
            return SignalResult(False, reason=f"bad_reply_type:{reply.type}")
        rec, ok, reason = self._verify_with_inline_bootstrap(peer_id, reply)
        if not ok or rec is None:
            self._negcache.record_failure(peer_id)
            self._audit.record("signal.hello_ack_invalid", peer=peer_id, reason=reason)
            return SignalResult(False, reason=f"ack_invalid:{reason}")
        session = self._get_or_make_session(peer_id, rec.public_key)
        session.remote_nonce = reply.payload.get("nonce")
        session.mark_established(
            local_nonce=session.local_nonce or hello.payload.get("nonce", ""),
            remote_nonce=session.remote_nonce or "",
        )
        self._negcache.clear(peer_id)
        self._audit.record("signal.established", peer=peer_id)
        self._start_ice(peer_id)
        return SignalResult(True, session_state=session.state.value)

    def ring(self, peer_id: str, *, body: Optional[dict] = None, timeout_s: float = 5.0) -> SignalResult:
        session = self.session(peer_id)
        if session is None or not session.is_trusted():
            return SignalResult(False, reason="no_established_session")
        ring_msg = build_and_sign(
            self._kp,
            SignalType.RING,
            sender=self._self,
            target=peer_id,
            body=body or {},
        )
        session.pending_ring_msg_id = ring_msg.msg_id
        session.state = SessionState.RINGING
        try:
            reply = self._request_reply(peer_id, ring_msg, SignalType.RING_ACK, timeout_s=timeout_s)
        except TransportTimeoutError:
            session.state = SessionState.ESTABLISHED
            self._audit.record("signal.ring_timeout", peer=peer_id)
            return SignalResult(False, reason="timeout")
        except UnreachableError:
            session.state = SessionState.ESTABLISHED
            return SignalResult(False, reason="unreachable")
        if reply.type != SignalType.RING_ACK.value:
            session.state = SessionState.ESTABLISHED
            return SignalResult(False, reason=f"bad_reply:{reply.type}")
        ok, reason = verify_envelope(reply, session.peer_public_key, self_peer_id=self._self)
        if not ok:
            session.state = SessionState.ESTABLISHED
            return SignalResult(False, reason=f"ack_invalid:{reason}")
        if not reply.payload.get("body", {}).get("accept", False):
            session.state = SessionState.ESTABLISHED
            return SignalResult(False, reason="declined")
        session.state = SessionState.IN_CALL
        self._audit.record("signal.in_call", peer=peer_id)
        return SignalResult(True, session_state=session.state.value)

    def send_passthrough(self, peer_id: str, sig_type: SignalType, body: dict) -> SignalResult:
        allowed = {
            SignalType.OFFER,
            SignalType.ANSWER,
            SignalType.CANDIDATE,
            SignalType.CHAT_CONTROL,
        }
        if sig_type not in allowed:
            return SignalResult(False, reason=f"type_not_passthrough:{sig_type.value}")
        session = self.session(peer_id)
        if session is None or not session.is_trusted():
            return SignalResult(False, reason="no_established_session")
        final_body = body
        if sig_type == SignalType.CANDIDATE:
            final_body = self._with_sender_record(dict(body or {}))
        msg = build_and_sign(self._kp, sig_type, sender=self._self, target=peer_id, body=final_body)
        try:
            self._send_best_effort(peer_id, msg)
            if sig_type == SignalType.CANDIDATE:
                own = self._own_record()
                self._audit.record("signal.candidate_update_sent", peer=peer_id, seq=getattr(own, "seq", None), endpoints=[e.address for e in getattr(own, "endpoints", [])] if own is not None else [])
            return SignalResult(True)
        except TransportError as e:
            return SignalResult(False, reason=str(e))

    def refresh_candidates(self, peer_id: str, *, reason: str = "manual_refresh") -> SignalResult:
        own = self._own_record()
        if own is None:
            return SignalResult(False, reason="no_own_record")
        return self.send_passthrough(peer_id, SignalType.CANDIDATE, {"candidate_refresh": True, "reason": reason, "record_seq": own.seq})

    def keepalive(self, peer_id: str, *, timeout_s: float = 1.0) -> SignalResult:
        session = self.session(peer_id)
        if session is None or not session.is_trusted():
            return SignalResult(False, reason="no_established_session")
        msg = build_and_sign(
            self._kp,
            SignalType.KEEPALIVE,
            sender=self._self,
            target=peer_id,
            body={},
        )
        try:
            reply = self._request_reply(peer_id, msg, SignalType.KEEPALIVE, timeout_s=timeout_s)
        except UnreachableError as e:
            self._handle_path_failure(peer_id, f"unreachable:{e}")
            self._audit.record("signal.keepalive_unreachable", peer=peer_id, error=str(e))
            return SignalResult(False, reason="unreachable")
        except TransportTimeoutError:
            self._handle_path_failure(peer_id, "timeout")
            self._audit.record("signal.keepalive_timeout", peer=peer_id)
            return SignalResult(False, reason="timeout")
        if reply.type != SignalType.KEEPALIVE.value:
            self._handle_path_failure(peer_id, f"bad_reply_type:{reply.type}")
            return SignalResult(False, reason=f"bad_reply_type:{reply.type}")
        ok, reason = verify_envelope(reply, session.peer_public_key, self_peer_id=self._self)
        if not ok:
            self._handle_path_failure(peer_id, f"ack_invalid:{reason}")
            return SignalResult(False, reason=f"ack_invalid:{reason}")
        if session.selected_remote_addr is not None:
            session.mark_path_healthy()
        self._audit.record("signal.keepalive_ok", peer=peer_id)
        return SignalResult(True, session_state=session.state.value)

    def bye(self, peer_id: str) -> SignalResult:
        session = self.session(peer_id)
        if session is None:
            return SignalResult(False, reason="no_session")
        msg = build_and_sign(
            self._kp,
            SignalType.BYE,
            sender=self._self,
            target=peer_id,
            body={},
        )
        try:
            self._send_best_effort(peer_id, msg)
        except TransportError:
            pass
        session.state = SessionState.CLOSED
        return SignalResult(True)

    def drain_inbox(self) -> list[tuple[str, Message]]:
        with self._inbox_lock:
            out = list(self._pass_through_inbox)
            self._pass_through_inbox.clear()
        return out

    # ---- maintenance ----

    def gc_idle_sessions(self, *, idle_timeout_s: int = IdleTimeoutS) -> int:
        from ..utils.time import now_s
        now = now_s()
        removed = 0
        with self._sessions_lock:
            to_del = [
                pid for pid, s in self._sessions.items()
                if s.state == SessionState.CLOSED or now - s.last_seen > idle_timeout_s
            ]
            for pid in to_del:
                del self._sessions[pid]
                removed += 1
        return removed

    def stats(self) -> dict:
        with self._sessions_lock:
            trusted = sum(1 for s in self._sessions.values() if s.is_trusted())
            selected = sum(1 for s in self._sessions.values() if s.selected_remote_addr is not None)
            relay_selected = sum(1 for s in self._sessions.values() if s.selected_pair_kind == "relay/relay")
        with self._relay_lock:
            active_relay_allocations = len(self._relay_allocations)
        return {
            "sessions": {
                "total": len(self._sessions),
                "trusted": trusted,
                "selected_paths": selected,
                "relay_selected": relay_selected,
            },
            "negcache": self._negcache.stats(),
            "relay": {"active_allocations": active_relay_allocations},
            "budgets": {
                "signal_send": {pid: b.stats() for pid, b in self._signal_send_budget.items()},
                "relay_allocate": {pid: b.stats() for pid, b in self._relay_allocate_budget.items()},
                "relay_send": {pid: b.stats() for pid, b in self._relay_send_budget.items()},
                "ice_restart": {pid: b.stats() for pid, b in self._ice_restart_budget.items()},
            },
            "metrics": self._metrics_snapshot(),
        }

    def negcache_stats(self) -> dict:
        return self._negcache.stats()
