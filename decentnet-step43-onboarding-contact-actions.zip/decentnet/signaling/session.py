"""Per-peer signaling session state.

A Session is created the first time we exchange hello-ack with a peer
and lives for as long as we want to keep a logical connection to
them. It tracks:

    * trust level (is the hello/hello_ack handshake complete?)
    * nonces we've sent (local_nonce) and received (remote_nonce)
    * recent msg_ids we've seen from this peer (replay window)
    * the ring/call state for the current logical interaction
    * last-seen timestamp for keepalive / idle GC

The signaling engine consults and mutates Sessions from its handlers.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from ..utils.time import now_s


REPLAY_WINDOW = 256          # per-peer recent msg_ids remembered


class SessionState(str, Enum):
    FRESH = "fresh"          # we've seen them via DHT, no handshake yet
    HANDSHAKING = "handshaking"
    ESTABLISHED = "established"
    RINGING = "ringing"      # a ring is in flight, awaiting ring_ack
    IN_CALL = "in_call"
    CLOSED = "closed"


@dataclass
class Session:
    peer_id: str
    peer_public_key: bytes
    state: SessionState = SessionState.FRESH
    local_nonce: Optional[str] = None
    remote_nonce: Optional[str] = None
    established_at: Optional[int] = None
    last_seen: int = field(default_factory=now_s)
    seen_msg_ids: deque[str] = field(default_factory=lambda: deque(maxlen=REPLAY_WINDOW))
    # Ring state — the msg_id of the most recent unanswered ring we
    # sent; helps correlate a RING_ACK to its RING.
    pending_ring_msg_id: Optional[str] = None
    # Preferred ICE-selected path for future outbound traffic.
    selected_local_addr: Optional[tuple[str, int]] = None
    selected_remote_addr: Optional[tuple[str, int]] = None
    selected_pair_kind: Optional[str] = None
    selected_rtt_ms: Optional[int] = None
    selected_at: Optional[int] = None
    selected_nominated: bool = False
    selected_path_ok_at: Optional[int] = None
    selected_path_degraded_at: Optional[int] = None
    selected_path_failures: int = 0
    last_path_error: Optional[str] = None
    ice_restart_count: int = 0
    relay_addr: Optional[tuple[str, int]] = None
    relay_allocated_at: Optional[int] = None
    relay_last_used_at: Optional[int] = None
    relay_expires_at: Optional[int] = None
    relay_token_fingerprint: Optional[str] = None
    relay_assumed: bool = False

    # ---- replay protection ----

    def is_replay(self, msg_id: str) -> bool:
        return msg_id in self.seen_msg_ids

    def remember(self, msg_id: str) -> None:
        self.seen_msg_ids.append(msg_id)

    def touch(self) -> None:
        self.last_seen = now_s()

    # ---- state transitions ----

    def mark_established(self, local_nonce: str, remote_nonce: str) -> None:
        self.local_nonce = local_nonce
        self.remote_nonce = remote_nonce
        self.state = SessionState.ESTABLISHED
        self.established_at = now_s()
        self.touch()

    def is_trusted(self) -> bool:
        return self.state in {
            SessionState.ESTABLISHED,
            SessionState.RINGING,
            SessionState.IN_CALL,
        }

    def mark_selected_path(
        self,
        *,
        local_addr: tuple[str, int],
        remote_addr: tuple[str, int],
        pair_kind: Optional[str] = None,
        rtt_ms: Optional[int] = None,
        nominated: bool = False,
    ) -> None:
        self.selected_local_addr = local_addr
        self.selected_remote_addr = remote_addr
        self.selected_pair_kind = pair_kind
        t = now_s()
        self.selected_rtt_ms = rtt_ms
        self.selected_at = t
        self.selected_nominated = nominated
        self.selected_path_ok_at = t
        self.selected_path_degraded_at = None
        self.selected_path_failures = 0
        self.last_path_error = None
        self.touch()

    def mark_path_healthy(self) -> None:
        t = now_s()
        self.selected_path_ok_at = t
        self.selected_path_degraded_at = None
        self.selected_path_failures = 0
        self.last_path_error = None
        self.touch()

    def mark_path_failure(self, reason: str) -> int:
        t = now_s()
        self.selected_path_failures += 1
        self.selected_path_degraded_at = t
        self.last_path_error = reason
        self.touch()
        return self.selected_path_failures

    def clear_selected_path(self) -> None:
        self.selected_local_addr = None
        self.selected_remote_addr = None
        self.selected_pair_kind = None
        self.selected_rtt_ms = None
        self.selected_at = None
        self.selected_nominated = False
        self.selected_path_ok_at = None
        self.selected_path_degraded_at = None
        self.selected_path_failures = 0
        self.last_path_error = None
        self.touch()

    def note_ice_restart(self) -> None:
        self.ice_restart_count += 1
        self.touch()

    def mark_relay_allocated(
        self,
        relay_addr: tuple[str, int],
        *,
        expires_at: Optional[int] = None,
        token_fingerprint: Optional[str] = None,
        assumed: bool = False,
    ) -> None:
        t = now_s()
        self.relay_addr = relay_addr
        self.relay_allocated_at = t
        self.relay_last_used_at = t
        self.relay_expires_at = expires_at
        self.relay_token_fingerprint = token_fingerprint
        self.relay_assumed = assumed
        self.touch()

    def mark_relay_used(self) -> None:
        self.relay_last_used_at = now_s()
        self.touch()

    def clear_relay_allocation(self) -> None:
        self.relay_addr = None
        self.relay_allocated_at = None
        self.relay_last_used_at = None
        self.relay_expires_at = None
        self.relay_token_fingerprint = None
        self.relay_assumed = False
        self.touch()


# --------------------------------------------------------------------


@dataclass
class NegativeEntry:
    failure_count: int = 0
    last_failure: int = 0
    backoff_until: int = 0


class NegativeCache:
    """Per-peer exponential backoff for failed signaling attempts."""

    def __init__(self, *, max_failures: int = 5, base_backoff_s: int = 5) -> None:
        self._entries: dict[str, NegativeEntry] = {}
        self._max = max_failures
        self._base = base_backoff_s

    def record_failure(self, peer_id: str) -> int:
        e = self._entries.setdefault(peer_id, NegativeEntry())
        e.failure_count += 1
        e.last_failure = now_s()
        # Exponential backoff capped at 1 hour.
        backoff = min(3600, self._base * (2 ** min(10, e.failure_count - 1)))
        e.backoff_until = e.last_failure + backoff
        return backoff

    def clear(self, peer_id: str) -> None:
        self._entries.pop(peer_id, None)

    def is_blocked(self, peer_id: str) -> bool:
        e = self._entries.get(peer_id)
        if e is None:
            return False
        return now_s() < e.backoff_until

    def stats(self) -> dict:
        return {
            "tracked": len(self._entries),
            "blocked": sum(1 for p in self._entries if self.is_blocked(p)),
        }
