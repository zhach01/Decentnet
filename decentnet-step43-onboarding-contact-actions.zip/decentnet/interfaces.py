from __future__ import annotations

"""Local interface discovery helpers for peer endpoint advertisement."""

from dataclasses import dataclass
import ipaddress
import os
import re
import subprocess
from typing import Iterable, Mapping, Optional

from .records.endpoints import Endpoint


@dataclass(frozen=True)
class InterfaceAddress:
    name: str
    address: str
    family: str


_IP_LINE_RE = re.compile(r"^\d+:\s+([^\s]+)\s+([^\s]+)\s+([^/]+)/\d+.*$")


def list_interface_output(*, command_runner=None) -> str:
    runner = command_runner or subprocess.run
    proc = runner(["ip", "-o", "addr", "show", "up"], capture_output=True, text=True, check=False)
    return proc.stdout or ""


def _normalize_ip(value: str) -> Optional[str]:
    value = (value or "").strip()
    if not value:
        return None
    if value.startswith("[") and value.endswith("]"):
        value = value[1:-1]
    try:
        ip = ipaddress.ip_address(value)
    except ValueError:
        return None
    if ip.is_loopback or ip.is_link_local or ip.is_unspecified or ip.is_multicast:
        return None
    return str(ip)


def _interface_allowed(name: str, *, allow: Iterable[str] | None, deny: Iterable[str] | None) -> bool:
    lname = (name or "").strip().lower()
    if not lname:
        return False
    deny_set = {x.strip().lower() for x in (deny or []) if str(x).strip()}
    allow_set = {x.strip().lower() for x in (allow or []) if str(x).strip()}
    if lname in deny_set:
        return False
    if allow_set and lname not in allow_set:
        return False
    return True


def _is_lan_ip(ip_text: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_text)
    except ValueError:
        return False
    return ip.is_private and not ip.is_loopback and not ip.is_link_local


def parse_interface_addresses(ip_output: str, *, allow: Iterable[str] | None = None, deny: Iterable[str] | None = None) -> list[InterfaceAddress]:
    out: list[InterfaceAddress] = []
    seen: set[tuple[str, str]] = set()
    for raw in (ip_output or "").splitlines():
        m = _IP_LINE_RE.match(raw.strip())
        if not m:
            continue
        ifname, fam, addr = m.groups()
        if fam not in {"inet", "inet6"}:
            continue
        if not _interface_allowed(ifname, allow=allow, deny=deny):
            continue
        ip = _normalize_ip(addr)
        if ip is None or not _is_lan_ip(ip):
            continue
        key = (ifname, ip)
        if key in seen:
            continue
        seen.add(key)
        out.append(InterfaceAddress(name=ifname, address=ip, family=fam))
    return out


def _make_address(ip: str, port: int) -> str:
    if ":" in ip and not ip.startswith("["):
        return f"[{ip}]:{port}"
    return f"{ip}:{port}"


def detect_lan_endpoints(
    port: int,
    *,
    allow: Iterable[str] | None = None,
    deny: Iterable[str] | None = None,
    env: Optional[Mapping[str, str]] = None,
    ip_output: Optional[str] = None,
    command_runner=None,
) -> list[Endpoint]:
    env_map = dict(os.environ if env is None else env)
    # Explicit override can be useful on constrained/mobile environments.
    explicit = env_map.get("DECENTNET_LAN_ENDPOINTS") or env_map.get("DECENTNET_LAN_ENDPOINT")
    out: list[Endpoint] = []
    seen: set[tuple[str, str]] = set()
    if explicit:
        for part in re.split(r"[;,]", explicit):
            spec = (part or "").strip()
            if not spec:
                continue
            addr = spec if ((spec.startswith("[") and "]:" in spec) or (spec.count(":") == 1 and spec.rpartition(":")[2].isdigit())) else _make_address(spec, port)
            ep = Endpoint(type="lan_udp", address=addr, discovered_by="env", confidence=0.9, priority=70)
            key = (ep.type, ep.address)
            if key not in seen:
                seen.add(key)
                out.append(ep)
    text = ip_output if ip_output is not None else env_map.get("DECENTNET_IP_OUTPUT")
    if text is None:
        text = list_interface_output(command_runner=command_runner)
    for item in parse_interface_addresses(text, allow=allow, deny=deny):
        ep = Endpoint(type="lan_udp", address=_make_address(item.address, port), discovered_by=item.name, confidence=0.85, priority=60)
        key = (ep.type, ep.address)
        if key not in seen:
            seen.add(key)
            out.append(ep)
    return out
