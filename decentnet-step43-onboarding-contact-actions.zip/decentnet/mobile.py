"""Mobile integration layer for decentnet.

Mobile devices introduce constraints desktop code doesn't see:

    * The OS freezes your process when the screen locks (Doze/App
      Standby on Android, Background App Refresh on iOS).
    * Cellular data is metered — background traffic costs money.
    * Connectivity flaps constantly (handoffs, captive portals,
      airplane-mode toggles).
    * Long-running threads drain battery fast.

`MobileNode` is a thin wrapper around `Node` that codifies sensible
defaults for these constraints and exposes hooks a Kivy app can
call on lifecycle events (foreground / background / network change).

Usage from a Kivy app:

    from decentnet.mobile import MobileNode, MobilePolicy
    from decentnet.node import NodeConfig

    node = MobileNode(
        NodeConfig.at('/data/data/org.example/files/decentnet'),
        policy=MobilePolicy.DEFAULT_MOBILE,
    )

    # in your App.on_pause / on_resume:
    node.on_enter_background()
    node.on_enter_foreground()

    # when the OS tells us the network changed:
    node.on_network_changed(cellular=True)
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional

from .node import Node, NodeConfig


class PowerMode(str, Enum):
    FOREGROUND = "foreground"
    BACKGROUND = "background"
    LOW_POWER = "low_power"


class NetworkKind(str, Enum):
    WIFI = "wifi"
    CELLULAR = "cellular"
    NONE = "none"


@dataclass
class MobilePolicy:
    """Concrete tuning knobs for a mobile environment.

    The defaults below balance responsiveness with battery life for a
    typical phone. A desktop-class device can pass `DEFAULT_DESKTOP`.
    """
    # How often to tick background refresh in each power mode.
    refresh_interval_foreground_s: int = 60
    refresh_interval_background_s: int = 900     # 15 min
    refresh_interval_low_power_s: int = 3600     # 1 hr

    # Keepalive cadence (signaling only).
    keepalive_interval_foreground_s: int = 30
    keepalive_interval_background_s: int = 300
    keepalive_interval_low_power_s: int = 0      # disable

    # On cellular, further scale the above intervals.
    cellular_multiplier: float = 2.0

    # Enable/disable republish loop.
    allow_republish: bool = True
    # Refuse to speak at all while backgrounded if True.
    pause_in_background: bool = False
    # Drop DHT replication work below k-closest responsibility.
    scoped_replication_only: bool = True


# Named presets.
MobilePolicy.DEFAULT_MOBILE = MobilePolicy()
MobilePolicy.DEFAULT_DESKTOP = MobilePolicy(
    refresh_interval_foreground_s=60,
    refresh_interval_background_s=60,
    refresh_interval_low_power_s=60,
    keepalive_interval_foreground_s=30,
    keepalive_interval_background_s=30,
    keepalive_interval_low_power_s=30,
    cellular_multiplier=1.0,
    allow_republish=True,
    pause_in_background=False,
    scoped_replication_only=False,
)
MobilePolicy.DEFAULT_LOW_POWER = MobilePolicy(
    refresh_interval_foreground_s=300,
    refresh_interval_background_s=3600,
    refresh_interval_low_power_s=0,    # completely quiet
    keepalive_interval_foreground_s=300,
    keepalive_interval_background_s=0,
    keepalive_interval_low_power_s=0,
    cellular_multiplier=4.0,
    allow_republish=False,
    pause_in_background=True,
    scoped_replication_only=True,
)


class MobileNode:
    """Lifecycle-aware Node for mobile applications."""

    def __init__(
        self,
        config: NodeConfig,
        *,
        policy: Optional[MobilePolicy] = None,
        network=None,
    ) -> None:
        self._policy = policy or MobilePolicy.DEFAULT_MOBILE
        self.node = Node(config, network=network)
        self._power: PowerMode = PowerMode.FOREGROUND
        self._network_kind: NetworkKind = NetworkKind.WIFI
        self._paused: bool = False
        if self._policy.scoped_replication_only:
            self.node.topic_policy.set_replicate_all(False)
        self._apply_policy()

    # ---- lifecycle ----

    def on_enter_foreground(self) -> None:
        self._power = PowerMode.FOREGROUND
        self._paused = False
        self._apply_policy()
        self.node.audit.record("mobile.enter_foreground")

    def on_enter_background(self) -> None:
        self._power = PowerMode.BACKGROUND
        if self._policy.pause_in_background:
            self.pause()
        else:
            self._apply_policy()
        self.node.audit.record("mobile.enter_background")

    def on_enter_low_power(self) -> None:
        """Called when the OS signals Battery Saver / Low Power Mode."""
        self._power = PowerMode.LOW_POWER
        self._apply_policy()
        self.node.audit.record("mobile.enter_low_power")

    def on_network_changed(self, *, kind: NetworkKind) -> None:
        previous = self._network_kind
        self._network_kind = kind
        self.node.audit.record(
            "mobile.network_changed",
            from_kind=previous.value, to_kind=kind.value,
        )
        if kind == NetworkKind.NONE:
            self.pause()
            return
        # Came back online? Drain deferred writes and resume schedulers.
        if previous == NetworkKind.NONE:
            self._paused = False
            try:
                result = self.node.drain_deferred()
                self.node.audit.record(
                    "mobile.deferred_drained_on_resume",
                    drained=result.get("drained", 0),
                )
            except Exception:
                pass
        self._apply_policy()

    def pause(self) -> None:
        """Stop all background work — OS wants quiet."""
        self._paused = True
        self.node.disable_background_refresh()
        self.node.disable_keepalive()
        self.node.audit.record("mobile.pause")

    def resume(self) -> None:
        self._paused = False
        self._apply_policy()
        self.node.audit.record("mobile.resume")

    # ---- policy application ----

    def _current_refresh_interval(self) -> int:
        p = self._policy
        base = {
            PowerMode.FOREGROUND: p.refresh_interval_foreground_s,
            PowerMode.BACKGROUND: p.refresh_interval_background_s,
            PowerMode.LOW_POWER: p.refresh_interval_low_power_s,
        }[self._power]
        if self._network_kind == NetworkKind.CELLULAR:
            base = int(base * p.cellular_multiplier)
        return base

    def _current_keepalive_interval(self) -> int:
        p = self._policy
        base = {
            PowerMode.FOREGROUND: p.keepalive_interval_foreground_s,
            PowerMode.BACKGROUND: p.keepalive_interval_background_s,
            PowerMode.LOW_POWER: p.keepalive_interval_low_power_s,
        }[self._power]
        if self._network_kind == NetworkKind.CELLULAR:
            base = int(base * p.cellular_multiplier)
        return base

    def _apply_policy(self) -> None:
        if self._paused:
            return
        refresh_s = self._current_refresh_interval()
        ka_s = self._current_keepalive_interval()
        # Refresh scheduler.
        if refresh_s > 0:
            self.node.enable_background_refresh(
                interval_s=refresh_s, start=True,
            )
        else:
            self.node.disable_background_refresh()
        # Keepalive scheduler.
        if ka_s > 0:
            self.node.enable_keepalive(interval_s=ka_s, start=True)
        else:
            self.node.disable_keepalive()

    def close(self) -> None:
        self.pause()
        self.node.close()

    def __enter__(self) -> "MobileNode":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # ---- introspection ----

    @property
    def power_mode(self) -> PowerMode:
        return self._power

    @property
    def network_kind(self) -> NetworkKind:
        return self._network_kind

    @property
    def is_paused(self) -> bool:
        return self._paused

    def status(self) -> dict:
        return {
            "peer_id": self.node.peer_id.value,
            "power_mode": self._power.value,
            "network_kind": self._network_kind.value,
            "paused": self._paused,
            "refresh_interval_s": self._current_refresh_interval(),
            "keepalive_interval_s": self._current_keepalive_interval(),
            "deferred_queue": self.node.deferred.size(),
        }
