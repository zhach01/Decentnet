"""Config file loading.

Precedence (highest to lowest):
    1. explicit CLI flags
    2. environment variables prefixed DECENTNET_
    3. TOML config file (default: $DECENTNET_CONFIG or /etc/decentnet/config.toml or ~/.decentnet/config.toml)
    4. NodeConfig defaults

TOML schema:

    [node]
    root = "/var/lib/decentnet"
    dht_k = 8

    [daemon]
    socket = "/run/decentnet/control.sock"

    [transport]
    bind_host = "0.0.0.0"
    bind_port = 41234

    [advertise]
    mode = "hybrid"   # auto | manual | hybrid
    auto_publish = true
    auto_vpn = true
    auto_lan = true

    [[advertise.manual_endpoints]]
    type = "lan_udp"
    address = "192.168.1.10:41234"
    priority = 80

    [interfaces]
    allow = ["eth0", "wlan0", "tailscale0", "wg0"]
    deny = ["lo", "docker0", "virbr0"]

    [capabilities]
    relay = false
    bootstrap_assist = false
    observer = false
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


# Python 3.11+ has tomllib stdlib.
try:
    import tomllib  # type: ignore
except ImportError:                       # pragma: no cover
    try:
        import tomli as tomllib           # type: ignore
    except ImportError:
        tomllib = None                    # type: ignore


DEFAULT_CONFIG_PATHS = [
    "/etc/decentnet/config.toml",
    "~/.decentnet/config.toml",
]


PROFILE_TEMPLATES: dict[str, dict[str, Any]] = {
    "laptop": {
        "node": {"root": "~/.decentnet", "dht_k": 8},
        "transport": {"bind_host": "0.0.0.0", "bind_port": 45001},
        "advertise": {
            "mode": "hybrid",
            "auto_publish": True,
            "auto_vpn": True,
            "auto_lan": True,
            "exclude_loopback": True,
        },
        "interfaces": {"allow": [], "deny": ["lo", "docker0", "virbr0"]},
        "capabilities": {"relay": False, "bootstrap_assist": False, "observer": False},
        "policies": {"replicate_all": True, "background_refresh_s": 60, "keepalive_s": 30, "auto_republish_s": 900},
        "metrics": {"enabled": False, "host": "127.0.0.1", "port": 9091},
    },
    "rpi": {
        "node": {"root": "/var/lib/decentnet", "dht_k": 8},
        "transport": {"bind_host": "0.0.0.0", "bind_port": 45001},
        "advertise": {
            "mode": "hybrid",
            "auto_publish": True,
            "auto_vpn": True,
            "auto_lan": True,
            "exclude_loopback": True,
        },
        "interfaces": {"allow": ["eth0", "wlan0", "tailscale0", "wg0"], "deny": ["lo", "docker0", "virbr0"]},
        "capabilities": {"relay": True, "bootstrap_assist": True, "observer": False},
        "policies": {"replicate_all": True, "background_refresh_s": 30, "keepalive_s": 20, "auto_republish_s": 600},
        "metrics": {"enabled": True, "host": "127.0.0.1", "port": 9091},
    },
    "phone": {
        "node": {"root": "~/.decentnet", "dht_k": 8},
        "transport": {"bind_host": "0.0.0.0", "bind_port": 45001},
        "advertise": {
            "mode": "auto",
            "auto_publish": True,
            "auto_vpn": True,
            "auto_lan": True,
            "exclude_loopback": True,
        },
        "interfaces": {"allow": [], "deny": ["lo", "docker0", "virbr0"]},
        "capabilities": {"relay": False, "bootstrap_assist": False, "observer": False},
        "mobile": {"cellular_multiplier": 2.0, "pause_in_background": True, "scoped_replication_only": True},
        "policies": {"replicate_all": False, "background_refresh_s": 120, "keepalive_s": 45, "auto_republish_s": 1200},
        "metrics": {"enabled": False, "host": "127.0.0.1", "port": 9091},
    },
    "helper": {
        "node": {"root": "/var/lib/decentnet", "dht_k": 8},
        "transport": {"bind_host": "0.0.0.0", "bind_port": 45001},
        "advertise": {
            "mode": "hybrid",
            "auto_publish": True,
            "auto_vpn": True,
            "auto_lan": True,
            "exclude_loopback": True,
        },
        "interfaces": {"allow": ["eth0", "wlan0", "tailscale0", "wg0"], "deny": ["lo", "docker0", "virbr0"]},
        "capabilities": {"relay": True, "bootstrap_assist": True, "observer": True},
        "policies": {"replicate_all": True, "background_refresh_s": 30, "keepalive_s": 20, "auto_republish_s": 300},
        "metrics": {"enabled": True, "host": "127.0.0.1", "port": 9091},
    },
}


def list_profiles() -> list[str]:
    return sorted(PROFILE_TEMPLATES)


def get_profile_template(name: str) -> dict[str, Any]:
    import copy
    try:
        return copy.deepcopy(PROFILE_TEMPLATES[name])
    except KeyError as e:
        raise KeyError(f"unknown profile {name!r}; available: {', '.join(list_profiles())}") from e


def render_profile_toml(name: str, *, root_override: Optional[str] = None) -> str:
    data = get_profile_template(name)
    if root_override:
        data.setdefault('node', {})['root'] = root_override
    lines: list[str] = [f"# DecentNet peer profile: {name}", ""]
    order = [
        'node', 'daemon', 'transport', 'advertise', 'interfaces',
        'capabilities', 'policies', 'logging', 'mobile', 'metrics',
    ]
    def fmt(v: Any) -> str:
        if isinstance(v, bool):
            return 'true' if v else 'false'
        if isinstance(v, (int, float)):
            return str(v)
        if isinstance(v, str):
            return '"' + v.replace('\\', '\\\\').replace('"', '\\"') + '"'
        if isinstance(v, list):
            return '[' + ', '.join(fmt(x) for x in v) + ']'
        raise TypeError(type(v))
    for sec in order:
        sec_data = data.get(sec)
        if not sec_data:
            continue
        lines.append(f"[{sec}]")
        scalar_keys=[]
        list_tables=[]
        for k,v in sec_data.items():
            if isinstance(v, list) and v and all(isinstance(i, dict) for i in v):
                list_tables.append((k,v))
            else:
                scalar_keys.append((k,v))
        for k,v in scalar_keys:
            lines.append(f"{k} = {fmt(v)}")
        for k,items in list_tables:
            lines.append('')
            for item in items:
                lines.append(f"[[{sec}.{k}]]")
                for ik,iv in item.items():
                    lines.append(f"{ik} = {fmt(iv)}")
        lines.append('')
    return '\n'.join(lines).rstrip() + '\n'





def infer_profile_name(cfg: "DecentnetConfig") -> Optional[str]:
    """Best-effort profile hint based on a few distinctive fields."""
    caps = cfg.capabilities
    mobile = cfg.mobile
    if caps.relay and caps.bootstrap_assist and caps.observer:
        return "helper"
    if caps.relay and caps.bootstrap_assist:
        return "rpi"
    if mobile.pause_in_background:
        return "phone"
    return "laptop"


def describe_endpoint_strategy(cfg: "DecentnetConfig") -> str:
    mode = (cfg.advertise.mode or 'hybrid').strip().lower()
    parts: list[str] = []
    if mode == 'manual':
        parts.append('manual advertised endpoints only')
    elif mode == 'auto':
        parts.append('automatic endpoint discovery')
    else:
        parts.append('hybrid manual + automatic endpoint discovery')
    autos: list[str] = []
    if cfg.advertise.auto_lan:
        autos.append('LAN')
    if cfg.advertise.auto_vpn:
        autos.append('VPN')
    if autos:
        parts.append('auto sources: ' + ', '.join(autos))
    if cfg.interfaces.allow:
        parts.append('allow interfaces: ' + ', '.join(cfg.interfaces.allow))
    if cfg.interfaces.deny:
        parts.append('deny interfaces: ' + ', '.join(cfg.interfaces.deny))
    return '; '.join(parts)


def validate_peer_config(cfg: "DecentnetConfig") -> dict[str, list[str]]:
    warnings: list[str] = []
    errors: list[str] = []
    bind_host = (cfg.transport.bind_host or '0.0.0.0').strip().lower()
    loopback_only = bind_host.startswith('127.') or bind_host == 'localhost'
    mode = (cfg.advertise.mode or 'hybrid').strip().lower()
    if mode not in {'auto', 'manual', 'hybrid', ''}:
        errors.append(f'advertise.mode {cfg.advertise.mode!r} is invalid')
    if loopback_only and cfg.capabilities.relay:
        warnings.append('relay capability is enabled but transport.bind_host is loopback-only')
    if loopback_only and cfg.advertise.auto_lan:
        warnings.append('transport.bind_host is loopback-only while advertise.auto_lan is enabled')
    if loopback_only and cfg.advertise.auto_vpn:
        warnings.append('transport.bind_host is loopback-only while advertise.auto_vpn is enabled')
    for item in cfg.advertise.manual_endpoints:
        addr = str(item.get('address', '')).strip()
        if not addr:
            warnings.append('manual endpoint with empty address was ignored')
            continue
        host = addr.rsplit(':', 1)[0].strip('[]').lower()
        if loopback_only and host not in {'127.0.0.1', 'localhost'}:
            warnings.append(f'manual endpoint {addr} is non-loopback but transport.bind_host is loopback-only')
        if cfg.advertise.exclude_loopback and host in {'127.0.0.1', 'localhost'}:
            warnings.append(f'manual endpoint {addr} is loopback while advertise.exclude_loopback is enabled')
    if not cfg.interfaces.allow and all(name in cfg.interfaces.deny for name in ['lo', 'docker0', 'virbr0']):
        warnings.append('no interface allow-list configured; endpoint auto-selection may include unexpected interfaces on complex hosts')
    return {'warnings': warnings, 'errors': errors}

@dataclass
class NodeSection:
    root: Optional[str] = None
    dht_k: int = 8


@dataclass
class DaemonSection:
    socket: Optional[str] = None
    udp_port: int = 0




@dataclass
class TransportSection:
    bind_host: str = "0.0.0.0"
    bind_port: int = 0


@dataclass
class AdvertiseSection:
    mode: str = "hybrid"
    auto_publish: bool = True
    auto_vpn: bool = True
    auto_lan: bool = True
    vpn_port: int = 0
    lan_port: int = 0
    exclude_loopback: bool = True
    manual_endpoints: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class InterfacesSection:
    allow: list[str] = field(default_factory=list)
    deny: list[str] = field(default_factory=lambda: ["lo", "docker0", "virbr0"])


@dataclass
class CapabilitiesSection:
    relay: bool = False
    bootstrap_assist: bool = False
    observer: bool = False


@dataclass
class PoliciesSection:
    replicate_all: bool = True
    background_refresh_s: int = 60
    keepalive_s: int = 30
    auto_republish_s: int = 900


@dataclass
class LoggingSection:
    level: str = "info"
    audit_max_bytes: int = 10 * 1024 * 1024
    audit_keep_rotated: int = 5
    audit_max_memory_entries: int = 10_000


@dataclass
class MobileSection:
    cellular_multiplier: float = 2.0
    pause_in_background: bool = False
    scoped_replication_only: bool = True


@dataclass
class MetricsSection:
    enabled: bool = False
    host: str = "127.0.0.1"
    port: int = 9091


@dataclass
class DecentnetConfig:
    node: NodeSection = field(default_factory=NodeSection)
    daemon: DaemonSection = field(default_factory=DaemonSection)
    transport: TransportSection = field(default_factory=TransportSection)
    advertise: AdvertiseSection = field(default_factory=AdvertiseSection)
    interfaces: InterfacesSection = field(default_factory=InterfacesSection)
    capabilities: CapabilitiesSection = field(default_factory=CapabilitiesSection)
    policies: PoliciesSection = field(default_factory=PoliciesSection)
    logging: LoggingSection = field(default_factory=LoggingSection)
    mobile: MobileSection = field(default_factory=MobileSection)
    metrics: MetricsSection = field(default_factory=MetricsSection)

    @classmethod
    def load(
        cls,
        path: Optional[str | Path] = None,
        *,
        env: Optional[dict[str, str]] = None,
    ) -> "DecentnetConfig":
        cfg = cls()
        resolved_path = _resolve_config_path(path)
        if resolved_path is not None:
            cfg._apply_toml(resolved_path)
        cfg._apply_env(env if env is not None else os.environ)
        return cfg

    # ---- internal loaders ----

    def _apply_toml(self, path: Path) -> None:
        if tomllib is None:
            raise RuntimeError(
                "TOML parsing not available; upgrade to Python 3.11+ "
                "or install tomli."
            )
        with path.open("rb") as f:
            data = tomllib.load(f)
        for section, obj in (
            ("node", self.node),
            ("daemon", self.daemon),
            ("transport", self.transport),
            ("advertise", self.advertise),
            ("interfaces", self.interfaces),
            ("capabilities", self.capabilities),
            ("policies", self.policies),
            ("logging", self.logging),
            ("mobile", self.mobile),
            ("metrics", self.metrics),
        ):
            section_data = data.get(section, {})
            if section == "advertise" and isinstance(section_data, dict):
                manual = data.get("advertise", {}).get("manual_endpoints")
                if isinstance(manual, list):
                    self.advertise.manual_endpoints = [dict(item) for item in manual if isinstance(item, dict)]
            for k, v in section_data.items():
                if k == "manual_endpoints":
                    continue
                if hasattr(obj, k):
                    setattr(obj, k, v)

    def _apply_env(self, env: dict) -> None:
        # Flat mapping: DECENTNET_<SECTION>_<KEY>.
        for raw_key, raw_val in env.items():
            if not raw_key.startswith("DECENTNET_"):
                continue
            _, _, tail = raw_key.partition("DECENTNET_")
            parts = tail.lower().split("_", 1)
            if len(parts) != 2:
                continue
            section_name, key = parts
            section = getattr(self, section_name, None)
            if section is None or not hasattr(section, key):
                continue
            current = getattr(section, key)
            try:
                if isinstance(current, bool):
                    new = raw_val.lower() in ("1", "true", "yes", "on")
                elif isinstance(current, int):
                    new = int(raw_val)
                elif isinstance(current, float):
                    new = float(raw_val)
                else:
                    new = raw_val
            except ValueError:
                continue
            setattr(section, key, new)




def startup_blockers(cfg: "DecentnetConfig") -> list[str]:
    """Return deployment issues serious enough to refuse peer startup."""
    blockers: list[str] = []
    cv = validate_peer_config(cfg)
    blockers.extend(cv.get('errors', []))
    bind_host = (cfg.transport.bind_host or '0.0.0.0').strip().lower()
    loopback_only = bind_host.startswith('127.') or bind_host == 'localhost'
    non_loopback_manual = []
    for item in cfg.advertise.manual_endpoints:
        addr = str(item.get('address', '')).strip()
        if not addr:
            continue
        host = addr.rsplit(':', 1)[0].strip('[]').lower()
        if host not in {'127.0.0.1', 'localhost'}:
            non_loopback_manual.append(addr)
    if loopback_only and non_loopback_manual:
        blockers.append('loopback-only bind cannot serve non-loopback manual endpoints')
    if loopback_only and cfg.capabilities.relay:
        blockers.append('loopback-only bind cannot expose relay capability to other peers')
    if loopback_only and (cfg.advertise.auto_lan or cfg.advertise.auto_vpn):
        blockers.append('loopback-only bind is incompatible with automatic LAN/VPN reachability')
    return blockers


def apply_runtime_overrides(cfg: "DecentnetConfig", *, bind_host: str | None = None, bind_port: int | None = None) -> "DecentnetConfig":
    if bind_host:
        cfg.transport.bind_host = bind_host
    if bind_port is not None and bind_port != 0:
        cfg.transport.bind_port = bind_port
    return cfg


def _resolve_config_path(path: Optional[str | Path]) -> Optional[Path]:
    if path is not None:
        p = Path(path).expanduser()
        return p if p.exists() else None
    env_path = os.environ.get("DECENTNET_CONFIG")
    if env_path:
        p = Path(env_path).expanduser()
        if p.exists():
            return p
    for candidate in DEFAULT_CONFIG_PATHS:
        p = Path(candidate).expanduser()
        if p.exists():
            return p
    return None
