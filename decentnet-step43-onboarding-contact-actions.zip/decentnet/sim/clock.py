"""VirtualClock — a controllable time source for the simulator.

Usage
-----
    clock = VirtualClock(start=1_700_000_000)
    with clock.install():
        # Inside this block, decentnet.utils.time.now_s() returns the
        # virtual clock's current value.
        clock.advance(60)     # jump 60 virtual seconds
        clock.tick()          # advance 1 virtual second

Outside the context manager, the real system clock is restored.

The virtual clock also supports timers: register a callback to fire
when the clock reaches or passes a given time. Used by the scheduled
republish loop and by scenarios that model "in one hour, node X goes
offline".
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Callable, Iterator

from ..utils.time import install_clock, reset_clock


TimerCallback = Callable[[], None]


@dataclass(order=True)
class _Timer:
    fires_at: float
    seq: int
    cb: TimerCallback = field(compare=False)


class VirtualClock:
    def __init__(self, start: float = 1_700_000_000.0) -> None:
        self._now = float(start)
        self._timers: list[_Timer] = []
        self._next_seq = 0

    # -------- time --------

    def time(self) -> float:
        return self._now

    def advance(self, seconds: float) -> None:
        """Move the clock forward `seconds` virtual seconds, firing any
        timers that become due along the way in chronological order."""
        target = self._now + float(seconds)
        while True:
            due = [t for t in self._timers if t.fires_at <= target]
            if not due:
                break
            due.sort(key=lambda t: (t.fires_at, t.seq))
            t = due[0]
            self._timers.remove(t)
            self._now = max(self._now, t.fires_at)
            try:
                t.cb()
            except Exception:
                pass
        self._now = target

    def tick(self) -> None:
        self.advance(1.0)

    def set(self, t: float) -> None:
        self.advance(float(t) - self._now)

    # -------- timers --------

    def at(self, when: float, cb: TimerCallback) -> None:
        self._next_seq += 1
        self._timers.append(_Timer(fires_at=float(when), seq=self._next_seq, cb=cb))

    def after(self, delay: float, cb: TimerCallback) -> None:
        self.at(self._now + float(delay), cb)

    def pending_timer_count(self) -> int:
        return len(self._timers)

    def clear_timers(self) -> None:
        self._timers.clear()

    # -------- install / uninstall --------

    @contextmanager
    def install(self) -> Iterator["VirtualClock"]:
        install_clock(self.time)
        try:
            yield self
        finally:
            reset_clock()
