"""SimNetwork — a harness for building networks of decentnet nodes.

Phase 2 uses this purely to drive the test suite and expose typical
scenarios (publish, lookup, churn, partition, anti-entropy) in a
compact, reusable way. Phase 3 will extend it with virtual clock
control, record corruption injection, noisy-neighbour bots, and
visualization outputs.
"""
from __future__ import annotations

import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional

from ..node.config import NodeConfig
from ..node.node import Node
from ..records.endpoints import Endpoint
from ..records.locator import LocatorRecord
from ..transport.inproc import InProcessNetwork


@dataclass
class SimNetwork:
    """A set of Phase-2 networked Nodes sharing one InProcessNetwork."""

    net: InProcessNetwork = field(default_factory=InProcessNetwork)
    nodes: list[Node] = field(default_factory=list)
    _root: Optional[Path] = None
    _tmpdir: Optional[tempfile.TemporaryDirectory] = None

    # ---- construction ----

    @classmethod
    def build(cls, n: int, *, k: int = 8) -> "SimNetwork":
        sim = cls()
        sim._tmpdir = tempfile.TemporaryDirectory()
        sim._root = Path(sim._tmpdir.name)
        # Create n nodes.
        bootstrap: list[tuple[str, str]] = []
        for i in range(n):
            cfg = NodeConfig.at(sim._root / f"n{i}")
            node = Node(cfg, network=sim.net, dht_k=k)
            # First node acts as seed for subsequent.
            if bootstrap:
                node.join_network(bootstrap)
            bootstrap.append((node.peer_id.value, f"inproc:{node.peer_id.short()}"))
            sim.nodes.append(node)
        # Give every node a chance to fill its routing table.
        for node in sim.nodes:
            if len(bootstrap) > 1:
                node.join_network(bootstrap[:5])   # seed with first few
        return sim

    # ---- access ----

    def __len__(self) -> int:
        return len(self.nodes)

    def __getitem__(self, i: int) -> Node:
        return self.nodes[i]

    def peer_ids(self) -> list[str]:
        return [n.peer_id.value for n in self.nodes]

    def find_by_peer_id(self, pid: str) -> Optional[Node]:
        for n in self.nodes:
            if n.peer_id.value == pid:
                return n
        return None

    # ---- network ops ----

    def publish(
        self,
        node: Node,
        endpoints: Iterable[Endpoint],
        **kwargs,
    ) -> LocatorRecord:
        """Publish `node`'s record to the whole network (both the local
        cache and the DHT)."""
        rec = node.publish_own_record(list(endpoints), **kwargs)
        node.publish_to_network()
        return rec

    def go_offline(self, i_or_node) -> None:
        node = self.nodes[i_or_node] if isinstance(i_or_node, int) else i_or_node
        self.net.set_offline(node.peer_id.value)

    def come_online(self, i_or_node) -> None:
        node = self.nodes[i_or_node] if isinstance(i_or_node, int) else i_or_node
        self.net.set_online(node.peer_id.value)

    def partition(self, *groups_of_indices: set[int]) -> None:
        groups = []
        for g in groups_of_indices:
            groups.append({self.nodes[i].peer_id.value for i in g})
        self.net.partition(*groups)

    def heal(self) -> None:
        self.net.heal_partition()

    # ---- adversary primitives (Phase Final) ----

    def inject_corrupt_replica(
        self, node, target_peer_id: str, *, fake_address: str = "6.6.6.6:6"
    ) -> None:
        """Force `node` to advertise a forged record for `target_peer_id`.

        We fabricate a record with a wrong public_key (so peers will
        reject it on validation). This simulates a malicious DHT
        replica; the simulator records that the injection happened
        and tests can then assert that no honest peer accepted it.
        """
        from ..identity.keypair import Keypair
        from ..identity.peer_id import PeerId
        from ..records.endpoints import Endpoint
        from ..records.locator import LocatorRecord
        attacker = Keypair.generate()
        # The forged record's signature *will* verify against attacker's
        # key, but b32(sha256(attacker_pubkey)) != target_peer_id, so
        # `LocatorRecord.verify()` rejects on the first integrity check.
        forged = LocatorRecord.build_and_sign(
            attacker,
            endpoints=[Endpoint(type="public_udp", address=fake_address)],
            seq=999_999,
        )
        # Splice peer_id to the target, leaving signature/pubkey wrong.
        forged.peer_id = target_peer_id
        # Direct write into THIS node's DHT replica store (bypass
        # validation): it's a "this is what a malicious peer holds".
        if node.directory is not None:
            with node.directory.store._lock:
                node.directory.store._records[target_peer_id] = forged
        node.audit.record(
            "sim.inject_corrupt_replica",
            target=target_peer_id,
            fake_address=fake_address,
        )

    def start_noisy_neighbor(
        self,
        attacker_node,
        target_node,
        *,
        rate_per_step: int = 5,
    ) -> None:
        """Mark `attacker_node` as a "noisy neighbor" of `target_node`.

        On each scenario step, the runner calls `step_noisy_neighbors()`
        which fires `rate_per_step` malformed datagrams from attacker
        to target. The transport's rate limiter and JSON parser drop
        them; the test asserts the limiter / drop counters move."""
        if not hasattr(self, "_noisy"):
            self._noisy = []
        self._noisy.append((attacker_node, target_node, rate_per_step))

    def step_noisy_neighbors(self) -> int:
        """Fire one round of noisy-neighbor traffic. Returns total
        datagrams attempted."""
        if not hasattr(self, "_noisy"):
            return 0
        from ..transport.messages import Message
        sent = 0
        for atk, tgt, rate in self._noisy:
            for i in range(rate):
                try:
                    # Send a junk Message (parses fine, fails validation
                    # on the receiver because the sender claims a peer_id
                    # we've never resolved).
                    msg = Message(
                        type="junk",
                        sender=atk.peer_id.value,
                        msg_id=f"noisy-{sent}",
                        payload={"x": "y"},
                    )
                    atk._transport.send(tgt.peer_id.value, msg)
                except Exception:
                    pass
                sent += 1
        return sent

    def make_silent(self, node) -> None:
        """Mark a node as silent — present but refuses to answer
        anything (drops every incoming message)."""
        if node._transport is None:
            return
        original_handler = node._transport._handler
        def _drop(*_args, **_kwargs):
            pass
        node._transport._handler = _drop
        # Save so we could restore.
        if not hasattr(self, "_silenced"):
            self._silenced = {}
        self._silenced[node.peer_id.value] = original_handler

    def restore_silenced(self, node) -> None:
        if not hasattr(self, "_silenced"):
            return
        h = self._silenced.pop(node.peer_id.value, None)
        if h is not None and node._transport is not None:
            node._transport._handler = h

    # ---- cleanup ----

    def shutdown(self) -> None:
        for node in self.nodes:
            try:
                node.close()
            except Exception:
                pass
        if self._tmpdir is not None:
            self._tmpdir.cleanup()

    def __enter__(self) -> "SimNetwork":
        return self

    def __exit__(self, *exc) -> None:
        self.shutdown()
