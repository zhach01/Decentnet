"""Built-in scenarios.

Each scenario is a function that returns a Scenario object with its
steps wired up. The runner drives them.

Run via:
    python -m decentnet sim list
    python -m decentnet sim run <name> --output <dir>
"""
from __future__ import annotations

import json
from typing import Callable

from ..records.endpoints import Endpoint
from ..records.locator import LocatorRecord
from .scenario import Scenario, ScenarioContext


# -- helpers ---------------------------------------------------------


def _pub(ctx: ScenarioContext, address: str) -> LocatorRecord:
    return ctx.sim.publish(
        ctx.sim[0],
        [Endpoint(type="public_udp", address=address)],
    )


# -- scenarios -------------------------------------------------------


def scenario_publish_and_resolve() -> Scenario:
    sc = Scenario(
        name="publish_and_resolve",
        description="Publisher publishes; every other node resolves via the DHT.",
        n_nodes=6,
        k=4,
    )

    def setup(ctx: ScenarioContext) -> None:
        # Publisher identity = node 0. Bootstrap already done by SimNetwork.build().
        ctx.note("node[0] is the publisher; others start with no record of it")

    sc.setup = setup

    sc.add(
        "01 publish v1",
        lambda ctx: (_pub(ctx, "1.1.1.1:1111")
                     and "publisher pushes v1 to its k-closest replicas"),
    )

    def resolve_all(ctx: ScenarioContext) -> str:
        pub_id = ctx.sim[0].peer_id.value
        for n in ctx.sim.nodes[1:]:
            n.resolve(pub_id, force_network=True)
        return "every non-publisher runs resolve() with write-through to L1"

    sc.add("02 resolve from every peer", resolve_all)
    return sc


def scenario_stale_vs_fresh() -> Scenario:
    sc = Scenario(
        name="stale_vs_fresh",
        description="Publisher updates; stale replicas get replaced via seq precedence.",
        n_nodes=5,
    )

    sc.add(
        "01 publish v1",
        lambda ctx: (_pub(ctx, "1.1.1.1:1111") and "v1 broadcast"),
    )
    sc.add(
        "02 publish v2 (IP change)",
        lambda ctx: (_pub(ctx, "2.2.2.2:2222")
                     and "seq bumps; (seq, issued_at) precedence overrides v1 everywhere"),
    )

    def resolve_all(ctx: ScenarioContext) -> str:
        pub_id = ctx.sim[0].peer_id.value
        for n in ctx.sim.nodes[1:]:
            n.resolve(pub_id, force_network=True)
        return "non-publishers resolve; all should see v2"

    sc.add("03 resolve from all peers", resolve_all)
    return sc


def scenario_partition_then_merge() -> Scenario:
    sc = Scenario(
        name="partition_then_merge",
        description="Partition splits A vs B. Update on A side. After heal, "
                    "anti-entropy propagates to B.",
        n_nodes=6,
    )

    sc.add(
        "01 publish v1 across whole net",
        lambda ctx: (_pub(ctx, "1.1.1.1:1111")
                     and "everyone holds v1 via initial DHT publish"),
    )

    def partition(ctx: ScenarioContext) -> str:
        ctx.sim.partition({0, 1, 2}, {3, 4, 5})
        return "network split: group A={0,1,2}, group B={3,4,5}"

    sc.add("02 partition", partition)

    def update_on_a(ctx: ScenarioContext) -> str:
        _pub(ctx, "2.2.2.2:2222")
        return "publisher (node[0], A-side) republishes v2; B-side cannot see it"

    sc.add("03 publish v2 (A-side only)", update_on_a)

    def heal(ctx: ScenarioContext) -> str:
        ctx.sim.heal()
        return "partition healed; DHT edges restored but stores are now divergent"

    sc.add("04 heal partition", heal)

    def anti_entropy(ctx: ScenarioContext) -> str:
        pub_id = ctx.sim[0].peer_id.value
        # Find any A-side node that holds v2.
        a_holder = None
        for i in (0, 1, 2):
            r = ctx.sim[i].dht_store().peek(pub_id)
            if r is not None and r.seq == 2:
                a_holder = ctx.sim[i]
                break
        # Every B-side node syncs with that holder.
        for i in (3, 4, 5):
            ctx.sim[i].sync_with(a_holder.peer_id.value)
        return "B-side runs sync_with(A-holder); RECORD_PUSH updates B's stores"

    sc.add("05 anti-entropy repair (B ← A)", anti_entropy)
    return sc


def scenario_primary_loss_and_reconstruction() -> Scenario:
    sc = Scenario(
        name="primary_loss_and_reconstruction",
        description="Publisher vanishes; a late joiner evicts its copy and "
                    "re-learns via anti-entropy from a surviving replica.",
        n_nodes=6,
    )

    sc.add(
        "01 publish v1",
        lambda ctx: (_pub(ctx, "1.1.1.1:1111") and "v1 broadcast across the DHT"),
    )

    def publisher_offline(ctx: ScenarioContext) -> str:
        ctx.sim.go_offline(ctx.sim[0])
        return "publisher (node[0]) is offline; its replicas persist elsewhere"

    sc.add("02 publisher goes offline", publisher_offline)

    def evict_late_joiner(ctx: ScenarioContext) -> str:
        pub_id = ctx.sim[0].peer_id.value
        # Node 5 is our "late joiner": drop its DHT copy.
        ctx.sim[5].dht_store().evict(pub_id)
        return "node[5] evicts its copy (modelling memory loss / restart-without-disk)"

    sc.add("03 node[5] loses its copy", evict_late_joiner)

    def rebuild(ctx: ScenarioContext) -> str:
        pub_id = ctx.sim[0].peer_id.value
        holder = None
        for i in (1, 2, 3, 4):
            if ctx.sim[i].dht_store().peek(pub_id) is not None:
                holder = ctx.sim[i]
                break
        ctx.sim[5].sync_with(holder.peer_id.value)
        return f"node[5] sync_with(node[{ctx.sim.nodes.index(holder)}]); record restored"

    sc.add("04 anti-entropy rebuild", rebuild)
    return sc


def scenario_replay_and_tamper_rejection() -> Scenario:
    sc = Scenario(
        name="replay_and_tamper_rejection",
        description="Attacker replays old record and tampers with new one. "
                    "Both rejected by signature + seq precedence.",
        n_nodes=4,
    )

    sc.add(
        "01 publish v1",
        lambda ctx: (_pub(ctx, "1.1.1.1:1111") and "v1 broadcast"),
    )

    def capture_v1_and_publish_v2(ctx: ScenarioContext) -> str:
        # Save v1 wire bytes (captured by attacker).
        ctx._captured_v1 = ctx.sim[0].export_own_record()
        _pub(ctx, "2.2.2.2:2222")
        return "attacker captured v1 wire bytes; publisher moves on to v2"

    sc.add("02 publish v2 (v1 now outdated)", capture_v1_and_publish_v2)

    def replay_v1(ctx: ScenarioContext) -> str:
        r = ctx.sim[2].ingest_record_bytes(ctx._captured_v1, source="attacker-replay")
        return f"attacker replays v1 to node[2]: accepted={r.accepted} reason={r.reason}"

    sc.add("03 replay v1 — rejected (not_newer)", replay_v1)

    def tamper_v2(ctx: ScenarioContext) -> str:
        wire = ctx.sim[0].export_own_record()
        obj = json.loads(wire)
        obj["endpoints"][0]["address"] = "9.9.9.9:9999"
        corrupted = json.dumps(obj).encode()
        r = ctx.sim[3].ingest_record_bytes(corrupted, source="attacker-tamper")
        return f"attacker tampers v2 and pushes to node[3]: " \
               f"accepted={r.accepted} reason={r.reason}"

    sc.add("04 tamper v2 — rejected (signature)", tamper_v2)
    return sc


# --------------------------------------------------------------------
# Phase Final scenarios — closing the gaps from the original brief.


def scenario_ip_change_without_refresh() -> Scenario:
    """Publisher's IP changes silently — they don't republish.
    Resolvers should keep using the (now stale) record until expiry,
    then trigger a fresh resolve and notice the new endpoint."""
    sc = Scenario(
        name="ip_change_without_refresh",
        description="Silent IP change; resolvers eventually re-resolve and pick up new endpoint.",
        n_nodes=4, k=3,
    )

    def step1(ctx):
        _pub(ctx, "1.1.1.1:1111")
        return "publisher publishes initial endpoint"
    sc.add("01 publish initial", step1)

    def step2(ctx):
        ctx.sim[1].resolve(ctx.sim[0].peer_id.value, force_network=True)
        rec = ctx.sim[1].lookup(ctx.sim[0].peer_id.value)
        return f"node[1] resolved → {rec.endpoints[0].address}"
    sc.add("02 resolve once", step2)

    def step3(ctx):
        # Publisher's IP changes (new physical move) but they don't
        # republish. From the network's view the old record is still
        # the latest known.
        ctx.note("publisher's IP silently changes (no republish)")
        return "publisher now lives at 9.9.9.9 but hasn't told anyone"
    sc.add("03 silent IP change", step3)

    def step4(ctx):
        # Eventually the publisher republishes (e.g. via the
        # republish loop) — the new record propagates.
        ctx.sim.publish(
            ctx.sim[0],
            [Endpoint(type="public_udp", address="9.9.9.9:9999")],
        )
        return "publisher republishes with new endpoint"
    sc.add("04 publisher catches up", step4)

    def step5(ctx):
        ctx.sim[1].resolve(ctx.sim[0].peer_id.value, force_network=True)
        rec = ctx.sim[1].lookup(ctx.sim[0].peer_id.value)
        return f"node[1] now sees {rec.endpoints[0].address} (seq={rec.seq})"
    sc.add("05 resolver picks up new endpoint", step5)
    return sc


def scenario_endpoint_remap() -> Scenario:
    """NAT rebinding mid-life: same peer keeps same key, new external
    port. Republish with bumped seq supersedes the old endpoint."""
    sc = Scenario(
        name="endpoint_remap",
        description="NAT rebinds; peer republishes with new external port; replicas adopt newer record.",
        n_nodes=5, k=4,
    )

    def step1(ctx):
        _pub(ctx, "5.5.5.5:5555")
        return "initial publish at port 5555"
    sc.add("01 publish v1", step1)

    def step2(ctx):
        ctx.sim.publish(
            ctx.sim[0],
            [Endpoint(type="public_udp", address="5.5.5.5:6666")],
        )
        return "NAT remapped to port 6666; republish with new endpoint"
    sc.add("02 remap + republish v2", step2)

    def step3(ctx):
        ctx.sim[2].resolve(ctx.sim[0].peer_id.value, force_network=True)
        rec = ctx.sim[2].lookup(ctx.sim[0].peer_id.value)
        return f"resolver sees port {rec.endpoints[0].address.split(':')[1]} seq={rec.seq}"
    sc.add("03 resolver gets new mapping", step3)
    return sc


def scenario_concurrent_updates_seq_conflict() -> Scenario:
    """Two devices mistakenly running with the same key publish
    concurrently. Highest (seq, issued_at) wins; both replicas
    converge on the winner."""
    sc = Scenario(
        name="concurrent_updates_seq_conflict",
        description="Two publishers race; precedence by (seq, issued_at) decides the winner.",
        n_nodes=4, k=3,
    )

    def step1(ctx):
        _pub(ctx, "1.1.1.1:1111")
        return "publisher (node 0) publishes v1"
    sc.add("01 publish v1", step1)

    def step2(ctx):
        # Simulate a "second device" publishing with same key by
        # advancing the seq and re-publishing.
        ctx.sim.publish(
            ctx.sim[0],
            [Endpoint(type="public_udp", address="2.2.2.2:2222")],
        )
        return "concurrent device publishes v2 with new endpoint"
    sc.add("02 publish v2", step2)

    def step3(ctx):
        rec = ctx.sim[2].resolve(
            ctx.sim[0].peer_id.value, force_network=True
        )
        return f"resolver gets seq={rec.seq} addr={rec.endpoints[0].address}"
    sc.add("03 resolver sees latest", step3)
    return sc


def scenario_symmetric_nat_relay_path() -> Scenario:
    """Two peers behind 'symmetric' NATs (modeled as nodes that go
    offline at the direct-transport layer) fall back to a relay path,
    which is just signaling-via-DHT."""
    sc = Scenario(
        name="symmetric_nat_relay_path",
        description="Direct path blocked → DHT-mediated signaling still resolves both peers; relay-style fallback path stays open.",
        n_nodes=4, k=3,
    )

    def step1(ctx):
        _pub(ctx, "10.0.0.1:1")
        ctx.sim.publish(
            ctx.sim[1],
            [Endpoint(type="lan_udp", address="10.0.0.2:2")],
        )
        # Warm caches on the intermediaries BEFORE partitioning, so
        # replicas are present to serve lookups after the split.
        for n in ctx.sim.nodes[2:]:
            n.resolve(ctx.sim[0].peer_id.value, force_network=True)
            n.resolve(ctx.sim[1].peer_id.value, force_network=True)
        return "both peers publish to DHT; intermediaries warmed"
    sc.add("01 both publish", step1)

    def step2(ctx):
        # Simulate symmetric NAT: pretend nodes 0 and 1 can no longer
        # talk directly, but their DHT replicas remain reachable via
        # neighbours.
        ctx.sim.partition({0, 2, 3}, {1, 2, 3})
        return "partition: 0 and 1 no longer reach each other directly"
    sc.add("02 partition direct path", step2)

    def step3(ctx):
        # Each can still resolve the other via the DHT (replicated on
        # neighbours), demonstrating the signaling path stays open
        # for relay-style negotiation.
        rec1 = ctx.sim[0].resolve(ctx.sim[1].peer_id.value, force_network=True)
        rec0 = ctx.sim[1].resolve(ctx.sim[0].peer_id.value, force_network=True)
        addr0 = rec1.endpoints[0].address if rec1 else "none"
        addr1 = rec0.endpoints[0].address if rec0 else "none"
        return f"mutual DHT-mediated resolve via intermediaries: 0→{addr0} 1→{addr1}"
    sc.add("03 mutual DHT-mediated resolve", step3)

    def step4(ctx):
        ctx.sim.heal()
        return "partition healed; direct path restored"
    sc.add("04 heal", step4)
    return sc


def scenario_cache_warming() -> Scenario:
    """A burst of resolves warms multiple caches; subsequent lookups
    are L1 hits (no network traffic)."""
    sc = Scenario(
        name="cache_warming",
        description="Burst of cold resolves populates L1 caches; subsequent lookups become hits.",
        n_nodes=5, k=4,
    )

    def step1(ctx):
        _pub(ctx, "1.1.1.1:1")
        return "publisher publishes"
    sc.add("01 publish", step1)

    def step2(ctx):
        for n in ctx.sim.nodes[1:]:
            n.resolve(ctx.sim[0].peer_id.value, force_network=True)
        return "all peers resolve once (cold) — caches now warm"
    sc.add("02 cold resolve burst", step2)

    def step3(ctx):
        hits = 0
        for n in ctx.sim.nodes[1:]:
            if n.lookup(ctx.sim[0].peer_id.value) is not None:
                hits += 1
        return f"L1 hit count: {hits} of {len(ctx.sim.nodes) - 1}"
    sc.add("03 L1 hit count", step3)
    return sc


def scenario_mass_churn() -> Scenario:
    """High churn rate: half the peers go offline+online in each round.
    The DHT keeps healing via anti-entropy."""
    sc = Scenario(
        name="mass_churn",
        description="Half the network churns each round; data survives via anti-entropy.",
        n_nodes=8, k=4,
    )

    def step1(ctx):
        _pub(ctx, "1.1.1.1:1")
        return "node 0 publishes; replicates to k-closest"
    sc.add("01 publish", step1)

    def step2(ctx):
        for i in range(2, 6):
            ctx.sim.go_offline(i)
        return "nodes 2..5 go offline (50% of fabric)"
    sc.add("02 churn offline", step2)

    def step3(ctx):
        for i in range(2, 6):
            ctx.sim.come_online(i)
        # Anti-entropy: alive peers pull from each other on next sync.
        ctx.sim[1].sync_with(ctx.sim[6].peer_id.value)
        ctx.sim[6].sync_with(ctx.sim[7].peer_id.value)
        return "back online + anti-entropy round"
    sc.add("03 churn online + sync", step3)

    def step4(ctx):
        rec = ctx.sim[7].resolve(ctx.sim[0].peer_id.value, force_network=True)
        return f"node[7] resolves publisher: addr={rec.endpoints[0].address}"
    sc.add("04 resolve survives", step4)
    return sc


def scenario_popularity_eviction_multi_node() -> Scenario:
    """Multi-node version of cache eviction: less-accessed records
    on a small-capacity node are evicted while popular ones remain."""
    sc = Scenario(
        name="popularity_eviction_multi_node",
        description="Tight cache + many records → least-popular evicted; popular survive.",
        n_nodes=6, k=4,
    )

    def step1(ctx):
        # node 0 holds many records; we'll set its cache cap low.
        ctx.sim[0].cache._max_records = 3
        ctx.note("node[0]: max_records=3")
        # Publish records from nodes 1..5; node 0 receives them via
        # bootstrap+gossip.
        for i in range(1, 6):
            ctx.sim.publish(
                ctx.sim[i],
                [Endpoint(type="public_udp", address=f"1.1.1.{i}:1{i}")],
            )
        return "5 distinct peers publish; node[0] cache capped at 3"
    sc.add("01 publish 5 records", step1)

    def step2(ctx):
        # Boost popularity of nodes 4 and 5 by repeated lookups.
        for _ in range(10):
            ctx.sim[0].lookup(ctx.sim[4].peer_id.value)
            ctx.sim[0].lookup(ctx.sim[5].peer_id.value)
        return "nodes 4,5 looked up repeatedly (popular)"
    sc.add("02 boost popularity", step2)

    def step3(ctx):
        # Force more inserts to trigger eviction.
        ctx.sim[0].cache.gc()
        n_kept = len(ctx.sim[0].cache.entries())
        return f"after eviction: {n_kept} records retained (cap=3)"
    sc.add("03 eviction triggered", step3)
    return sc


def scenario_burst_lookups() -> Scenario:
    """High lookup load: 1 publisher, 50 lookups in a tight burst,
    rate limiter keeps the system stable."""
    sc = Scenario(
        name="burst_lookups",
        description="50 lookups in burst; system stays responsive; rate-limit drops are bounded.",
        n_nodes=4, k=3,
    )

    def step1(ctx):
        _pub(ctx, "1.1.1.1:1")
        return "publisher publishes"
    sc.add("01 publish", step1)

    def step2(ctx):
        successes = 0
        for _ in range(50):
            r = ctx.sim[1].resolve(
                ctx.sim[0].peer_id.value, force_network=False
            )
            if r is not None:
                successes += 1
        return f"50 lookups, {successes} successful (L1 hits dominate after first resolve)"
    sc.add("02 burst", step2)
    return sc


def scenario_adversary_corrupt_replica() -> Scenario:
    """A single replica node is corrupted (we forge its DHT store
    entry for the publisher). Honest peers reject the forged record
    on validation; the publisher's true record still wins via the
    other replicas."""
    sc = Scenario(
        name="adversary_corrupt_replica",
        description="Forged replica entry is rejected by honest validators; quorum prevails.",
        n_nodes=5, k=4,
    )

    def step1(ctx):
        _pub(ctx, "8.8.8.8:8")
        return "publisher publishes legit record"
    sc.add("01 publish", step1)

    def step2(ctx):
        ctx.sim.inject_corrupt_replica(
            ctx.sim[2], ctx.sim[0].peer_id.value, fake_address="6.6.6.6:6",
        )
        return "node[2] now holds a forged record for the publisher"
    sc.add("02 inject corruption", step2)

    def step3(ctx):
        rec = ctx.sim[3].resolve(
            ctx.sim[0].peer_id.value, force_network=True
        )
        # The forged record fails verify() so it's never returned.
        return f"node[3] still resolves to {rec.endpoints[0].address}"
    sc.add("03 honest resolve", step3)
    return sc


def scenario_adversary_noisy_neighbor() -> Scenario:
    """A neighbour spams junk traffic; rate limiter on the receiver
    keeps loss bounded; legit traffic still flows."""
    sc = Scenario(
        name="adversary_noisy_neighbor",
        description="Spam from one peer; rate limiter caps it; legit lookups still succeed.",
        n_nodes=4, k=3,
    )

    def step1(ctx):
        _pub(ctx, "1.1.1.1:1")
        return "publisher publishes"
    sc.add("01 publish", step1)

    def step2(ctx):
        ctx.sim.start_noisy_neighbor(
            ctx.sim[2], ctx.sim[1], rate_per_step=20,
        )
        sent = ctx.sim.step_noisy_neighbors()
        return f"node[2] fired {sent} junk datagrams at node[1]"
    sc.add("02 inject noise", step2)

    def step3(ctx):
        rec = ctx.sim[1].resolve(
            ctx.sim[0].peer_id.value, force_network=True
        )
        return f"node[1] still resolves: {rec.endpoints[0].address}"
    sc.add("03 legit traffic survives", step3)
    return sc


def scenario_adversary_silent_node() -> Scenario:
    """A node refuses to answer anything (silent neighbour). Lookups
    skip it after timeout and contact other replicas."""
    sc = Scenario(
        name="adversary_silent_node",
        description="One node never answers; lookups still succeed via other replicas.",
        n_nodes=5, k=4,
    )

    def step1(ctx):
        _pub(ctx, "1.1.1.1:1")
        return "publisher publishes"
    sc.add("01 publish", step1)

    def step2(ctx):
        ctx.sim.make_silent(ctx.sim[2])
        return "node[2] silenced (drops all incoming)"
    sc.add("02 silence node[2]", step2)

    def step3(ctx):
        rec = ctx.sim[3].resolve(
            ctx.sim[0].peer_id.value, force_network=True
        )
        return f"node[3] still resolves via other replicas: {rec.endpoints[0].address}"
    sc.add("03 lookup succeeds", step3)
    return sc


# --------------------------------------------------------------------


REGISTRY: dict[str, Callable[[], Scenario]] = {
    "publish_and_resolve": scenario_publish_and_resolve,
    "stale_vs_fresh": scenario_stale_vs_fresh,
    "partition_then_merge": scenario_partition_then_merge,
    "primary_loss_and_reconstruction": scenario_primary_loss_and_reconstruction,
    "replay_and_tamper_rejection": scenario_replay_and_tamper_rejection,
    "ip_change_without_refresh": scenario_ip_change_without_refresh,
    "endpoint_remap": scenario_endpoint_remap,
    "concurrent_updates_seq_conflict": scenario_concurrent_updates_seq_conflict,
    "symmetric_nat_relay_path": scenario_symmetric_nat_relay_path,
    "cache_warming": scenario_cache_warming,
    "mass_churn": scenario_mass_churn,
    "popularity_eviction_multi_node": scenario_popularity_eviction_multi_node,
    "burst_lookups": scenario_burst_lookups,
    "adversary_corrupt_replica": scenario_adversary_corrupt_replica,
    "adversary_noisy_neighbor": scenario_adversary_noisy_neighbor,
    "adversary_silent_node": scenario_adversary_silent_node,
}


def list_scenarios() -> list[tuple[str, str]]:
    out = []
    for name, factory in REGISTRY.items():
        sc = factory()
        out.append((name, sc.description))
    return out


def get_scenario(name: str) -> Scenario:
    if name not in REGISTRY:
        raise KeyError(f"unknown scenario {name!r}; "
                       f"known: {sorted(REGISTRY.keys())}")
    return REGISTRY[name]()
