"""Snapshots of simulator state.

A `Snapshot` is a JSON-serializable view of a SimNetwork at a moment:
who's online, what each node holds in its DHT store for a subject
peer, each record's freshness (fresh / stale / hard-expired / missing),
and routing-table sizes.

Snapshots are the substrate of Phase 3 visualization. The renderer
draws them; the scenario runner emits a timeline of them.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from typing import Any, Optional

from ..utils.time import now_s


# Node record-state labels used for coloring.
STATE_FRESH = "fresh"            # in store, not soft-expired
STATE_STALE = "stale"            # in store, past soft TTL but not hard
STATE_EXPIRED = "expired"        # past hard TTL
STATE_MISSING = "missing"        # not in store
STATE_CORRUPTED = "corrupted"    # present but fails verify()
STATE_PUBLISHER = "publisher"    # the subject's own node


@dataclass
class NodeSnapshot:
    index: int
    peer_id: str
    peer_id_short: str
    online: bool
    partition_group: int            # 0 = unrestricted
    routing_table_size: int
    dht_store_size: int
    local_cache_size: int
    record_state: str               # STATE_* for the subject peer
    record_seq: Optional[int] = None
    record_endpoint: Optional[str] = None
    is_publisher: bool = False


@dataclass
class Snapshot:
    label: str
    virtual_time: float
    subject_peer_id: str
    nodes: list[NodeSnapshot] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "label": self.label,
            "virtual_time": self.virtual_time,
            "subject_peer_id": self.subject_peer_id,
            "nodes": [asdict(n) for n in self.nodes],
            "notes": list(self.notes),
        }

    def to_json(self, *, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, sort_keys=True)


def take_snapshot(
    sim,                      # SimNetwork (avoid circular import)
    subject_peer_id: str,
    label: str,
    *,
    virtual_time: Optional[float] = None,
    notes: Optional[list[str]] = None,
) -> Snapshot:
    """Walk the sim and build a Snapshot focused on `subject_peer_id`."""
    t = now_s() if virtual_time is None else float(virtual_time)
    snap = Snapshot(
        label=label,
        virtual_time=t,
        subject_peer_id=subject_peer_id,
        notes=list(notes or []),
    )
    # Figure out per-node offline/partition status from the network.
    offline = getattr(sim.net, "_offline", set())
    part = getattr(sim.net, "_partition", {})

    for i, node in enumerate(sim.nodes):
        pid = node.peer_id.value
        online = pid not in offline
        group = part.get(pid, 0)
        rec = None
        try:
            rec = node.dht_store().peek(subject_peer_id) if node.directory is not None else None
        except Exception:
            rec = None

        state = STATE_MISSING
        seq = None
        endpoint = None
        if pid == subject_peer_id:
            state = STATE_PUBLISHER
            own = node.own_record()
            if own is not None:
                seq = own.seq
                if own.endpoints:
                    endpoint = own.endpoints[0].address
        elif rec is not None:
            seq = rec.seq
            if rec.endpoints:
                endpoint = rec.endpoints[0].address
            # Validate the cached record's state.
            ok, _ = rec.verify()
            if not ok:
                state = STATE_CORRUPTED
            elif rec.is_hard_expired(at=int(t)):
                state = STATE_EXPIRED
            elif rec.needs_soft_refresh(at=int(t)):
                state = STATE_STALE
            else:
                state = STATE_FRESH

        snap.nodes.append(
            NodeSnapshot(
                index=i,
                peer_id=pid,
                peer_id_short=node.peer_id.short(),
                online=online,
                partition_group=group,
                routing_table_size=(
                    node.routing_table().size() if node.directory is not None else 0
                ),
                dht_store_size=(
                    node.dht_store().size() if node.directory is not None else 0
                ),
                local_cache_size=len(node.cache.all_peers()),
                record_state=state,
                record_seq=seq,
                record_endpoint=endpoint,
                is_publisher=(pid == subject_peer_id),
            )
        )
    return snap
