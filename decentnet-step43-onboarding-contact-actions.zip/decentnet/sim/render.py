"""Render a `Snapshot` as a standalone SVG.

No external dependencies — we emit SVG text directly. The layout is
a ring: nodes placed at equal angles around a circle. The publisher
gets a distinctive marker. Edge color/node color communicate state.

Color scheme
------------
    FRESH       #4ade80  green   — record present, not stale
    STALE       #fbbf24  amber   — past soft TTL but still valid
    EXPIRED     #9ca3af  gray    — past hard TTL
    MISSING     #e5e7eb  very light gray — no record
    CORRUPTED   #ef4444  red     — present but verify() fails
    PUBLISHER           blue ring around whichever colour
    OFFLINE             dashed outline; 50% opacity

Partitions
----------
When a partition is active, group index is encoded in a colored
background halo behind the node.
"""
from __future__ import annotations

import math
from typing import Optional

from .snapshot import (
    Snapshot,
    STATE_CORRUPTED,
    STATE_EXPIRED,
    STATE_FRESH,
    STATE_MISSING,
    STATE_PUBLISHER,
    STATE_STALE,
)


_STATE_COLORS = {
    STATE_FRESH: "#4ade80",
    STATE_STALE: "#fbbf24",
    STATE_EXPIRED: "#9ca3af",
    STATE_MISSING: "#e5e7eb",
    STATE_CORRUPTED: "#ef4444",
    STATE_PUBLISHER: "#60a5fa",
}

_PARTITION_HALOS = {
    0: None,
    1: "#bfdbfe",    # light blue
    2: "#fecaca",    # light red
    3: "#bbf7d0",    # light green
    4: "#fde68a",    # light amber
}


def render_snapshot_svg(
    snap: Snapshot,
    *,
    width: int = 900,
    height: int = 680,
    title: Optional[str] = None,
) -> str:
    n = len(snap.nodes)
    cx, cy = width // 2, height // 2 + 10
    radius = min(width, height) // 3
    node_r = 34

    # Compute positions (stable: ordered by the node `index` attribute)
    positions: list[tuple[float, float]] = []
    ordered = sorted(snap.nodes, key=lambda x: x.index)
    for idx, node in enumerate(ordered):
        theta = -math.pi / 2 + 2 * math.pi * idx / max(1, n)
        x = cx + radius * math.cos(theta)
        y = cy + radius * math.sin(theta)
        positions.append((x, y))

    # Routing edges: thin lines between each node and every node that
    # appears in its routing table. In Phase 3 we only draw edges for
    # the subject-peer relationships (too noisy otherwise).
    # Simpler: draw light edges between all online pairs, heavier edge
    # from publisher to every node that currently stores a fresh record.

    parts: list[str] = []
    parts.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'viewBox="0 0 {width} {height}" width="{width}" height="{height}" '
        f'font-family="ui-sans-serif,system-ui,Inter,Arial">'
    )
    parts.append(
        '<style>'
        '.lbl { font-size: 11px; fill: #111827; font-weight: 600; }'
        '.sub { font-size: 10px; fill: #374151; }'
        '.lgd { font-size: 12px; fill: #111827; }'
        '.note{ font-size: 12px; fill: #4b5563; }'
        '.ttl { font-size: 16px; font-weight: 700; fill: #111827; }'
        '</style>'
    )
    # Background
    parts.append(f'<rect width="100%" height="100%" fill="#ffffff"/>')

    # Title
    t_txt = title or snap.label
    parts.append(
        f'<text x="{width // 2}" y="28" text-anchor="middle" class="ttl">{_esc(t_txt)}</text>'
    )
    subtitle = f'subject = {snap.subject_peer_id[:18]}…   t = {int(snap.virtual_time)}'
    parts.append(
        f'<text x="{width // 2}" y="48" text-anchor="middle" class="sub">'
        f'{_esc(subtitle)}</text>'
    )

    # Partition halos
    for (x, y), node in zip(positions, ordered):
        halo = _PARTITION_HALOS.get(node.partition_group)
        if halo:
            parts.append(
                f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{node_r + 16}" '
                f'fill="{halo}" stroke="none" opacity="0.35"/>'
            )

    # Publisher -> holder edges (highlight data flow)
    pub_pos = None
    for (p, node) in zip(positions, ordered):
        if node.is_publisher:
            pub_pos = p
            break
    if pub_pos is not None:
        px, py = pub_pos
        for (x, y), node in zip(positions, ordered):
            if node.is_publisher:
                continue
            if node.record_state == STATE_FRESH:
                stroke = "#4ade80"
                opacity = 0.55
                w = 2
            elif node.record_state == STATE_STALE:
                stroke = "#fbbf24"
                opacity = 0.45
                w = 1.5
            elif node.record_state == STATE_CORRUPTED:
                stroke = "#ef4444"
                opacity = 0.55
                w = 2
            else:
                continue
            parts.append(
                f'<line x1="{px:.1f}" y1="{py:.1f}" x2="{x:.1f}" y2="{y:.1f}" '
                f'stroke="{stroke}" stroke-width="{w}" opacity="{opacity}"/>'
            )

    # Nodes
    for (x, y), node in zip(positions, ordered):
        colour = _STATE_COLORS.get(node.record_state, "#e5e7eb")
        outline = "#111827"
        dash = ""
        op = 1.0
        if not node.online:
            dash = ' stroke-dasharray="4 4"'
            op = 0.45
        ring_extra = ""
        if node.is_publisher:
            ring_extra = (
                f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{node_r + 6}" '
                f'fill="none" stroke="#1d4ed8" stroke-width="3"/>'
            )
        parts.append(ring_extra)
        parts.append(
            f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{node_r}" '
            f'fill="{colour}" stroke="{outline}" stroke-width="2"'
            f'{dash} opacity="{op}"/>'
        )
        parts.append(
            f'<text x="{x:.1f}" y="{y + 4:.1f}" text-anchor="middle" class="lbl">'
            f'[{node.index}] {node.peer_id_short[:6]}</text>'
        )
        seq_bit = f'seq {node.record_seq}' if node.record_seq is not None else ''
        state_bit = node.record_state if node.record_state != STATE_MISSING else ''
        tail_txt = f'{seq_bit}  {state_bit}'.strip()
        if tail_txt:
            parts.append(
                f'<text x="{x:.1f}" y="{y + node_r + 16:.1f}" '
                f'text-anchor="middle" class="sub">{_esc(tail_txt)}</text>'
            )

    # Legend
    legend_y = height - 110
    legend = [
        ("fresh",      STATE_FRESH),
        ("stale",      STATE_STALE),
        ("expired",    STATE_EXPIRED),
        ("corrupted",  STATE_CORRUPTED),
        ("missing",    STATE_MISSING),
    ]
    parts.append(
        f'<text x="40" y="{legend_y - 10}" class="lbl">record state</text>'
    )
    for i, (label, state) in enumerate(legend):
        lx = 40 + i * 140
        parts.append(
            f'<circle cx="{lx + 10}" cy="{legend_y + 12}" r="10" '
            f'fill="{_STATE_COLORS[state]}" stroke="#111827" stroke-width="1.5"/>'
        )
        parts.append(
            f'<text x="{lx + 28}" y="{legend_y + 16}" class="lgd">{label}</text>'
        )

    # Offline legend
    off_y = legend_y + 40
    parts.append(
        f'<circle cx="50" cy="{off_y + 12}" r="10" fill="#e5e7eb" '
        f'stroke="#111827" stroke-width="1.5" stroke-dasharray="4 4" opacity="0.5"/>'
        f'<text x="68" y="{off_y + 16}" class="lgd">offline</text>'
    )
    parts.append(
        f'<circle cx="200" cy="{off_y + 12}" r="12" fill="none" '
        f'stroke="#1d4ed8" stroke-width="3"/>'
        f'<text x="220" y="{off_y + 16}" class="lgd">publisher</text>'
    )

    # Notes
    if snap.notes:
        notes_y = off_y + 38
        parts.append(
            f'<text x="40" y="{notes_y}" class="lbl">notes</text>'
        )
        for i, note in enumerate(snap.notes[:4]):
            parts.append(
                f'<text x="40" y="{notes_y + 18 + i * 16}" '
                f'class="note">• {_esc(note)}</text>'
            )

    parts.append("</svg>")
    return "\n".join(parts)


def _esc(s: str) -> str:
    return (
        s.replace("&", "&amp;")
         .replace("<", "&lt;")
         .replace(">", "&gt;")
         .replace('"', "&quot;")
    )


# --------------------------------------------------------------------


def render_index_html(
    snapshots: list[Snapshot],
    svg_filenames: list[str],
    *,
    title: str = "decentnet scenario timeline",
) -> str:
    """Render a single-file HTML index that steps through a timeline of
    snapshots. Pure CSS + minimal inline JS; works offline."""
    assert len(snapshots) == len(svg_filenames)
    frames_js_items = []
    for snap, fname in zip(snapshots, svg_filenames):
        notes = " • ".join(snap.notes) if snap.notes else ""
        frames_js_items.append(
            "{label: %r, file: %r, notes: %r}" % (snap.label, fname, notes)
        )
    frames_js = ",\n  ".join(frames_js_items)

    return f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>{_esc(title)}</title>
<style>
  body {{ font-family: ui-sans-serif, system-ui, Inter, Arial, sans-serif;
         margin: 0; padding: 16px; background: #f9fafb; color: #111827; }}
  h1 {{ margin: 0 0 6px 0; font-size: 20px; }}
  .bar {{ display: flex; gap: 10px; align-items: center;
          padding: 10px 0 14px 0; }}
  button {{ padding: 6px 12px; font-size: 14px; border: 1px solid #d1d5db;
            background: white; border-radius: 6px; cursor: pointer; }}
  button:hover {{ background: #f3f4f6; }}
  .step {{ font-size: 14px; color: #4b5563; }}
  .label {{ font-size: 16px; font-weight: 600; margin-bottom: 6px; }}
  .notes {{ font-size: 13px; color: #4b5563; margin-bottom: 10px; min-height: 1.2em; }}
  .frame {{ background: white; border: 1px solid #e5e7eb; border-radius: 10px;
            padding: 8px; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }}
  iframe {{ width: 100%; height: 720px; border: 0; }}
  .tl {{ display: flex; flex-wrap: wrap; gap: 6px; margin-top: 12px; }}
  .pill {{ padding: 4px 8px; background: #e5e7eb; border-radius: 999px;
           font-size: 12px; cursor: pointer; }}
  .pill.active {{ background: #1d4ed8; color: white; }}
</style>
</head>
<body>
<h1>{_esc(title)}</h1>
<div class="bar">
  <button onclick="prev()">← prev</button>
  <button onclick="next()">next →</button>
  <span class="step"><span id="idx">1</span> / {len(snapshots)}</span>
</div>
<div class="label" id="label"></div>
<div class="notes" id="notes"></div>
<div class="frame"><iframe id="frame"></iframe></div>
<div class="tl" id="tl"></div>
<script>
  const frames = [
  {frames_js}
  ];
  let i = 0;
  const tl = document.getElementById('tl');
  frames.forEach((f, k) => {{
    const p = document.createElement('span');
    p.className = 'pill';
    p.textContent = (k + 1) + '. ' + f.label;
    p.onclick = () => show(k);
    tl.appendChild(p);
  }});
  function show(k) {{
    i = Math.max(0, Math.min(frames.length - 1, k));
    document.getElementById('idx').textContent = (i + 1);
    document.getElementById('label').textContent = frames[i].label;
    document.getElementById('notes').textContent = frames[i].notes;
    document.getElementById('frame').src = frames[i].file;
    document.querySelectorAll('.pill').forEach((el, k2) => {{
      el.classList.toggle('active', k2 === i);
    }});
  }}
  function next() {{ show(i + 1); }}
  function prev() {{ show(i - 1); }}
  document.addEventListener('keydown', e => {{
    if (e.key === 'ArrowRight') next();
    if (e.key === 'ArrowLeft') prev();
  }});
  show(0);
</script>
</body>
</html>
"""
