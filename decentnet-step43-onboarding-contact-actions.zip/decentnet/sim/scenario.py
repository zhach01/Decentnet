"""Scenario runner.

A `Scenario` is a named, scripted sequence of actions on a SimNetwork.
The runner executes the script, takes a snapshot at each named
checkpoint, and emits:

    output_dir/
        report.json          -- structured dump of all snapshots
        report.md            -- human-readable summary
        01_<label>.svg       -- snapshot SVGs, in order
        02_<label>.svg
        ...
        index.html           -- single-page timeline viewer

Scenarios are also directly testable: the runner returns the list of
snapshots and the set of audit events seen, and tests can assert on
those without writing to disk.

Built-in scenarios are defined in `sim/builtin_scenarios.py`.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

from .clock import VirtualClock
from .network import SimNetwork
from .render import render_index_html, render_snapshot_svg
from .snapshot import Snapshot, take_snapshot


Step = Callable[["ScenarioContext"], Optional[str]]
"""A scenario step mutates the sim and optionally returns a one-line
note that gets attached to the next snapshot."""


@dataclass
class ScenarioContext:
    sim: SimNetwork
    clock: VirtualClock
    subject_peer_id: str                          # usually publisher's id
    snapshots: list[Snapshot] = field(default_factory=list)
    pending_notes: list[str] = field(default_factory=list)

    def note(self, s: str) -> None:
        self.pending_notes.append(s)

    def checkpoint(self, label: str) -> None:
        snap = take_snapshot(
            self.sim,
            self.subject_peer_id,
            label,
            virtual_time=self.clock.time(),
            notes=list(self.pending_notes),
        )
        self.snapshots.append(snap)
        self.pending_notes.clear()


@dataclass
class Scenario:
    name: str
    description: str
    n_nodes: int = 6
    k: int = 4
    setup: Optional[Callable[[ScenarioContext], None]] = None
    steps: list[tuple[str, Step]] = field(default_factory=list)

    def add(self, label: str, step: Step) -> "Scenario":
        self.steps.append((label, step))
        return self


# --------------------------------------------------------------------


@dataclass
class ScenarioResult:
    scenario_name: str
    snapshots: list[Snapshot]
    output_dir: Optional[Path] = None


def run_scenario(
    scenario: Scenario,
    *,
    output_dir: Optional[Path | str] = None,
    clock_start: float = 1_700_000_000.0,
) -> ScenarioResult:
    clock = VirtualClock(start=clock_start)
    with clock.install():
        sim = SimNetwork.build(n=scenario.n_nodes, k=scenario.k)
        try:
            # Pick the publisher as node 0 by convention; scenarios
            # can override inside `setup`.
            subject = sim[0].peer_id.value
            ctx = ScenarioContext(sim=sim, clock=clock, subject_peer_id=subject)
            if scenario.setup is not None:
                scenario.setup(ctx)
            # Initial snapshot.
            ctx.note(scenario.description)
            ctx.checkpoint("00 initial state")
            for label, step in scenario.steps:
                note = step(ctx)
                if note:
                    ctx.note(note)
                ctx.checkpoint(label)
        finally:
            sim.shutdown()

    result = ScenarioResult(scenario_name=scenario.name, snapshots=ctx.snapshots)
    if output_dir is not None:
        result.output_dir = _write_outputs(scenario, ctx.snapshots, Path(output_dir))
    return result


# --------------------------------------------------------------------


_SAFE_FN_RE = re.compile(r"[^a-zA-Z0-9_.-]+")


def _safe_filename(s: str) -> str:
    return _SAFE_FN_RE.sub("_", s).strip("_")


def _write_outputs(
    scenario: Scenario,
    snaps: list[Snapshot],
    output_dir: Path,
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)

    svg_filenames: list[str] = []
    for i, snap in enumerate(snaps):
        base = f"{i:02d}_{_safe_filename(snap.label)}.svg"
        (output_dir / base).write_text(
            render_snapshot_svg(snap), encoding="utf-8"
        )
        svg_filenames.append(base)

    # report.json
    report = {
        "scenario": {
            "name": scenario.name,
            "description": scenario.description,
            "n_nodes": scenario.n_nodes,
            "k": scenario.k,
        },
        "snapshots": [s.to_dict() for s in snaps],
    }
    (output_dir / "report.json").write_text(
        json.dumps(report, indent=2, sort_keys=True), encoding="utf-8"
    )

    # report.md
    md_lines = [f"# {scenario.name}\n", f"{scenario.description}\n"]
    md_lines.append(f"**{len(snaps)} checkpoints**, "
                    f"{scenario.n_nodes} nodes (k={scenario.k}).\n")
    for i, snap in enumerate(snaps):
        md_lines.append(f"## {i + 1}. {snap.label}  — t={int(snap.virtual_time)}")
        if snap.notes:
            for n in snap.notes:
                md_lines.append(f"- {n}")
        tally: dict[str, int] = {}
        for n in snap.nodes:
            tally[n.record_state] = tally.get(n.record_state, 0) + 1
        order = ["publisher", "fresh", "stale", "expired", "missing", "corrupted"]
        row = "  ".join(
            f"**{k}**: {tally[k]}" for k in order if tally.get(k)
        )
        md_lines.append(f"\n{row}\n")
    (output_dir / "report.md").write_text(
        "\n".join(md_lines), encoding="utf-8"
    )

    # index.html
    (output_dir / "index.html").write_text(
        render_index_html(
            snaps, svg_filenames,
            title=f"decentnet — {scenario.name}",
        ),
        encoding="utf-8",
    )

    return output_dir
