"""decentnet CLI.

Usage:
    decentnet init [--root PATH]
    decentnet whoami [--root PATH]
    decentnet publish --endpoint TYPE:ADDR [--endpoint ...] [--ttl S]
                      [--soft-ttl S] [--capability C] [--root PATH]
    decentnet show [PEER_ID] [--json]
    decentnet lookup PEER_ID [--json]
    decentnet export [PEER_ID] [--out FILE]
    decentnet import FILE [--source NAME]
    decentnet peers
    decentnet log [--tail N] [--kind KIND]
    decentnet gc
    decentnet stats

The CLI is a thin wrapper over Node; all real logic lives in the
library so other front-ends (Kivy app, daemon, tests) share it.
"""
from __future__ import annotations

import argparse
import base64
import json
import sys
import zlib
import io
import time
from pathlib import Path
from typing import Optional

from .. import __version__
from ..node import Node, NodeConfig
from ..records.endpoints import Endpoint, EndpointType
from ..records.locator import DEFAULT_SOFT_TTL_S, DEFAULT_TTL_S
from ..config_file import (
    list_profiles, render_profile_toml, DecentnetConfig, infer_profile_name,
    describe_endpoint_strategy, validate_peer_config, startup_blockers,
    apply_runtime_overrides,
)
from ..doctor import preview_advertised_endpoints


# ---------------- argument parsing ----------------


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="decentnet", description="Decentralized peer-resolution framework"
    )
    p.add_argument("--version", action="version", version=f"decentnet {__version__}")
    p.add_argument("--root", default=None, help="Data directory (default: ~/.decentnet)")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("init", help="Initialize a node (generate identity).")
    sub.add_parser("whoami", help="Print this node's peer ID.")

    pub = sub.add_parser("publish", help="Publish a new signed locator record.")
    pub.add_argument(
        "--endpoint",
        action="append",
        default=[],
        metavar="TYPE:ADDR",
        help="Endpoint candidate, e.g. public_udp:203.0.113.5:41234 "
             "(repeatable)",
    )
    pub.add_argument("--auto-vpn", action="store_true", help="Detect and publish VPN/overlay endpoints automatically.")
    pub.add_argument("--vpn-port", type=int, default=None, help="Port to use for detected VPN endpoints (default: inferred from first endpoint port).")
    pub.add_argument("--ttl", type=int, default=DEFAULT_TTL_S)
    pub.add_argument("--soft-ttl", type=int, default=DEFAULT_SOFT_TTL_S)
    pub.add_argument("--capability", action="append", default=[])
    pub.add_argument("--topic", action="append", default=[])

    show = sub.add_parser("show", help="Show one cached record (default: own).")
    show.add_argument("peer_id", nargs="?")
    show.add_argument("--json", action="store_true")

    lk = sub.add_parser("lookup", help="L1 lookup of a peer ID.")
    lk.add_argument("peer_id")
    lk.add_argument("--json", action="store_true")

    ex = sub.add_parser("export", help="Export a record as canonical wire bytes.")
    ex.add_argument("peer_id", nargs="?")
    ex.add_argument("--out", default=None, help="Output file (default: stdout).")

    im = sub.add_parser("import", help="Import a record from a file.")
    im.add_argument("file")
    im.add_argument("--source", default="cli_import")

    sub.add_parser("peers", help="List all cached peers.")

    lg = sub.add_parser("log", help="Show audit events.")
    lg.add_argument("--tail", type=int, default=50)
    lg.add_argument("--kind", default=None)

    sub.add_parser("gc", help="Run cache garbage collection.")
    sub.add_parser("stats", help="Print cache stats.")

    # ---- Phase 3: simulation ----
    sim = sub.add_parser("sim", help="Run built-in scenarios.")
    sim_sub = sim.add_subparsers(dest="sim_cmd", required=True)
    sim_sub.add_parser("list", help="List built-in scenarios.")
    sim_run = sim_sub.add_parser("run", help="Run a scenario.")
    sim_run.add_argument("name", help="Scenario name (see `sim list`).")
    sim_run.add_argument(
        "--output", "-o",
        default=None,
        help="Output directory; if omitted, prints JSON to stdout.",
    )

    # ---- Phase 2: DHT operations ----
    dht = sub.add_parser("dht", help="DHT operations (requires a running daemon).")
    dht_sub = dht.add_subparsers(dest="dht_cmd", required=True)
    dht_sub.add_parser(
        "store", help="Print local DHT replica store contents."
    )
    dht_rsync = dht_sub.add_parser(
        "anti-entropy", help="Run an anti-entropy sync with a peer (via daemon).",
    )
    dht_rsync.add_argument("peer_id")

    # ---- Phase 4: signaling ----
    sig = sub.add_parser("signaling", help="Direct signaling operations (daemon).")
    sig_sub = sig.add_subparsers(dest="sig_cmd", required=True)
    sig_sub.add_parser("peers", help="List signaling sessions + states.")
    sig_hello = sig_sub.add_parser("hello", help="Initiate a hello handshake.")
    sig_hello.add_argument("peer_id")
    sig_ring = sig_sub.add_parser("ring", help="Send a ring to an established peer.")
    sig_ring.add_argument("peer_id")
    sig_ring.add_argument("--body", default="{}", help="JSON body for the ring.")
    sig_bye = sig_sub.add_parser("bye", help="Close signaling session with a peer.")
    sig_bye.add_argument("peer_id")

    # ---- Phase 5: NAT discovery ----
    nat = sub.add_parser("nat", help="STUN / NAT discovery operations.")
    nat_sub = nat.add_subparsers(dest="nat_cmd", required=True)
    nat_probe = nat_sub.add_parser("probe", help="Send a STUN Binding Request.")
    nat_probe.add_argument(
        "--server", required=True, metavar="HOST:PORT",
        help="STUN server to probe, e.g. stun.l.google.com:19302",
    )
    nat_probe.add_argument("--timeout", type=float, default=2.0)
    nat_class = nat_sub.add_parser(
        "classify", help="Classify NAT type against 1–2 STUN servers.",
    )
    nat_class.add_argument(
        "--server", action="append", required=True, metavar="HOST:PORT",
        help="STUN server (repeat for cone-vs-symmetric detection)",
    )

    # ---- Phase 6: ICE + relay ----
    ice = sub.add_parser("ice", help="ICE candidate-pair operations.")
    ice_sub = ice.add_subparsers(dest="ice_cmd", required=True)
    ice_probe = ice_sub.add_parser(
        "enumerate", help="Print candidate pairs between own record and peer.",
    )
    ice_probe.add_argument("peer_id")

    relay = sub.add_parser("relay", help="Run a cooperative UDP relay server.")
    relay_sub = relay.add_subparsers(dest="relay_cmd", required=True)
    relay_srv = relay_sub.add_parser("serve", help="Run the relay in foreground.")
    relay_srv.add_argument("--host", default="127.0.0.1")
    relay_srv.add_argument("--port", type=int, default=0)
    relay_tok = relay_sub.add_parser(
        "issue-token", help="Issue a signed relay token for a peer.",
    )
    relay_tok.add_argument("peer_id")
    relay_tok.add_argument("--ttl", type=int, default=3600)

    # ---- Final: rotation / topics / snapshots ----
    rot = sub.add_parser("rotate", help="Rotate the node's identity key.")
    rot.add_argument(
        "--endpoint", action="append", required=True, metavar="TYPE:ADDR",
        help="Endpoint(s) for the first record under the new identity.",
    )

    topic = sub.add_parser("topic", help="Manage topic subscriptions.")
    topic_sub = topic.add_subparsers(dest="topic_cmd", required=True)
    topic_sub.add_parser("list", help="List subscribed topics + replicate_all flag.")
    topic_sub_sub = topic_sub.add_parser("subscribe", help="Subscribe to a topic.")
    topic_sub_sub.add_argument("name")
    topic_mode = topic_sub.add_parser(
        "mode", help="Set replicate-all mode (true/false).",
    )
    topic_mode.add_argument("value", choices=["true", "false"])

    snap = sub.add_parser("snapshot", help="Global snapshot operations.")
    snap_sub = snap.add_subparsers(dest="snap_cmd", required=True)
    snap_take = snap_sub.add_parser("take", help="Take a signed snapshot.")
    snap_take.add_argument(
        "--out", default=None,
        help="Output file (default: snapshot-<ts>.json in cwd)",
    )
    snap_imp = snap_sub.add_parser("import", help="Import a foreign snapshot.")
    snap_imp.add_argument("file")
    snap_rec = snap_sub.add_parser(
        "reconstruct", help="Reconstruct from local snapshot archive.",
    )

    defrd = sub.add_parser("deferred", help="Manage deferred publish queue.")
    defrd_sub = defrd.add_subparsers(dest="defrd_cmd", required=True)
    defrd_sub.add_parser("list", help="List queued deferred publishes.")
    defrd_sub.add_parser("drain", help="Attempt to drain the deferred queue.")

    conf = sub.add_parser("confidence", help="Show confidence scores.")
    conf.add_argument("peer_id", nargs="?")

    ks = sub.add_parser("keystore", help="Manage the encrypted identity keyfile.")
    ks_sub = ks.add_subparsers(dest="keystore_cmd", required=True)
    ks_enc = ks_sub.add_parser("encrypt", help="Wrap the keyfile with a passphrase.")
    ks_enc.add_argument("--passphrase", default=None,
                        help="(testing only; prompts interactively if omitted)")
    ks_dec = ks_sub.add_parser("decrypt", help="Unwrap an encrypted keyfile.")
    ks_dec.add_argument("--passphrase", default=None)
    ks_sub.add_parser("status", help="Print whether the keyfile is encrypted.")

    # ---- Daemon ----
    daemon = sub.add_parser(
        "daemon", help="Long-running node process with a control socket.",
    )
    daemon.add_argument(
        "--socket", default=None,
        help="Unix-domain control socket path (default: <root>/control.sock)",
    )
    daemon.add_argument(
        "--udp-host", default=None,
        help="Local UDP bind host (default: config transport.bind_host or 0.0.0.0).",
    )
    daemon.add_argument(
        "--udp-port", type=int, default=0,
        help="Local UDP port (0 = config/default/OS-assigned).",
    )
    daemon.add_argument(
        "--config", default=None,
        help="TOML config file (default: $DECENTNET_CONFIG or /etc/decentnet/config.toml)",
    )
    daemon.add_argument(
        "--metrics-host", default=None,
        help="Start Prometheus metrics endpoint on this host (default: disabled)",
    )
    daemon.add_argument(
        "--metrics-port", type=int, default=0,
        help="Port for metrics endpoint (default: 9091 if host given)",
    )
    daemon.add_argument(
        "--log-level", default="info",
        choices=["debug", "info", "warning", "error", "critical"],
    )

    client = sub.add_parser(
        "client", help="Send a command to a running daemon.",
    )
    client.add_argument(
        "--socket", default=None, help="Daemon control socket path.",
    )
    client_sub = client.add_subparsers(dest="client_cmd", required=True)
    for verb in ("status", "health", "metrics", "reload", "peers",
                 "publish_network", "shutdown", "deferred.drain",
                 "signaling.peers", "snapshot.take"):
        client_sub.add_parser(verb, help=f"Send {{'cmd':'{verb}'}}.")
    cli_lookup = client_sub.add_parser("lookup")
    cli_lookup.add_argument("peer_id")
    cli_resolve = client_sub.add_parser("resolve")
    cli_resolve.add_argument("peer_id")
    cli_hello = client_sub.add_parser("signaling.hello")
    cli_hello.add_argument("peer_id")
    cli_ring = client_sub.add_parser("signaling.ring")
    cli_ring.add_argument("peer_id")
    cli_ring.add_argument("--body", default="{}")
    cli_bye = client_sub.add_parser("signaling.bye")
    cli_bye.add_argument("peer_id")
    cli_log = client_sub.add_parser("log")
    cli_log.add_argument("--tail", type=int, default=50)
    cli_raw = client_sub.add_parser("raw",
        help="Send an arbitrary JSON request (escape hatch).")
    cli_raw.add_argument("request")

    up = sub.add_parser("up", help="Start a peer daemon in the background.")
    up.add_argument("--config", default=None, help="TOML config file (default: $DECENTNET_CONFIG or /etc/decentnet/config.toml)")
    up.add_argument("--udp-host", default=None, help="Override UDP bind host")
    up.add_argument("--udp-port", type=int, default=0, help="Override UDP bind port")
    up.add_argument("--socket", default=None, help="Override control socket path")
    up.add_argument("--log-level", default="info", choices=["debug", "info", "warning", "error", "critical"])
    up.add_argument("--metrics-host", default=None)
    up.add_argument("--metrics-port", type=int, default=0)

    status_cmd = sub.add_parser("status", help="Show peer daemon status if running.")
    status_cmd.add_argument("--config", default=None, help="TOML config file used to resolve defaults")
    status_cmd.add_argument("--socket", default=None, help="Override control socket path")
    status_cmd.add_argument("--json", action="store_true", help="Print machine-readable JSON")

    down = sub.add_parser("down", help="Stop a background peer daemon.")
    down.add_argument("--config", default=None, help="TOML config file used to resolve defaults")
    down.add_argument("--socket", default=None, help="Override control socket path")

    profile = sub.add_parser("profile", help="Inspect built-in peer deployment profiles.")
    profile_sub = profile.add_subparsers(dest="profile_cmd", required=True)
    profile_sub.add_parser("list", help="List built-in profiles.")
    profile_show = profile_sub.add_parser("show", help="Render one built-in profile as TOML.")
    profile_show.add_argument("name")
    profile_show.add_argument("--root-override", default=None)

    config_cmd = sub.add_parser("config", help="Generate peer config templates.")
    config_sub = config_cmd.add_subparsers(dest="config_cmd", required=True)
    config_init = config_sub.add_parser("init", help="Write a config.toml from a built-in profile.")
    config_init.add_argument("--profile", choices=list_profiles(), default="laptop")
    config_init.add_argument("--out", default=None, help="Output path (default: <root>/config.toml)")
    config_init.add_argument("--force", action="store_true", help="Overwrite existing file")
    config_init.add_argument("--root-override", default=None, help="Override node.root in the rendered config")

    setup = sub.add_parser("setup", help="Interactive/non-interactive peer setup wizard.")
    setup.add_argument("--profile", choices=list_profiles(), default=None, help="Peer deployment profile")
    setup.add_argument("--out", default=None, help="Config output path (default: <root>/config.toml)")
    setup.add_argument("--force", action="store_true", help="Overwrite existing config")
    setup.add_argument("--root-override", default=None, help="Override node.root in the rendered config")
    setup.add_argument("--yes", action="store_true", help="Accept defaults without prompting")
    setup.add_argument("--start", action="store_true", help="Start the peer after writing config")

    bundle = sub.add_parser("bundle", help="Export/import peer onboarding bundles.")
    bundle_sub = bundle.add_subparsers(dest="bundle_cmd", required=True)
    bundle_export = bundle_sub.add_parser("export", help="Export this peer as a shareable bundle.")
    bundle_export.add_argument("--out", default=None, help="Output JSON file (default: <root>/peer-bundle.json)")
    bundle_export.add_argument("--config", default=None, help="Optional config file for metadata hints")
    bundle_inspect = bundle_sub.add_parser("inspect", help="Inspect a bundle JSON file.")
    bundle_inspect.add_argument("file")
    bundle_inspect.add_argument("--json", action="store_true")
    bundle_import = bundle_sub.add_parser("import", help="Import a peer bundle into the local cache.")
    bundle_import.add_argument("file")
    bundle_import.add_argument("--source", default="bundle_import")
    bundle_import.add_argument("--json", action="store_true")

    connect = sub.add_parser("connect", help="Import a peer bundle and optionally attempt first contact.")
    connect.add_argument("file", help="Peer bundle JSON file")
    connect.add_argument("--source", default="bundle_connect")
    connect.add_argument("--hello", action="store_true", help="Attempt signaling hello after import")
    connect.add_argument("--ring", action="store_true", help="Attempt signaling ring after a successful hello")
    connect.add_argument("--body", default="{}", help="JSON body for optional first ring")
    connect.add_argument("--socket", default=None, help="Daemon control socket path (required for hello/ring unless default socket exists)")
    connect.add_argument("--json", action="store_true", help="Print machine-readable JSON")

    join = sub.add_parser("join", help="Import multiple peer bundles and optionally attempt first contact.")
    join.add_argument("files", nargs="*", help="Peer bundle JSON files")
    join.add_argument("--dir", dest="bundle_dir", default=None, help="Directory containing peer bundle JSON files")
    join.add_argument("--source", default="bundle_join")
    join.add_argument("--hello", action="store_true", help="Attempt signaling hello after import")
    join.add_argument("--ring", action="store_true", help="Attempt signaling ring after a successful hello")
    join.add_argument("--body", default="{}", help="JSON body for optional first ring")
    join.add_argument("--socket", default=None, help="Daemon control socket path (required for hello/ring unless default socket exists)")
    join.add_argument("--hello-limit", type=int, default=0, help="Maximum number of imported peers to contact (0 = all)")
    join.add_argument("--json", action="store_true", help="Print machine-readable JSON")

    meshpack = sub.add_parser("meshpack", help="Export/import starter mesh packs made of multiple peer bundles.")
    meshpack_sub = meshpack.add_subparsers(dest="meshpack_cmd", required=True)
    meshpack_export = meshpack_sub.add_parser("export", help="Export a starter mesh pack from one or more peer bundles.")
    meshpack_export.add_argument("files", nargs="*", help="Extra peer bundle JSON files to include")
    meshpack_export.add_argument("--dir", dest="bundle_dir", default=None, help="Directory containing peer bundle JSON files")
    meshpack_export.add_argument("--include-self", action="store_true", help="Include this peer's own bundle if available")
    meshpack_export.add_argument("--out", default=None, help="Output JSON file (default: <root>/mesh-pack.json)")
    meshpack_export.add_argument("--config", default=None, help="Optional config file for self bundle metadata hints")
    meshpack_inspect = meshpack_sub.add_parser("inspect", help="Inspect a mesh pack JSON file.")
    meshpack_inspect.add_argument("file")
    meshpack_inspect.add_argument("--json", action="store_true")
    meshpack_import = meshpack_sub.add_parser("import", help="Import all peer bundles contained in a mesh pack.")
    meshpack_import.add_argument("file")
    meshpack_import.add_argument("--source", default="meshpack_import")
    meshpack_import.add_argument("--hello", action="store_true", help="Attempt signaling hello after import")
    meshpack_import.add_argument("--ring", action="store_true", help="Attempt signaling ring after a successful hello")
    meshpack_import.add_argument("--body", default="{}", help="JSON body for optional first ring")
    meshpack_import.add_argument("--socket", default=None, help="Daemon control socket path (required for hello/ring unless default socket exists)")
    meshpack_import.add_argument("--hello-limit", type=int, default=0, help="Maximum number of imported peers to contact (0 = all)")
    meshpack_import.add_argument("--json", action="store_true", help="Print machine-readable JSON")

    invite = sub.add_parser("invite", help="Export/import compact peer invitations for easier sharing and QR-style onboarding.")
    invite_sub = invite.add_subparsers(dest="invite_cmd", required=True)
    invite_export = invite_sub.add_parser("export", help="Export a compact invitation from this peer or an existing bundle.")
    invite_export.add_argument("--bundle", default=None, help="Existing peer bundle JSON file to compactify")
    invite_export.add_argument("--out", default=None, help="Output invitation JSON file (default: <root>/peer-invite.json)")
    invite_export.add_argument("--config", default=None, help="Optional config file for self bundle metadata hints")
    invite_export.add_argument("--print-token", action="store_true", help="Also print the compact invitation token")
    invite_export.add_argument("--print-url", action="store_true", help="Also print a QR/share-friendly invitation URL")
    invite_export.add_argument("--url-prefix", default="decentnet://invite?token=", help="Prefix used when constructing the invitation URL")
    invite_export.add_argument("--url-out", default=None, help="Write the invitation URL to a text file")
    invite_export.add_argument("--html-out", default=None, help="Write a small self-contained onboarding HTML page")
    invite_export.add_argument("--qr-svg-out", default=None, help="Write a QR-ready SVG image for the invitation URL")
    invite_export.add_argument("--qr-png-out", default=None, help="Write a QR-ready PNG image for the invitation URL")
    invite_inspect = invite_sub.add_parser("inspect", help="Inspect a compact invitation token or file.")
    invite_src = invite_inspect.add_mutually_exclusive_group(required=True)
    invite_src.add_argument("--file", dest="file", default=None, help="Invitation JSON file")
    invite_src.add_argument("--token", dest="token", default=None, help="Compact invitation token")
    invite_src.add_argument("--url", dest="url", default=None, help="Invitation URL containing a token")
    invite_inspect.add_argument("--json", action="store_true")
    invite_import = invite_sub.add_parser("import", help="Import a compact invitation into the local cache.")
    invite_import_src = invite_import.add_mutually_exclusive_group(required=True)
    invite_import_src.add_argument("--file", dest="file", default=None, help="Invitation JSON file")
    invite_import_src.add_argument("--token", dest="token", default=None, help="Compact invitation token")
    invite_import_src.add_argument("--url", dest="url", default=None, help="Invitation URL containing a token")
    invite_import.add_argument("--source", default="invite_import")
    invite_import.add_argument("--json", action="store_true")
    invite_serve = invite_sub.add_parser("serve", help="Run a small onboarding web page and import endpoint for LAN/mobile sharing.")
    invite_serve.add_argument("--host", default="127.0.0.1", help="HTTP bind host (use 0.0.0.0 for same-LAN devices)")
    invite_serve.add_argument("--port", type=int, default=0, help="HTTP bind port (0 = OS-assigned)")
    invite_serve.add_argument("--config", default=None, help="Optional config file used for self invite metadata hints")
    invite_serve.add_argument("--socket", default=None, help="Daemon control socket path for optional hello/ring after import")

    dash = sub.add_parser("dashboard", help="Run the live HTML dashboard or export snapshot pages.")
    dash.add_argument("--watch-root", action="append", default=[], help="Node root to watch (repeatable)")
    dash.add_argument("--roots-dir", default=None, help="Directory whose child directories are node roots")
    dash.add_argument("--host", default="127.0.0.1")
    dash.add_argument("--port", type=int, default=8765)
    dash.add_argument("--audit-tail", type=int, default=400)
    dash.add_argument("--event-limit", type=int, default=200)
    dash.add_argument("--soak-report", action="append", default=[], help="Soak/matrix/operator report JSON (repeatable)")
    dash.add_argument("--soak-dir", action="append", default=[], help="Directory containing soak/matrix/operator reports")
    dash.add_argument("--operator-report", action="append", default=[], help="Two-host operator report JSON (repeatable)")
    dash.add_argument("--operator-report-dir", action="append", default=[], help="Directory containing operator reports")
    dash.add_argument("--snapshot-json-out", default=None, help="Write a self-contained dashboard snapshot JSON")
    dash.add_argument("--snapshot-html-out", default=None, help="Write a self-contained dashboard snapshot HTML page")
    dash.add_argument("--snapshot-in", default=None, help="Serve a previously exported snapshot JSON instead of live roots")
    dash.add_argument("--once", action="store_true", help="Export snapshot outputs and exit without serving")

    doctor = sub.add_parser("doctor", help="Run local environment, STUN, and operator-pack diagnostics.")
    doctor.add_argument("--json", action="store_true", help="Print machine-readable JSON")
    doctor.add_argument("--bind-udp-port", type=int, default=None, help="Attempt a UDP bind on this port (0 = ephemeral)")
    doctor.add_argument("--bind-udp-host", default=None, help="Attempt the UDP bind on this host (defaults to config transport.bind_host)")
    doctor.add_argument("--config", default=None, help="TOML config file used for deployment preview")
    doctor.add_argument("--vpn-port", type=int, default=None, help="Detect VPN endpoints for this port (defaults to successful bound UDP port if available)")
    doctor.add_argument("--stun-server", action="append", default=[], help="Probe a STUN server HOST:PORT (repeatable)")
    doctor.add_argument("--stun-timeout", type=float, default=2.0, help="Timeout for STUN probe(s)")
    doctor.add_argument("--pack", default=None, help="Verify an operator bundle directory or .zip archive")

    return p


# ---------------- helpers ----------------


def _parse_endpoint_spec(spec: str) -> Endpoint:
    """'<type>:<addr>' where <addr> may itself contain colons (e.g. IPv6)."""
    if ":" not in spec:
        raise SystemExit(f"endpoint spec must be TYPE:ADDR, got {spec!r}")
    kind, _, addr = spec.partition(":")
    kind = kind.strip().lower()
    try:
        EndpointType(kind)  # validate
    except ValueError:
        allowed = ", ".join(t.value for t in EndpointType)
        raise SystemExit(f"unknown endpoint type {kind!r}; allowed: {allowed}")
    return Endpoint(type=kind, address=addr.strip(), discovered_by="self")


def _load_node(args: argparse.Namespace) -> Node:
    cfg = NodeConfig.at(args.root)
    return Node(cfg)


def _bundle_path_default(root: Optional[str]) -> Path:
    return _root_cfg(root).root / "peer-bundle.json"


def _meshpack_path_default(root: Optional[str]) -> Path:
    return _root_cfg(root).root / "mesh-pack.json"


def _invite_path_default(root: Optional[str]) -> Path:
    return _root_cfg(root).root / "peer-invite.json"


def _invite_html_path_default(root: Optional[str]) -> Path:
    return _root_cfg(root).root / "peer-invite.html"


def _invite_qr_svg_path_default(root: Optional[str]) -> Path:
    return _root_cfg(root).root / "peer-invite-qr.svg"


def _invite_qr_png_path_default(root: Optional[str]) -> Path:
    return _root_cfg(root).root / "peer-invite-qr.png"


def _invite_url_from_token(token: str, prefix: str) -> str:
    return f"{prefix}{token}"


def _token_from_invite_url(url: str) -> str:
    marker = "token="
    idx = url.find(marker)
    if idx == -1:
        raise SystemExit("invalid invitation URL: missing token=")
    token = url[idx + len(marker):].strip()
    if not token:
        raise SystemExit("invalid invitation URL: empty token")
    return token




def _make_qr_svg(url: str) -> str:
    import qrcode
    import qrcode.image.svg

    image = qrcode.make(url, image_factory=qrcode.image.svg.SvgImage, box_size=8, border=2)
    stream = io.BytesIO()
    image.save(stream)
    return stream.getvalue().decode("utf-8")


def _make_qr_png_bytes(url: str) -> bytes:
    import qrcode

    image = qrcode.make(url, box_size=8, border=2)
    stream = io.BytesIO()
    image.save(stream, format="PNG")
    return stream.getvalue()


def _qr_svg_data_uri(url: str) -> str:
    svg = _make_qr_svg(url)
    return "data:image/svg+xml;base64," + base64.b64encode(svg.encode("utf-8")).decode("ascii")


def _render_invite_html(invite: dict, token: str, url: str) -> str:
    import html
    peer_id = str(invite.get("peer_id") or "")
    endpoints = invite.get("endpoint_addresses") or []
    endpoint_items = "".join(f"<li><code>{html.escape(str(ep))}</code></li>" for ep in endpoints) or "<li><em>No endpoint summary</em></li>"
    qr_data_uri = _qr_svg_data_uri(url)
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>DecentNet Peer Invite</title>
  <style>
    body {{ font-family: system-ui, sans-serif; margin: 1rem; line-height: 1.45; background:#f7f7f7; color:#222; }}
    code, textarea, pre {{ font-family: ui-monospace, monospace; }}
    textarea {{ width: 100%; min-height: 8rem; }}
    .box {{ background:#fff; border: 1px solid #ccc; border-radius: 16px; padding: 1rem; margin: 1rem 0; box-shadow: 0 1px 3px rgba(0,0,0,.05); }}
    .hero {{ display:flex; flex-wrap:wrap; gap:1rem; align-items:center; }}
    .hero img {{ width: min(320px, 80vw); height: auto; background:#fff; border-radius:12px; border:1px solid #ddd; padding:0.6rem; }}
    .small {{ color:#666; font-size: .95rem; }}
  </style>
</head>
<body>
  <h1>DecentNet Peer Invite</h1>
  <p><strong>Peer ID:</strong> <code>{html.escape(peer_id)}</code></p>
  <div class="box hero">
    <div>
      <h2>Scan or share</h2>
      <p class="small">This QR code encodes the compact invite URL and is suitable for another phone, tablet, Raspberry Pi, or laptop to scan or copy.</p>
      <img alt="DecentNet invite QR" src="{qr_data_uri}">
    </div>
    <div style="flex:1 1 260px;">
      <h2>Share URL</h2>
      <textarea readonly>{html.escape(url)}</textarea>
      <h2>Invite token</h2>
      <textarea readonly>{html.escape(token)}</textarea>
    </div>
  </div>
  <div class="box">
    <h2>Endpoint summary</h2>
    <ul>{endpoint_items}</ul>
  </div>
  <div class="box">
    <h2>On another device</h2>
    <pre>decentnet invite import --url '{html.escape(url)}' --json
decentnet invite import --token '{html.escape(token)}' --json</pre>
  </div>
</body>
</html>
"""


def _load_bundle_file(path: str | Path) -> dict:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, dict) or "record_wire_b64" not in data or "peer_id" not in data:
        raise SystemExit(f"invalid peer bundle: {path}")
    return data


def _bundle_record_bytes(bundle: dict) -> bytes:
    try:
        return base64.b64decode(bundle["record_wire_b64"].encode("ascii"))
    except Exception as e:
        raise SystemExit(f"invalid bundle record encoding: {e}")


def _invite_token_from_bundle(bundle: dict) -> str:
    payload = json.dumps(bundle, sort_keys=True, separators=(",", ":")).encode("utf-8")
    compressed = zlib.compress(payload, level=9)
    return base64.urlsafe_b64encode(compressed).decode("ascii").rstrip("=")


def _bundle_from_invite_token(token: str) -> dict:
    try:
        padded = token + "=" * ((4 - len(token) % 4) % 4)
        compressed = base64.urlsafe_b64decode(padded.encode("ascii"))
        payload = zlib.decompress(compressed)
        bundle = json.loads(payload.decode("utf-8"))
    except Exception as e:
        raise SystemExit(f"invalid invitation token: {e}")
    if not isinstance(bundle, dict) or "record_wire_b64" not in bundle or "peer_id" not in bundle:
        raise SystemExit("invalid invitation token payload")
    return bundle


def _load_invite(args: argparse.Namespace) -> tuple[dict, str]:
    if getattr(args, "token", None):
        bundle = _bundle_from_invite_token(args.token)
        return bundle, args.token
    if getattr(args, "url", None):
        token = _token_from_invite_url(args.url)
        bundle = _bundle_from_invite_token(token)
        return bundle, token
    path = Path(args.file)
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or data.get("kind") != "decentnet_peer_invite":
        raise SystemExit(f"invalid peer invitation: {path}")
    token = data.get("invite_token")
    if not isinstance(token, str) or not token:
        raise SystemExit(f"invalid peer invitation token: {path}")
    bundle = _bundle_from_invite_token(token)
    return bundle, token




def _load_invite_bundle_from_payload(data: dict) -> tuple[dict, str]:
    token = data.get("token")
    if token:
        bundle = _bundle_from_invite_token(str(token))
        return bundle, str(token)
    url = data.get("url")
    if url:
        token = _token_from_invite_url(str(url))
        bundle = _bundle_from_invite_token(token)
        return bundle, token
    raise SystemExit("missing token/url")


def _record_to_bundle_preview(rec, profile_hint: Optional[str], endpoint_strategy: Optional[str], host: str, port: int) -> dict:
    bundle = {
        "kind": "decentnet_peer_bundle",
        "version": 1,
        "peer_id": rec.peer_id,
        "record_wire_b64": base64.b64encode(rec.to_wire_bytes()).decode("ascii"),
        "endpoint_addresses": [e.address for e in rec.endpoints],
        "profile_hint": profile_hint,
        "endpoint_strategy": endpoint_strategy,
    }
    token = _invite_token_from_bundle(bundle)
    url = _invite_url_from_token(token, f"http://{host}:{port}/?token=")
    return {
        "peer_id": rec.peer_id,
        "endpoint_addresses": [e.address for e in rec.endpoints],
        "profile_hint": profile_hint,
        "endpoint_strategy": endpoint_strategy,
        "invite_token": token,
        "invite_url": url,
        "issued_at": rec.issued_at,
        "expires_at": rec.expires_at,
        "soft_expires_at": rec.soft_expires_at,
        "max_confidence": max((float(getattr(e, "confidence", 0.5) or 0.5) for e in rec.endpoints), default=0.5),
        "reachable_guess": any(not str(e.address).startswith("127.") and not str(e.address).startswith("localhost") for e in rec.endpoints),
    }


def _nearby_peers_preview(root: Optional[str], config: Optional[str], host: str, port: int, socket_path: Optional[str] = None) -> list[dict]:
    now = int(time.time())
    previews = []
    session_map: dict[str, dict] = {}
    spath = socket_path or _default_socket_path(root)
    try:
        resp = _daemon_json_call(spath, {"cmd": "signaling.sessions"})
        if resp.get("ok") and isinstance(resp.get("sessions"), list):
            session_map = {str(s.get("peer_id")): s for s in resp.get("sessions", []) if isinstance(s, dict) and s.get("peer_id")}
    except Exception:
        session_map = {}
    with _load_node(argparse.Namespace(root=root)) as node:
        for rec, _meta in node.cache.entries():
            if rec.peer_id == node.peer_id.value:
                continue
            item = _record_to_bundle_preview(rec, None, None, host, port)
            sess = session_map.get(rec.peer_id) or {}
            item["trusted"] = bool(sess.get("trusted", False))
            item["session_state"] = sess.get("state")
            item["last_seen"] = sess.get("last_seen")
            item["selected_pair_kind"] = sess.get("selected_pair_kind")
            item["selected_path_ok_at"] = sess.get("selected_path_ok_at")
            item["selected_path_failures"] = int(sess.get("selected_path_failures") or 0)
            item["relay_in_use"] = str(sess.get("selected_pair_kind") or "") == "relay/relay"
            previews.append(item)
    previews.sort(key=lambda item: (
        item.get("expires_at", 0) <= now,
        not item.get("trusted", False),
        not item.get("reachable_guess", False),
        item.get("selected_path_failures", 0),
        -int(item.get("last_seen") or 0),
        -item.get("max_confidence", 0.0),
        -item.get("expires_at", 0),
        -item.get("issued_at", 0),
        item.get("peer_id", ""),
    ))
    for item in previews:
        expires_at = int(item.get("expires_at") or 0)
        item["freshness_s"] = max(0, expires_at - now)
        item["stale"] = expires_at <= now
        last_seen = int(item.get("last_seen") or 0)
        item["seen_ago_s"] = None if last_seen <= 0 else max(0, now - last_seen)
    return previews


def _render_onboarding_page(root: Optional[str], config: Optional[str], host: str, port: int) -> str:
    import html
    bundle = _make_self_bundle(root, config)
    nearby = _nearby_peers_preview(root, config, host, port)
    invite_section = "<p><em>No own published record yet. Run <code>decentnet publish</code> first if you want to share this peer from the page.</em></p>"
    if bundle is not None:
        token = _invite_token_from_bundle(bundle)
        url = _invite_url_from_token(token, f"http://{host}:{port}/?token=")
        qr_data_uri = _qr_svg_data_uri(url)
        endpoint_items = "".join(f"<li><code>{html.escape(str(ep))}</code></li>" for ep in (bundle.get("endpoint_addresses") or [])) or "<li><em>No endpoint summary</em></li>"
        invite_section = f"""
  <div class="box">
    <h2>Share this peer</h2>
    <p><strong>Peer ID:</strong> <code>{html.escape(str(bundle.get('peer_id') or ''))}</code></p>
    <p class="small">This page can be opened from another device on the same LAN when the server binds on <code>0.0.0.0</code>.</p>
    <div class="row">
      <div style="flex:0 1 320px;">
        <img alt="DecentNet onboarding QR" src="{qr_data_uri}" style="width:min(320px, 80vw);height:auto;border:1px solid #ddd;border-radius:12px;padding:0.6rem;background:#fff;">
      </div>
      <div style="flex:1 1 280px;">
        <label>Invite URL</label>
        <textarea readonly>{html.escape(url)}</textarea>
        <label>Invite token</label>
        <textarea readonly>{html.escape(token)}</textarea>
      </div>
    </div>
    <p class="small">Endpoint summary:</p>
    <ul>{endpoint_items}</ul>
  </div>
"""
    nearby_html = "".join(
        f"<div class='peer-card'><div><strong><code>{html.escape(p['peer_id'])}</code></strong></div><div class='small'>endpoints: {html.escape(', '.join(p['endpoint_addresses']) or 'none')}</div><div class='small'>freshness: {int(p.get('freshness_s', 0))}s{' · stale' if p.get('stale') else ''}</div><button onclick=\"importKnownPeer('{html.escape(p['invite_token'])}')\">Import peer</button></div>"
        for p in nearby
    ) or "<p class='small'><em>No nearby cached peers yet.</em></p>"
    page = """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>DecentNet Onboarding</title>
  <style>
    body {{ font-family: system-ui, sans-serif; margin: 1rem; line-height: 1.45; max-width: 960px; background:#f7f7f7; }}
    code, textarea, pre, input {{ font-family: ui-monospace, monospace; }}
    textarea {{ width: 100%; min-height: 7rem; }}
    .box {{ background:#fff; border: 1px solid #ccc; border-radius: 16px; padding: 1rem; margin: 1rem 0; box-shadow: 0 1px 3px rgba(0,0,0,.05); }}
    .row {{ display:flex; gap: 1rem; flex-wrap: wrap; align-items:flex-start; }}
    .row > div {{ flex:1 1 220px; }}
    label {{ display:block; margin: 0.6rem 0 0.2rem; font-weight: 600; }}
    button {{ margin-top: 1rem; padding: 0.8rem 1rem; border-radius: 10px; border: 1px solid #777; background: #f5f5f5; }}
    .small {{ color:#666; font-size: 0.95rem; }}
    #result {{ white-space: pre-wrap; background:#fafafa; padding:0.8rem; border-radius:8px; border:1px solid #ddd; }}
    .peer-grid {{ display:grid; grid-template-columns: repeat(auto-fit,minmax(240px,1fr)); gap:0.75rem; }}
    .peer-card {{ border:1px solid #ddd; border-radius:12px; padding:0.75rem; background:#fafafa; }}
  </style>
</head>
<body>
  <h1>DecentNet Local Onboarding</h1>
  <p>Open this page on another device, paste or scan an invite, and import it into this peer. The page refreshes nearby peers automatically.</p>
  __INVITE_SECTION__
  <div class="box">
    <div class="row"><div><h2>Nearby known peers</h2></div><div class="small" style="text-align:right;">auto refresh every 5s · <span id="peerStatus">loading…</span></div></div>
    <div id="nearbyPeers" class="peer-grid">__NEARBY_HTML__</div>
  </div>
  <div class="box">
    <h2>Import another peer</h2>
    <label>Invite URL or token</label>
    <textarea id="inviteInput" placeholder="Paste a decentnet://invite?token=... URL or a raw token here"></textarea>
    <div class="row">
      <div><label><input type="checkbox" id="hello"> Attempt hello after import</label></div>
      <div><label><input type="checkbox" id="ring"> Attempt ring after hello</label></div>
    </div>
    <label>Ring body JSON</label>
    <textarea id="bodyInput">{{}}</textarea>
    <button onclick="submitInvite()">Import invite</button>
    <p class="small">POST endpoint: <code>/api/import</code></p>
  </div>
  <div class="box">
    <h2>Result</h2>
    <div id="result">No action yet.</div>
  </div>
<script>
async function submitInvite(rawOverride) {{
  const raw = (rawOverride || document.getElementById('inviteInput').value).trim();
  const payload = {{ hello: document.getElementById('hello').checked, ring: document.getElementById('ring').checked }};
  try {{ payload.body = JSON.parse(document.getElementById('bodyInput').value || '{{}}'); }} catch (e) {{ document.getElementById('result').textContent = 'Invalid JSON body: ' + e; return; }}
  if (!raw) {{ document.getElementById('result').textContent = 'Please paste an invite URL or token.'; return; }}
  if (raw.includes('token=')) payload.url = raw; else payload.token = raw;
  const res = await fetch('/api/import', {{ method:'POST', headers:{{'Content-Type':'application/json'}}, body: JSON.stringify(payload) }});
  const text = await res.text();
  document.getElementById('result').textContent = text;
  refreshPeers();
}}
function importKnownPeer(token) {{ submitInvite(token); }}
async function refreshPeers() {{
  try {{
    const res = await fetch('/api/peers');
    const data = await res.json();
    const peers = data.peers || [];
    document.getElementById('peerStatus').textContent = peers.length + ' peer(s) · updated ' + new Date().toLocaleTimeString();
    const container = document.getElementById('nearbyPeers');
    if (!peers.length) {{
      container.innerHTML = '<p class="small"><em>No nearby cached peers yet.</em></p>';
      return;
    }}
    container.innerHTML = peers.map(function(p) {{ return '<div class="peer-card">' + '<div><strong><code>' + p.peer_id + '</code></strong></div>' + '<div class="small">endpoints: ' + (((p.endpoint_addresses || []).join(', ')) || 'none') + '</div>' + '<div class="small">freshness: ' + (p.freshness_s || 0) + 's' + (p.stale ? ' · stale' : '') + (p.reachable_guess ? ' · reachable-ish' : '') + (p.trusted ? ' · trusted' : '') + (p.relay_in_use ? ' · relay' : '') + '</div>' + '<div class="small">session: ' + (p.session_state || 'none') + ((p.seen_ago_s == null) ? '' : (' · seen ' + p.seen_ago_s + 's ago')) + ((p.selected_pair_kind) ? (' · path ' + p.selected_pair_kind) : '') + '</div>' + '<div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.5rem;">' + '<button onclick="importKnownPeer(\'' + p.invite_token + '\')">Import</button>' + '<button onclick="helloKnownPeer(\'' + p.peer_id + '\')">Hello</button>' + '<button onclick="ringKnownPeer(\'' + p.peer_id + '\')">Ring</button>' + '</div>' + '</div>'; }}).join('');
  }} catch (e) {{
    document.getElementById('peerStatus').textContent = 'refresh failed: ' + e;
  }}
}}
setInterval(refreshPeers, 5000);
refreshPeers();
</script>
</body>
</html>
"""
    return page.replace("__INVITE_SECTION__", invite_section).replace("__NEARBY_HTML__", nearby_html)



def _create_invite_http_server(root: Optional[str], config: Optional[str], host: str, port: int, socket_path: Optional[str] = None):
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    import urllib.parse

    socket_path = socket_path or _default_socket_path(root)

    class Handler(BaseHTTPRequestHandler):
        server_version = "DecentNetInviteHTTP/1.0"

        def _send_json(self, obj: dict, status: int = 200):
            data = json.dumps(obj, indent=2, sort_keys=True).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _send_html(self, html_text: str, status: int = 200):
            data = html_text.encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            parsed = urllib.parse.urlparse(self.path)
            if parsed.path in ("/", "/index.html"):
                self._send_html(_render_onboarding_page(root, config, self.server.server_address[0] or host, self.server.server_address[1]))
                return
            if parsed.path == "/api/info":
                bundle = _make_self_bundle(root, config)
                invite_url = None
                token = None
                if bundle is not None:
                    token = _invite_token_from_bundle(bundle)
                    invite_url = _invite_url_from_token(token, f"http://{self.server.server_address[0] or host}:{self.server.server_address[1]}/?token=")
                self._send_json({
                    "ok": True,
                    "host": self.server.server_address[0],
                    "port": self.server.server_address[1],
                    "has_self_bundle": bundle is not None,
                    "peer_id": None if bundle is None else bundle.get("peer_id"),
                    "endpoint_addresses": [] if bundle is None else bundle.get("endpoint_addresses", []),
                    "invite_token": token,
                    "invite_url": invite_url,
                    "qr_svg_url": None if invite_url is None else f"http://{self.server.server_address[0] or host}:{self.server.server_address[1]}/qr.svg",
                })
                return
            if parsed.path == "/api/peers":
                peers = _nearby_peers_preview(root, config, self.server.server_address[0] or host, self.server.server_address[1], socket_path)
                self._send_json({"ok": True, "peers": peers, "updated_at": int(time.time())})
                return
            if parsed.path == "/qr.svg":
                bundle = _make_self_bundle(root, config)
                if bundle is None:
                    self._send_json({"ok": False, "error": "no_self_bundle"}, status=404)
                    return
                token = _invite_token_from_bundle(bundle)
                invite_url = _invite_url_from_token(token, f"http://{self.server.server_address[0] or host}:{self.server.server_address[1]}/?token=")
                data = _make_qr_svg(invite_url).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "image/svg+xml; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            self._send_json({"ok": False, "error": "not_found"}, status=404)

        def do_POST(self):
            if self.path == "/api/contact":
                try:
                    length = int(self.headers.get("Content-Length", "0") or "0")
                    raw = self.rfile.read(length)
                    payload = json.loads(raw.decode("utf-8") or "{}")
                    peer_id = str(payload.get("peer_id") or "").strip()
                    if not peer_id:
                        self._send_json({"ok": False, "error": "peer_id_required"}, status=400)
                        return
                    hello = _daemon_json_call(socket_path, {"cmd": "signaling.hello", "peer_id": peer_id})
                    ring = None
                    if payload.get("ring") and hello.get("ok"):
                        body = payload.get("body") if isinstance(payload.get("body"), dict) else {}
                        ring = _daemon_json_call(socket_path, {"cmd": "signaling.ring", "peer_id": peer_id, "body": body})
                    self._send_json({"ok": bool(hello.get("ok")), "peer_id": peer_id, "hello": hello, "ring": ring}, status=200 if hello.get("ok") else 400)
                    return
                except Exception as e:
                    self._send_json({"ok": False, "error": str(e)}, status=500)
                    return
            if self.path != "/api/import":
                self._send_json({"ok": False, "error": "not_found"}, status=404)
                return
            try:
                length = int(self.headers.get("Content-Length", "0") or "0")
                raw = self.rfile.read(length)
                payload = json.loads(raw.decode("utf-8") or "{}")
                bundle, _token = _load_invite_bundle_from_payload(payload)
                data = _bundle_record_bytes(bundle)
                with _load_node(argparse.Namespace(root=root)) as node:
                    ingest = node.ingest_record_bytes(data, source="invite_http")
                out = {
                    "ok": bool(ingest.accepted),
                    "peer_id": bundle.get("peer_id"),
                    "accepted": bool(ingest.accepted),
                    "previous_seq": ingest.previous_seq,
                    "new_seq": ingest.new_seq,
                    "reason": ingest.reason,
                    "hello": None,
                    "ring": None,
                }
                if ingest.accepted and payload.get("hello"):
                    out["hello"] = _daemon_json_call(socket_path, {"cmd": "signaling.hello", "peer_id": bundle.get("peer_id")})
                    if payload.get("ring") and out["hello"].get("ok"):
                        body = payload.get("body") if isinstance(payload.get("body"), dict) else {}
                        out["ring"] = _daemon_json_call(socket_path, {"cmd": "signaling.ring", "peer_id": bundle.get("peer_id"), "body": body})
                self._send_json(out, status=200 if out.get("ok") else 400)
            except SystemExit as e:
                self._send_json({"ok": False, "error": str(e)}, status=400)
            except Exception as e:
                self._send_json({"ok": False, "error": str(e)}, status=500)

        def log_message(self, fmt, *args):
            return

    return ThreadingHTTPServer((host, port), Handler)

def _dump_record_human(record, meta: Optional[dict] = None) -> str:
    lines = [
        f"peer_id:         {record.peer_id}",
        f"seq:             {record.seq}",
        f"issued_at:       {record.issued_at}",
        f"expires_at:      {record.expires_at}",
        f"soft_expires_at: {record.soft_expires_at}",
        f"capabilities:    {record.capabilities}",
        f"topic_hashes:    {record.topic_hashes}",
        f"endpoints:",
    ]
    for e in record.endpoints:
        extra = []
        if e.discovered_by:
            extra.append(f"via={e.discovered_by}")
        if e.confidence != 0.5:
            extra.append(f"conf={e.confidence:.2f}")
        if e.priority:
            extra.append(f"prio={e.priority}")
        suffix = f"  [{', '.join(extra)}]" if extra else ""
        lines.append(f"  {e.type:<18} {e.address}{suffix}")
    if meta:
        lines.append("cache_metadata:")
        for k, v in meta.items():
            lines.append(f"  {k:<18} {v}")
    return "\n".join(lines)


# ---------------- command handlers ----------------


def cmd_init(args: argparse.Namespace) -> int:
    with _load_node(args) as node:
        print(f"Node initialized at {node.config.root}")
        print(f"peer_id: {node.peer_id}")
    return 0


def cmd_whoami(args: argparse.Namespace) -> int:
    with _load_node(args) as node:
        print(node.peer_id.value)
    return 0


def cmd_publish(args: argparse.Namespace) -> int:
    endpoints = [_parse_endpoint_spec(s) for s in args.endpoint]
    if args.auto_vpn:
        from ..vpn import detect_vpn_endpoints

        vpn_port = args.vpn_port
        if vpn_port is None:
            for ep in endpoints:
                _host, _sep, port_s = ep.address.rpartition(":")
                try:
                    vpn_port = int(port_s)
                    break
                except ValueError:
                    continue
        if vpn_port is None:
            print("publish requires at least one --endpoint or --vpn-port when --auto-vpn is used", file=sys.stderr)
            return 2
        endpoints.extend(detect_vpn_endpoints(vpn_port))
    if not endpoints:
        print("publish requires at least one --endpoint or --auto-vpn/--vpn-port", file=sys.stderr)
        return 2
    with _load_node(args) as node:
        rec = node.publish_own_record(
            endpoints=endpoints,
            ttl_s=args.ttl,
            soft_ttl_s=args.soft_ttl,
            capabilities=list(args.capability),
            topic_hashes=list(args.topic),
        )
        print(f"Published seq={rec.seq} with {len(rec.endpoints)} endpoint(s).")
        print(f"peer_id: {rec.peer_id}")
    return 0


def cmd_show(args: argparse.Namespace) -> int:
    with _load_node(args) as node:
        pid = args.peer_id or node.peer_id.value
        rec = node.cache.peek(pid)
        if rec is None:
            print(f"no cached record for {pid}", file=sys.stderr)
            return 1
        if args.json:
            print(json.dumps(rec.to_dict(), indent=2, sort_keys=True))
        else:
            print(_dump_record_human(rec))
    return 0


def cmd_lookup(args: argparse.Namespace) -> int:
    with _load_node(args) as node:
        rec = node.lookup(args.peer_id)
        if rec is None:
            print(f"miss: {args.peer_id}", file=sys.stderr)
            return 1
        if args.json:
            print(json.dumps(rec.to_dict(), indent=2, sort_keys=True))
        else:
            print(_dump_record_human(rec))
    return 0


def cmd_export(args: argparse.Namespace) -> int:
    with _load_node(args) as node:
        pid = args.peer_id or node.peer_id.value
        rec = node.cache.peek(pid)
        if rec is None:
            print(f"no record to export for {pid}", file=sys.stderr)
            return 1
        data = rec.to_wire_bytes()
        if args.out:
            Path(args.out).write_bytes(data)
            print(f"wrote {len(data)} bytes to {args.out}")
        else:
            sys.stdout.buffer.write(data)
            sys.stdout.buffer.write(b"\n")
    return 0


def cmd_import(args: argparse.Namespace) -> int:
    data = Path(args.file).read_bytes()
    with _load_node(args) as node:
        result = node.ingest_record_bytes(data, source=args.source)
        if result.accepted:
            print(f"accepted (seq {result.previous_seq} -> {result.new_seq})")
            return 0
        print(f"rejected: {result.reason}", file=sys.stderr)
        return 1


def cmd_peers(args: argparse.Namespace) -> int:
    with _load_node(args) as node:
        entries = node.cache.entries()
        if not entries:
            print("(no cached peers)")
            return 0
        for rec, meta in entries:
            self_marker = " (self)" if rec.peer_id == node.peer_id.value else ""
            print(
                f"{rec.peer_id}  seq={rec.seq}  "
                f"endpoints={len(rec.endpoints)}  "
                f"source={meta['source']}  "
                f"access={meta['access_count']}{self_marker}"
            )
    return 0


def cmd_log(args: argparse.Namespace) -> int:
    with _load_node(args) as node:
        entries = list(node.audit.iter_file())
        if args.kind:
            entries = [e for e in entries if e.get("kind") == args.kind]
        for e in entries[-args.tail :]:
            print(json.dumps(e, sort_keys=True))
    return 0


def cmd_gc(args: argparse.Namespace) -> int:
    with _load_node(args) as node:
        out = node.cache.gc()
        print(f"removed {out['removed']} expired record(s)")
    return 0


def cmd_stats(args: argparse.Namespace) -> int:
    with _load_node(args) as node:
        s = node.cache.stats()
        print(json.dumps(s, indent=2, sort_keys=True))
    return 0


def cmd_sim(args: argparse.Namespace) -> int:
    from ..sim import (
        get_scenario,
        list_scenarios,
        run_scenario,
    )

    if args.sim_cmd == "list":
        for name, desc in list_scenarios():
            print(f"  {name:<40} {desc}")
        return 0

    if args.sim_cmd == "run":
        try:
            scenario = get_scenario(args.name)
        except KeyError as e:
            print(str(e), file=sys.stderr)
            return 2
        if args.output is None:
            # Run without persisting; print a compact JSON summary.
            result = run_scenario(scenario)
            out = {
                "scenario": scenario.name,
                "snapshots": [s.to_dict() for s in result.snapshots],
            }
            print(json.dumps(out, indent=2, sort_keys=True))
            return 0
        out_dir = Path(args.output)
        result = run_scenario(scenario, output_dir=out_dir)
        print(f"wrote {len(result.snapshots)} snapshot(s) to {out_dir}")
        print(f"  open: {out_dir / 'index.html'}")
        print(f"  json: {out_dir / 'report.json'}")
        print(f"  md:   {out_dir / 'report.md'}")
        return 0
    return 2


def cmd_dht(args: argparse.Namespace) -> int:
    with _load_node(args) as node:
        if args.dht_cmd == "store":
            if node.directory is None:
                print("no network attached — DHT store unavailable", file=sys.stderr)
                return 1
            records = node.directory.store.all_records()
            print(json.dumps(
                [{"peer_id": r.peer_id, "seq": r.seq,
                  "endpoints": [e.address for e in r.endpoints]}
                 for r in records], indent=2, sort_keys=True,
            ))
            return 0
        if args.dht_cmd == "anti-entropy":
            # Requires a running daemon (or a live in-proc network).
            if node.directory is None:
                print("no network attached — run via daemon", file=sys.stderr)
                return 1
            result = node.directory.sync_with(args.peer_id)
            print(json.dumps(result, indent=2, sort_keys=True, default=str))
            return 0
    return 2


def cmd_signaling(args: argparse.Namespace) -> int:
    # Signaling commands require a running daemon to have a stable
    # UDP socket + signaling engine. Delegate via the daemon client.
    import os
    socket_path = _default_socket_path(args.root)
    if not os.path.exists(socket_path):
        print(f"no daemon running at {socket_path}", file=sys.stderr)
        print("Start it with: decentnet daemon", file=sys.stderr)
        return 1
    body = {"cmd": f"signaling.{args.sig_cmd}"}
    if args.sig_cmd in ("hello", "ring", "bye"):
        body["peer_id"] = args.peer_id
    if args.sig_cmd == "ring":
        try:
            body["body"] = json.loads(args.body)
        except json.JSONDecodeError as e:
            print(f"invalid --body JSON: {e}", file=sys.stderr)
            return 2
    return _daemon_call(socket_path, body)


def cmd_nat(args: argparse.Namespace) -> int:
    from ..transport.udp import UDPTransport
    from ..nat import NATDiscovery

    with _load_node(args) as node:
        udp = UDPTransport(node.peer_id.value)
        try:
            servers = []
            for spec in (args.server if isinstance(args.server, list)
                         else [args.server]):
                host, _, port = spec.rpartition(":")
                servers.append((host, int(port)))
            disc = NATDiscovery(udp, servers, audit=node.audit)
            if args.nat_cmd == "probe":
                mapped = disc.discover(timeout_s=args.timeout)
                if mapped is None:
                    print("STUN timeout", file=sys.stderr)
                    return 1
                print(json.dumps(
                    {"mapped_host": mapped[0], "mapped_port": mapped[1]},
                    indent=2,
                ))
                return 0
            if args.nat_cmd == "classify":
                nat_type = disc.classify()
                print(json.dumps({
                    "nat_type": nat_type.value,
                    "last_mapped": (
                        f"{disc.last_mapped[0]}:{disc.last_mapped[1]}"
                        if disc.last_mapped else None
                    ),
                }, indent=2))
                return 0
        finally:
            udp.close()
    return 2


def cmd_ice(args: argparse.Namespace) -> int:
    from ..ice import candidates_from_endpoints, enumerate_pairs
    with _load_node(args) as node:
        if args.ice_cmd == "enumerate":
            peer_rec = node.cache.peek(args.peer_id)
            own = node.own_record()
            if peer_rec is None:
                print(f"no cached record for {args.peer_id}", file=sys.stderr)
                return 1
            if own is None:
                print("no own record (run `publish` first)", file=sys.stderr)
                return 1
            local_cands = candidates_from_endpoints(own.endpoints)
            remote_cands = candidates_from_endpoints(peer_rec.endpoints)
            pairs = enumerate_pairs(local_cands, remote_cands, we_control=True)
            print(json.dumps([
                {
                    "priority": p.priority(),
                    "local": {"type": p.local.type.value,
                              "addr": f"{p.local.host}:{p.local.port}"},
                    "remote": {"type": p.remote.type.value,
                               "addr": f"{p.remote.host}:{p.remote.port}"},
                }
                for p in pairs
            ], indent=2))
            return 0
    return 2


def cmd_relay(args: argparse.Namespace) -> int:
    from ..relay import RelayServer
    if args.relay_cmd == "serve":
        import time as _t
        relay = RelayServer(bind_host=args.host, bind_port=args.port)
        print(f"relay listening at {relay.bind_host}:{relay.bind_port}")
        print(f"relay pubkey (hex): {relay.public_key.hex()}")
        print("Ctrl-C to stop.")
        try:
            while True:
                _t.sleep(10)
                print(
                    f"  allocations={len(relay.allocations())} "
                    f"allocate_count={relay.allocate_count} "
                    f"forward_count={relay.forward_count}"
                )
        except KeyboardInterrupt:
            print("\nShutting down.")
        finally:
            relay.close()
        return 0
    if args.relay_cmd == "issue-token":
        # Standalone token issuance: uses the node's keypair as the
        # relay operator identity.
        with _load_node(args) as node:
            from ..relay import issue_relay_token
            tok = issue_relay_token(
                node.keypair, args.peer_id, ttl_s=args.ttl,
            )
            print(tok.to_json())
        return 0
    return 2


def cmd_rotate(args: argparse.Namespace) -> int:
    endpoints = [_parse_endpoint_spec(s) for s in args.endpoint]
    with _load_node(args) as node:
        old_pid = node.peer_id.value
        rec, receipt = node.rotate_identity(endpoints=endpoints)
        print(json.dumps({
            "old_peer_id": old_pid,
            "new_peer_id": node.peer_id.value,
            "seq": rec.seq,
            "receipt_signed_by_old_key": True,
        }, indent=2))
    return 0


def cmd_topic(args: argparse.Namespace) -> int:
    with _load_node(args) as node:
        if args.topic_cmd == "list":
            print(json.dumps({
                "replicate_all": node.topic_policy.replicate_all,
                "subscribed_topics": sorted(node.topic_policy.subscribed_topics),
            }, indent=2))
            return 0
        if args.topic_cmd == "subscribe":
            h = node.subscribe_topic(args.name)
            print(f"subscribed '{args.name}' -> hash={h}")
            return 0
        if args.topic_cmd == "mode":
            node.set_replicate_all(args.value == "true")
            print(f"replicate_all = {args.value}")
            return 0
    return 2


def cmd_snapshot(args: argparse.Namespace) -> int:
    import time as _t
    with _load_node(args) as node:
        if args.snap_cmd == "take":
            snap = node.take_snapshot()
            out = args.out or f"snapshot-{_t.time():.0f}.json"
            Path(out).write_bytes(snap.to_bytes())
            print(json.dumps({
                "output": out,
                "record_count": snap.record_count,
                "issued_at": snap.issued_at,
            }, indent=2))
            return 0
        if args.snap_cmd == "import":
            data = Path(args.file).read_bytes()
            result = node.import_snapshot(data)
            print(json.dumps(result, indent=2, sort_keys=True))
            return 0
        if args.snap_cmd == "reconstruct":
            result = node.reconstruct_from_local_snapshots()
            print(json.dumps(result, indent=2, sort_keys=True))
            return 0
    return 2


def cmd_deferred(args: argparse.Namespace) -> int:
    with _load_node(args) as node:
        if args.defrd_cmd == "list":
            items = node.deferred.items()
            print(json.dumps([
                {"id": it.id, "kind": it.kind, "queued_at": it.queued_at,
                 "attempts": it.attempts, "target": it.target}
                for it in items
            ], indent=2))
            return 0
        if args.defrd_cmd == "drain":
            if node.directory is None:
                print(
                    "no network attached — run via `decentnet daemon` to drain",
                    file=sys.stderr,
                )
                return 1
            out = node.drain_deferred()
            print(json.dumps(out, indent=2, sort_keys=True))
            return 0
    return 2


def cmd_confidence(args: argparse.Namespace) -> int:
    with _load_node(args) as node:
        if args.peer_id:
            score = node.confidence.confidence(args.peer_id)
            sources = node.confidence.sources_for(args.peer_id)
            print(json.dumps({
                "peer_id": args.peer_id,
                "confidence": round(score, 4),
                "sources": [
                    {"source": s.source, "seq": s.seq,
                     "observed_at": s.observed_at}
                    for s in sources
                ],
            }, indent=2))
            return 0
        # No peer_id: list all peers we've observed.
        entries = node.cache.entries()
        out = []
        for rec, _ in entries:
            score = node.confidence.confidence(rec.peer_id, current_seq=rec.seq)
            out.append({
                "peer_id": rec.peer_id, "seq": rec.seq,
                "confidence": round(score, 4),
            })
        print(json.dumps(out, indent=2, sort_keys=True))
    return 0


# ---- daemon / client ----

def _root_cfg(root: Optional[str]) -> NodeConfig:
    return NodeConfig.at(root)


def _pidfile_path(root: Optional[str]) -> Path:
    return _root_cfg(root).root / "daemon.pid"


def _read_pidfile(path: Path) -> Optional[int]:
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except Exception:
        return None


def _is_pid_running(pid: int) -> bool:
    import os
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _default_socket_path(root: Optional[str]) -> str:
    from ..node import NodeConfig as _NC
    cfg = _NC.at(root)
    return str(cfg.root / "control.sock")


def _daemon_call(socket_path: str, body: dict) -> int:
    import socket as _sock
    try:
        s = _sock.socket(_sock.AF_UNIX, _sock.SOCK_STREAM)
        s.settimeout(5.0)
        s.connect(socket_path)
        s.sendall((json.dumps(body) + "\n").encode("utf-8"))
        chunks = []
        while True:
            b = s.recv(4096)
            if not b:
                break
            chunks.append(b)
        s.close()
        reply = b"".join(chunks).decode("utf-8").strip()
        if reply:
            print(reply)
        return 0
    except Exception as e:
        print(f"daemon call failed: {e}", file=sys.stderr)
        return 1


def cmd_up(args: argparse.Namespace) -> int:
    import subprocess
    import time

    cfg = _root_cfg(args.root)
    cfg.ensure()
    socket_path = args.socket or _default_socket_path(args.root)
    pidfile = _pidfile_path(args.root)
    existing = _read_pidfile(pidfile)

    file_cfg = apply_runtime_overrides(
        DecentnetConfig.load(args.config),
        bind_host=getattr(args, "udp_host", None),
        bind_port=getattr(args, "udp_port", 0),
    )
    bind_port = file_cfg.transport.bind_port or file_cfg.daemon.udp_port or 0
    advertise_preview = preview_advertised_endpoints(
        config_path=args.config,
        bind_udp_port=bind_port,
        bind_udp_host=file_cfg.transport.bind_host,
    )
    validation = validate_peer_config(file_cfg)
    blockers = startup_blockers(file_cfg)
    startup_summary = {
        "profile_hint": infer_profile_name(file_cfg),
        "endpoint_strategy": describe_endpoint_strategy(file_cfg),
        "bind_host": file_cfg.transport.bind_host,
        "bind_port": bind_port,
        "advertised_endpoints": [e["address"] for e in advertise_preview.get("endpoints", [])],
        "config_validation": validation,
        "startup_blockers": blockers,
    }

    if blockers:
        print(json.dumps({
            "ok": False,
            "startup_refused": True,
            "reason": "config_not_deployable",
            "socket": socket_path,
            "summary": startup_summary,
        }, indent=2))
        return 1

    if existing and _is_pid_running(existing):
        print(json.dumps({
            "ok": True, "already_running": True, "pid": existing, "socket": socket_path,
            "summary": startup_summary,
        }, indent=2))
        return 0
    stdout_log = cfg.root / "daemon.stdout.log"
    stderr_log = cfg.root / "daemon.stderr.log"
    cmd = [sys.executable, "-m", "decentnet", "--root", str(cfg.root), "daemon"]
    if socket_path:
        cmd += ["--socket", socket_path]
    if args.config:
        cmd += ["--config", args.config]
    if args.udp_host:
        cmd += ["--udp-host", args.udp_host]
    if args.udp_port:
        cmd += ["--udp-port", str(args.udp_port)]
    if args.metrics_host:
        cmd += ["--metrics-host", args.metrics_host]
    if args.metrics_port:
        cmd += ["--metrics-port", str(args.metrics_port)]
    if args.log_level:
        cmd += ["--log-level", args.log_level]
    with stdout_log.open("ab") as out, stderr_log.open("ab") as err:
        proc = subprocess.Popen(cmd, stdout=out, stderr=err, start_new_session=True, cwd=str(Path.cwd()))
    pidfile.write_text(str(proc.pid), encoding="utf-8")
    for _ in range(30):
        if Path(socket_path).exists():
            break
        time.sleep(0.1)
    print(json.dumps({
        "ok": True, "pid": proc.pid, "socket": socket_path,
        "stdout_log": str(stdout_log), "stderr_log": str(stderr_log),
        "summary": startup_summary,
    }, indent=2))
    return 0


def cmd_status_cmd(args: argparse.Namespace) -> int:
    socket_path = args.socket or _default_socket_path(args.root)
    pidfile = _pidfile_path(args.root)
    pid = _read_pidfile(pidfile)
    running = bool(pid and _is_pid_running(pid))
    body = {"ok": True, "running": running, "pid": pid, "socket": socket_path, "pidfile": str(pidfile)}
    if Path(socket_path).exists():
        import socket as _sock
        try:
            s = _sock.socket(_sock.AF_UNIX, _sock.SOCK_STREAM)
            s.settimeout(2.0)
            s.connect(socket_path)
            s.sendall(b'{\"cmd\":\"status\"}\n')
            chunks=[]
            while True:
                b=s.recv(4096)
                if not b:
                    break
                chunks.append(b)
            s.close()
            if chunks:
                body["daemon_status"] = json.loads(b"".join(chunks).decode("utf-8").strip())
        except Exception as e:
            body["ok"] = False
            body["error"] = f"status query failed: {e}"
    if args.json:
        print(json.dumps(body, indent=2, sort_keys=True))
    else:
        print(f"running: {body['running']}")
        print(f"pid: {body.get('pid')}")
        print(f"socket: {body['socket']}")
        if body.get("daemon_status"):
            print(json.dumps(body["daemon_status"], indent=2, sort_keys=True))
        elif body.get("error"):
            print(f"error: {body['error']}")
    return 0 if body.get("ok", True) else 1


def cmd_down(args: argparse.Namespace) -> int:
    socket_path = args.socket or _default_socket_path(args.root)
    rc = _daemon_call(socket_path, {"cmd": "shutdown"}) if Path(socket_path).exists() else 1
    pidfile = _pidfile_path(args.root)
    if pidfile.exists():
        try:
            pidfile.unlink()
        except Exception:
            pass
    if Path(socket_path).exists():
        try:
            Path(socket_path).unlink()
        except Exception:
            pass
    return 0 if rc == 0 else 1


def cmd_daemon(args: argparse.Namespace) -> int:
    from ..daemon import run_daemon
    socket_path = args.socket or _default_socket_path(args.root)
    return run_daemon(
        root=args.root, socket_path=socket_path, udp_port=args.udp_port,
        udp_host=getattr(args, "udp_host", None),
        config_path=getattr(args, "config", None),
        metrics_host=getattr(args, "metrics_host", None),
        metrics_port=getattr(args, "metrics_port", 0),
        log_level=getattr(args, "log_level", "info"),
    )


def cmd_client(args: argparse.Namespace) -> int:
    socket_path = args.socket or _default_socket_path(args.root)
    verb = args.client_cmd
    if verb == "raw":
        try:
            body = json.loads(args.request)
        except json.JSONDecodeError as e:
            print(f"invalid request JSON: {e}", file=sys.stderr)
            return 2
    else:
        body: dict = {"cmd": verb}
        if verb in ("lookup", "resolve", "signaling.hello",
                    "signaling.bye"):
            body["peer_id"] = args.peer_id
        elif verb == "signaling.ring":
            body["peer_id"] = args.peer_id
            try:
                body["body"] = json.loads(args.body)
            except json.JSONDecodeError as e:
                print(f"invalid --body JSON: {e}", file=sys.stderr)
                return 2
        elif verb == "log":
            body["tail"] = int(args.tail)
    return _daemon_call(socket_path, body)



def cmd_profile(args: argparse.Namespace) -> int:
    if args.profile_cmd == "list":
        for name in list_profiles():
            print(name)
        return 0
    if args.profile_cmd == "show":
        print(render_profile_toml(args.name, root_override=args.root_override), end="")
        return 0
    return 2


def cmd_config_cmd(args: argparse.Namespace) -> int:
    if args.config_cmd != "init":
        return 2
    cfg = _root_cfg(args.root)
    cfg.ensure()
    out_path = Path(args.out) if args.out else (cfg.root / "config.toml")
    if out_path.exists() and not args.force:
        print(f"config already exists at {out_path}; use --force to overwrite", file=sys.stderr)
        return 1
    rendered = render_profile_toml(args.profile, root_override=args.root_override or str(cfg.root))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(rendered, encoding='utf-8')
    print(json.dumps({"ok": True, "profile": args.profile, "out": str(out_path)}, indent=2))
    return 0

def _prompt_choice(prompt: str, choices: list[str], default: str) -> str:
    choice_str = "/".join(choices)
    while True:
        raw = input(f"{prompt} [{default}] ({choice_str}): ").strip()
        picked = raw or default
        if picked in choices:
            return picked
        print(f"Choose one of: {', '.join(choices)}", file=sys.stderr)


def _prompt_text(prompt: str, default: str) -> str:
    raw = input(f"{prompt} [{default}]: ").strip()
    return raw or default


def cmd_setup(args: argparse.Namespace) -> int:
    from ..doctor import run_doctor

    cfg = _root_cfg(args.root)
    cfg.ensure()
    default_profile = args.profile or "laptop"
    default_out = args.out or str(cfg.root / "config.toml")
    default_root = args.root_override or str(cfg.root)

    if args.yes or not sys.stdin.isatty():
        profile = default_profile
        out_path = Path(default_out)
        root_override = default_root
        start_peer = bool(args.start)
    else:
        profile = _prompt_choice("Peer profile", list_profiles(), default_profile)
        root_override = _prompt_text("Peer root", default_root)
        out_path = Path(_prompt_text("Config output", default_out))
        start_peer = _prompt_choice("Start peer now", ["yes", "no"], "yes" if args.start else "no") == "yes"

    if out_path.exists() and not args.force:
        print(f"config already exists at {out_path}; use --force to overwrite", file=sys.stderr)
        return 1

    rendered = render_profile_toml(profile, root_override=root_override)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(rendered, encoding='utf-8')

    report = run_doctor(
        root=args.root,
        config_path=str(out_path),
        bind_udp_host=None,
        bind_udp_port=None,
        stun_servers=[],
        stun_timeout=2.0,
        pack=None,
        vpn_port=None,
    )
    result = {
        "ok": True,
        "profile": profile,
        "config": str(out_path),
        "root_override": root_override,
        "doctor_ok": report.get("ok", True),
        "doctor_profile_hint": report.get("profile_hint"),
        "doctor_guidance": report.get("doctor_guidance", []),
        "doctor_config_validation": report.get("config_validation", {}),
    }

    if start_peer:
        import types
        up_args = types.SimpleNamespace(
            root=args.root,
            socket=None,
            config=str(out_path),
            udp_host=None,
            udp_port=0,
            metrics_host=None,
            metrics_port=0,
            log_level=None,
        )
        rc = cmd_up(up_args)
        result["start_requested"] = True
        result["start_rc"] = rc
        result["ok"] = (rc == 0)
    else:
        result["start_requested"] = False

    print(json.dumps(result, indent=2))
    return 0 if result["ok"] else 1


def _join_bundle_paths(files: list[str], bundle_dir: Optional[str]) -> list[Path]:
    paths: list[Path] = []
    seen: set[str] = set()
    for raw in files or []:
        p = Path(raw)
        if p.is_file():
            key = str(p.resolve())
            if key not in seen:
                seen.add(key)
                paths.append(p)
    if bundle_dir:
        d = Path(bundle_dir)
        if d.is_dir():
            for p in sorted(d.glob('*.json')):
                key = str(p.resolve())
                if key not in seen:
                    seen.add(key)
                    paths.append(p)
    return paths


def _daemon_json_call(socket_path: str, body: dict) -> dict:
    import socket as _sock
    s = _sock.socket(_sock.AF_UNIX, _sock.SOCK_STREAM)
    s.settimeout(5.0)
    s.connect(socket_path)
    s.sendall((json.dumps(body) + "\n").encode("utf-8"))
    chunks = []
    while True:
        b = s.recv(4096)
        if not b:
            break
        chunks.append(b)
    s.close()
    return json.loads(b"".join(chunks).decode("utf-8").strip() or "{}")



def _make_self_bundle(root: Optional[str], config: Optional[str]) -> Optional[dict]:
    with _load_node(argparse.Namespace(root=root)) as node:
        rec = node.cache.peek(node.peer_id.value)
        if rec is None:
            return None
        file_cfg = DecentnetConfig.load(config)
        return {
            "kind": "decentnet_peer_bundle",
            "version": 1,
            "peer_id": node.peer_id.value,
            "record_wire_b64": base64.b64encode(rec.to_wire_bytes()).decode("ascii"),
            "endpoint_addresses": [e.address for e in rec.endpoints],
            "profile_hint": infer_profile_name(file_cfg),
            "endpoint_strategy": describe_endpoint_strategy(file_cfg),
        }


def _meshpack_peer_summary(bundle: dict) -> dict:
    return {
        "peer_id": bundle.get("peer_id"),
        "endpoint_addresses": bundle.get("endpoint_addresses", []),
        "profile_hint": bundle.get("profile_hint"),
        "endpoint_strategy": bundle.get("endpoint_strategy"),
    }


def _load_meshpack_file(path: str | Path) -> dict:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, dict) or data.get("kind") != "decentnet_mesh_pack":
        raise SystemExit(f"invalid mesh pack: {path}")
    bundles = data.get("bundles")
    if not isinstance(bundles, list) or not bundles:
        raise SystemExit(f"invalid mesh pack bundles: {path}")
    for idx, bundle in enumerate(bundles):
        if not isinstance(bundle, dict) or "record_wire_b64" not in bundle or "peer_id" not in bundle:
            raise SystemExit(f"invalid peer bundle in mesh pack at index {idx}: {path}")
    return data


def _import_bundles_with_optional_contact(args: argparse.Namespace, bundles: list[dict], source: str) -> tuple[dict, int]:
    out = {
        'ok': True,
        'total_files': len(bundles),
        'imported': 0,
        'accepted': 0,
        'rejected': 0,
        'peers': [],
        'hello_attempted': 0,
        'hello_ok': 0,
        'ring_attempted': 0,
        'ring_ok': 0,
    }
    with _load_node(args) as node:
        for bundle in bundles:
            data = _bundle_record_bytes(bundle)
            ingest = node.ingest_record_bytes(data, source=source)
            peer = {
                'file': bundle.get('_source_file'),
                'peer_id': bundle.get('peer_id'),
                'endpoint_addresses': bundle.get('endpoint_addresses', []),
                'accepted': bool(ingest.accepted),
                'reason': ingest.reason,
                'hello': None,
                'ring': None,
            }
            out['imported'] += 1
            if ingest.accepted:
                out['accepted'] += 1
            else:
                out['rejected'] += 1
                out['ok'] = False
            out['peers'].append(peer)
    if getattr(args, 'hello', False) and out['accepted'] > 0:
        socket_path = args.socket or _default_socket_path(args.root)
        try:
            ring_body = json.loads(args.body)
        except json.JSONDecodeError as e:
            print(f"invalid --body JSON: {e}", file=sys.stderr)
            return out, 2
        limit = int(args.hello_limit or 0)
        contacted = 0
        for peer in out['peers']:
            if not peer['accepted']:
                continue
            if limit and contacted >= limit:
                break
            contacted += 1
            out['hello_attempted'] += 1
            try:
                reply = _daemon_json_call(socket_path, {'cmd': 'signaling.hello', 'peer_id': peer['peer_id']})
                peer['hello'] = reply
                if reply.get('ok'):
                    out['hello_ok'] += 1
                    if getattr(args, 'ring', False):
                        out['ring_attempted'] += 1
                        r = _daemon_json_call(socket_path, {'cmd': 'signaling.ring', 'peer_id': peer['peer_id'], 'body': ring_body})
                        peer['ring'] = r
                        if r.get('ok'):
                            out['ring_ok'] += 1
                else:
                    out['ok'] = False
            except Exception as e:
                peer['hello'] = {'ok': False, 'error': str(e)}
                out['ok'] = False
    rc = 0 if out['accepted'] > 0 and (not getattr(args, 'hello', False) or out['hello_attempted'] == out['hello_ok']) else 1
    return out, rc

def cmd_join(args: argparse.Namespace) -> int:
    paths = _join_bundle_paths(getattr(args, 'files', []), getattr(args, 'bundle_dir', None))
    if not paths:
        print('no peer bundles found', file=sys.stderr)
        return 1
    bundles = []
    for path in paths:
        bundle = _load_bundle_file(path)
        bundle['_source_file'] = str(path)
        bundles.append(bundle)
    out, rc = _import_bundles_with_optional_contact(args, bundles, args.source)
    print(json.dumps(out, indent=2, sort_keys=True))
    return rc



def cmd_meshpack(args: argparse.Namespace) -> int:
    if args.meshpack_cmd == "export":
        bundle_paths = _join_bundle_paths(getattr(args, 'files', []), getattr(args, 'bundle_dir', None))
        bundles: list[dict] = []
        by_peer: dict[str, dict] = {}
        if args.include_self:
            self_bundle = _make_self_bundle(args.root, getattr(args, 'config', None))
            if self_bundle is None:
                print("no own record to export; run `decentnet publish` first", file=sys.stderr)
                return 1
            by_peer[self_bundle['peer_id']] = self_bundle
        for path in bundle_paths:
            bundle = _load_bundle_file(path)
            by_peer.setdefault(bundle['peer_id'], bundle)
        bundles = list(by_peer.values())
        if not bundles:
            print('no peer bundles found to export', file=sys.stderr)
            return 1
        pack = {
            'kind': 'decentnet_mesh_pack',
            'version': 1,
            'peer_count': len(bundles),
            'peer_ids': [b.get('peer_id') for b in bundles],
            'bundles': bundles,
        }
        out_path = Path(args.out) if args.out else _meshpack_path_default(args.root)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(pack, indent=2, sort_keys=True), encoding='utf-8')
        print(json.dumps({'ok': True, 'peer_count': len(bundles), 'out': str(out_path)}, indent=2))
        return 0
    if args.meshpack_cmd == 'inspect':
        pack = _load_meshpack_file(args.file)
        out = {
            'ok': True,
            'kind': pack.get('kind'),
            'version': pack.get('version'),
            'peer_count': len(pack.get('bundles', [])),
            'peers': [_meshpack_peer_summary(b) for b in pack.get('bundles', [])],
        }
        print(json.dumps(out, indent=2, sort_keys=True))
        return 0
    if args.meshpack_cmd == 'import':
        pack = _load_meshpack_file(args.file)
        bundles = []
        for idx, bundle in enumerate(pack.get('bundles', [])):
            clone = dict(bundle)
            clone['_source_file'] = f"{args.file}#{idx}"
            bundles.append(clone)
        out, rc = _import_bundles_with_optional_contact(args, bundles, args.source)
        out['meshpack_peer_count'] = len(bundles)
        print(json.dumps(out, indent=2, sort_keys=True))
        return rc
    return 2

def cmd_invite(args: argparse.Namespace) -> int:
    if args.invite_cmd == "export":
        bundle = _load_bundle_file(args.bundle) if getattr(args, "bundle", None) else _make_self_bundle(args.root, getattr(args, "config", None))
        if bundle is None:
            print("no own record to export; run `decentnet publish` first", file=sys.stderr)
            return 1
        token = _invite_token_from_bundle(bundle)
        invite = {
            "kind": "decentnet_peer_invite",
            "version": 1,
            "peer_id": bundle.get("peer_id"),
            "endpoint_addresses": bundle.get("endpoint_addresses", []),
            "profile_hint": bundle.get("profile_hint"),
            "endpoint_strategy": bundle.get("endpoint_strategy"),
            "invite_token": token,
        }
        out_path = Path(args.out) if args.out else _invite_path_default(args.root)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(invite, indent=2, sort_keys=True), encoding="utf-8")
        url = _invite_url_from_token(token, args.url_prefix)
        url_out = None
        if args.url_out:
            url_path = Path(args.url_out)
            url_path.parent.mkdir(parents=True, exist_ok=True)
            url_path.write_text(url + "\n", encoding="utf-8")
            url_out = str(url_path)
        html_out = None
        if args.html_out:
            html_path = Path(args.html_out)
        elif args.out is None:
            html_path = _invite_html_path_default(args.root)
        else:
            html_path = None
        if html_path is not None:
            html_path.parent.mkdir(parents=True, exist_ok=True)
            html_path.write_text(_render_invite_html(invite, token, url), encoding="utf-8")
            html_out = str(html_path)
        qr_svg_out = None
        if args.qr_svg_out:
            qr_svg_path = Path(args.qr_svg_out)
        elif args.out is None:
            qr_svg_path = _invite_qr_svg_path_default(args.root)
        else:
            qr_svg_path = None
        if qr_svg_path is not None:
            qr_svg_path.parent.mkdir(parents=True, exist_ok=True)
            qr_svg_path.write_text(_make_qr_svg(url), encoding="utf-8")
            qr_svg_out = str(qr_svg_path)
        qr_png_out = None
        if args.qr_png_out:
            qr_png_path = Path(args.qr_png_out)
            qr_png_path.parent.mkdir(parents=True, exist_ok=True)
            qr_png_path.write_bytes(_make_qr_png_bytes(url))
            qr_png_out = str(qr_png_path)
        result = {"ok": True, "peer_id": bundle.get("peer_id"), "out": str(out_path), "token_length": len(token), "invite_url": url}
        if url_out:
            result["url_out"] = url_out
        if html_out:
            result["html_out"] = html_out
        if qr_svg_out:
            result["qr_svg_out"] = qr_svg_out
        if qr_png_out:
            result["qr_png_out"] = qr_png_out
        if args.print_token:
            result["invite_token"] = token
        if args.print_url:
            result["invite_url_printed"] = url
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0
    if args.invite_cmd == "inspect":
        bundle, token = _load_invite(args)
        out = {
            "ok": True,
            "peer_id": bundle.get("peer_id"),
            "endpoint_addresses": bundle.get("endpoint_addresses", []),
            "profile_hint": bundle.get("profile_hint"),
            "endpoint_strategy": bundle.get("endpoint_strategy"),
            "kind": "decentnet_peer_invite",
            "version": 1,
            "token_length": len(token),
            "invite_url": _invite_url_from_token(token, "decentnet://invite?token="),
        }
        print(json.dumps(out, indent=2, sort_keys=True))
        return 0
    if args.invite_cmd == "import":
        bundle, _token = _load_invite(args)
        data = _bundle_record_bytes(bundle)
        with _load_node(args) as node:
            result = node.ingest_record_bytes(data, source=args.source)
            out = {
                "ok": bool(result.accepted),
                "peer_id": bundle.get("peer_id"),
                "accepted": bool(result.accepted),
                "previous_seq": result.previous_seq,
                "new_seq": result.new_seq,
                "reason": result.reason,
            }
            print(json.dumps(out, indent=2, sort_keys=True))
            return 0 if result.accepted else 1
    if args.invite_cmd == "serve":
        import time
        server = _create_invite_http_server(args.root, getattr(args, 'config', None), args.host, args.port, getattr(args, 'socket', None))
        bound_host, bound_port = server.server_address[:2]
        print(json.dumps({
            "ok": True,
            "host": bound_host,
            "port": bound_port,
            "url": f"http://{bound_host}:{bound_port}/",
            "api_import": f"http://{bound_host}:{bound_port}/api/import",
        }, indent=2, sort_keys=True))
        try:
            server.serve_forever(poll_interval=0.2)
        except KeyboardInterrupt:
            pass
        finally:
            server.server_close()
        return 0
    return 2


def cmd_bundle(args: argparse.Namespace) -> int:
    if args.bundle_cmd == "export":
        bundle = _make_self_bundle(args.root, getattr(args, "config", None))
        if bundle is None:
            print("no own record to export; run `decentnet publish` first", file=sys.stderr)
            return 1
        out_path = Path(args.out) if args.out else _bundle_path_default(args.root)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(bundle, indent=2, sort_keys=True), encoding="utf-8")
        print(json.dumps({"ok": True, "peer_id": bundle["peer_id"], "out": str(out_path)}, indent=2))
        return 0
    if args.bundle_cmd == "inspect":
        bundle = _load_bundle_file(args.file)
        out = {
            "ok": True,
            "peer_id": bundle.get("peer_id"),
            "endpoint_addresses": bundle.get("endpoint_addresses", []),
            "profile_hint": bundle.get("profile_hint"),
            "endpoint_strategy": bundle.get("endpoint_strategy"),
            "kind": bundle.get("kind"),
            "version": bundle.get("version"),
        }
        if args.json:
            print(json.dumps(out, indent=2, sort_keys=True))
        else:
            print(json.dumps(out, indent=2, sort_keys=True))
        return 0
    if args.bundle_cmd == "import":
        bundle = _load_bundle_file(args.file)
        data = _bundle_record_bytes(bundle)
        with _load_node(args) as node:
            result = node.ingest_record_bytes(data, source=args.source)
            out = {
                "ok": bool(result.accepted),
                "peer_id": bundle.get("peer_id"),
                "accepted": bool(result.accepted),
                "previous_seq": result.previous_seq,
                "new_seq": result.new_seq,
                "reason": result.reason,
            }
            print(json.dumps(out, indent=2, sort_keys=True))
            return 0 if result.accepted else 1
    return 2


def cmd_connect(args: argparse.Namespace) -> int:
    bundle = _load_bundle_file(args.file)
    data = _bundle_record_bytes(bundle)
    peer_id = bundle.get("peer_id")
    with _load_node(args) as node:
        ingest = node.ingest_record_bytes(data, source=args.source)
    out = {
        "ok": bool(ingest.accepted),
        "peer_id": peer_id,
        "import_accepted": bool(ingest.accepted),
        "reason": ingest.reason,
        "hello": None,
        "ring": None,
    }
    if not ingest.accepted:
        if args.json:
            print(json.dumps(out, indent=2, sort_keys=True))
        else:
            print(json.dumps(out, indent=2, sort_keys=True))
        return 1
    socket_path = args.socket or _default_socket_path(args.root)
    if args.hello:
        import socket as _sock
        try:
            s = _sock.socket(_sock.AF_UNIX, _sock.SOCK_STREAM)
            s.settimeout(5.0)
            s.connect(socket_path)
            req = {"cmd": "signaling.hello", "peer_id": peer_id}
            s.sendall((json.dumps(req) + "\n").encode("utf-8"))
            chunks = []
            while True:
                b = s.recv(4096)
                if not b:
                    break
                chunks.append(b)
            s.close()
            reply = json.loads(b"".join(chunks).decode("utf-8").strip() or "{}")
            out["hello"] = reply
            out["ok"] = out["ok"] and bool(reply.get("ok"))
            if args.ring and reply.get("ok"):
                s = _sock.socket(_sock.AF_UNIX, _sock.SOCK_STREAM)
                s.settimeout(5.0)
                s.connect(socket_path)
                try:
                    ring_body = json.loads(args.body)
                except json.JSONDecodeError as e:
                    print(f"invalid --body JSON: {e}", file=sys.stderr)
                    return 2
                req = {"cmd": "signaling.ring", "peer_id": peer_id, "body": ring_body}
                s.sendall((json.dumps(req) + "\n").encode("utf-8"))
                chunks = []
                while True:
                    b = s.recv(4096)
                    if not b:
                        break
                    chunks.append(b)
                s.close()
                out["ring"] = json.loads(b"".join(chunks).decode("utf-8").strip() or "{}")
                out["ok"] = out["ok"] and bool(out["ring"].get("ok"))
        except Exception as e:
            out["hello"] = {"ok": False, "error": str(e)}
            out["ok"] = False
    if args.json:
        print(json.dumps(out, indent=2, sort_keys=True))
    else:
        print(json.dumps(out, indent=2, sort_keys=True))
    return 0 if out["ok"] else 1


def cmd_dashboard(args: argparse.Namespace) -> int:
    from ..dashboard import dashboard_main
    return dashboard_main(args)


def cmd_doctor(args: argparse.Namespace) -> int:
    from ..doctor import render_human, run_doctor

    report = run_doctor(
        root=args.root,
        bind_udp_port=args.bind_udp_port,
        bind_udp_host=args.bind_udp_host,
        config_path=args.config,
        stun_servers=list(args.stun_server or []),
        stun_timeout=args.stun_timeout,
        pack=args.pack,
        vpn_port=args.vpn_port,
    )
    if args.json:
        print(json.dumps(report, indent=2, sort_keys=True))
    else:
        print(render_human(report))
    return 0 if report.get("ok") else 1


def cmd_keystore(args: argparse.Namespace) -> int:
    import getpass
    from ..identity import keystore as _ks
    cfg = NodeConfig.at(args.root)
    cfg.ensure()
    path = cfg.keyfile
    if not path.exists():
        print("no keyfile yet; run `decentnet init` first", file=sys.stderr)
        return 1
    if args.keystore_cmd == "status":
        encrypted = _ks.is_encrypted_keyfile(path)
        print(json.dumps({"encrypted": encrypted, "path": str(path)}, indent=2))
        return 0
    if args.keystore_cmd == "encrypt":
        if _ks.is_encrypted_keyfile(path):
            print("keyfile is already encrypted", file=sys.stderr)
            return 1
        pw = args.passphrase or getpass.getpass("New passphrase: ")
        _ks.wrap_keyfile(path, pw)
        print("keyfile encrypted in place.")
        return 0
    if args.keystore_cmd == "decrypt":
        if not _ks.is_encrypted_keyfile(path):
            print("keyfile is not encrypted", file=sys.stderr)
            return 1
        pw = args.passphrase or getpass.getpass("Passphrase: ")
        try:
            _ks.unwrap_keyfile(path, pw)
        except _ks.KeystoreError as e:
            print(str(e), file=sys.stderr)
            return 1
        print("keyfile decrypted in place.")
        return 0
    return 2


_HANDLERS = {
    "init": cmd_init,
    "whoami": cmd_whoami,
    "publish": cmd_publish,
    "show": cmd_show,
    "lookup": cmd_lookup,
    "export": cmd_export,
    "import": cmd_import,
    "peers": cmd_peers,
    "log": cmd_log,
    "gc": cmd_gc,
    "stats": cmd_stats,
    "sim": cmd_sim,
    "dht": cmd_dht,
    "signaling": cmd_signaling,
    "nat": cmd_nat,
    "ice": cmd_ice,
    "relay": cmd_relay,
    "rotate": cmd_rotate,
    "topic": cmd_topic,
    "snapshot": cmd_snapshot,
    "deferred": cmd_deferred,
    "confidence": cmd_confidence,
    "daemon": cmd_daemon,
    "client": cmd_client,
    "up": cmd_up,
    "status": cmd_status_cmd,
    "down": cmd_down,
    "profile": cmd_profile,
    "config": cmd_config_cmd,
    "setup": cmd_setup,
    "meshpack": cmd_meshpack,
    "invite": cmd_invite,
    "bundle": cmd_bundle,
    "connect": cmd_connect,
    "join": cmd_join,
    "dashboard": cmd_dashboard,
    "doctor": cmd_doctor,
    "keystore": cmd_keystore,
}


def main(argv: Optional[list[str]] = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    handler = _HANDLERS[args.cmd]
    return handler(args)


if __name__ == "__main__":
    sys.exit(main())
