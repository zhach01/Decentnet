"""Shared record-validation pipeline.

Used by both `LocalCache` (L1) and `DHTStore` (L3) so that every store
applies exactly the same rules. This is the single source of truth
for "is this record acceptable to persist right now?".

Rules (in order)
----------------
1. Structural + cryptographic (`LocatorRecord.verify`).
2. `record.issued_at` is not too far in the future (clock-skew clamp).
3. Not hard-expired.
4. If an existing record for the same peer is present:
   a. Same public key (identity continuity), UNLESS the new record
      carries a `prev_key_rotation` receipt whose `prev_peer_id`
      matches and whose signature verifies under the old public key.
      (That's a real key rotation by the rightful owner.)
   b. Strictly newer by `(seq, issued_at)` precedence.

The `max_future_skew_s` default of 300s (5 minutes) matches common
practice — tight enough to make "infinity-seq" attacks impossible,
loose enough to tolerate realistic client clock drift.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from ..utils.time import now_s
from .locator import LocatorRecord, record_is_newer


DEFAULT_MAX_FUTURE_SKEW_S = 300


@dataclass
class ValidationResult:
    ok: bool
    reason: Optional[str] = None
    rotation_accepted: bool = False    # True iff this record introduced a new key for the existing peer_id


def _is_valid_rotation(record: LocatorRecord, existing: LocatorRecord) -> bool:
    """If `record` carries a rotation receipt that legitimately hands
    over from `existing`'s key, return True."""
    rot = record.prev_key_rotation
    if not rot:
        return False
    try:
        from ..identity.rotation import RotationReceipt
        receipt = RotationReceipt.from_dict(rot)
    except Exception:
        return False
    ok, _ = receipt.verify()
    if not ok:
        return False
    # The receipt must hand over from the EXISTING peer to a different new peer.
    if receipt.prev_peer_id != existing.peer_id:
        return False
    if receipt.prev_public_key != existing.public_key:
        return False
    if receipt.new_public_key != record.public_key:
        return False
    return True


def validate_for_storage(
    record: LocatorRecord,
    existing: Optional[LocatorRecord] = None,
    *,
    max_future_skew_s: int = DEFAULT_MAX_FUTURE_SKEW_S,
    at: Optional[int] = None,
) -> ValidationResult:
    """Run the full validation pipeline. Returns a structured result."""
    ok, reason = record.verify()
    if not ok:
        return ValidationResult(False, reason=reason)

    t = now_s() if at is None else at

    if record.issued_at > t + max_future_skew_s:
        return ValidationResult(False, reason="issued_in_future")

    if record.is_hard_expired(at=t):
        return ValidationResult(False, reason="hard_expired")

    if existing is not None:
        if existing.public_key != record.public_key:
            # Either spoofing OR a legitimate rotation. Distinguish.
            if _is_valid_rotation(record, existing):
                # Don't apply seq monotonicity across the rotation
                # boundary (new identity restarts seq at 1).
                return ValidationResult(True, rotation_accepted=True)
            return ValidationResult(False, reason="public_key_mismatch")
        if not record_is_newer(record, existing):
            return ValidationResult(False, reason="not_newer")

    return ValidationResult(True, reason=None)
