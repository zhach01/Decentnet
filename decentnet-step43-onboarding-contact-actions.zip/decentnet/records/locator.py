"""Signed locator records.

A LocatorRecord is what the network actually shares. It binds a
peer's cryptographic identity to a (possibly multi-endpoint) claim
about how to reach them, with freshness and replay protection.

Signing input
-------------
The signature covers the canonical-JSON encoding of the record with
the `signature` field removed. This gives deterministic, portable
signing without depending on any specific Python object representation.

Validity rules (checked by `verify()`)
--------------------------------------
1. `public_key` is a valid Ed25519 public key.
2. `peer_id` matches SHA-256 of `public_key` (base32, unpadded).
3. `signature` verifies under `public_key` over the canonical
   signing input.
4. `version` is a supported protocol version.
5. `issued_at <= expires_at` and `issued_at <= soft_expires_at <= expires_at`.
6. `seq >= 0`.

Freshness, replay, and rollback are enforced at the cache layer,
because those require comparison to previously-seen state.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from .. import PROTOCOL_VERSION
from ..identity.keypair import Keypair, verify_with_public_key
from ..identity.peer_id import PeerId
from ..utils.encoding import (
    b64u_decode,
    b64u_encode,
    canonical_json_bytes,
)
from ..utils.time import now_s
from .endpoints import Endpoint


# Default time-to-live values (seconds). Chosen so that a missed refresh
# doesn't immediately mark a peer unreachable.
DEFAULT_TTL_S = 3600            # hard expiry
DEFAULT_SOFT_TTL_S = 900        # refresh-please threshold


@dataclass
class LocatorRecord:
    """A signed claim: "peer <peer_id> is reachable at <endpoints>, as of <issued_at>"."""

    version: int
    peer_id: str                     # base32, must match sha256(public_key)
    public_key: bytes                # raw 32 bytes
    seq: int                         # monotonic per peer
    issued_at: int
    expires_at: int
    soft_expires_at: int
    endpoints: list[Endpoint] = field(default_factory=list)
    capabilities: list[str] = field(default_factory=list)
    nat_metadata: dict[str, Any] = field(default_factory=dict)
    topic_hashes: list[str] = field(default_factory=list)
    # Per-recipient encrypted endpoint envelopes (selective disclosure).
    # Each entry is the dict form of `EncryptedEnvelope`.
    encrypted_endpoints: list[dict[str, Any]] = field(default_factory=list)
    # Optional: signature over the previous public key by the new one,
    # used for future key rotation (Phase 2+). Currently unused but
    # carried end-to-end so older nodes tolerate its presence.
    prev_key_rotation: Optional[dict[str, str]] = None
    signature: Optional[bytes] = None   # Ed25519 signature over signing_input()

    # ---------- construction ----------

    @classmethod
    def build_and_sign(
        cls,
        keypair: Keypair,
        endpoints: list[Endpoint],
        seq: int,
        *,
        ttl_s: int = DEFAULT_TTL_S,
        soft_ttl_s: int = DEFAULT_SOFT_TTL_S,
        capabilities: Optional[list[str]] = None,
        nat_metadata: Optional[dict[str, Any]] = None,
        topic_hashes: Optional[list[str]] = None,
        issued_at: Optional[int] = None,
        prev_key_rotation: Optional[dict[str, Any]] = None,
        encrypted_endpoints: Optional[list[dict[str, Any]]] = None,
    ) -> "LocatorRecord":
        """Build a new record and sign it with the given keypair.

        `prev_key_rotation` is a serialized RotationReceipt dict;
        include it on the FIRST record published under a new key
        after rotating from `prev_key_rotation['prev_peer_id']`.
        """
        if soft_ttl_s > ttl_s:
            raise ValueError("soft_ttl must be <= ttl")
        t = issued_at if issued_at is not None else now_s()
        rec = cls(
            version=PROTOCOL_VERSION,
            peer_id=PeerId.from_public_key(keypair.public_key_bytes).value,
            public_key=keypair.public_key_bytes,
            seq=int(seq),
            issued_at=int(t),
            expires_at=int(t) + int(ttl_s),
            soft_expires_at=int(t) + int(soft_ttl_s),
            endpoints=list(endpoints),
            capabilities=list(capabilities or []),
            nat_metadata=dict(nat_metadata or {}),
            topic_hashes=list(topic_hashes or []),
            encrypted_endpoints=list(encrypted_endpoints or []),
            prev_key_rotation=dict(prev_key_rotation) if prev_key_rotation else None,
        )
        rec.signature = keypair.sign(rec.signing_input())
        return rec

    # ---------- serialization ----------

    def to_dict(self, *, include_signature: bool = True) -> dict[str, Any]:
        d: dict[str, Any] = {
            "version": int(self.version),
            "peer_id": self.peer_id,
            "public_key": b64u_encode(self.public_key),
            "seq": int(self.seq),
            "issued_at": int(self.issued_at),
            "expires_at": int(self.expires_at),
            "soft_expires_at": int(self.soft_expires_at),
            "endpoints": [e.to_dict() for e in self.endpoints],
            "capabilities": list(self.capabilities),
            "nat_metadata": dict(self.nat_metadata),
            "topic_hashes": list(self.topic_hashes),
            "encrypted_endpoints": list(self.encrypted_endpoints),
        }
        if self.prev_key_rotation is not None:
            d["prev_key_rotation"] = dict(self.prev_key_rotation)
        if include_signature and self.signature is not None:
            d["signature"] = b64u_encode(self.signature)
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "LocatorRecord":
        return cls(
            version=int(d["version"]),
            peer_id=str(d["peer_id"]),
            public_key=b64u_decode(d["public_key"]),
            seq=int(d["seq"]),
            issued_at=int(d["issued_at"]),
            expires_at=int(d["expires_at"]),
            soft_expires_at=int(d["soft_expires_at"]),
            endpoints=[Endpoint.from_dict(e) for e in d.get("endpoints", [])],
            capabilities=list(d.get("capabilities", [])),
            nat_metadata=dict(d.get("nat_metadata", {})),
            topic_hashes=list(d.get("topic_hashes", [])),
            encrypted_endpoints=list(d.get("encrypted_endpoints", [])),
            prev_key_rotation=dict(d["prev_key_rotation"])
                if "prev_key_rotation" in d else None,
            signature=b64u_decode(d["signature"]) if "signature" in d else None,
        )

    def signing_input(self) -> bytes:
        """Canonical bytes used as the signature input (excludes `signature`)."""
        return canonical_json_bytes(self.to_dict(include_signature=False))

    def to_wire_bytes(self) -> bytes:
        """Canonical on-wire representation (signature included)."""
        if self.signature is None:
            raise ValueError("Record is not signed.")
        return canonical_json_bytes(self.to_dict(include_signature=True))

    @classmethod
    def from_wire_bytes(cls, data: bytes) -> "LocatorRecord":
        import json
        return cls.from_dict(json.loads(data.decode("utf-8")))

    # ---------- validation ----------

    def verify(self) -> tuple[bool, Optional[str]]:
        """Return (ok, reason). `reason` is None on success, else a short string."""
        if self.version != PROTOCOL_VERSION:
            return False, f"unsupported protocol version {self.version}"
        if self.signature is None:
            return False, "missing signature"
        if len(self.public_key) != 32:
            return False, "public key must be 32 bytes (Ed25519)"
        expected = PeerId.from_public_key(self.public_key).value
        if expected != self.peer_id:
            return False, "peer_id does not match public_key"
        if self.seq < 0:
            return False, "seq must be non-negative"
        if self.issued_at > self.expires_at:
            return False, "issued_at > expires_at"
        if not (self.issued_at <= self.soft_expires_at <= self.expires_at):
            return False, "soft_expires_at out of range"
        if not verify_with_public_key(
            self.public_key, self.signing_input(), self.signature
        ):
            return False, "signature verification failed"
        return True, None

    # ---------- freshness ----------

    def is_hard_expired(self, *, at: Optional[int] = None) -> bool:
        at = now_s() if at is None else at
        return at >= self.expires_at

    def needs_soft_refresh(self, *, at: Optional[int] = None) -> bool:
        at = now_s() if at is None else at
        return at >= self.soft_expires_at and at < self.expires_at

    def age_s(self, *, at: Optional[int] = None) -> int:
        at = now_s() if at is None else at
        return max(0, at - self.issued_at)


# -------- ordering / precedence --------

def record_is_newer(candidate: LocatorRecord, existing: LocatorRecord) -> bool:
    """Is `candidate` strictly more recent than `existing` for the same peer?

    Precedence rules (applied in order):
        1. Higher seq wins.
        2. Same seq -> later issued_at wins.
        3. Same seq and same issued_at -> candidate is NOT newer (reject to
           prevent equal-seq thrashing; treat as duplicate).
    """
    if candidate.peer_id != existing.peer_id:
        raise ValueError("record_is_newer called on records from different peers")
    if candidate.seq > existing.seq:
        return True
    if candidate.seq < existing.seq:
        return False
    return candidate.issued_at > existing.issued_at
