"""Selective disclosure for LocatorRecord endpoints.

Public endpoint records are visible to anyone who can read the DHT.
For sensitive deployments — friends-only contact info, room-scoped
endpoints, etc. — we want some endpoints to be readable only by an
allowed set of peers.

Approach
--------
A record's `endpoints` field stays signed and authenticated. The
`encrypted_endpoints` field carries one or more "envelopes", each
addressed to a specific allowed peer:

    encrypted_endpoints: [
        {
            recipient: "<peer_id>",
            ephemeral_pub: "<b64url X25519 pub>",
            nonce: "<b64url 12 bytes>",
            ciphertext: "<b64url ChaCha20-Poly1305 ciphertext>",
        },
        ...
    ]

Each envelope contains a JSON-encoded `Endpoint`-list, encrypted to
the recipient's X25519 key derived from their Ed25519 identity.

Crypto details
--------------
* The publisher generates a per-envelope ephemeral X25519 keypair.
* They derive a shared secret via X25519 with the recipient's
  X25519 public key (computed from the recipient's Ed25519 public
  key by the standard signal-protocol-style conversion).
* The shared secret is fed into HKDF-SHA256 to produce a 32-byte
  ChaCha20-Poly1305 key.
* The ciphertext authenticates the (record_peer_id, recipient,
  ephemeral_pub) as additional data so envelopes can't be moved
  between records or recipients.

What this protects
------------------
* Confidentiality of the encrypted endpoint set against everyone
  except the listed recipients.
* Integrity: AEAD plus the additional-data binding mean a
  modified envelope or one swapped to a different recipient fails
  decryption.
* Forward secrecy of envelope keys (per-envelope ephemerals).

What this does NOT protect
--------------------------
* The publisher's identity. The signing key is still the long-term
  Ed25519 key.
* Metadata (who's in the recipient list). The recipient peer_ids
  are visible; if you need recipient anonymity, hash them and have
  recipients try every known hash.
* Replay of the whole record. The signed envelope's seq + issued_at
  + signature already handle that.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Optional

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from ..identity.keypair import Keypair
from ..records.endpoints import Endpoint
from ..utils.encoding import b64u_decode, b64u_encode


HKDF_INFO = b"decentnet/v1 endpoint envelope"


# -------- Ed25519 ↔ X25519 key conversion --------
#
# X25519 uses Curve25519. Ed25519 uses Edwards25519. There's a
# birationally-equivalent map from Ed25519 public keys to X25519
# public keys (RFC 7748 / libsignal). We implement the map manually
# rather than depending on PyNaCl because cryptography>=41 doesn't
# expose it natively.

def _ed25519_pub_to_x25519_pub(ed_pub: bytes) -> bytes:
    """Convert Ed25519 public key to X25519 public key.

    Birational map: Mont = (1 + Y) / (1 - Y) mod p, where Y is the
    Edwards y-coordinate (the Ed25519 public key with sign-bit cleared).
    """
    if len(ed_pub) != 32:
        raise ValueError("expected 32-byte Ed25519 public key")
    p = (1 << 255) - 19
    # Decode y from little-endian; clear the sign bit (top bit of byte 31).
    y_bytes = bytearray(ed_pub)
    y_bytes[31] &= 0x7F
    y = int.from_bytes(y_bytes, "little")
    one_plus_y = (1 + y) % p
    one_minus_y = (1 - y) % p
    inv = pow(one_minus_y, p - 2, p)   # modular inverse
    u = (one_plus_y * inv) % p
    return u.to_bytes(32, "little")


def _ed25519_priv_to_x25519_priv(ed_priv_seed: bytes) -> bytes:
    """Convert Ed25519 private seed to X25519 private key.

    Per RFC 8032 §5.1.5: take SHA-512(seed), keep first 32 bytes,
    apply X25519 clamp (clear bottom 3 bits, clear top bit, set
    second-from-top bit).
    """
    import hashlib
    if len(ed_priv_seed) != 32:
        raise ValueError("expected 32-byte Ed25519 seed")
    h = hashlib.sha512(ed_priv_seed).digest()
    a = bytearray(h[:32])
    a[0] &= 248
    a[31] &= 127
    a[31] |= 64
    return bytes(a)


# -------- envelope helpers --------


@dataclass
class EncryptedEnvelope:
    recipient: str            # peer_id (base32)
    ephemeral_pub: bytes      # X25519 public key (32 bytes)
    nonce: bytes              # 12-byte ChaCha20-Poly1305 nonce
    ciphertext: bytes         # AEAD ciphertext+tag

    def to_dict(self) -> dict:
        return {
            "recipient": self.recipient,
            "ephemeral_pub": b64u_encode(self.ephemeral_pub),
            "nonce": b64u_encode(self.nonce),
            "ciphertext": b64u_encode(self.ciphertext),
        }

    @classmethod
    def from_dict(cls, d: dict) -> "EncryptedEnvelope":
        return cls(
            recipient=d["recipient"],
            ephemeral_pub=b64u_decode(d["ephemeral_pub"]),
            nonce=b64u_decode(d["nonce"]),
            ciphertext=b64u_decode(d["ciphertext"]),
        )


def _aad(publisher_peer_id: str, recipient_peer_id: str,
         ephemeral_pub: bytes) -> bytes:
    """Authenticated additional data binding an envelope to its
    publisher, recipient, and ephemeral key."""
    return (
        b"decentnet/v1|"
        + publisher_peer_id.encode("utf-8") + b"|"
        + recipient_peer_id.encode("utf-8") + b"|"
        + ephemeral_pub
    )


def encrypt_endpoints_for(
    publisher_peer_id: str,
    recipient_ed25519_pub: bytes,
    endpoints: list[Endpoint],
) -> EncryptedEnvelope:
    """Build an envelope of `endpoints` readable only by the holder
    of the Ed25519 private key matching `recipient_ed25519_pub`."""
    from ..identity.peer_id import PeerId
    recipient_peer_id = PeerId.from_public_key(recipient_ed25519_pub).value

    # Per-envelope ephemeral X25519 keypair.
    eph_priv = X25519PrivateKey.generate()
    eph_pub_bytes = eph_priv.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )

    # Recipient's X25519 pubkey from Ed25519 pubkey.
    recip_x_pub_bytes = _ed25519_pub_to_x25519_pub(recipient_ed25519_pub)
    recip_x_pub = X25519PublicKey.from_public_bytes(recip_x_pub_bytes)

    shared = eph_priv.exchange(recip_x_pub)
    aead_key = HKDF(
        algorithm=hashes.SHA256(), length=32,
        salt=None, info=HKDF_INFO,
    ).derive(shared)

    nonce = os.urandom(12)
    plaintext = json.dumps(
        [e.to_dict() for e in endpoints],
        separators=(",", ":"),
    ).encode("utf-8")
    aead = ChaCha20Poly1305(aead_key)
    ct = aead.encrypt(
        nonce, plaintext,
        _aad(publisher_peer_id, recipient_peer_id, eph_pub_bytes),
    )
    return EncryptedEnvelope(
        recipient=recipient_peer_id,
        ephemeral_pub=eph_pub_bytes,
        nonce=nonce,
        ciphertext=ct,
    )


def decrypt_envelope(
    envelope: EncryptedEnvelope,
    publisher_peer_id: str,
    recipient_keypair: Keypair,
) -> Optional[list[Endpoint]]:
    """Decrypt an envelope addressed to `recipient_keypair`. Returns
    the endpoint list or None if not for us / decryption fails."""
    from ..identity.peer_id import PeerId
    our_peer_id = PeerId.from_public_key(
        recipient_keypair.public_key_bytes
    ).value
    if envelope.recipient != our_peer_id:
        return None
    if recipient_keypair.private_key_bytes is None:
        return None

    our_x_priv_bytes = _ed25519_priv_to_x25519_priv(
        recipient_keypair.private_key_bytes
    )
    our_x_priv = X25519PrivateKey.from_private_bytes(our_x_priv_bytes)
    eph_x_pub = X25519PublicKey.from_public_bytes(envelope.ephemeral_pub)

    shared = our_x_priv.exchange(eph_x_pub)
    aead_key = HKDF(
        algorithm=hashes.SHA256(), length=32,
        salt=None, info=HKDF_INFO,
    ).derive(shared)

    aead = ChaCha20Poly1305(aead_key)
    try:
        plaintext = aead.decrypt(
            envelope.nonce, envelope.ciphertext,
            _aad(publisher_peer_id, our_peer_id, envelope.ephemeral_pub),
        )
    except Exception:
        return None
    try:
        items = json.loads(plaintext.decode("utf-8"))
        return [Endpoint.from_dict(d) for d in items]
    except Exception:
        return None
