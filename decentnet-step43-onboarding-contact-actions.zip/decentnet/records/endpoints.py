"""Endpoint candidate definitions.

An endpoint is a candidate "place" where a peer claims (or is
observed) to be reachable. Peers publish multiple candidates because
they usually have several: a LAN address, a STUN-learned public
address, an optional relay candidate, etc. The eventual connectivity
layer will run ICE-style probing to pick one.

Endpoint records do NOT carry a signature by themselves — they are
fields inside the signed LocatorRecord. Their `discovered_by` field
is a hint ("self", "stun", "observed", "relay-assigned") and is
advisory only; verification is at the record level.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Optional


class EndpointType(str, Enum):
    LAN_UDP = "lan_udp"
    PUBLIC_UDP = "public_udp"
    PUBLIC_TCP = "public_tcp"
    VPN_UDP = "vpn_udp"
    TAILSCALE_UDP = "tailscale_udp"
    WIREGUARD_UDP = "wireguard_udp"
    WEBSOCKET = "websocket"
    WEBRTC_CANDIDATE = "webrtc_candidate"
    RELAY_CANDIDATE = "relay_candidate"


_ALLOWED_TYPES = {t.value for t in EndpointType}


@dataclass
class Endpoint:
    """A single candidate address for a peer.

    Fields:
        type:            one of EndpointType values
        address:         "host:port" string (IPv4 "a.b.c.d:p", IPv6 "[::1]:p",
                         or URL for websocket/webrtc candidates)
        priority:        higher = prefer first. Advisory.
        confidence:      0.0-1.0, set by whoever observed the endpoint.
                         Signer sets their own; receivers can decorate
                         cache entries with their own observations.
        discovered_by:   free-form hint (e.g. "self", "stun", "observed")
        last_success:    UNIX seconds of last successful direct connect,
                         or None if never validated. Set by the cache,
                         NOT by the publisher, so signed records usually
                         have None here.
    """

    type: str
    address: str
    priority: int = 0
    confidence: float = 0.5
    discovered_by: Optional[str] = None
    last_success: Optional[int] = None

    def __post_init__(self) -> None:
        if self.type not in _ALLOWED_TYPES:
            raise ValueError(
                f"Unknown endpoint type {self.type!r}; "
                f"allowed: {sorted(_ALLOWED_TYPES)}"
            )
        if not isinstance(self.address, str) or not self.address:
            raise ValueError("Endpoint address must be a non-empty string")
        if not 0.0 <= float(self.confidence) <= 1.0:
            raise ValueError("confidence must be in [0.0, 1.0]")

    # ----- serialization -----

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "type": self.type,
            "address": self.address,
            "priority": int(self.priority),
            "confidence": float(self.confidence),
        }
        if self.discovered_by is not None:
            d["discovered_by"] = self.discovered_by
        if self.last_success is not None:
            d["last_success"] = int(self.last_success)
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Endpoint":
        return cls(
            type=d["type"],
            address=d["address"],
            priority=int(d.get("priority", 0)),
            confidence=float(d.get("confidence", 0.5)),
            discovered_by=d.get("discovered_by"),
            last_success=d.get("last_success"),
        )
