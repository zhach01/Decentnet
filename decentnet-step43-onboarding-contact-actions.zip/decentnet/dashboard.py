from __future__ import annotations

import argparse
import json
import math
import threading
import time
from dataclasses import dataclass, field
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Iterable, Optional
from urllib.parse import urlparse

from .audit.log import AuditLog
from .cache.local import LocalCache
from .identity.keypair import Keypair
from .identity.peer_id import PeerId
from .node.config import NodeConfig


_OPERATOR_KINDS = {
    "two_host_report",
    "two_host_orchestrated_report",
    "two_host_matrix_report",
    "two_host_soak_report",
}


def _safe_load_peer_id(cfg: NodeConfig, entries: list[dict[str, Any]]) -> Optional[str]:
    if cfg.keyfile.exists():
        try:
            kp = Keypair.load(cfg.keyfile)
            return PeerId.from_public_key(kp.public_key_bytes).value
        except Exception:
            pass
    for entry in reversed(entries):
        pid = entry.get("peer_id") or entry.get("peer")
        if isinstance(pid, str) and pid:
            return pid
    return None


def _read_audit_entries(path: Path, tail: int = 400) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    lines = path.read_text(encoding="utf-8").splitlines()
    out: list[dict[str, Any]] = []
    for line in lines[-tail:]:
        line = line.strip()
        if not line:
            continue
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict):
            out.append(payload)
    return out


def _read_json(path: Path) -> Optional[dict[str, Any]]:
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def _expand_paths(files: Iterable[str | Path], dirs: Iterable[str | Path], *, suffix: str = ".json") -> list[Path]:
    out: list[Path] = []
    seen: set[str] = set()
    for item in files:
        p = Path(item)
        key = str(p.resolve()) if p.exists() else str(p)
        if key not in seen:
            out.append(p)
            seen.add(key)
    for d in dirs:
        root = Path(d)
        if not root.exists() or not root.is_dir():
            continue
        for p in sorted(root.rglob(f"*{suffix}")):
            key = str(p.resolve())
            if key not in seen:
                out.append(p)
                seen.add(key)
    return out


def _load_report_rows(files: Iterable[str | Path], dirs: Iterable[str | Path]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in _expand_paths(files, dirs):
        payload = _read_json(path)
        if not payload:
            continue
        kind = payload.get("kind")
        if kind not in _OPERATOR_KINDS:
            continue
        verdict = payload.get("verdict") or {}
        rows.append(
            {
                "path": str(path),
                "label": path.name,
                "kind": kind,
                "ok": bool(payload.get("ok")),
                "checked_at": float(payload.get("checked_at", 0.0) or 0.0),
                "hello_completed": bool(verdict.get("hello_completed") or payload.get("hello_completed")),
                "ring_completed": bool(verdict.get("ring_completed") or payload.get("ring_completed")),
                "relay_used": bool(verdict.get("relay_used") or payload.get("relay_used") or payload.get("relay_runs", 0)),
                "total_runs": int(payload.get("total_runs", 1) or 1),
                "passed_runs": int(payload.get("passed_runs", 1 if payload.get("ok") else 0) or 0),
                "failed_runs": int(payload.get("failed_runs", 0 if payload.get("ok") else 1) or 0),
                "selected_pair_kind": verdict.get("selected_pair_kind_b")
                or verdict.get("selected_pair_kind_a")
                or ((payload.get("host_b") or {}).get("peer", {}) or {}).get("selected_pair_kind")
                or payload.get("selected_pair_kind"),
            }
        )
    rows.sort(key=lambda x: (x["checked_at"], x["path"]))
    return rows


def _summarize_reports(rows: list[dict[str, Any]]) -> dict[str, Any]:
    if not rows:
        return {
            "report_count": 0,
            "ok_count": 0,
            "failed_count": 0,
            "pass_rate": 0.0,
            "relay_used_count": 0,
            "total_runs": 0,
            "passed_runs": 0,
            "failed_runs": 0,
            "by_kind": {},
            "recent_reports": [],
        }
    by_kind: dict[str, dict[str, int]] = {}
    ok_count = 0
    relay_used_count = 0
    total_runs = 0
    passed_runs = 0
    failed_runs = 0
    for row in rows:
        kind = str(row["kind"])
        slot = by_kind.setdefault(kind, {"total": 0, "ok": 0, "failed": 0})
        slot["total"] += 1
        if row["ok"]:
            ok_count += 1
            slot["ok"] += 1
        else:
            slot["failed"] += 1
        if row["relay_used"]:
            relay_used_count += 1
        total_runs += int(row.get("total_runs", 0))
        passed_runs += int(row.get("passed_runs", 0))
        failed_runs += int(row.get("failed_runs", 0))
    return {
        "report_count": len(rows),
        "ok_count": ok_count,
        "failed_count": len(rows) - ok_count,
        "pass_rate": round(ok_count / len(rows), 4),
        "relay_used_count": relay_used_count,
        "total_runs": total_runs,
        "passed_runs": passed_runs,
        "failed_runs": failed_runs,
        "by_kind": by_kind,
        "recent_reports": rows[-8:],
    }


def _load_cache_summary(cfg: NodeConfig) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    if not cfg.cache_db.exists():
        return {"records": 0, "max_records": 0}, []
    cache = LocalCache(cfg.cache_db, audit=AuditLog(None))
    try:
        stats = cache.stats()
        rows: list[dict[str, Any]] = []
        for rec, meta in cache.entries():
            rows.append(
                {
                    "peer_id": rec.peer_id,
                    "seq": rec.seq,
                    "soft_expires_at": rec.soft_expires_at,
                    "expires_at": rec.expires_at,
                    "source": meta["source"],
                    "access_count": meta["access_count"],
                    "endpoints": [
                        {
                            "type": e.type,
                            "address": e.address,
                            "priority": e.priority,
                            "confidence": e.confidence,
                        }
                        for e in rec.endpoints
                    ],
                }
            )
        return stats, rows
    finally:
        cache.close()


def _summarize_event(entry: dict[str, Any], own_peer_id: Optional[str]) -> dict[str, Any]:
    kind = str(entry.get("kind", "unknown"))
    ts = float(entry.get("ts", 0.0))
    peer = entry.get("peer") or entry.get("peer_id")
    from_peer = entry.get("from_peer")
    source = None
    target = None
    summary = kind

    if kind.startswith("signal."):
        source = own_peer_id
        target = entry.get("peer")
        summary = f"{kind} → {str(target)[:10]}" if target else kind
    elif kind.startswith("ice."):
        source = own_peer_id
        target = entry.get("peer")
        summary = f"{kind} {entry.get('path_kind') or entry.get('error') or ''}".strip()
    elif kind.startswith("relay."):
        source = own_peer_id
        target = entry.get("peer")
        summary = f"{kind} {entry.get('relay') or entry.get('reason') or ''}".strip()
    elif kind.startswith("dht.") and isinstance(from_peer, str):
        source = from_peer
        target = own_peer_id
        summary = f"{kind} from {from_peer[:10]}"
    elif kind == "cache.put":
        source_name = entry.get("source")
        target = peer
        source = own_peer_id if source_name in ("self", "bootstrap", "l3", None) else str(source_name)
        summary = f"cache.put {str(peer)[:10]} seq={entry.get('seq')}"
    elif kind == "cache.reject":
        target = peer
        source = own_peer_id
        summary = f"cache.reject {str(peer)[:10]} ({entry.get('reason')})"
    elif kind == "node.publish":
        source = own_peer_id
        target = own_peer_id
        summary = f"publish seq={entry.get('seq')}"
    elif kind == "node.resolve":
        source = own_peer_id
        target = peer
        summary = f"resolve {str(peer)[:10]} hit={entry.get('hit')}"
    elif kind == "directory.join":
        source = own_peer_id
        summary = f"join reachable={entry.get('reachable_seeds')}"
    else:
        source = own_peer_id
        if isinstance(peer, str):
            target = peer

    return {
        "ts": ts,
        "kind": kind,
        "source": source,
        "target": target,
        "summary": summary,
        "raw": entry,
    }


def _infer_online(entries: list[dict[str, Any]], now_ts: float) -> bool:
    if not entries:
        return False
    last = entries[-1]
    if last.get("kind") == "node.stop":
        return False
    return (now_ts - float(last.get("ts", 0))) <= 120.0


def _status_text(entries: list[dict[str, Any]], now_ts: float) -> str:
    if not entries:
        return "unknown"
    last = entries[-1]
    if last.get("kind") == "node.stop":
        return "stopped"
    age = now_ts - float(last.get("ts", 0))
    if age <= 15:
        return "live"
    if age <= 120:
        return "idle"
    return "stale"


def _component_groups(node_ids: list[str], edges: Iterable[tuple[str, str]]) -> dict[str, int]:
    parent = {n: n for n in node_ids}

    def find(x: str) -> str:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: str, b: str) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    for a, b in edges:
        if a in parent and b in parent:
            union(a, b)

    roots: dict[str, int] = {}
    out: dict[str, int] = {}
    next_id = 1
    for n in node_ids:
        r = find(n)
        if r not in roots:
            roots[r] = next_id
            next_id += 1
        out[n] = roots[r]
    return out


def _count_event_prefixes(entries: list[dict[str, Any]]) -> dict[str, int]:
    out = {"signal": 0, "cache": 0, "dht": 0, "node": 0, "relay": 0, "ice": 0, "other": 0}
    for e in entries:
        kind = str(e.get("kind", ""))
        prefix = kind.split(".", 1)[0]
        if prefix in out:
            out[prefix] += 1
        else:
            out["other"] += 1
    return out


def collect_dashboard_state(
    roots: list[str | Path],
    *,
    audit_tail: int = 400,
    event_limit: int = 200,
    soak_reports: Optional[list[str | Path]] = None,
    soak_dirs: Optional[list[str | Path]] = None,
    operator_reports: Optional[list[str | Path]] = None,
    operator_report_dirs: Optional[list[str | Path]] = None,
) -> dict[str, Any]:
    now_ts = time.time()
    node_cards: list[dict[str, Any]] = []
    all_events: list[dict[str, Any]] = []
    global_known: dict[str, dict[str, Any]] = {}
    all_edges: set[tuple[str, str]] = set()

    for root in roots:
        cfg = NodeConfig.at(root)
        entries = _read_audit_entries(cfg.audit_log, tail=audit_tail)
        own_peer_id = _safe_load_peer_id(cfg, entries)
        stats, cache_rows = _load_cache_summary(cfg)

        neighbors: set[str] = set()
        for row in cache_rows:
            pid = row["peer_id"]
            if pid != own_peer_id:
                neighbors.add(pid)
            cur = global_known.get(pid)
            if cur is None or int(row["seq"]) >= int(cur["seq"]):
                global_known[pid] = {
                    "peer_id": pid,
                    "seq": row["seq"],
                    "source_root": str(cfg.root),
                    "endpoints": row["endpoints"],
                }

        event_rows = [_summarize_event(e, own_peer_id) for e in entries]
        for e in event_rows:
            if isinstance(e.get("target"), str) and e["target"] != own_peer_id:
                neighbors.add(e["target"])
                if own_peer_id:
                    all_edges.add((own_peer_id, e["target"]))
            if isinstance(e.get("source"), str) and isinstance(e.get("target"), str):
                all_edges.add((e["source"], e["target"]))
            e["node_root"] = str(cfg.root)
            e["node_peer_id"] = own_peer_id
            all_events.append(e)

        fill_max = max(1, int(stats.get("max_records", 1) or 1))
        fill_count = int(stats.get("records", 0) or 0)
        node_cards.append(
            {
                "root": str(cfg.root),
                "label": Path(cfg.root).name,
                "peer_id": own_peer_id,
                "peer_short": own_peer_id[:10] if own_peer_id else "unknown",
                "online": _infer_online(entries, now_ts),
                "status": _status_text(entries, now_ts),
                "last_event_ts": float(entries[-1]["ts"]) if entries else None,
                "cache_records": fill_count,
                "cache_capacity": fill_max,
                "cache_fill_ratio": min(1.0, fill_count / fill_max),
                "known_neighbors": sorted(neighbors),
                "known_neighbor_count": len(neighbors),
                "local_records": cache_rows[:40],
                "recent_events": event_rows[-25:],
                "event_counts": _count_event_prefixes(entries),
            }
        )

    node_ids = [n["peer_id"] for n in node_cards if n.get("peer_id")]
    groups = _component_groups(node_ids, all_edges)
    for card in node_cards:
        pid = card.get("peer_id")
        card["group"] = groups.get(pid, 0) if pid else 0

    all_events.sort(key=lambda x: x.get("ts", 0))
    recent_events = all_events[-event_limit:]
    recent_kind_counts = {"signal": 0, "relay": 0, "ice": 0, "cache": 0, "other": 0}
    for idx, ev in enumerate(recent_events):
        ev["age_s"] = max(0.0, now_ts - float(ev.get("ts", now_ts)))
        ev["id"] = idx
        prefix = str(ev.get("kind", "")).split(".", 1)[0]
        if prefix in recent_kind_counts:
            recent_kind_counts[prefix] += 1
        else:
            recent_kind_counts["other"] += 1

    report_rows = _load_report_rows(operator_reports or [], operator_report_dirs or [])
    # Soak reports are operator reports too, but allow users to point them separately.
    if soak_reports or soak_dirs:
        existing = {row["path"] for row in report_rows}
        for row in _load_report_rows(soak_reports or [], soak_dirs or []):
            if row["path"] not in existing:
                report_rows.append(row)
                existing.add(row["path"])
        report_rows.sort(key=lambda x: (x["checked_at"], x["path"]))
    operator_summary = _summarize_reports(report_rows)

    state = {
        "generated_at": now_ts,
        "roots": [str(Path(r)) for r in roots],
        "global": {
            "node_count": len(node_cards),
            "online_count": sum(1 for n in node_cards if n["online"]),
            "groups_count": len({n["group"] for n in node_cards if n["group"]}),
            "known_peer_count": len(global_known),
            "recent_event_count": len(recent_events),
            "recent_kind_counts": recent_kind_counts,
            "global_registry": sorted(global_known.values(), key=lambda x: x["peer_id"]),
        },
        "nodes": node_cards,
        "events": recent_events,
        "operator": operator_summary,
    }
    state["layout"] = _build_layout(state)
    return state


def _build_layout(state: dict[str, Any]) -> dict[str, Any]:
    nodes = state["nodes"]
    width = 1100
    height = 660
    groups: dict[int, list[dict[str, Any]]] = {}
    for node in nodes:
        groups.setdefault(int(node.get("group", 0) or 0), []).append(node)
    group_ids = sorted(groups)
    if not group_ids:
        return {"width": width, "height": height, "nodes": [], "edges": []}
    ring_r = min(width, height) * 0.28
    cx = width / 2
    cy = height / 2
    centers = []
    for i, gid in enumerate(group_ids):
        theta = -math.pi / 2 + 2 * math.pi * i / max(1, len(group_ids))
        centers.append((gid, cx + ring_r * math.cos(theta), cy + ring_r * math.sin(theta)))

    node_positions: dict[str, dict[str, float]] = {}
    for gid, gcx, gcy in centers:
        members = sorted(groups[gid], key=lambda n: n.get("peer_id") or "")
        local_r = 90 if len(members) > 1 else 0
        for j, node in enumerate(members):
            ang = -math.pi / 2 + 2 * math.pi * j / max(1, len(members))
            x = gcx + local_r * math.cos(ang)
            y = gcy + local_r * math.sin(ang)
            if node.get("peer_id"):
                node_positions[node["peer_id"]] = {"x": x, "y": y, "group": gid}

    edges = []
    seen = set()
    for ev in state["events"]:
        src = ev.get("source")
        dst = ev.get("target")
        if not (isinstance(src, str) and isinstance(dst, str)):
            continue
        if src not in node_positions or dst not in node_positions:
            continue
        key = (src, dst, ev.get("kind"))
        if key in seen:
            continue
        seen.add(key)
        edges.append({
            "source": src,
            "target": dst,
            "kind": ev.get("kind"),
            "recent": ev.get("age_s", 999) < 8,
            "age_s": ev.get("age_s", 999),
        })

    return {"width": width, "height": height, "nodes": node_positions, "edges": edges}


def _render_html(state: Optional[dict[str, Any]] = None, *, snapshot_mode: bool = False) -> str:
    bootstrap = json.dumps(state or {}, ensure_ascii=False)
    mode = "snapshot" if snapshot_mode else "live"
    return f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>DecentNet {'snapshot' if snapshot_mode else 'live'} dashboard</title>
<style>
:root{{--bg:#0b1220;--panel:#121a2b;--text:#e5eefc;--muted:#9eb2ce;--accent:#67e8f9;--green:#4ade80;--amber:#fbbf24;--red:#f87171;--blue:#60a5fa;--violet:#a78bfa;--line:#23324d}}
*{{box-sizing:border-box}} body{{margin:0;font-family:Inter,ui-sans-serif,system-ui,Arial;background:linear-gradient(180deg,#0a1020,#081019);color:var(--text)}}
header{{padding:18px 22px;border-bottom:1px solid var(--line);display:flex;gap:18px;align-items:end;justify-content:space-between}}
header h1{{margin:0;font-size:24px}} header p{{margin:4px 0 0;color:var(--muted)}}
.grid{{display:grid;grid-template-columns:1.6fr 1fr;gap:16px;padding:16px}}
.panel{{background:rgba(18,26,43,.92);border:1px solid var(--line);border-radius:18px;box-shadow:0 20px 60px rgba(0,0,0,.2)}}
.panel h2{{margin:0;padding:16px 18px 6px;font-size:16px}} .panel .body{{padding:0 18px 18px}}
.cards{{display:grid;grid-template-columns:repeat(8,minmax(0,1fr));gap:12px;padding:16px}}
.card{{background:rgba(255,255,255,.03);border:1px solid var(--line);padding:14px;border-radius:14px}}
.card .label{{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.06em}} .card .value{{font-size:28px;font-weight:700;margin-top:6px}}
#networkWrap{{padding:16px}} .legend{{display:flex;gap:14px;flex-wrap:wrap;color:var(--muted);font-size:12px;padding:0 16px 16px}} .dot{{width:10px;height:10px;display:inline-block;border-radius:999px;margin-right:6px;vertical-align:middle}}
svg{{width:100%;height:auto;display:block;background:radial-gradient(circle at 50% 35%,rgba(29,78,216,.10),transparent 45%),linear-gradient(180deg,rgba(255,255,255,.02),transparent)}}
.tbl{{width:100%;border-collapse:collapse}} .tbl th,.tbl td{{padding:10px 8px;border-bottom:1px solid rgba(255,255,255,.06);text-align:left;font-size:13px}} .tbl th{{color:var(--muted);font-weight:600}}
.badge{{display:inline-block;padding:2px 8px;border-radius:999px;font-size:12px;font-weight:700}} .live{{background:rgba(74,222,128,.15);color:var(--green)}} .idle{{background:rgba(251,191,36,.14);color:var(--amber)}} .stopped,.stale{{background:rgba(248,113,113,.14);color:var(--red)}}
.nodeCard{{border:1px solid rgba(255,255,255,.06);border-radius:14px;padding:12px;margin:0 0 10px;background:rgba(255,255,255,.02)}}
.fill{{height:8px;border-radius:999px;background:#0a1325;border:1px solid rgba(255,255,255,.08);overflow:hidden}} .fill>span{{display:block;height:100%;background:linear-gradient(90deg,var(--accent),var(--blue))}}
.chips{{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}} .chip{{padding:4px 8px;border-radius:999px;background:#0d1628;color:#c9daf5;font-size:12px;border:1px solid rgba(255,255,255,.08)}}
.timeline{{max-height:380px;overflow:auto}} .evt{{padding:10px 0;border-bottom:1px solid rgba(255,255,255,.06)}} .evt .top{{display:flex;justify-content:space-between;gap:12px;font-size:13px}} .evt .kind{{font-weight:700}} .evt .meta{{color:var(--muted);font-size:12px;margin-top:4px}}
.small{{font-size:12px;color:var(--muted)}} .mono{{font-family:ui-monospace,SFMono-Regular,Menlo,monospace}}
@media (max-width:1280px){{.cards{{grid-template-columns:repeat(4,minmax(0,1fr))}}}}
@media (max-width:1100px){{.grid{{grid-template-columns:1fr}}.cards{{grid-template-columns:repeat(2,minmax(0,1fr))}}}}
</style>
</head>
<body>
<header>
  <div>
    <h1>DecentNet {'snapshot' if snapshot_mode else 'live'} network dashboard</h1>
    <p>Global topology, local caches, relay and ICE activity, operator report summaries, and exportable snapshot pages.</p>
  </div>
  <div class="small" id="stamp">waiting…</div>
</header>
<div class="cards" id="cards"></div>
<div class="grid">
  <section class="panel">
    <h2>Network map</h2>
    <div id="networkWrap"><svg id="networkSvg" viewBox="0 0 1100 660"></svg></div>
    <div class="legend">
      <span><i class="dot" style="background:#4ade80"></i>live node</span>
      <span><i class="dot" style="background:#fbbf24"></i>idle node</span>
      <span><i class="dot" style="background:#f87171"></i>stopped or stale</span>
      <span><i class="dot" style="background:#67e8f9"></i>recent signal pulse</span>
      <span><i class="dot" style="background:#a78bfa"></i>relay / ICE activity</span>
    </div>
  </section>
  <section class="panel">
    <h2>Recent circulation</h2>
    <div class="body timeline" id="timeline"></div>
  </section>
  <section class="panel">
    <h2>Local nodes</h2>
    <div class="body" id="nodesPane"></div>
  </section>
  <section class="panel">
    <h2>Operator reports</h2>
    <div class="body"><table class="tbl"><thead><tr><th>Kind</th><th>Status</th><th>Runs</th><th>Relay</th><th>Selected pair</th><th>File</th></tr></thead><tbody id="operatorBody"></tbody></table></div>
  </section>
  <section class="panel">
    <h2>Global registry</h2>
    <div class="body"><table class="tbl"><thead><tr><th>Peer</th><th>Seq</th><th>Source root</th><th>Endpoints</th></tr></thead><tbody id="registryBody"></tbody></table></div>
  </section>
</div>
<script>
const DASHBOARD_MODE = {json.dumps(mode)};
const SNAPSHOT_STATE = {bootstrap};
const fmtAgo = (s) => s < 1 ? 'now' : s < 60 ? `${{Math.round(s)}}s ago` : `${{Math.round(s/60)}}m ago`;
function esc(s){{return String(s).replace(/[&<>]/g,m=>({{'&':'&amp;','<':'&lt;','>':'&gt;'}}[m]));}}
function colorForStatus(status){{if(status==='live')return '#4ade80'; if(status==='idle')return '#fbbf24'; return '#f87171';}}
function renderCards(state){{
  const g=state.global||{{}}; const op=state.operator||{{}};
  const cards=[
    ['Nodes',g.node_count||0],['Online',g.online_count||0],['Groups',g.groups_count||0],
    ['Known peers',g.known_peer_count||0],['ICE events',(g.recent_kind_counts||{{}}).ice||0],['Relay events',(g.recent_kind_counts||{{}}).relay||0],
    ['Reports',op.report_count||0],['Report pass rate', op.report_count ? `${{Math.round((op.pass_rate||0)*100)}}%` : 'n/a']
  ];
  document.getElementById('cards').innerHTML=cards.map(([l,v])=>`<div class="card"><div class="label">${{l}}</div><div class="value">${{v}}</div></div>`).join('');
}}
function renderNodes(state){{
  const html=(state.nodes||[]).map(n=>`<div class="nodeCard">\n<div style="display:flex;justify-content:space-between;gap:12px;align-items:center"><div><strong>${{esc(n.label)}}</strong><div class="small">${{esc(n.peer_short)}} • group ${{n.group || 0}}</div></div><span class="badge ${{esc(n.status)}}">${{esc(n.status)}}</span></div>\n<div class="small" style="margin:10px 0 6px">Local register fill: ${{n.cache_records}} / ${{n.cache_capacity}}</div><div class="fill"><span style="width:${{Math.round((n.cache_fill_ratio||0)*100)}}%"></span></div>\n<div class="small" style="margin-top:10px">Neighbors discovered: ${{n.known_neighbor_count}}</div><div class="chips">${{(n.known_neighbors||[]).slice(0,10).map(p=>`<span class="chip">${{esc(p.slice(0,10))}}</span>`).join('') || '<span class="small">none yet</span>'}}</div>\n<div class="small" style="margin-top:10px">Signals ${{n.event_counts.signal}} • Cache ${{n.event_counts.cache}} • ICE ${{n.event_counts.ice}} • Relay ${{n.event_counts.relay}}</div>\n</div>`).join('');
  document.getElementById('nodesPane').innerHTML=html;
}}
function renderRegistry(state){{
  document.getElementById('registryBody').innerHTML = (state.global.global_registry||[]).map(r=>`<tr><td>${{esc(r.peer_id.slice(0,14))}}</td><td>${{r.seq}}</td><td>${{esc(r.source_root.split('/').slice(-1)[0])}}</td><td>${{esc((r.endpoints||[]).map(e=>e.address).join(', '))}}</td></tr>`).join('');
}}
function renderTimeline(state){{
  document.getElementById('timeline').innerHTML = (state.events||[]).slice().reverse().map(e=>`<div class="evt"><div class="top"><div><span class="kind">${{esc(e.kind)}}</span> · ${{esc(e.summary)}}</div><div class="small">${{fmtAgo(e.age_s||0)}}</div></div><div class="meta">${{esc((e.node_root||'').split('/').slice(-1)[0])}}${{e.target ? ' → ' + esc(String(e.target).slice(0,12)) : ''}}</div></div>`).join('');
}}
function renderOperator(state){{
  const rows=(state.operator&&state.operator.recent_reports)||[];
  document.getElementById('operatorBody').innerHTML = rows.slice().reverse().map(r=>`<tr><td>${{esc(r.kind)}}</td><td>${{r.ok ? 'PASS' : 'FAIL'}}</td><td>${{r.passed_runs}}/${{r.total_runs}}</td><td>${{r.relay_used ? 'yes' : 'no'}}</td><td class="mono">${{esc(r.selected_pair_kind || 'n/a')}}</td><td class="mono">${{esc(r.label)}}</td></tr>`).join('') || '<tr><td colspan="6" class="small">No operator reports loaded.</td></tr>';
}}
function renderMap(state){{
  const svg = document.getElementById('networkSvg');
  const layout = state.layout || {{nodes: {{}}, edges: []}}; const nodes = layout.nodes || {{}};
  const byId = Object.entries(nodes); const groups = {{}}; byId.forEach(([id, p]) => {{ (groups[p.group] ||= []).push(p); }});
  let out = '';
  Object.entries(groups).forEach(([gid, members])=>{{
    const xs = members.map(m=>m.x), ys = members.map(m=>m.y);
    const minX = Math.min(...xs)-80, maxX = Math.max(...xs)+80, minY = Math.min(...ys)-80, maxY = Math.max(...ys)+80;
    out += `<rect x="${{minX}}" y="${{minY}}" rx="32" ry="32" width="${{maxX-minX}}" height="${{maxY-minY}}" fill="rgba(167,139,250,.07)" stroke="rgba(167,139,250,.18)" stroke-dasharray="8 8"></rect>`;
  }});
  (layout.edges||[]).forEach(e=>{{
    const a=nodes[e.source], b=nodes[e.target]; if(!a||!b) return;
    const op = e.recent ? 0.95 : 0.25; const width = e.recent ? 4 : 1.5;
    const prefix = String(e.kind||'').split('.',1)[0];
    const color = prefix==='signal' ? '#67e8f9' : (prefix==='relay' || prefix==='ice') ? '#a78bfa' : prefix==='cache' ? '#60a5fa' : '#94a3b8';
    out += `<line x1="${{a.x}}" y1="${{a.y}}" x2="${{b.x}}" y2="${{b.y}}" stroke="${{color}}" stroke-width="${{width}}" opacity="${{op}}"></line>`;
    if(e.recent){{ const mx=(a.x+b.x)/2,my=(a.y+b.y)/2; out += `<circle cx="${{mx}}" cy="${{my}}" r="5" fill="${{color}}"><animate attributeName="r" values="3;8;3" dur="1.2s" repeatCount="indefinite"/></circle>`; }}
  }});
  (state.nodes||[]).forEach(n=>{{
    const p = nodes[n.peer_id]; if(!p) return; const color = colorForStatus(n.status);
    out += `<circle cx="${{p.x}}" cy="${{p.y}}" r="30" fill="${{color}}" fill-opacity=".16" stroke="${{color}}" stroke-width="2"></circle>`;
    out += `<circle cx="${{p.x}}" cy="${{p.y}}" r="22" fill="#111b30" stroke="${{color}}" stroke-width="3"></circle>`;
    out += `<text x="${{p.x}}" y="${{p.y+5}}" text-anchor="middle" fill="#e5eefc" font-size="12" font-weight="700">${{esc(n.peer_short.slice(0,6))}}</text>`;
    out += `<text x="${{p.x}}" y="${{p.y+42}}" text-anchor="middle" fill="#9eb2ce" font-size="12">${{esc(n.label)}}</text>`;
  }});
  svg.innerHTML = out;
}}
async function tick(){{
  let state;
  if(DASHBOARD_MODE === 'snapshot'){{ state = SNAPSHOT_STATE; }}
  else {{ const res = await fetch('/api/state'); state = await res.json(); }}
  document.getElementById('stamp').textContent = `Updated ${{new Date((state.generated_at||0)*1000).toLocaleTimeString()}}`;
  renderCards(state); renderMap(state); renderTimeline(state); renderNodes(state); renderRegistry(state); renderOperator(state);
}}
if (DASHBOARD_MODE === 'snapshot') {{ tick().catch(console.error); }} else {{ setInterval(()=>tick().catch(console.error), 1000); tick().catch(console.error); }}
</script>
</body>
</html>'''


@dataclass
class DashboardConfig:
    roots: list[Path] = field(default_factory=list)
    host: str = "127.0.0.1"
    port: int = 8765
    audit_tail: int = 400
    event_limit: int = 200
    soak_reports: list[Path] = field(default_factory=list)
    soak_dirs: list[Path] = field(default_factory=list)
    operator_reports: list[Path] = field(default_factory=list)
    operator_report_dirs: list[Path] = field(default_factory=list)
    snapshot_state: Optional[dict[str, Any]] = None


class _DashboardHandler(BaseHTTPRequestHandler):
    server_version = "DecentNetDashboard/0.4"

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path in ("/", "/index.html"):
            cfg: DashboardConfig = self.server.dashboard_config  # type: ignore[attr-defined]
            html = _render_html(cfg.snapshot_state, snapshot_mode=cfg.snapshot_state is not None)
            self._send_html(html)
            return
        if parsed.path == "/api/state":
            cfg: DashboardConfig = self.server.dashboard_config  # type: ignore[attr-defined]
            state = cfg.snapshot_state or collect_dashboard_state(
                cfg.roots,
                audit_tail=cfg.audit_tail,
                event_limit=cfg.event_limit,
                soak_reports=cfg.soak_reports,
                soak_dirs=cfg.soak_dirs,
                operator_reports=cfg.operator_reports,
                operator_report_dirs=cfg.operator_report_dirs,
            )
            self._send_json(state)
            return
        if parsed.path == "/api/config":
            cfg: DashboardConfig = self.server.dashboard_config  # type: ignore[attr-defined]
            self._send_json({
                "roots": [str(r) for r in cfg.roots],
                "host": cfg.host,
                "port": cfg.port,
                "soak_reports": [str(p) for p in cfg.soak_reports],
                "soak_dirs": [str(p) for p in cfg.soak_dirs],
                "operator_reports": [str(p) for p in cfg.operator_reports],
                "operator_report_dirs": [str(p) for p in cfg.operator_report_dirs],
                "snapshot_mode": cfg.snapshot_state is not None,
            })
            return
        self.send_error(HTTPStatus.NOT_FOUND, "not found")

    def log_message(self, fmt: str, *args: Any) -> None:
        return

    def _send_html(self, html: str) -> None:
        body = html.encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_json(self, payload: Any) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


class DashboardServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, config: DashboardConfig):
        super().__init__((config.host, config.port), _DashboardHandler)
        self.dashboard_config = config


def run_dashboard(
    roots: list[str | Path],
    *,
    host: str = "127.0.0.1",
    port: int = 8765,
    audit_tail: int = 400,
    event_limit: int = 200,
    soak_reports: Optional[list[str | Path]] = None,
    soak_dirs: Optional[list[str | Path]] = None,
    operator_reports: Optional[list[str | Path]] = None,
    operator_report_dirs: Optional[list[str | Path]] = None,
    snapshot_state: Optional[dict[str, Any]] = None,
) -> DashboardServer:
    cfg = DashboardConfig(
        roots=[Path(r) for r in roots],
        host=host,
        port=port,
        audit_tail=audit_tail,
        event_limit=event_limit,
        soak_reports=[Path(p) for p in (soak_reports or [])],
        soak_dirs=[Path(p) for p in (soak_dirs or [])],
        operator_reports=[Path(p) for p in (operator_reports or [])],
        operator_report_dirs=[Path(p) for p in (operator_report_dirs or [])],
        snapshot_state=snapshot_state,
    )
    server = DashboardServer(cfg)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


def export_dashboard_snapshot(
    roots: list[str | Path],
    *,
    audit_tail: int = 400,
    event_limit: int = 200,
    soak_reports: Optional[list[str | Path]] = None,
    soak_dirs: Optional[list[str | Path]] = None,
    operator_reports: Optional[list[str | Path]] = None,
    operator_report_dirs: Optional[list[str | Path]] = None,
    json_out: Optional[str | Path] = None,
    html_out: Optional[str | Path] = None,
) -> dict[str, Any]:
    state = collect_dashboard_state(
        roots,
        audit_tail=audit_tail,
        event_limit=event_limit,
        soak_reports=soak_reports,
        soak_dirs=soak_dirs,
        operator_reports=operator_reports,
        operator_report_dirs=operator_report_dirs,
    )
    if json_out:
        Path(json_out).write_text(json.dumps(state, indent=2, sort_keys=True), encoding="utf-8")
    if html_out:
        Path(html_out).write_text(_render_html(state, snapshot_mode=True), encoding="utf-8")
    return state


def load_dashboard_snapshot(path: str | Path) -> dict[str, Any]:
    payload = _read_json(Path(path))
    if payload is None:
        raise FileNotFoundError(path)
    return payload


def _resolve_roots(args: argparse.Namespace) -> list[Path]:
    roots = [Path(r) for r in (getattr(args, "watch_root", None) or [])]
    if getattr(args, "root", None) is not None:
        roots.append(Path(args.root))
    if getattr(args, "roots_dir", None):
        roots.extend(sorted(p for p in Path(args.roots_dir).iterdir() if p.is_dir()))
    dedup: list[Path] = []
    seen = set()
    for r in roots:
        key = str(r.resolve()) if r.exists() else str(r)
        if key not in seen:
            dedup.append(r)
            seen.add(key)
    return dedup


def dashboard_main(args: argparse.Namespace) -> int:
    snapshot_state = None
    roots: list[Path] = []
    if getattr(args, "snapshot_in", None):
        snapshot_state = load_dashboard_snapshot(args.snapshot_in)
    else:
        roots = _resolve_roots(args)
        if not roots:
            raise SystemExit("dashboard needs at least one --watch-root/--roots-dir or --snapshot-in")

    if getattr(args, "snapshot_json_out", None) or getattr(args, "snapshot_html_out", None):
        if snapshot_state is None:
            snapshot_state = export_dashboard_snapshot(
                roots,
                audit_tail=args.audit_tail,
                event_limit=args.event_limit,
                soak_reports=args.soak_report,
                soak_dirs=args.soak_dir,
                operator_reports=args.operator_report,
                operator_report_dirs=args.operator_report_dir,
                json_out=args.snapshot_json_out,
                html_out=args.snapshot_html_out,
            )
        else:
            if args.snapshot_json_out:
                Path(args.snapshot_json_out).write_text(json.dumps(snapshot_state, indent=2, sort_keys=True), encoding="utf-8")
            if args.snapshot_html_out:
                Path(args.snapshot_html_out).write_text(_render_html(snapshot_state, snapshot_mode=True), encoding="utf-8")
    if getattr(args, "once", False):
        return 0

    server = run_dashboard(
        roots,
        host=args.host,
        port=args.port,
        audit_tail=args.audit_tail,
        event_limit=args.event_limit,
        soak_reports=args.soak_report,
        soak_dirs=args.soak_dir,
        operator_reports=args.operator_report,
        operator_report_dirs=args.operator_report_dir,
        snapshot_state=snapshot_state,
    )
    bound_host, bound_port = server.server_address
    print(f"Dashboard running on http://{bound_host}:{bound_port}")
    if snapshot_state is not None and not roots:
        print("Serving snapshot mode from embedded state")
    else:
        print("Watching roots:")
        for root in roots:
            print(f"  - {root}")
    try:
        while True:
            time.sleep(1.0)
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()
        server.server_close()
    return 0
