from __future__ import annotations

import json
import os
import shutil
import socket
import tempfile
import zipfile
from pathlib import Path
from typing import Any, Mapping

from . import __version__
from .identity.keystore import is_encrypted_keyfile
from .node import Node, NodeConfig
from . import vpn as vpn_mod
from .config_file import DecentnetConfig, describe_endpoint_strategy, infer_profile_name, validate_peer_config
from .interfaces import detect_lan_endpoints, parse_interface_addresses


def _sha256_file(path: Path) -> str:
    import hashlib

    h = hashlib.sha256()
    with path.open('rb') as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def inspect_root(root: Path) -> dict[str, Any]:
    cfg = NodeConfig.at(root)
    info: dict[str, Any] = {
        'root': str(cfg.root),
        'exists': cfg.root.exists(),
        'writable': False,
        'files': {
            'keyfile': cfg.keyfile.exists(),
            'cache_db': cfg.cache_db.exists(),
            'audit_log': cfg.audit_log.exists(),
            'seq_file': cfg.seq_file.exists(),
            'dht_store_db': cfg.dht_store_db.exists(),
            'snapshot_db': cfg.snapshot_db.exists(),
        },
    }
    try:
        cfg.root.mkdir(parents=True, exist_ok=True)
        probe = cfg.root / '.doctor-write-test'
        probe.write_text('ok', encoding='utf-8')
        probe.unlink()
        info['writable'] = True
    except Exception as e:
        info['write_error'] = str(e)

    if cfg.keyfile.exists():
        info['keyfile_encrypted'] = is_encrypted_keyfile(cfg.keyfile)
    else:
        info['keyfile_encrypted'] = None

    if cfg.keyfile.exists() and not info['keyfile_encrypted']:
        try:
            with Node(cfg) as node:
                info['peer_id'] = node.peer_id.value
                info['cache_stats'] = node.cache.stats()
                own = node.own_record()
                if own is not None:
                    info['own_record'] = {
                        'seq': own.seq,
                        'endpoint_count': len(own.endpoints),
                    }
        except Exception as e:
            info['node_error'] = str(e)
    return info




def preview_advertised_endpoints(*, config_path: str | Path | None, bind_udp_port: int | None, bind_udp_host: str | None = None, vpn_port: int | None = None, vpn_env: Mapping[str, str] | None = None, vpn_ip_output: str | None = None, lan_env: Mapping[str, str] | None = None, lan_ip_output: str | None = None) -> dict[str, Any]:
    cfg = DecentnetConfig.load(config_path)
    bind_host = bind_udp_host or cfg.transport.bind_host
    bind_port = bind_udp_port if bind_udp_port is not None else (cfg.transport.bind_port or cfg.daemon.udp_port or 0)
    endpoints: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    warnings: list[str] = []

    def _add(ep_type: str, addr: str, source: str) -> None:
        key = (ep_type, addr)
        if key in seen:
            return
        seen.add(key)
        endpoints.append({"type": ep_type, "address": addr, "source": source})

    for item in cfg.advertise.manual_endpoints:
        ep_type = str(item.get("type", "public_udp"))
        addr = str(item.get("address", "")).strip()
        if addr:
            _add(ep_type, addr, "manual")

    if cfg.advertise.mode in {"auto", "hybrid"} and cfg.advertise.auto_lan and bind_port:
        lan_eps = detect_lan_endpoints(
            cfg.advertise.lan_port or bind_port,
            allow=cfg.interfaces.allow,
            deny=cfg.interfaces.deny,
            env=lan_env,
            ip_output=lan_ip_output,
        )
        for ep in lan_eps:
            _add(ep.type, ep.address, f"lan:{ep.discovered_by}")
    eff_vpn_port = vpn_port if vpn_port is not None else (cfg.advertise.vpn_port or bind_port)
    if cfg.advertise.mode in {"auto", "hybrid"} and cfg.advertise.auto_vpn and eff_vpn_port:
        for ep in vpn_mod.detect_vpn_endpoints(eff_vpn_port, env=vpn_env, ip_output=vpn_ip_output):
            _add(ep.type, ep.address, "vpn")

    bind_loopback_only = bind_host.startswith("127.") or bind_host == "localhost"
    for item in endpoints:
        host = item["address"].rsplit(":", 1)[0].strip("[]")
        if bind_loopback_only and host not in {"127.0.0.1", "localhost"}:
            warnings.append(f"bind_host {bind_host} is loopback-only but advertised endpoint {item['address']} is non-loopback")
    return {
        "bind_host": bind_host,
        "bind_port": bind_port,
        "endpoints": endpoints,
        "validation_warnings": warnings,
    }

def udp_bind_check(port: int = 0, host: str = "127.0.0.1") -> dict[str, Any]:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.bind((host, port))
        bound = sock.getsockname()
        return {
            'ok': True,
            'bound_host': bound[0],
            'bound_port': bound[1],
        }
    except Exception as e:
        return {'ok': False, 'error': str(e), 'host': host, 'port': port}
    finally:
        sock.close()


def stun_check(server_specs: list[str], timeout_s: float = 2.0) -> list[dict[str, Any]]:
    from .nat import NATDiscovery
    from .transport.udp import UDPTransport

    if not server_specs:
        return []
    udp = UDPTransport('doctor-check', bind_port=0)
    try:
        results: list[dict[str, Any]] = []
        for spec in server_specs:
            host, _, port_s = spec.rpartition(':')
            port = int(port_s)
            entry: dict[str, Any] = {'server': spec}
            try:
                entry['resolved_host'] = socket.gethostbyname(host)
            except Exception as e:
                entry['ok'] = False
                entry['error'] = f'DNS resolution failed: {e}'
                results.append(entry)
                continue
            try:
                disc = NATDiscovery(udp, [(host, port)])
                mapped = disc.discover(timeout_s=timeout_s)
                if mapped is None:
                    entry['ok'] = False
                    entry['error'] = 'STUN timeout'
                else:
                    entry['ok'] = True
                    entry['mapped_host'] = mapped[0]
                    entry['mapped_port'] = mapped[1]
            except Exception as e:
                entry['ok'] = False
                entry['error'] = str(e)
            results.append(entry)
        return results
    finally:
        udp.close()


def verify_pack(pack_path: Path) -> dict[str, Any]:
    pack_path = Path(pack_path)
    tmpdir_obj = None
    base_dir = pack_path
    zip_checked = False
    if pack_path.is_file() and pack_path.suffix.lower() == '.zip':
        tmpdir_obj = tempfile.TemporaryDirectory(prefix='decentnet-pack-verify-')
        base_dir = Path(tmpdir_obj.name)
        with zipfile.ZipFile(pack_path, 'r') as zf:
            zf.extractall(base_dir)
        zip_checked = True
    manifest_path = base_dir / 'manifest.json'
    result: dict[str, Any] = {
        'path': str(pack_path),
        'zip_checked': zip_checked,
        'manifest_exists': manifest_path.exists(),
        'ok': False,
        'file_count': 0,
        'verified_files': 0,
        'missing_files': [],
        'hash_mismatches': [],
    }
    try:
        if not manifest_path.exists():
            result['error'] = 'manifest.json missing'
            return result
        manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
        result['kind'] = manifest.get('kind')
        result['generated_at'] = manifest.get('generated_at')
        files = manifest.get('files', [])
        result['file_count'] = len(files)
        for item in files:
            rel = item.get('bundle_path')
            expected_sha = item.get('sha256')
            expected_size = item.get('size')
            if not rel:
                result['hash_mismatches'].append({'bundle_path': rel, 'error': 'missing bundle_path'})
                continue
            path = base_dir / rel
            if not path.exists():
                result['missing_files'].append(rel)
                continue
            actual_sha = _sha256_file(path)
            actual_size = path.stat().st_size
            if expected_sha and actual_sha != expected_sha:
                result['hash_mismatches'].append({'bundle_path': rel, 'expected': expected_sha, 'actual': actual_sha})
                continue
            if expected_size is not None and actual_size != expected_size:
                result['hash_mismatches'].append({'bundle_path': rel, 'expected_size': expected_size, 'actual_size': actual_size})
                continue
            result['verified_files'] += 1
        snap = manifest.get('snapshot', {})
        result['snapshot_json_exists'] = bool(snap.get('json')) and (base_dir / snap.get('json')).exists()
        result['snapshot_html_exists'] = bool(snap.get('html')) and (base_dir / snap.get('html')).exists()
        result['ok'] = (
            result['manifest_exists']
            and not result['missing_files']
            and not result['hash_mismatches']
            and result['verified_files'] == result['file_count']
        )
        return result
    finally:
        if tmpdir_obj is not None:
            tmpdir_obj.cleanup()


def run_doctor(
    *,
    root: str | Path | None,
    bind_udp_port: int | None = None,
    bind_udp_host: str | None = None,
    config_path: str | Path | None = None,
    stun_servers: list[str] | None = None,
    stun_timeout: float = 2.0,
    pack: str | Path | None = None,
    vpn_port: int | None = None,
    vpn_env: Mapping[str, str] | None = None,
    vpn_ip_output: str | None = None,
    lan_env: Mapping[str, str] | None = None,
    lan_ip_output: str | None = None,
) -> dict[str, Any]:
    root_path = Path(root) if root is not None else NodeConfig.at(None).root
    data: dict[str, Any] = {
        'kind': 'decentnet_doctor',
        'version': __version__,
        'root': inspect_root(root_path),
    }
    checks: list[bool] = [data['root'].get('writable', False)]
    cfg_preview = DecentnetConfig.load(config_path)
    data['profile_hint'] = infer_profile_name(cfg_preview)
    data['endpoint_strategy'] = describe_endpoint_strategy(cfg_preview)
    data['config_validation'] = validate_peer_config(cfg_preview)
    effective_bind_host = bind_udp_host or cfg_preview.transport.bind_host or '127.0.0.1'
    if bind_udp_port is not None:
        data['udp_bind'] = udp_bind_check(bind_udp_port, host=effective_bind_host)
        checks.append(bool(data['udp_bind'].get('ok')))
    eff_vpn_port = vpn_port
    if eff_vpn_port is None and isinstance(data.get('udp_bind'), dict) and data['udp_bind'].get('ok'):
        eff_vpn_port = int(data['udp_bind']['bound_port'])
    vpn_ifaces = vpn_mod.detect_vpn_interfaces(env=vpn_env, ip_output=vpn_ip_output)
    vpn_eps = vpn_mod.detect_vpn_endpoints(eff_vpn_port, env=vpn_env, ip_output=vpn_ip_output) if eff_vpn_port is not None else []
    data['lan'] = {
        'interfaces': [item.__dict__ for item in parse_interface_addresses(lan_ip_output if lan_ip_output is not None else '', allow=cfg_preview.interfaces.allow, deny=cfg_preview.interfaces.deny)] if lan_ip_output is not None else [item.__dict__ for item in parse_interface_addresses('', allow=cfg_preview.interfaces.allow, deny=cfg_preview.interfaces.deny)],
        'endpoints': [ep.to_dict() for ep in detect_lan_endpoints(cfg_preview.advertise.lan_port or eff_vpn_port or cfg_preview.transport.bind_port or 0, allow=cfg_preview.interfaces.allow, deny=cfg_preview.interfaces.deny, env=lan_env, ip_output=lan_ip_output)] if (cfg_preview.advertise.lan_port or eff_vpn_port or cfg_preview.transport.bind_port) else [],
    }
    data['vpn'] = {
        'requested_port': eff_vpn_port,
        'interface_count': len(vpn_ifaces),
        'endpoint_count': len(vpn_eps),
        'interfaces': [iface.__dict__ for iface in vpn_ifaces],
        'endpoints': [ep.to_dict() for ep in vpn_eps],
    }
    if stun_servers:
        data['stun'] = stun_check(list(stun_servers), timeout_s=stun_timeout)
        checks.extend(bool(item.get('ok')) for item in data['stun'])
    data['advertise_preview'] = preview_advertised_endpoints(
        config_path=config_path,
        bind_udp_port=bind_udp_port,
        vpn_port=vpn_port,
        vpn_env=vpn_env,
        vpn_ip_output=vpn_ip_output,
        lan_env=lan_env,
        lan_ip_output=lan_ip_output,
    )
    data['doctor_guidance'] = []
    if data['profile_hint'] == 'phone':
        data['doctor_guidance'].append('Phone profile works best with auto or hybrid advertise mode and VPN/LAN preference.')
    elif data['profile_hint'] == 'rpi':
        data['doctor_guidance'].append('Raspberry Pi peers should usually bind on 0.0.0.0 and prefer stable LAN or VPN interfaces.')
    elif data['profile_hint'] == 'helper':
        data['doctor_guidance'].append('Helper peers should stay long-lived, bind on non-loopback addresses, and publish reachable LAN/VPN/manual endpoints.')
    else:
        data['doctor_guidance'].append('Laptop peers usually work best in hybrid mode with LAN and VPN auto-detection enabled.')
    if data['config_validation']['warnings']:
        data['doctor_guidance'].append('Fix validation warnings before expecting reliable multi-device reachability.')
    if data['advertise_preview']['validation_warnings']:
        data['doctor_guidance'].append('Advertised endpoints do not match the current bind scope; other peers may not reach this node.')
    if pack is not None:
        data['pack'] = verify_pack(Path(pack))
        checks.append(bool(data['pack'].get('ok')))
    data['ok'] = all(checks) if checks else True
    return data


def render_human(report: dict[str, Any]) -> str:
    lines = [
        f"DecentNet doctor {report.get('version')}",
        f"overall: {'OK' if report.get('ok') else 'FAIL'}",
        f"root: {report['root'].get('root')}",
        f"  exists={report['root'].get('exists')} writable={report['root'].get('writable')} keyfile={report['root']['files'].get('keyfile')} cache={report['root']['files'].get('cache_db')}",
    ]
    if report['root'].get('peer_id'):
        lines.append(f"  peer_id={report['root']['peer_id']}")
    if report['root'].get('keyfile_encrypted') is not None:
        lines.append(f"  keyfile_encrypted={report['root']['keyfile_encrypted']}")
    if report.get('profile_hint'):
        lines.append(f"profile_hint: {report['profile_hint']}")
    if report.get('endpoint_strategy'):
        lines.append(f"endpoint_strategy: {report['endpoint_strategy']}")
    if report.get('config_validation'):
        cv = report['config_validation']
        lines.append(f"config_validation: warnings={len(cv.get('warnings', []))} errors={len(cv.get('errors', []))}")
        for warn in cv.get('warnings', [])[:5]:
            lines.append(f"  warning={warn}")
        for err in cv.get('errors', [])[:5]:
            lines.append(f"  error={err}")
    if 'udp_bind' in report:
        ub = report['udp_bind']
        lines.append(f"udp_bind: {'OK' if ub.get('ok') else 'FAIL'}")
        if ub.get('ok'):
            lines.append(f"  bound={ub.get('bound_host')}:{ub.get('bound_port')}")
        else:
            lines.append(f"  error={ub.get('error')}")
    for item in report.get('stun', []) or []:
        lines.append(f"stun {item.get('server')}: {'OK' if item.get('ok') else 'FAIL'}")
        if item.get('ok'):
            lines.append(f"  mapped={item.get('mapped_host')}:{item.get('mapped_port')}")
        else:
            lines.append(f"  error={item.get('error')}")
    if report.get('lan'):
        lan = report['lan']
        lines.append(f"lan: endpoints={len(lan.get('endpoints', []))}")
        for ep in lan.get('endpoints', [])[:5]:
            lines.append(f"  {ep.get('type')} {ep.get('address')}")
    if report.get('vpn'):
        vpn = report['vpn']
        lines.append(f"vpn: interfaces={vpn.get('interface_count')} endpoints={vpn.get('endpoint_count')}")
        for ep in vpn.get('endpoints', [])[:5]:
            lines.append(f"  {ep.get('type')} {ep.get('address')}")
    if report.get('advertise_preview'):
        ap = report['advertise_preview']
        lines.append(f"advertise_preview: bind={ap.get('bind_host')}:{ap.get('bind_port')} endpoints={len(ap.get('endpoints', []))}")
        for ep in ap.get('endpoints', [])[:5]:
            lines.append(f"  {ep.get('type')} {ep.get('address')} [{ep.get('source')}]")
        for warn in ap.get('validation_warnings', [])[:5]:
            lines.append(f"  warning={warn}")
    if report.get('doctor_guidance'):
        lines.append('guidance:')
        for item in report['doctor_guidance'][:5]:
            lines.append(f"  - {item}")
    if 'pack' in report:
        pack = report['pack']
        lines.append(f"pack: {'OK' if pack.get('ok') else 'FAIL'} {pack.get('path')}")
        lines.append(f"  verified_files={pack.get('verified_files')}/{pack.get('file_count')}")
        if pack.get('missing_files'):
            lines.append(f"  missing={len(pack['missing_files'])}")
        if pack.get('hash_mismatches'):
            lines.append(f"  mismatches={len(pack['hash_mismatches'])}")
    return '\n'.join(lines)
