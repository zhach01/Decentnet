"""Compact anti-entropy summaries: Bloom filters and Merkle digests.

These replace the full-list summary exchange from Phase 2 for large
stores where shipping every (peer_id, seq) pair is wasteful.

Usage is peer-negotiated: if your counterparty advertises support
for "bloom_summary" in its bootstrap manifest capability list, you
can send/accept a `BloomSummary` instead of a flat list.

Bloom filter
------------
For rough "does peer_id X probably exist in your store?" queries,
used for cheap first-pass comparison. The classic k-hash formula:

    size_bits = ceil(-n * ln(p) / (ln 2)^2)
    n_hashes  = round(size_bits / n * ln 2)

We use two SHA-256 hashes + double-hashing to derive `k` positions
per element.

Merkle bucket digest
--------------------
Splits the keyspace into 256 buckets by the first byte of the
peer_id hash. For each bucket we compute a Merkle root over the
sorted (peer_id, seq) tuples. A counterparty compares bucket roots:
buckets with equal roots are skipped; buckets with mismatched roots
trigger a full (peer_id, seq) exchange for that bucket only.

This gives `O(number-of-differing-buckets * bucket-size)` exchange
instead of `O(total-store-size)` for nodes with mostly-identical
stores.
"""
from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass, field
from typing import Iterable

from ..utils.encoding import b64u_decode, b64u_encode


# ---------------------------------------------------------------- Bloom


@dataclass
class BloomSummary:
    size_bits: int
    n_hashes: int
    bits: bytearray

    @classmethod
    def for_capacity(
        cls, expected_n: int, *, false_positive_rate: float = 0.01
    ) -> "BloomSummary":
        if expected_n < 1:
            expected_n = 1
        p = max(1e-9, min(0.5, false_positive_rate))
        size_bits = max(64, int(math.ceil(
            -expected_n * math.log(p) / (math.log(2) ** 2)
        )))
        # Round up to a byte boundary.
        size_bits = ((size_bits + 7) // 8) * 8
        n_hashes = max(1, int(round(size_bits / expected_n * math.log(2))))
        return cls(size_bits=size_bits, n_hashes=n_hashes,
                   bits=bytearray(size_bits // 8))

    def _positions(self, key: str) -> list[int]:
        h = hashlib.sha256(key.encode("utf-8")).digest()
        h1 = int.from_bytes(h[:16], "big")
        h2 = int.from_bytes(h[16:], "big") or 1
        return [
            (h1 + i * h2) % self.size_bits
            for i in range(self.n_hashes)
        ]

    def add(self, key: str) -> None:
        for pos in self._positions(key):
            byte = pos >> 3
            bit = 1 << (pos & 7)
            self.bits[byte] |= bit

    def contains(self, key: str) -> bool:
        for pos in self._positions(key):
            byte = pos >> 3
            bit = 1 << (pos & 7)
            if not (self.bits[byte] & bit):
                return False
        return True

    def to_dict(self) -> dict:
        return {
            "size_bits": self.size_bits,
            "n_hashes": self.n_hashes,
            "bits": b64u_encode(bytes(self.bits)),
        }

    @classmethod
    def from_dict(cls, d: dict) -> "BloomSummary":
        return cls(
            size_bits=int(d["size_bits"]),
            n_hashes=int(d["n_hashes"]),
            bits=bytearray(b64u_decode(d["bits"])),
        )


def build_bloom_for_peers(peer_ids: Iterable[str], *,
                          false_positive_rate: float = 0.01
                          ) -> BloomSummary:
    peer_list = list(peer_ids)
    bloom = BloomSummary.for_capacity(
        len(peer_list), false_positive_rate=false_positive_rate,
    )
    for pid in peer_list:
        bloom.add(pid)
    return bloom


# --------------------------------------------------------------- Merkle


def _leaf_hash(peer_id: str, seq: int) -> bytes:
    return hashlib.sha256(
        peer_id.encode("utf-8") + b"|" + str(int(seq)).encode("ascii")
    ).digest()


def _node_hash(left: bytes, right: bytes) -> bytes:
    return hashlib.sha256(left + right).digest()


def _merkle_root(leaves: list[bytes]) -> bytes:
    if not leaves:
        return b"\x00" * 32
    layer = list(leaves)
    while len(layer) > 1:
        nxt = []
        for i in range(0, len(layer), 2):
            left = layer[i]
            right = layer[i + 1] if i + 1 < len(layer) else layer[i]
            nxt.append(_node_hash(left, right))
        layer = nxt
    return layer[0]


@dataclass
class MerkleBucketSummary:
    """256-bucket summary: bucket_id = first byte of sha256(peer_id)."""
    bucket_roots: list[bytes] = field(default_factory=lambda: [b""] * 256)
    bucket_counts: list[int] = field(default_factory=lambda: [0] * 256)

    @classmethod
    def build(
        cls, entries: Iterable[tuple[str, int]]
    ) -> "MerkleBucketSummary":
        buckets: list[list[tuple[str, int]]] = [[] for _ in range(256)]
        for peer_id, seq in entries:
            b = hashlib.sha256(peer_id.encode("utf-8")).digest()[0]
            buckets[b].append((peer_id, int(seq)))
        roots = []
        counts = []
        for b in buckets:
            b.sort()
            leaves = [_leaf_hash(pid, s) for pid, s in b]
            roots.append(_merkle_root(leaves))
            counts.append(len(b))
        return cls(bucket_roots=roots, bucket_counts=counts)

    def diff_buckets(self, other: "MerkleBucketSummary") -> list[int]:
        """Return the bucket indices where our root differs from
        `other`'s. These are the buckets worth exchanging in detail."""
        return [
            i for i in range(256)
            if self.bucket_roots[i] != other.bucket_roots[i]
        ]

    def to_dict(self) -> dict:
        return {
            "bucket_roots": [b64u_encode(r) for r in self.bucket_roots],
            "bucket_counts": list(self.bucket_counts),
        }

    @classmethod
    def from_dict(cls, d: dict) -> "MerkleBucketSummary":
        return cls(
            bucket_roots=[b64u_decode(r) for r in d["bucket_roots"]],
            bucket_counts=list(d["bucket_counts"]),
        )
