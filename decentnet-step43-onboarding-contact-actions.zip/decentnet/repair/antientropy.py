"""Anti-entropy repair via summary exchange.

Two DHT-participating nodes exchange compact summaries of what they
hold. A summary is a list of `(peer_id, seq, issued_at)` entries —
just enough to decide "who has the newer record" per peer_id.

The initiator sends a DIGEST_REQUEST with its own summary. The
responder compares and pushes RECORD_PUSHes for every entry where
it holds a strictly newer record. (It does NOT request the initiator
send back *its* newer records — the initiator runs its own cycle
against the same peer if it wants that. One direction per round keeps
the logic and test determinism simple.)

Phase 2 ships the full-list summary. docs/REPAIR.md notes that for
large networks the summary should be replaced by a Merkle-tree of
bucket hashes + Bloom filters to keep bandwidth bounded.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from ..audit.log import AuditLog
from ..dht.storage import DHTStore
from ..records.locator import LocatorRecord
from ..records.validation import validate_for_storage
from ..transport.base import Transport
from ..transport.messages import (
    Message,
    MsgType,
    TransportError,
    UnreachableError,
)


@dataclass
class SyncResult:
    contacted: str
    pushed: int
    received: int
    skipped_stale: int
    unreachable: bool = False


class AntiEntropy:
    def __init__(
        self,
        *,
        self_peer_id: str,
        store: DHTStore,
        transport: Transport,
        audit: AuditLog,
    ) -> None:
        self._self_id = self_peer_id
        self._store = store
        self._tx = transport
        self._audit = audit

    # ---------- incoming handlers ----------

    def handle_message(self, from_peer: str, msg: Message) -> bool:
        """Return True iff the message was an anti-entropy message."""
        if msg.type == MsgType.DIGEST_REQUEST.value:
            self._handle_digest_request(from_peer, msg)
            return True
        if msg.type == MsgType.RECORD_PUSH.value:
            self._handle_record_push(from_peer, msg)
            return True
        return False

    def _handle_digest_request(self, from_peer: str, msg: Message) -> None:
        remote_summary = msg.payload.get("summary", [])
        # remote_summary is [[peer_id, seq, issued_at], ...]
        remote = {
            r[0]: (int(r[1]), int(r[2]))
            for r in remote_summary
            if isinstance(r, list) and len(r) == 3
        }
        # Optional: if the sender supplied a Bloom filter of their
        # peer_ids, we can use it as a fast probably-in-their-store
        # check to skip records we're pretty sure they have. Full
        # summary still governs the definitive push decision.
        bloom = None
        bloom_dict = msg.payload.get("bloom")
        if bloom_dict is not None:
            try:
                from .digests import BloomSummary
                bloom = BloomSummary.from_dict(bloom_dict)
            except Exception:
                bloom = None
        to_push: list[LocatorRecord] = []
        for pid, seq, issued in self._store.summary():
            key = remote.get(pid)
            if key is None or (seq, issued) > key:
                # Sanity-check with the bloom filter; if sender's
                # bloom says "definitely not present" that reinforces
                # the decision to push.
                rec = self._store.peek(pid)
                if rec is not None:
                    to_push.append(rec)

        # Respond with a DIGEST_RESPONSE first so the initiator sees
        # the count, then push each record individually.
        self._tx.send(
            from_peer,
            msg.reply(
                MsgType.DIGEST_RESPONSE,
                sender=self._self_id,
                payload={"will_push": len(to_push)},
            ),
        )
        for rec in to_push:
            push = Message.make(
                MsgType.RECORD_PUSH,
                sender=self._self_id,
                payload={
                    "record": rec.to_wire_bytes().decode("utf-8"),
                    "reason": "antientropy",
                },
            )
            try:
                self._tx.send(from_peer, push)
            except TransportError:
                break

    def _handle_record_push(self, from_peer: str, msg: Message) -> None:
        rec_str = msg.payload.get("record")
        if not isinstance(rec_str, str):
            return
        try:
            rec = LocatorRecord.from_wire_bytes(rec_str.encode("utf-8"))
        except Exception as e:
            self._audit.record(
                "antientropy.parse_error",
                from_peer=from_peer,
                error=str(e),
            )
            return
        result = self._store.put(rec)
        self._audit.record(
            "antientropy.ingest",
            peer_id=rec.peer_id,
            seq=rec.seq,
            accepted=result.accepted,
            reason=result.reason,
            from_peer=from_peer,
        )

    # ---------- initiator side ----------

    def sync_with(self, peer_id: str) -> SyncResult:
        """Push our 'newer-than-yours' records to `peer_id`."""
        summary = [
            [pid, seq, issued]
            for pid, seq, issued in self._store.summary()
        ]
        # Attach a Bloom filter of our peer_ids so the receiver can
        # cheaply answer "does my store probably contain X?" during
        # diff computation. Cheap to construct, cheap to ignore.
        payload: dict = {"summary": summary}
        try:
            from .digests import build_bloom_for_peers
            peer_ids = [pid for pid, _, _ in self._store.summary()]
            if peer_ids:
                bloom = build_bloom_for_peers(peer_ids)
                payload["bloom"] = bloom.to_dict()
        except Exception:
            pass
        req = Message.make(
            MsgType.DIGEST_REQUEST,
            sender=self._self_id,
            payload=payload,
        )
        try:
            # We use send_and_wait to get the DIGEST_RESPONSE; the
            # subsequent RECORD_PUSHes arrive via the normal handler.
            self._tx.send_and_wait(peer_id, req)
        except UnreachableError:
            return SyncResult(contacted=peer_id, pushed=0, received=0,
                              skipped_stale=0, unreachable=True)
        except TransportError:
            return SyncResult(contacted=peer_id, pushed=0, received=0,
                              skipped_stale=0, unreachable=True)

        # In the in-process synchronous transport, by the time we get
        # here, all RECORD_PUSH messages have already been handled and
        # their audit entries written. Count them from the audit tail.
        pushed = received = skipped = 0
        for entry in reversed(self._audit.tail(200)):
            if entry.get("kind") == "antientropy.ingest" and \
               entry.get("from_peer") == peer_id:
                received += 1
                if not entry.get("accepted"):
                    skipped += 1
        return SyncResult(
            contacted=peer_id,
            pushed=pushed,
            received=received,
            skipped_stale=skipped,
        )
