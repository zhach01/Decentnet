"""Global snapshotting & catastrophic-loss reconstruction.

A `GlobalSnapshot` is a signed, timestamped manifest of every
locator record a node currently holds (in either L1 or its DHT
store). Snapshots are serializable and can be exchanged between
nodes through any channel (file copy, anti-entropy, USB stick).

Reconstruction
--------------
After catastrophic loss (e.g. a fresh data dir on a node that used
to participate in the DHT), a node can:

    1. Acquire one or more snapshots from peers it trusts (or from
       multiple untrusted peers, treating their union as a quorum).
    2. Validate every record in each snapshot through the same
       `validate_for_storage` pipeline used for live ingestion.
    3. Per peer_id, take the highest-`(seq, issued_at)` valid record
       across all snapshots — multi-source reconstruction.
    4. Insert into the local cache and DHT store.

The snapshot is signed by the producer's keypair so a recipient can
verify provenance. The snapshot's signature does NOT replace
per-record signatures: every contained record is independently signed
and is re-verified on import.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional

from ..identity.keypair import Keypair, verify_with_public_key
from ..records.locator import LocatorRecord
from ..records.validation import validate_for_storage
from ..utils.encoding import b64u_decode, b64u_encode, canonical_json_bytes
from ..utils.time import now_s


SNAPSHOT_VERSION = 1


@dataclass
class GlobalSnapshot:
    version: int
    producer_peer_id: str
    producer_public_key: bytes
    issued_at: int
    record_count: int
    records: list[dict]                # each = LocatorRecord.to_dict()
    signature: Optional[bytes] = None

    # ---- canonicalize / sign ----

    def _signing_input(self) -> bytes:
        return canonical_json_bytes({
            "version": self.version,
            "producer_peer_id": self.producer_peer_id,
            "producer_public_key": b64u_encode(self.producer_public_key),
            "issued_at": self.issued_at,
            "record_count": self.record_count,
            "records": list(self.records),
        })

    def to_bytes(self) -> bytes:
        assert self.signature is not None
        d = json.loads(self._signing_input().decode("utf-8"))
        d["signature"] = b64u_encode(self.signature)
        return canonical_json_bytes(d)

    @classmethod
    def from_bytes(cls, data: bytes) -> "GlobalSnapshot":
        obj = json.loads(data.decode("utf-8"))
        return cls(
            version=int(obj["version"]),
            producer_peer_id=obj["producer_peer_id"],
            producer_public_key=b64u_decode(obj["producer_public_key"]),
            issued_at=int(obj["issued_at"]),
            record_count=int(obj["record_count"]),
            records=list(obj.get("records", [])),
            signature=b64u_decode(obj["signature"]) if "signature" in obj else None,
        )

    @classmethod
    def build_and_sign(
        cls,
        keypair: Keypair,
        records: Iterable[LocatorRecord],
        *,
        producer_peer_id: str,
    ) -> "GlobalSnapshot":
        record_dicts = [r.to_dict() for r in records]
        snap = cls(
            version=SNAPSHOT_VERSION,
            producer_peer_id=producer_peer_id,
            producer_public_key=keypair.public_key_bytes,
            issued_at=now_s(),
            record_count=len(record_dicts),
            records=record_dicts,
        )
        snap.signature = keypair.sign(snap._signing_input())
        return snap

    def verify(self) -> tuple[bool, Optional[str]]:
        if self.version != SNAPSHOT_VERSION:
            return False, f"unsupported version {self.version}"
        if self.signature is None:
            return False, "unsigned"
        from ..identity.peer_id import PeerId
        if PeerId.from_public_key(self.producer_public_key).value != self.producer_peer_id:
            return False, "producer pubkey/peer_id mismatch"
        if not verify_with_public_key(
            self.producer_public_key, self._signing_input(), self.signature
        ):
            return False, "signature verification failed"
        if len(self.records) != self.record_count:
            return False, "record_count mismatch"
        return True, None


# --------------------------------------------------------------------


class SnapshotStore:
    """Local archive of received snapshots — used both for our own
    historical snapshots and for snapshots received from peers (e.g.
    during reconstruction)."""

    def __init__(self, db_path: Path | str | None) -> None:
        if db_path is None:
            self._conn = sqlite3.connect(":memory:", check_same_thread=False)
        else:
            p = Path(db_path)
            p.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(p), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        with self._lock, self._conn:
            self._conn.executescript("""
                CREATE TABLE IF NOT EXISTS snapshots (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    producer_peer_id TEXT NOT NULL,
                    issued_at INTEGER NOT NULL,
                    record_count INTEGER NOT NULL,
                    snapshot_bytes BLOB NOT NULL,
                    received_at INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_snap_producer
                    ON snapshots(producer_peer_id);
                CREATE INDEX IF NOT EXISTS idx_snap_issued
                    ON snapshots(issued_at);
            """)

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def store(self, snap: GlobalSnapshot) -> int:
        ok, reason = snap.verify()
        if not ok:
            raise ValueError(f"snapshot rejected: {reason}")
        with self._lock, self._conn:
            cur = self._conn.execute(
                """INSERT INTO snapshots
                   (producer_peer_id, issued_at, record_count,
                    snapshot_bytes, received_at)
                   VALUES (?, ?, ?, ?, ?)""",
                (
                    snap.producer_peer_id,
                    snap.issued_at,
                    snap.record_count,
                    snap.to_bytes(),
                    now_s(),
                ),
            )
            return cur.lastrowid

    def latest_for_producer(
        self, producer_peer_id: str
    ) -> Optional[GlobalSnapshot]:
        with self._lock, self._conn:
            row = self._conn.execute(
                """SELECT snapshot_bytes FROM snapshots
                   WHERE producer_peer_id = ?
                   ORDER BY issued_at DESC LIMIT 1""",
                (producer_peer_id,),
            ).fetchone()
        if row is None:
            return None
        return GlobalSnapshot.from_bytes(row["snapshot_bytes"])

    def all_snapshots(self) -> list[GlobalSnapshot]:
        with self._lock, self._conn:
            rows = self._conn.execute(
                "SELECT snapshot_bytes FROM snapshots ORDER BY issued_at"
            ).fetchall()
        out = []
        for r in rows:
            try:
                out.append(GlobalSnapshot.from_bytes(r["snapshot_bytes"]))
            except Exception:
                continue
        return out

    def stats(self) -> dict:
        with self._lock, self._conn:
            row = self._conn.execute(
                "SELECT COUNT(*) AS n FROM snapshots"
            ).fetchone()
        return {"snapshots": row["n"]}


# --------------------------------------------------------------------


@dataclass
class ReconstructionResult:
    snapshots_processed: int
    records_seen: int
    records_accepted: int
    records_rejected: int
    rejection_reasons: dict[str, int] = field(default_factory=dict)


def reconstruct_from_snapshots(
    snapshots: Iterable[GlobalSnapshot],
    *,
    cache_put,                     # callable (LocatorRecord, source_label) -> PutResult
) -> ReconstructionResult:
    """Multi-source reconstruction: walk every snapshot, validate
    every record independently, take the newest per peer_id, and
    insert through `cache_put`. Rejection reasons are tallied.

    `cache_put` is a function-of-record-and-source so this works with
    either `LocalCache.put` (passing through `source=`) or anything
    else that exposes the same shape.
    """
    seen_count = 0
    accepted = 0
    rejected = 0
    reasons: dict[str, int] = {}
    # First pass: gather highest-(seq, issued_at) per peer_id across
    # snapshots, after per-record validation.
    by_peer: dict[str, tuple[LocatorRecord, str]] = {}
    n_snaps = 0
    for snap in snapshots:
        n_snaps += 1
        ok, _ = snap.verify()
        if not ok:
            continue
        for rd in snap.records:
            seen_count += 1
            try:
                rec = LocatorRecord.from_dict(rd)
            except Exception:
                rejected += 1
                reasons["parse_error"] = reasons.get("parse_error", 0) + 1
                continue
            v = validate_for_storage(rec)
            if not v.ok:
                rejected += 1
                reasons[v.reason or "unknown"] = (
                    reasons.get(v.reason or "unknown", 0) + 1
                )
                continue
            cur = by_peer.get(rec.peer_id)
            if cur is None or (rec.seq, rec.issued_at) > (
                cur[0].seq, cur[0].issued_at
            ):
                by_peer[rec.peer_id] = (
                    rec, f"reconstruct:{snap.producer_peer_id[:8]}"
                )
    # Second pass: insert.
    for peer_id, (rec, source) in by_peer.items():
        result = cache_put(rec, source=source)
        if getattr(result, "accepted", False):
            accepted += 1
        else:
            rejected += 1
            r = getattr(result, "reason", "unknown") or "unknown"
            reasons[r] = reasons.get(r, 0) + 1
    return ReconstructionResult(
        snapshots_processed=n_snaps,
        records_seen=seen_count,
        records_accepted=accepted,
        records_rejected=rejected,
        rejection_reasons=reasons,
    )
