"""Structured logging for decentnet.

Wraps Python's `logging` with a consistent `decentnet.*` namespace
and a structured JSON formatter. Complementary to the audit log:

    * Audit log  = every material state change, grep-friendly JSONL,
                   queryable, rotated on disk.
    * Structured log = operator-facing, severity-filtered, shipped to
                       stderr / syslog / journald.

Defaults are quiet so nothing prints by default — call `setup_logging()`
from `__main__` / daemon code to turn it on.
"""
from __future__ import annotations

import json
import logging
import os
import sys
from typing import Optional


LEVELS = {
    "debug": logging.DEBUG,
    "info": logging.INFO,
    "warn": logging.WARNING,
    "warning": logging.WARNING,
    "error": logging.ERROR,
    "critical": logging.CRITICAL,
}


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": int(record.created),
            "level": record.levelname.lower(),
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        # Any extra=... fields the caller passed get included.
        for k, v in record.__dict__.items():
            if k in (
                "name", "msg", "args", "levelname", "levelno", "pathname",
                "filename", "module", "exc_info", "exc_text", "stack_info",
                "lineno", "funcName", "created", "msecs", "relativeCreated",
                "thread", "threadName", "processName", "process", "message",
            ):
                continue
            try:
                json.dumps(v)
                payload[k] = v
            except Exception:
                payload[k] = repr(v)
        return json.dumps(payload, sort_keys=True)


_configured = False


def setup_logging(
    level: str = "info",
    *,
    structured: bool = True,
    stream=None,
) -> None:
    """Idempotent — calling twice doesn't double-handle."""
    global _configured
    if _configured:
        return
    _configured = True
    lvl = LEVELS.get(level.lower(), logging.INFO)
    handler = logging.StreamHandler(stream or sys.stderr)
    if structured:
        handler.setFormatter(JsonFormatter())
    else:
        handler.setFormatter(logging.Formatter(
            "%(asctime)s %(levelname)s %(name)s %(message)s"
        ))
    root = logging.getLogger("decentnet")
    root.setLevel(lvl)
    root.addHandler(handler)
    # Don't propagate to Python's root — tests capture stderr
    # independently.
    root.propagate = False


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"decentnet.{name}")


def reset_logging_for_tests() -> None:
    global _configured
    root = logging.getLogger("decentnet")
    for h in list(root.handlers):
        root.removeHandler(h)
    _configured = False
