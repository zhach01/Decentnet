"""Metrics collection and Prometheus text-format exposition.

No external dependency. We implement just enough of the Prometheus
text format (no histograms for now — counters + gauges) to let a
standard Prometheus scraper ingest `/metrics`.

Exposed metrics (all gauges except where noted):

    decentnet_cache_records_total
    decentnet_cache_rejections_total{reason=...}          # counter
    decentnet_dht_replicas_total
    decentnet_deferred_queue_size
    decentnet_confidence_peers_total
    decentnet_rotations_total                             # counter
    decentnet_signaling_sessions_total
    decentnet_signaling_trusted_total
    decentnet_reputation_avg_score
    decentnet_audit_entries_total                         # counter
    decentnet_uptime_seconds
"""
from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Optional

from .utils.time import now_s


@dataclass
class MetricsRegistry:
    started_at: int = field(default_factory=now_s)
    _counters: dict = field(default_factory=dict)
    _gauges: dict = field(default_factory=dict)
    _lock: threading.Lock = field(
        default_factory=threading.Lock, repr=False, compare=False,
    )

    # ---- counters ----

    def counter_inc(self, name: str, labels: Optional[dict] = None,
                    value: int = 1) -> None:
        key = self._key(name, labels)
        with self._lock:
            self._counters[key] = self._counters.get(key, 0) + value

    # ---- gauges ----

    def gauge_set(self, name: str, value: float,
                  labels: Optional[dict] = None) -> None:
        key = self._key(name, labels)
        with self._lock:
            self._gauges[key] = float(value)

    # ---- util ----

    @staticmethod
    def _key(name: str, labels: Optional[dict]) -> tuple:
        if labels:
            return (name, tuple(sorted(labels.items())))
        return (name, ())

    # ---- snapshots ----

    def snapshot_from_node(self, node) -> None:
        """Populate gauges from a Node's current state."""
        with self._lock:
            # Cache size.
            entries = list(node.cache.entries())
            self._gauges[("decentnet_cache_records_total", ())] = float(len(entries))
            # DHT replicas.
            if node.directory is not None:
                self._gauges[("decentnet_dht_replicas_total", ())] = float(
                    node.directory.store.size()
                )
            # Deferred queue.
            self._gauges[("decentnet_deferred_queue_size", ())] = float(
                node.deferred.size()
            )
            # Signaling sessions.
            if node.signaling is not None:
                with node.signaling._sessions_lock:
                    n_sessions = len(node.signaling._sessions)
                self._gauges[("decentnet_signaling_sessions_total", ())] = float(n_sessions)
                self._gauges[("decentnet_signaling_trusted_total", ())] = float(
                    len(node.signaling.trusted_peers())
                )
            # Reputation average.
            peers = node.reputation.all_peers()
            if peers:
                avg = sum(p.score_raw for p in peers) / len(peers)
                self._gauges[("decentnet_reputation_avg_score", ())] = float(avg)
            # Confidence tracker peer count.
            self._gauges[("decentnet_confidence_peers_total", ())] = float(
                len({rec.peer_id for rec, _ in entries})
            )
            # Audit entries.
            self._counters[("decentnet_audit_entries_total", ())] = \
                len(node.audit.entries())
            # Uptime.
            self._gauges[("decentnet_uptime_seconds", ())] = float(
                now_s() - self.started_at
            )

    def prometheus_text(self) -> str:
        lines: list[str] = []
        with self._lock:
            for (name, labels), value in sorted(self._counters.items()):
                lines.append(f"# TYPE {name} counter")
                lines.append(f"{_render(name, labels)} {int(value)}")
            for (name, labels), value in sorted(self._gauges.items()):
                lines.append(f"# TYPE {name} gauge")
                lines.append(f"{_render(name, labels)} {value:g}")
        return "\n".join(lines) + "\n"


def _render(name: str, labels: tuple) -> str:
    if not labels:
        return name
    parts = ",".join(f'{k}="{_escape(v)}"' for k, v in labels)
    return f"{name}{{{parts}}}"


def _escape(v) -> str:
    return str(v).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")


# ----------------- HTTP endpoint ----------------------------------


def start_metrics_server(
    registry: MetricsRegistry,
    host: str = "127.0.0.1",
    port: int = 9091,
    *,
    snapshot_cb=None,
) -> "MetricsServer":
    return MetricsServer(registry, host, port, snapshot_cb=snapshot_cb)


class MetricsServer:
    def __init__(
        self,
        registry: MetricsRegistry,
        host: str,
        port: int,
        *,
        snapshot_cb=None,
    ) -> None:
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

        self._registry = registry
        self._snapshot_cb = snapshot_cb

        outer = self

        class _Handler(BaseHTTPRequestHandler):
            def log_message(self, *args, **kwargs):
                pass

            def do_GET(self):
                if self.path != "/metrics":
                    self.send_response(404)
                    self.end_headers()
                    return
                if outer._snapshot_cb is not None:
                    try:
                        outer._snapshot_cb()
                    except Exception:
                        pass
                body = outer._registry.prometheus_text().encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type",
                                 "text/plain; version=0.0.4; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        self._server = ThreadingHTTPServer((host, port), _Handler)
        self.host, self.port = self._server.server_address
        self._thread = threading.Thread(
            target=self._server.serve_forever,
            name="decentnet-metrics",
            daemon=True,
        )
        self._thread.start()

    def close(self) -> None:
        try:
            self._server.shutdown()
            self._server.server_close()
        except Exception:
            pass
