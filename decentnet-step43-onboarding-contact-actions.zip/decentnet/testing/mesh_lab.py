from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from ..node import Node, NodeConfig
from ..records.endpoints import Endpoint
from ..relay import RelayServer
from ..signaling.engine import SignalingEngine
from ..transport.messages import UnreachableError
from ..transport.udp import UDPTransport


@dataclass
class MeshNode:
    name: str
    node: Node
    relay_token_json: Optional[str] = None
    blocked_addrs: set[tuple[str, int]] = field(default_factory=set)

    @property
    def peer_id(self) -> str:
        return self.node.peer_id.value

    @property
    def transport(self) -> UDPTransport:
        assert isinstance(self.node._transport, UDPTransport)
        return self.node._transport

    @property
    def bind_addr(self) -> tuple[str, int]:
        return (self.transport.bind_host, self.transport.bind_port)


class LocalUDPMeshLab:
    """Small helper for real local-UDP multi-node integration tests.

    Creates actual UDP transports bound to 127.0.0.1 on ephemeral ports,
    with optional cooperative relay support. The helper takes care of:
    - swapping Nodes onto UDPTransport + SignalingEngine
    - publishing locator records with direct and optional relay endpoints
    - pairwise record bootstrap
    - pairwise endpoint registration
    - clean shutdown
    """

    def __init__(self, root: Path, *, with_relay: bool = False) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.nodes: dict[str, MeshNode] = {}
        self.relay = RelayServer(bind_host="127.0.0.1", bind_port=0) if with_relay else None

    def _install_transport_guards(self, bundle: MeshNode) -> None:
        transport = bundle.transport
        base_send_raw = transport.send_raw

        def guarded_send_raw(data, addr):
            if addr in bundle.blocked_addrs:
                raise UnreachableError(f"blocked {bundle.name} -> {addr[0]}:{addr[1]}")
            return base_send_raw(data, addr)

        transport.send_raw = guarded_send_raw

    def _issue_relay_token(self, peer_id: str) -> Optional[str]:
        if self.relay is None:
            return None
        return self.relay.issue_token(peer_id, ttl_s=900).to_json()

    def add_node(self, name: str) -> MeshNode:
        cfg = NodeConfig.at(self.root / name)
        node = Node(cfg)
        node._transport = UDPTransport(node.peer_id.value, bind_host="127.0.0.1", bind_port=0)
        node.signaling = SignalingEngine(
            local_peer_id=node.peer_id.value,
            keypair=node.keypair,
            transport=node._transport,
            local_cache=node.cache,
            audit=node.audit,
        )
        bundle = MeshNode(name=name, node=node, relay_token_json=self._issue_relay_token(node.peer_id.value))
        self.nodes[name] = bundle
        self._install_transport_guards(bundle)
        return bundle

    def close(self) -> None:
        for bundle in list(self.nodes.values()):
            try:
                bundle.node.close()
            except Exception:
                pass
        self.nodes.clear()
        if self.relay is not None:
            try:
                self.relay.close()
            except Exception:
                pass
            self.relay = None

    def __enter__(self) -> "LocalUDPMeshLab":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def publish_node(self, name: str, *, direct_addr: Optional[str] = None) -> None:
        bundle = self.nodes[name]
        bind_host, bind_port = bundle.bind_addr
        relay_addr_s = None
        endpoints = [
            Endpoint(type="public_udp", address=direct_addr or f"{bind_host}:{bind_port}")
        ]
        nat_metadata = None
        if self.relay is not None:
            relay_addr_s = f"{self.relay.bind_host}:{self.relay.bind_port}"
            endpoints.append(Endpoint(type="relay_candidate", address=relay_addr_s))
            nat_metadata = {"relay_token": bundle.relay_token_json}
        bundle.node.publish_own_record(endpoints=endpoints, nat_metadata=nat_metadata)

    def publish_all(self) -> None:
        for name in self.nodes:
            self.publish_node(name)

    def bootstrap_pair(self, src: str, dst: str) -> None:
        s = self.nodes[src]
        d = self.nodes[dst]
        s.node.ingest_record_bytes(d.node.export_own_record(), source="bootstrap")
        s.transport.register_endpoint(d.peer_id, d.transport.bind_host, d.transport.bind_port)

    def bootstrap_full_mesh(self) -> None:
        names = list(self.nodes)
        for src in names:
            for dst in names:
                if src == dst:
                    continue
                self.bootstrap_pair(src, dst)

    def override_route(self, src: str, dst: str, host: str, port: int) -> None:
        self.nodes[src].transport.register_endpoint(self.nodes[dst].peer_id, host, port)

    def clear_route(self, src: str, dst: str) -> None:
        peer_id = self.nodes[dst].peer_id
        with self.nodes[src].transport._endpoints_lock:
            self.nodes[src].transport._peer_endpoints.pop(peer_id, None)

    def block_direct(self, src: str, dst: str) -> None:
        self.nodes[src].blocked_addrs.add(self.nodes[dst].bind_addr)
        self.clear_route(src, dst)

    def unblock_direct(self, src: str, dst: str) -> None:
        self.nodes[src].blocked_addrs.discard(self.nodes[dst].bind_addr)
        self.override_route(src, dst, *self.nodes[dst].bind_addr)

    def partition_pair(self, a: str, b: str) -> None:
        self.block_direct(a, b)
        self.block_direct(b, a)

    def heal_pair(self, a: str, b: str) -> None:
        self.unblock_direct(a, b)
        self.unblock_direct(b, a)

    @contextmanager
    def direct_partition(self, a: str, b: str):
        self.partition_pair(a, b)
        try:
            yield
        finally:
            self.heal_pair(a, b)

    def ensure_relay_pair(self, src: str, dst: str):
        if self.relay is None:
            return None
        return self.nodes[src].node.signaling._ensure_relay_allocation(self.nodes[dst].peer_id)

    def hello(self, src: str, dst: str, *, timeout_s: float = 0.6):
        return self.nodes[src].node.signaling.hello(self.nodes[dst].peer_id, timeout_s=timeout_s)

    def ring(self, src: str, dst: str, *, body: Optional[dict] = None, timeout_s: float = 0.6):
        return self.nodes[src].node.signaling.ring(self.nodes[dst].peer_id, body=body or {}, timeout_s=timeout_s)

    def keepalive(self, src: str, dst: str, *, timeout_s: float = 0.5):
        return self.nodes[src].node.signaling.keepalive(self.nodes[dst].peer_id, timeout_s=timeout_s)

    def refresh_candidates(self, src: str, dst: str, *, reason: str = "mesh_refresh"):
        return self.nodes[src].node.signaling.refresh_candidates(self.nodes[dst].peer_id, reason=reason)

    def rebind_node(self, name: str) -> tuple[str, int]:
        bundle = self.nodes[name]
        old_transport = bundle.node._transport
        if old_transport is not None:
            try:
                old_transport.close()
            except Exception:
                pass
        bundle.node._transport = UDPTransport(bundle.node.peer_id.value, bind_host="127.0.0.1", bind_port=0)
        bundle.node.signaling = SignalingEngine(
            local_peer_id=bundle.node.peer_id.value,
            keypair=bundle.node.keypair,
            transport=bundle.node._transport,
            local_cache=bundle.node.cache,
            audit=bundle.node.audit,
        )
        self._install_transport_guards(bundle)
        # Re-register current peers against their real transport endpoints.
        for other_name, other in self.nodes.items():
            if other_name == name:
                continue
            if other.bind_addr not in bundle.blocked_addrs:
                bundle.transport.register_endpoint(other.peer_id, other.transport.bind_host, other.transport.bind_port)
            if bundle.bind_addr not in other.blocked_addrs:
                other.transport.register_endpoint(bundle.peer_id, bundle.transport.bind_host, bundle.transport.bind_port)
            sess = other.node.signaling.session(bundle.peer_id)
            if sess is not None:
                sess.clear_selected_path()
        self.publish_node(name)
        return bundle.bind_addr

    def restart_node(self, name: str) -> MeshNode:
        old = self.nodes[name]
        old_blocked = set(old.blocked_addrs)
        old_root = old.node.config.root
        try:
            old.node.close()
        except Exception:
            pass
        cfg = NodeConfig.at(old_root)
        node = Node(cfg)
        node._transport = UDPTransport(node.peer_id.value, bind_host="127.0.0.1", bind_port=0)
        node.signaling = SignalingEngine(
            local_peer_id=node.peer_id.value,
            keypair=node.keypair,
            transport=node._transport,
            local_cache=node.cache,
            audit=node.audit,
        )
        bundle = MeshNode(name=name, node=node, relay_token_json=self._issue_relay_token(node.peer_id.value), blocked_addrs=old_blocked)
        self.nodes[name] = bundle
        self._install_transport_guards(bundle)
        for other_name, other in self.nodes.items():
            if other_name == name:
                continue
            if other.bind_addr not in bundle.blocked_addrs:
                bundle.transport.register_endpoint(other.peer_id, other.transport.bind_host, other.transport.bind_port)
            if bundle.bind_addr not in other.blocked_addrs:
                other.transport.register_endpoint(bundle.peer_id, bundle.transport.bind_host, bundle.transport.bind_port)
            sess = other.node.signaling.session(bundle.peer_id)
            if sess is not None:
                sess.clear_selected_path()
            try:
                bundle.node.ingest_record_bytes(other.node.export_own_record(), source="bootstrap")
            except Exception:
                pass
        self.publish_node(name)
        for other_name, other in self.nodes.items():
            if other_name == name:
                continue
            try:
                other.node.ingest_record_bytes(bundle.node.export_own_record(), source="bootstrap")
            except Exception:
                pass
        return bundle
