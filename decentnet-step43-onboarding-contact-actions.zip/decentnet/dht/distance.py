"""XOR distance between Peer IDs — the Kademlia metric.

Peer IDs are base32-encoded SHA-256 digests; under the hood they are
32-byte bit strings, so XOR distance is a 256-bit integer.

We use the raw SHA-256 bytes as the DHT node ID. This matches what
libp2p does: the peer's cryptographic identity *is* the DHT identity.
The consequence is that an attacker cannot cheaply manipulate their
DHT node ID without grinding keys — a weak but real Sybil defence.
Stronger defences (S/Kademlia-style crypto puzzles, multi-path
lookups) are listed as Phase 7+ hardening in docs/ARCHITECTURE.md.
"""
from __future__ import annotations

from ..utils.encoding import b32decode_nopad


ID_BYTES = 32
ID_BITS = ID_BYTES * 8  # 256


def peer_id_to_bytes(peer_id: str) -> bytes:
    raw = b32decode_nopad(peer_id)
    if len(raw) != ID_BYTES:
        raise ValueError(
            f"peer ID must decode to {ID_BYTES} bytes, got {len(raw)}"
        )
    return raw


def xor_distance(a: str, b: str) -> int:
    ba = peer_id_to_bytes(a)
    bb = peer_id_to_bytes(b)
    return int.from_bytes(bytes(x ^ y for x, y in zip(ba, bb)), "big")


def bucket_index(self_id: str, other_id: str) -> int:
    """Which k-bucket (0..ID_BITS-1) does `other_id` belong in for `self_id`?

    The bucket index is the position of the highest differing bit.
    Convention: bucket 0 holds the node closest to self (1-bit difference
    in the lowest-order bit), bucket ID_BITS-1 holds the furthest.

    Here we flip the orientation: bucket i contains nodes whose XOR
    distance lies in [2**i, 2**(i+1)). If the peers are identical
    (distance 0), we return -1 (don't insert self in routing table).
    """
    d = xor_distance(self_id, other_id)
    if d == 0:
        return -1
    return d.bit_length() - 1


def sort_by_distance(target: str, candidates: list[str]) -> list[str]:
    return sorted(candidates, key=lambda p: xor_distance(p, target))
