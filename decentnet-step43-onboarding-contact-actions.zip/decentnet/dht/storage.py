"""DHTStore — records a node holds **as a DHT replica**."""
from __future__ import annotations

import sqlite3
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from ..records.locator import LocatorRecord
from ..records.validation import (
    DEFAULT_MAX_FUTURE_SKEW_S,
    validate_for_storage,
)
from ..utils.time import now_s
from .topics import TopicPolicy


@dataclass
class DHTStoreResult:
    accepted: bool
    reason: Optional[str] = None


class DHTStore:
    def __init__(
        self,
        *,
        persist_path: Optional[str | Path] = None,
        max_future_skew_s: int = DEFAULT_MAX_FUTURE_SKEW_S,
        topic_policy: Optional[TopicPolicy] = None,
    ) -> None:
        self._records: dict[str, LocatorRecord] = {}
        self._max_skew = max_future_skew_s
        self._topic_policy = topic_policy
        self._persist_path: Optional[Path] = (
            Path(persist_path) if persist_path is not None else None
        )
        self._conn: Optional[sqlite3.Connection] = None
        self._lock = threading.Lock()
        if self._persist_path is not None:
            self._open_persistence()
            self._rehydrate()

    # ---- persistence plumbing ----

    def _open_persistence(self) -> None:
        assert self._persist_path is not None
        self._persist_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._persist_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        with self._lock, self._conn:
            self._conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS dht_records (
                    peer_id TEXT PRIMARY KEY,
                    record_json TEXT NOT NULL,
                    seq INTEGER NOT NULL,
                    expires_at INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_dht_expires
                    ON dht_records(expires_at);
                """
            )

    def _rehydrate(self) -> None:
        assert self._conn is not None
        with self._lock, self._conn:
            cur = self._conn.execute("SELECT * FROM dht_records")
            now = now_s()
            for row in cur.fetchall():
                if row["expires_at"] <= now:
                    continue
                try:
                    rec = LocatorRecord.from_wire_bytes(
                        row["record_json"].encode("utf-8")
                    )
                    ok, _ = rec.verify()
                    if ok:
                        self._records[rec.peer_id] = rec
                except Exception:
                    continue

    def _persist_upsert(self, rec: LocatorRecord) -> None:
        if self._conn is None:
            return
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT INTO dht_records
                   (peer_id, record_json, seq, expires_at)
                   VALUES (?,?,?,?)
                   ON CONFLICT(peer_id) DO UPDATE SET
                     record_json=excluded.record_json,
                     seq=excluded.seq,
                     expires_at=excluded.expires_at""",
                (
                    rec.peer_id,
                    rec.to_wire_bytes().decode("utf-8"),
                    rec.seq,
                    rec.expires_at,
                ),
            )

    def _persist_delete(self, peer_id: str) -> None:
        if self._conn is None:
            return
        with self._lock, self._conn:
            self._conn.execute(
                "DELETE FROM dht_records WHERE peer_id = ?", (peer_id,)
            )

    def close(self) -> None:
        if self._conn is not None:
            with self._lock:
                self._conn.close()
                self._conn = None

    # ---- writes ----

    def put(self, record: LocatorRecord) -> DHTStoreResult:
        if (
            self._topic_policy is not None
            and not self._topic_policy.should_replicate(record.topic_hashes)
        ):
            return DHTStoreResult(False, reason="topic_not_subscribed")
        existing = self._records.get(record.peer_id)
        result = validate_for_storage(
            record, existing=existing, max_future_skew_s=self._max_skew
        )
        if not result.ok:
            return DHTStoreResult(False, reason=result.reason)
        self._records[record.peer_id] = record
        self._persist_upsert(record)
        return DHTStoreResult(True)

    # ---- reads ----

    def get(self, peer_id: str) -> Optional[LocatorRecord]:
        rec = self._records.get(peer_id)
        if rec is None:
            return None
        if rec.is_hard_expired():
            del self._records[peer_id]
            self._persist_delete(peer_id)
            return None
        return rec

    def peek(self, peer_id: str) -> Optional[LocatorRecord]:
        return self._records.get(peer_id)

    def all_peer_ids(self) -> list[str]:
        return list(self._records.keys())

    def all_records(self) -> list[LocatorRecord]:
        return list(self._records.values())

    def size(self) -> int:
        return len(self._records)

    # ---- maintenance ----

    def gc(self, *, at: Optional[int] = None) -> int:
        t = at if at is not None else now_s()
        to_del = [pid for pid, r in self._records.items() if r.expires_at <= t]
        for pid in to_del:
            del self._records[pid]
            self._persist_delete(pid)
        return len(to_del)

    def evict(self, peer_id: str) -> bool:
        if self._records.pop(peer_id, None) is not None:
            self._persist_delete(peer_id)
            return True
        return False

    def summary(self) -> list[tuple[str, int, int]]:
        return [
            (pid, rec.seq, rec.issued_at)
            for pid, rec in self._records.items()
        ]
