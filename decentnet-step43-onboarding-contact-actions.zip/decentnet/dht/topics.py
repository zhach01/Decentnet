"""Topic-scoped replication policy.

A node can declare a set of "topics" it cares about. The DHT then
applies an additional acceptance filter beyond XOR distance:

    A record is replicated locally only if EITHER
        * the record carries no topic_hashes (it's "global", e.g. a
          plain reachability record), OR
        * the record's topic_hashes intersect the node's
          subscribed_topics set, OR
        * the node has explicitly opted into "replicate everything"
          (the default for backwards compatibility).

This lets thin clients (mobile, IoT) subscribe to "the topics I'm
in" and not waste storage replicating the world.

Subscriptions are persisted as JSON in the node's data directory so
they survive restart.
"""
from __future__ import annotations

import hashlib
import json
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from ..utils.encoding import b64u_encode


def hash_topic(name: str) -> str:
    """Topic name → opaque hash used in records."""
    return b64u_encode(hashlib.sha256(name.encode("utf-8")).digest())


@dataclass
class TopicPolicy:
    """Persistent topic subscription set + replication mode."""

    path: Optional[Path] = None
    replicate_all: bool = True            # default: behave like Phase 1-6
    subscribed_topics: set[str] = field(default_factory=set)
    _lock: threading.RLock = field(
        default_factory=threading.RLock, repr=False, compare=False,
    )

    def __post_init__(self) -> None:
        if self.path is not None and self.path.exists():
            try:
                d = json.loads(self.path.read_text())
                self.replicate_all = bool(d.get("replicate_all", True))
                self.subscribed_topics = set(d.get("subscribed_topics", []))
            except Exception:
                pass

    def _save(self) -> None:
        if self.path is None:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps({
            "replicate_all": self.replicate_all,
            "subscribed_topics": sorted(self.subscribed_topics),
        }, indent=2))
        tmp.replace(self.path)

    def subscribe_topic(self, topic_name: str) -> str:
        """Subscribe by human-readable name; returns the hash used in records."""
        h = hash_topic(topic_name)
        with self._lock:
            self.subscribed_topics.add(h)
            self._save()
        return h

    def subscribe_hash(self, topic_hash: str) -> None:
        with self._lock:
            self.subscribed_topics.add(topic_hash)
            self._save()

    def unsubscribe_hash(self, topic_hash: str) -> None:
        with self._lock:
            self.subscribed_topics.discard(topic_hash)
            self._save()

    def set_replicate_all(self, value: bool) -> None:
        with self._lock:
            self.replicate_all = bool(value)
            self._save()

    def should_replicate(self, record_topic_hashes: list[str]) -> bool:
        with self._lock:
            if self.replicate_all:
                return True
            if not record_topic_hashes:
                # Records with no topics are global; replicate.
                return True
            return any(h in self.subscribed_topics for h in record_topic_hashes)
