"""DHTEngine — handles DHT RPCs and drives iterative lookups.

Responsibilities
----------------
* Serve PING, FIND_NODE, STORE, FIND_VALUE from other peers.
* Perform iterative lookups: FIND_NODE(target) and FIND_VALUE(peer_id).
* Publish records to the k closest peers discovered.
* Keep the routing table healthy (observe every incoming sender).

The engine is transport-agnostic — it takes a `Transport` and calls
`send` / `send_and_wait` without caring whether the underlying channel
is in-process, UDP, or WebSocket.

Concurrency note
----------------
In Phase 2 we call `send_and_wait` serially (alpha=1 practical effect
with the in-process synchronous transport). The data structures are
already shaped for parallel queries so Phase 4's real transport can
fan out without changing call sites.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

from ..audit.log import AuditLog
from ..records.locator import LocatorRecord
from ..transport.base import Transport
from ..transport.messages import (
    Message,
    MsgType,
    TransportError,
    UnreachableError,
)
from ..utils.time import now_s
from .distance import sort_by_distance, xor_distance
from .routing import Contact, RoutingTable
from .storage import DHTStore


DEFAULT_ALPHA = 3
DEFAULT_LOOKUP_TIMEOUT_S = 5.0


@dataclass
class LookupResult:
    """Outcome of `find_value`."""
    record: Optional[LocatorRecord]
    quorum_records: list[LocatorRecord]        # every valid record we saw
    closest: list[Contact]                     # k closest nodes we learned about
    queried: int                               # how many nodes we asked


class DHTEngine:
    def __init__(
        self,
        *,
        routing_table: RoutingTable,
        store: DHTStore,
        transport: Transport,
        audit: AuditLog,
        local_cache_observer: Optional[Callable[[LocatorRecord, str], None]] = None,
        k: Optional[int] = None,
        alpha: int = DEFAULT_ALPHA,
        reputation=None,
    ) -> None:
        self._rt = routing_table
        self._store = store
        self._tx = transport
        self._audit = audit
        self._k = k if k is not None else routing_table.k
        self._alpha = alpha
        self._observer = local_cache_observer
        self._rep = reputation
        transport.set_receive_handler(self._on_message)

    # =============== RPC handlers (server side) ===============

    def _on_message(self, from_peer: str, msg: Message) -> None:
        # Every incoming message is evidence of liveness — refresh the
        # routing table.
        self._rt.observe(from_peer)

        handler = {
            MsgType.PING.value: self._handle_ping,
            MsgType.FIND_NODE.value: self._handle_find_node,
            MsgType.STORE.value: self._handle_store,
            MsgType.FIND_VALUE.value: self._handle_find_value,
        }.get(msg.type)

        if handler is not None:
            try:
                handler(from_peer, msg)
            except Exception as e:
                self._audit.record(
                    "dht.handler_error",
                    kind=msg.type,
                    error=str(e),
                    from_peer=from_peer,
                )

    def _handle_ping(self, from_peer: str, msg: Message) -> None:
        self._tx.send(
            from_peer,
            msg.reply(MsgType.PONG, sender=self._rt.self_peer_id),
        )

    def _handle_find_node(self, from_peer: str, msg: Message) -> None:
        target = msg.payload.get("target")
        if not isinstance(target, str):
            return
        closest = self._rt.closest(target, self._k)
        self._tx.send(
            from_peer,
            msg.reply(
                MsgType.NODE_LIST,
                sender=self._rt.self_peer_id,
                payload={
                    "nodes": [
                        {"peer_id": c.peer_id, "endpoint": c.endpoint}
                        for c in closest
                    ]
                },
            ),
        )

    def _handle_store(self, from_peer: str, msg: Message) -> None:
        record_bytes_b64 = msg.payload.get("record")
        if not isinstance(record_bytes_b64, str):
            return
        try:
            record = LocatorRecord.from_wire_bytes(record_bytes_b64.encode("utf-8"))
        except Exception as e:
            self._tx.send(
                from_peer,
                msg.reply(
                    MsgType.STORE_REJECT,
                    sender=self._rt.self_peer_id,
                    payload={"reason": f"parse_error: {e}"},
                ),
            )
            return

        result = self._store.put(record)
        if result.accepted:
            self._audit.record(
                "dht.store_accept",
                peer_id=record.peer_id,
                seq=record.seq,
                from_peer=from_peer,
            )
            # Also notify L1 cache observer (usually the Node) so a
            # fresh record propagates to the publisher's own lookups.
            if self._observer is not None:
                try:
                    self._observer(record, f"dht:{from_peer}")
                except Exception:
                    pass
            self._tx.send(
                from_peer,
                msg.reply(MsgType.STORE_OK, sender=self._rt.self_peer_id),
            )
        else:
            self._audit.record(
                "dht.store_reject",
                peer_id=record.peer_id,
                reason=result.reason,
                from_peer=from_peer,
            )
            self._tx.send(
                from_peer,
                msg.reply(
                    MsgType.STORE_REJECT,
                    sender=self._rt.self_peer_id,
                    payload={"reason": result.reason},
                ),
            )

    def _handle_find_value(self, from_peer: str, msg: Message) -> None:
        key = msg.payload.get("key")
        if not isinstance(key, str):
            return
        rec = self._store.get(key)
        if rec is not None:
            self._tx.send(
                from_peer,
                msg.reply(
                    MsgType.VALUE,
                    sender=self._rt.self_peer_id,
                    payload={"record": rec.to_wire_bytes().decode("utf-8")},
                ),
            )
            return
        # Miss: respond with the nodes we know closest to `key`.
        closest = self._rt.closest(key, self._k)
        self._tx.send(
            from_peer,
            msg.reply(
                MsgType.VALUE_MISS,
                sender=self._rt.self_peer_id,
                payload={
                    "nodes": [
                        {"peer_id": c.peer_id, "endpoint": c.endpoint}
                        for c in closest
                    ]
                },
            ),
        )

    # =============== client-side lookups ===============

    def ping(self, peer: Contact) -> bool:
        msg = Message.make(MsgType.PING, sender=self._rt.self_peer_id)
        try:
            reply = self._tx.send_and_wait(peer.peer_id, msg)
            return reply.type == MsgType.PONG.value
        except TransportError:
            return False

    def _rpc(self, peer: Contact, msg: Message) -> Optional[Message]:
        try:
            return self._tx.send_and_wait(peer.peer_id, msg)
        except TransportError:
            return None

    def find_node(self, target: str) -> list[Contact]:
        """Iterative FIND_NODE. Returns up to k closest contacts."""
        shortlist, closest, queried = self._init_shortlist(target)
        while shortlist:
            to_query = self._pick_next(shortlist, queried, self._alpha)
            if not to_query:
                break
            for peer in to_query:
                queried.add(peer.peer_id)
                msg = Message.make(
                    MsgType.FIND_NODE,
                    sender=self._rt.self_peer_id,
                    payload={"target": target},
                )
                reply = self._rpc(peer, msg)
                if reply is None:
                    continue
                self._absorb_nodes(reply, target, shortlist, closest, queried)
        self._audit.record(
            "dht.find_node_done",
            target=target,
            queried=len(queried),
            found=len(closest),
        )
        return sorted(
            closest.values(),
            key=lambda c: xor_distance(c.peer_id, target),
        )[: self._k]

    def find_value(self, key: str) -> LookupResult:
        """Iterative FIND_VALUE. Continues until a record is found and
        enough replicas have been polled to get a quorum view, or the
        shortlist is exhausted."""
        shortlist, closest, queried = self._init_shortlist(key)
        records_seen: dict[tuple[str, int, int], LocatorRecord] = {}

        # First: if we locally store this key, we already have a candidate.
        local = self._store.get(key)
        if local is not None:
            k_ = (local.peer_id, local.seq, local.issued_at)
            records_seen[k_] = local

        while shortlist:
            to_query = self._pick_next(shortlist, queried, self._alpha)
            if not to_query:
                break
            for peer in to_query:
                queried.add(peer.peer_id)
                msg = Message.make(
                    MsgType.FIND_VALUE,
                    sender=self._rt.self_peer_id,
                    payload={"key": key},
                )
                reply = self._rpc(peer, msg)
                if reply is None:
                    continue
                if reply.type == MsgType.VALUE.value:
                    rec_str = reply.payload.get("record")
                    if isinstance(rec_str, str):
                        try:
                            rec = LocatorRecord.from_wire_bytes(rec_str.encode("utf-8"))
                            ok, _reason = rec.verify()
                            if ok and not rec.is_hard_expired():
                                k_ = (rec.peer_id, rec.seq, rec.issued_at)
                                records_seen[k_] = rec
                        except Exception:
                            pass
                    # Still absorb node liveness info.
                    # (VALUE responses don't carry a node list.)
                elif reply.type == MsgType.VALUE_MISS.value:
                    self._absorb_nodes(reply, key, shortlist, closest, queried)

        # Quorum resolution: pick the record with the highest (seq, issued_at).
        chosen: Optional[LocatorRecord] = None
        for rec in records_seen.values():
            if chosen is None or (rec.seq, rec.issued_at) > (
                chosen.seq, chosen.issued_at
            ):
                chosen = rec

        result = LookupResult(
            record=chosen,
            quorum_records=list(records_seen.values()),
            closest=sorted(
                closest.values(), key=lambda c: xor_distance(c.peer_id, key)
            )[: self._k],
            queried=len(queried),
        )
        self._audit.record(
            "dht.find_value_done",
            key=key,
            queried=result.queried,
            variants=len(records_seen),
            found=chosen is not None,
            chosen_seq=chosen.seq if chosen else None,
        )
        return result

    def store_on_network(self, record: LocatorRecord) -> dict:
        """Publish a record to the k peers XOR-closest to its peer_id.

        Returns a summary: {accepted, rejected, unreachable, closest}.
        """
        target = record.peer_id
        closest = self.find_node(target)
        accepted: list[str] = []
        rejected: list[tuple[str, str]] = []
        unreachable: list[str] = []

        # Also store locally if we're among the k closest to the key.
        all_plus_self = closest + [
            Contact(peer_id=self._rt.self_peer_id, endpoint="self")
        ]
        ordered = sorted(
            all_plus_self, key=lambda c: xor_distance(c.peer_id, target)
        )[: self._k]

        for contact in ordered:
            if contact.peer_id == self._rt.self_peer_id:
                r = self._store.put(record)
                if r.accepted:
                    accepted.append(contact.peer_id)
                elif r.reason == "not_newer":
                    # Already have at least as fresh; count as accepted.
                    accepted.append(contact.peer_id)
                else:
                    rejected.append((contact.peer_id, r.reason or "unknown"))
                continue
            msg = Message.make(
                MsgType.STORE,
                sender=self._rt.self_peer_id,
                payload={"record": record.to_wire_bytes().decode("utf-8")},
            )
            try:
                reply = self._tx.send_and_wait(contact.peer_id, msg)
                if reply.type == MsgType.STORE_OK.value:
                    accepted.append(contact.peer_id)
                    if self._rep is not None:
                        self._rep.note_success(contact.peer_id)
                else:
                    rejected.append(
                        (contact.peer_id, reply.payload.get("reason", "rejected"))
                    )
                    if self._rep is not None:
                        self._rep.note_failure(contact.peer_id)
            except UnreachableError:
                unreachable.append(contact.peer_id)
                if self._rep is not None:
                    self._rep.note_failure(contact.peer_id)
            except TransportError:
                unreachable.append(contact.peer_id)
                if self._rep is not None:
                    self._rep.note_failure(contact.peer_id)

        self._audit.record(
            "dht.publish",
            peer_id=record.peer_id,
            seq=record.seq,
            accepted=len(accepted),
            rejected=len(rejected),
            unreachable=len(unreachable),
        )
        return {
            "accepted": accepted,
            "rejected": rejected,
            "unreachable": unreachable,
            "closest": [c.peer_id for c in ordered],
        }

    # =============== internals ===============

    def _init_shortlist(
        self, target: str
    ) -> tuple[dict[str, Contact], dict[str, Contact], set[str]]:
        seed = self._rt.closest(target, self._k)
        shortlist: dict[str, Contact] = {c.peer_id: c for c in seed}
        closest: dict[str, Contact] = dict(shortlist)
        queried: set[str] = set()
        return shortlist, closest, queried

    def _pick_next(
        self,
        shortlist: dict[str, Contact],
        queried: set[str],
        alpha: int,
    ) -> list[Contact]:
        remaining = [c for pid, c in shortlist.items() if pid not in queried]
        if not remaining:
            return []
        remaining.sort(
            key=lambda c: xor_distance(c.peer_id, self._rt.self_peer_id)
        )
        return remaining[:alpha]

    def _absorb_nodes(
        self,
        reply: Message,
        target: str,
        shortlist: dict[str, Contact],
        closest: dict[str, Contact],
        queried: set[str],
    ) -> None:
        for nd in reply.payload.get("nodes", []):
            pid = nd.get("peer_id")
            endpoint = nd.get("endpoint", "")
            if not isinstance(pid, str):
                continue
            if pid == self._rt.self_peer_id:
                continue
            self._rt.observe(pid, endpoint)
            if pid not in shortlist:
                shortlist[pid] = Contact(peer_id=pid, endpoint=endpoint)
            if pid not in closest:
                closest[pid] = Contact(peer_id=pid, endpoint=endpoint)
        # Cap the shortlist to k nearest to target.
        ordered = sorted(
            shortlist.values(),
            key=lambda c: xor_distance(c.peer_id, target),
        )[: self._k]
        shortlist.clear()
        shortlist.update({c.peer_id: c for c in ordered})
