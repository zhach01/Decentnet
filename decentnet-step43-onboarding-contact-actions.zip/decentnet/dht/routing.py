"""Kademlia-style routing table.

We keep one bucket per leading-bit-difference (see `distance.bucket_index`).
Each bucket holds at most `k` contacts in LRU order.

A `Contact` records the minimum data needed to send an RPC: peer_id
plus an opaque endpoint hint (used by the UDP transport; in-process
transport ignores it). We keep `last_seen` so the router can prefer
fresh peers when selecting candidates.

When a bucket is full and we learn of a new peer, Kademlia prescribes
PINGing the oldest contact; if it replies, keep the old and drop the
new; if it doesn't, evict and insert. For Phase 2's in-process setup
where PING is ~always successful we keep the classic rule but expose
`force_add` for tests.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Callable, Optional

from ..utils.time import now_s
from .distance import ID_BITS, bucket_index, sort_by_distance, xor_distance


DEFAULT_K = 8
"""Replication / bucket size. Smaller than real Kademlia's 20 to keep
simulator runs fast; the algorithms are identical."""


@dataclass
class Contact:
    peer_id: str
    endpoint: str = ""                   # opaque hint; "" means "ask transport"
    last_seen: int = field(default_factory=now_s)

    def touch(self) -> None:
        self.last_seen = now_s()


PingCallback = Callable[[Contact], bool]
"""Returns True iff the contact replies to PING."""


# --------------------------------------------------------------------


class KBucket:
    __slots__ = ("_k", "_contacts")

    def __init__(self, k: int) -> None:
        self._k = k
        self._contacts: deque[Contact] = deque()

    def __len__(self) -> int:
        return len(self._contacts)

    def contacts(self) -> list[Contact]:
        return list(self._contacts)

    def get(self, peer_id: str) -> Optional[Contact]:
        for c in self._contacts:
            if c.peer_id == peer_id:
                return c
        return None

    def touch_or_insert(
        self,
        contact: Contact,
        *,
        ping_cb: Optional[PingCallback] = None,
    ) -> bool:
        existing = self.get(contact.peer_id)
        if existing is not None:
            existing.touch()
            if contact.endpoint:
                existing.endpoint = contact.endpoint
            # Move-to-most-recent: remove and re-append.
            self._contacts.remove(existing)
            self._contacts.append(existing)
            return True

        if len(self._contacts) < self._k:
            contact.touch()
            self._contacts.append(contact)
            return True

        # Bucket full: Kademlia behavior — PING the oldest.
        oldest = self._contacts[0]
        if ping_cb is not None and ping_cb(oldest):
            # Oldest is alive; drop the newcomer, refresh oldest.
            oldest.touch()
            self._contacts.remove(oldest)
            self._contacts.append(oldest)
            return False
        # Oldest dead (or no ping cb): evict, insert new.
        self._contacts.popleft()
        contact.touch()
        self._contacts.append(contact)
        return True

    def remove(self, peer_id: str) -> bool:
        existing = self.get(peer_id)
        if existing is None:
            return False
        self._contacts.remove(existing)
        return True


# --------------------------------------------------------------------


class RoutingTable:
    def __init__(self, self_peer_id: str, *, k: int = DEFAULT_K) -> None:
        self._self_id = self_peer_id
        self._k = k
        self._buckets: list[KBucket] = [KBucket(k) for _ in range(ID_BITS)]

    @property
    def k(self) -> int:
        return self._k

    @property
    def self_peer_id(self) -> str:
        return self._self_id

    # ---- insertion / removal ----

    def observe(
        self,
        peer_id: str,
        endpoint: str = "",
        *,
        ping_cb: Optional[PingCallback] = None,
    ) -> bool:
        """Record that we've seen/heard from this peer. Returns True if
        the routing table now contains them."""
        if peer_id == self._self_id:
            return False
        idx = bucket_index(self._self_id, peer_id)
        if idx < 0:
            return False
        return self._buckets[idx].touch_or_insert(
            Contact(peer_id=peer_id, endpoint=endpoint),
            ping_cb=ping_cb,
        )

    def remove(self, peer_id: str) -> bool:
        idx = bucket_index(self._self_id, peer_id)
        if idx < 0:
            return False
        return self._buckets[idx].remove(peer_id)

    # ---- queries ----

    def all_contacts(self) -> list[Contact]:
        out: list[Contact] = []
        for b in self._buckets:
            out.extend(b.contacts())
        return out

    def closest(self, target: str, count: Optional[int] = None) -> list[Contact]:
        """Return up to `count` contacts closest to `target`. Defaults to k."""
        n = count if count is not None else self._k
        all_c = self.all_contacts()
        all_c.sort(key=lambda c: xor_distance(c.peer_id, target))
        return all_c[:n]

    def size(self) -> int:
        return sum(len(b) for b in self._buckets)

    def stats(self) -> dict:
        populated = sum(1 for b in self._buckets if len(b) > 0)
        return {
            "k": self._k,
            "contacts": self.size(),
            "populated_buckets": populated,
            "total_buckets": ID_BITS,
        }
