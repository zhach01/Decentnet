"""ICE candidates: local address variants and priority math.

RFC 5245 / 8445 defines candidate types:

    host    — an interface address on this device (our LAN IPs)
    srflx   — server-reflexive: the NAT mapping learned via STUN
    prflx   — peer-reflexive: a mapping discovered during ICE itself
    relay   — allocated on a TURN/relay server

For decentnet Phase 6 we use host, srflx, and relay; prflx is
emergent (the peer sees a mapping we didn't know we had and
promotes the pair accordingly, see `agent.py`).

Priority formula (RFC 8445 §5.1.2.1):

    priority = (2^24)*type_pref + (2^8)*local_pref + (256 - component)

We treat every candidate as a single-component datagram flow
(component = 1), matching RTP-only WebRTC.

Typical type preferences:

    host  = 126
    prflx = 110
    srflx = 100
    relay =   0

Local preference is a tiebreaker across multiple addresses of the
same type (e.g., prefer wired LAN over Wi-Fi).

Candidate pair priority (RFC 8445 §6.1.2.3), with `G` the controlling
(initiator) priority and `D` the controlled:

    pair_priority = (2^32 * min(G,D)) + (2 * max(G,D)) + (G > D ? 1 : 0)
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class CandidateType(str, Enum):
    HOST = "host"
    SRFLX = "srflx"     # server-reflexive (learned via STUN)
    PRFLX = "prflx"     # peer-reflexive (discovered during ICE)
    RELAY = "relay"     # allocated on a relay server


TYPE_PREFERENCE = {
    CandidateType.HOST: 126,
    CandidateType.PRFLX: 110,
    CandidateType.SRFLX: 100,
    CandidateType.RELAY: 0,
}


# Endpoint type -> ICE candidate type mapping used when we convert
# a LocatorRecord's endpoints into ICE candidates.
ENDPOINT_TO_ICE_TYPE = {
    "lan_udp": CandidateType.HOST,
    "public_udp": CandidateType.SRFLX,   # usually STUN-learned
    "public_tcp": CandidateType.HOST,    # treat as host for priority
    "vpn_udp": CandidateType.HOST,
    "tailscale_udp": CandidateType.HOST,
    "wireguard_udp": CandidateType.HOST,
    "relay_candidate": CandidateType.RELAY,
}

ENDPOINT_LOCAL_PREF_BONUS = {
    "tailscale_udp": 20000,
    "wireguard_udp": 18000,
    "vpn_udp": 16000,
    "lan_udp": 8000,
    "public_udp": 2000,
    "public_tcp": 1000,
    "relay_candidate": 0,
}


@dataclass(frozen=True)
class IceCandidate:
    type: CandidateType
    host: str
    port: int
    local_preference: int = 65535       # tiebreaker; higher = prefer
    component: int = 1                  # we only use a single datagram flow
    # When this candidate was learned from a relay, the base is the
    # local address used to reach the relay (useful for ICE semantics;
    # not essential for our simplified flow).
    base_address: Optional[str] = None
    base_port: Optional[int] = None

    def priority(self) -> int:
        type_pref = TYPE_PREFERENCE[self.type]
        return (
            (type_pref << 24)
            | (self.local_preference << 8)
            | (256 - self.component)
        )

    def address_tuple(self) -> tuple[str, int]:
        return (self.host, self.port)

    def to_dict(self) -> dict:
        return {
            "type": self.type.value,
            "host": self.host,
            "port": self.port,
            "local_preference": self.local_preference,
            "component": self.component,
            "base_address": self.base_address,
            "base_port": self.base_port,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "IceCandidate":
        return cls(
            type=CandidateType(d["type"]),
            host=d["host"],
            port=int(d["port"]),
            local_preference=int(d.get("local_preference", 65535)),
            component=int(d.get("component", 1)),
            base_address=d.get("base_address"),
            base_port=d.get("base_port"),
        )


def pair_priority(
    controlling_priority: int,
    controlled_priority: int,
    *,
    we_control: bool,
) -> int:
    """RFC 8445 §6.1.2.3 pair priority."""
    g = controlling_priority
    d = controlled_priority
    lo = min(g, d)
    hi = max(g, d)
    tiebreak = 1 if (g > d and we_control) or (g < d and not we_control) else 0
    return (lo << 32) + (2 * hi) + tiebreak


def candidates_from_endpoints(
    endpoints: list,   # list[Endpoint]
) -> list[IceCandidate]:
    """Convert a LocatorRecord.endpoints list to IceCandidates."""
    out: list[IceCandidate] = []
    for ep in endpoints:
        ice_type = ENDPOINT_TO_ICE_TYPE.get(ep.type)
        if ice_type is None:
            continue
        host, _, port_s = ep.address.rpartition(":")
        # Handle IPv6 "[::1]:port" form.
        if host.startswith("[") and host.endswith("]"):
            host = host[1:-1]
        try:
            port = int(port_s)
        except ValueError:
            continue
        # Endpoints carry a `confidence` and `priority` already; fold
        # those into local_preference so caller hints matter.
        local_pref = max(
            0,
            min(
                65535,
                ENDPOINT_LOCAL_PREF_BONUS.get(getattr(ep, "type", ""), 0)
                + int(getattr(ep, "priority", 0)) * 256
                + int(getattr(ep, "confidence", 0.5) * 255),
            ),
        )
        out.append(
            IceCandidate(
                type=ice_type, host=host, port=port,
                local_preference=local_pref,
            )
        )
    return out
