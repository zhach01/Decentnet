"""ICE agent — candidate-pair probing and nomination.

We reuse decentnet's signed signaling envelope (`sig.*`) for
connectivity checks rather than implementing STUN's USERNAME /
MESSAGE-INTEGRITY / FINGERPRINT. Justification:

- The signed envelope already carries app_magic, sender peer_id,
  target peer_id, nonce, freshness, replay-protected msg_id, and
  an Ed25519 signature over all of it. That's stronger authentication
  than STUN's HMAC-SHA1 with short-term credentials.
- The connectivity-check probe is just a signaling pass-through
  message of type `sig.conn_check` with a `check_id` in the body;
  the responder replies with `sig.conn_check_ack` carrying the
  same `check_id`.
- Using one wire format keeps the UDP demux simple and lets the
  existing replay cache apply to ICE as well.

Interop note: this means decentnet ICE does not interoperate with
WebRTC ICE over the wire. That's fine for Phase 6 — peers are both
decentnet nodes talking to each other. If future phases need to
bridge to browser WebRTC, we can add a STUN-compatible probe
alongside.

States per RFC 8445 §6.1.2.6:
    NEW             never tried
    IN_PROGRESS     check sent, awaiting ack
    SUCCEEDED       ack received, pair is live
    FAILED          timeout/error/negcache
    NOMINATED       promoted by the controlling agent
"""
from __future__ import annotations

import threading
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Optional

from ..audit.log import AuditLog
from ..signaling.messages import SignalType, build_and_sign
from ..transport.messages import (
    Message,
    TransportError,
    TransportTimeoutError,
    UnreachableError,
)
from ..utils.time import now_s
from .candidates import IceCandidate, pair_priority


DEFAULT_CHECK_TIMEOUT_S = 1.0
DEFAULT_MAX_CHECKS_PER_PAIR = 3


class PairState(str, Enum):
    NEW = "new"
    IN_PROGRESS = "in_progress"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    NOMINATED = "nominated"


@dataclass
class CandidatePair:
    local: IceCandidate
    remote: IceCandidate
    we_control: bool
    state: PairState = PairState.NEW
    attempts: int = 0
    rtt_ms: Optional[int] = None
    last_check_at: Optional[int] = None
    last_error: Optional[str] = None

    def priority(self) -> int:
        return pair_priority(
            self.local.priority() if self.we_control else self.remote.priority(),
            self.remote.priority() if self.we_control else self.local.priority(),
            we_control=self.we_control,
        )


# --------------------------------------------------------------------


# "Transport sender" abstraction: we need to emit a conn-check on a
# specific *local* candidate to a specific *remote* address. For the
# Phase 6 tests we use an in-memory transport that accepts raw bytes;
# for real deployment the UDPTransport's `send_raw` + opportunistic
# endpoint learning gives us the same surface.

CheckSender = Callable[[IceCandidate, tuple[str, int], bytes], None]
"""`(local_cand, remote_addr, datagram) -> None`. Raises on failure."""


@dataclass
class ConnCheckResult:
    pair: CandidatePair
    ok: bool
    reason: Optional[str] = None


class ICEAgent:
    """Coordinates candidate-pair probing for a single remote peer.

    The agent:
      1. Receives local + remote candidate lists.
      2. Enumerates and sorts pairs by priority.
      3. Probes pairs in priority order, calling `check_sender`.
      4. When a `sig.conn_check_ack` arrives for an outstanding
         check (via `handle_ack`), marks the pair SUCCEEDED.
      5. The controlling agent nominates the highest-priority
         SUCCEEDED pair.

    Hole-punch semantics are implicit: starting a check on a pair
    causes an outbound datagram, which opens the local NAT mapping
    so the peer's mirror check can make it back. Both sides run the
    agent in parallel; whichever check punches through first wins.
    """

    def __init__(
        self,
        *,
        self_peer_id: str,
        remote_peer_id: str,
        keypair,
        check_sender: CheckSender,
        audit: Optional[AuditLog] = None,
        we_control: bool = True,
    ) -> None:
        self._self = self_peer_id
        self._remote = remote_peer_id
        self._kp = keypair
        self._send = check_sender
        self._audit = audit or AuditLog(None)
        self._we_control = we_control
        self._pairs: list[CandidatePair] = []
        self._pending: dict[str, tuple[CandidatePair, threading.Event, int]] = {}
        self._pending_lock = threading.Lock()
        self._nominated: Optional[CandidatePair] = None
        self._lock = threading.RLock()

    # ---- setup ----

    def set_candidates(
        self,
        local: list[IceCandidate],
        remote: list[IceCandidate],
    ) -> None:
        with self._lock:
            self._pairs = []
            for l in local:
                for r in remote:
                    # Skip obviously mismatched (e.g. IPv4 vs IPv6).
                    self._pairs.append(
                        CandidatePair(
                            local=l, remote=r, we_control=self._we_control,
                        )
                    )
            self._pairs.sort(key=lambda p: p.priority(), reverse=True)
        self._audit.record(
            "ice.pairs_enumerated",
            remote=self._remote,
            total=len(self._pairs),
        )

    def pairs(self) -> list[CandidatePair]:
        with self._lock:
            return list(self._pairs)

    def nominated(self) -> Optional[CandidatePair]:
        return self._nominated

    # ---- checks ----

    def _build_check_message(
        self, check_id: str, pair: CandidatePair
    ) -> Message:
        """Build a signed sig.conn_check message."""
        return build_and_sign(
            self._kp,
            SignalType.CONN_CHECK,
            sender=self._self,
            target=self._remote,
            body={
                "check_id": check_id,
                "local_prio": pair.local.priority(),
                "remote_prio": pair.remote.priority(),
                "we_control": pair.we_control,
            },
        )

    def probe_pair(
        self,
        pair: CandidatePair,
        *,
        timeout_s: float = DEFAULT_CHECK_TIMEOUT_S,
    ) -> ConnCheckResult:
        """Send a single connectivity check on a pair and wait for ack."""
        check_id = uuid.uuid4().hex
        msg = self._build_check_message(check_id, pair)
        data = msg.to_wire_bytes()
        event = threading.Event()
        with self._pending_lock:
            self._pending[check_id] = (pair, event, now_s())

        with self._lock:
            pair.state = PairState.IN_PROGRESS
            pair.attempts += 1
            pair.last_check_at = now_s()

        try:
            self._send(pair.local, pair.remote.address_tuple(), data)
        except (UnreachableError, TransportError) as e:
            with self._lock:
                pair.state = PairState.FAILED
                pair.last_error = str(e)
            self._audit.record(
                "ice.check_send_failed",
                remote=self._remote, reason=str(e),
                local=f"{pair.local.host}:{pair.local.port}",
                peer_addr=f"{pair.remote.host}:{pair.remote.port}",
            )
            with self._pending_lock:
                self._pending.pop(check_id, None)
            return ConnCheckResult(pair=pair, ok=False, reason=str(e))

        if not event.wait(timeout_s):
            with self._lock:
                pair.state = PairState.FAILED
                pair.last_error = "timeout"
            self._audit.record(
                "ice.check_timeout",
                remote=self._remote,
                peer_addr=f"{pair.remote.host}:{pair.remote.port}",
            )
            with self._pending_lock:
                self._pending.pop(check_id, None)
            return ConnCheckResult(pair=pair, ok=False, reason="timeout")

        # Ack arrived; state was updated by handle_ack.
        return ConnCheckResult(pair=pair, ok=True)

    def gather_and_probe(
        self,
        *,
        timeout_s: float = DEFAULT_CHECK_TIMEOUT_S,
        max_pairs: Optional[int] = None,
    ) -> Optional[CandidatePair]:
        """Probe pairs in priority order until one succeeds (then, if
        we control, nominate it). Returns the nominated pair or None.
        """
        with self._lock:
            ordered = list(self._pairs)
        if max_pairs is not None:
            ordered = ordered[:max_pairs]
        for pair in ordered:
            result = self.probe_pair(pair, timeout_s=timeout_s)
            if result.ok:
                if self._we_control:
                    self.nominate(pair)
                return pair
        return None

    def nominate(self, pair: CandidatePair) -> None:
        with self._lock:
            pair.state = PairState.NOMINATED
            self._nominated = pair
        self._audit.record(
            "ice.nominated",
            remote=self._remote,
            local=f"{pair.local.host}:{pair.local.port}",
            peer=f"{pair.remote.host}:{pair.remote.port}",
            type_pair=f"{pair.local.type.value}/{pair.remote.type.value}",
        )

    # ---- incoming check / ack handling ----

    def handle_check(
        self,
        from_peer: str,
        from_addr: tuple[str, int],
        msg: Message,
        *,
        local_cand: IceCandidate,
    ) -> Optional[bytes]:
        """Handle an incoming sig.conn_check. Return the ack datagram
        to send back. The caller emits the datagram on the same socket
        the check arrived on (to preserve the hole-punched mapping).
        """
        if from_peer != self._remote:
            return None
        body = msg.payload.get("body", {}) or {}
        check_id = body.get("check_id")
        if not isinstance(check_id, str):
            return None
        ack = build_and_sign(
            self._kp,
            SignalType.CONN_CHECK_ACK,
            sender=self._self,
            target=self._remote,
            in_reply_to=msg.msg_id,
            body={
                "check_id": check_id,
                "observed_remote": f"{from_addr[0]}:{from_addr[1]}",
            },
        )
        self._audit.record(
            "ice.check_received",
            remote=self._remote,
            peer_addr=f"{from_addr[0]}:{from_addr[1]}",
            local=f"{local_cand.host}:{local_cand.port}",
        )
        return ack.to_wire_bytes()

    def handle_ack(
        self,
        from_peer: str,
        from_addr: tuple[str, int],
        msg: Message,
    ) -> None:
        if from_peer != self._remote:
            return
        body = msg.payload.get("body", {}) or {}
        check_id = body.get("check_id")
        if not isinstance(check_id, str):
            return
        with self._pending_lock:
            entry = self._pending.pop(check_id, None)
        if entry is None:
            return
        pair, event, sent_at = entry
        with self._lock:
            pair.state = PairState.SUCCEEDED
            pair.rtt_ms = int((now_s() - sent_at) * 1000)
        event.set()
        self._audit.record(
            "ice.check_succeeded",
            remote=self._remote,
            local=f"{pair.local.host}:{pair.local.port}",
            peer=f"{pair.remote.host}:{pair.remote.port}",
            rtt_ms=pair.rtt_ms,
        )


# --------------------------------------------------------------------


def enumerate_pairs(
    local: list[IceCandidate],
    remote: list[IceCandidate],
    *,
    we_control: bool = True,
) -> list[CandidatePair]:
    """Standalone utility for tests."""
    pairs = [
        CandidatePair(local=l, remote=r, we_control=we_control)
        for l in local for r in remote
    ]
    pairs.sort(key=lambda p: p.priority(), reverse=True)
    return pairs
