"""Node — the top-level facade an app or CLI talks to.

Phase 1: identity + LocalCache + audit + seq counter + CLI surface.

Phase 2 (optional): plug an `InProcessNetwork` (or any transport) in
at construction time and the Node also runs as a DHT participant:
it replicates records it's XOR-close to, publishes to and resolves
from the network, and can repair divergence with neighbours via
anti-entropy. Without a network argument, everything behaves exactly
as in Phase 1 (backwards-compatible).

Lookup fallthrough
------------------
    resolve(peer_id) ->   L1 local cache
                       -> (if miss and networked) L3 DHT FIND_VALUE
                          with quorum across up to k replicas
                       -> if a record is found via L3, it is also
                          written back to L1 for future hits.

Safety layered on in Phase 2
----------------------------
* `validate_for_storage` adds a future-skew clamp (prevents
  "issued_at = 2099" attacks).
* Ingest is rate-limited per source to mitigate flood/DoS.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Iterable, Optional

from ..audit.log import AuditLog
from ..cache.confidence import ConfidenceTracker
from ..cache.deferred import DeferredWriteBuffer
from ..cache.local import LocalCache, PutResult
from ..identity.keypair import Keypair
from ..identity.ledger import RotationLedger
from ..identity.peer_id import PeerId
from ..identity.rotation import RotationReceipt, issue_rotation_receipt
from ..limits.rates import RateLimiter
from ..limits.reputation import ReputationTracker
from ..schedulers import BackgroundRefresh, KeepaliveScheduler
from ..records.endpoints import Endpoint
from ..records.locator import (
    DEFAULT_SOFT_TTL_S,
    DEFAULT_TTL_S,
    LocatorRecord,
)
from ..utils.time import now_s
from .config import NodeConfig


class Node:
    def __init__(
        self,
        config: NodeConfig,
        *,
        network: Optional[Any] = None,   # InProcessNetwork or None
        dht_k: int = 8,
        rate_burst: float = 50.0,
        rate_refill_per_s: float = 10.0,
    ) -> None:
        config.ensure()
        self.config = config
        self.keypair = Keypair.load_or_create(config.keyfile)
        self.peer_id = PeerId.from_public_key(self.keypair.public_key_bytes)
        self.audit = AuditLog(config.audit_log)
        self.rotation_ledger = RotationLedger(config.rotation_ledger_db)
        self.confidence = ConfidenceTracker(config.confidence_db)
        self.deferred = DeferredWriteBuffer(config.deferred_writes_db)
        self.reputation = ReputationTracker(config.reputation_db)
        self._refresh_scheduler: Optional[BackgroundRefresh] = None
        self._keepalive_scheduler: Optional[KeepaliveScheduler] = None

        def _confidence_hook(record: LocatorRecord, source: str) -> None:
            self.confidence.record(
                record.peer_id, source, record.seq, record.issued_at,
            )

        self.cache = LocalCache(
            config.cache_db, audit=self.audit,
            rotation_ledger=self.rotation_ledger,
            on_accept=_confidence_hook,
        )
        self._seq = _SeqCounter(config.seq_file)
        self._limiter = RateLimiter(
            burst=rate_burst, refill_per_s=rate_refill_per_s
        )

        # Topic-scoped replication policy (Phase 2-bis: scoped caches).
        from ..dht.topics import TopicPolicy
        self.topic_policy = TopicPolicy(path=config.topic_subscriptions_file)

        # Optional Phase 2 networking.
        self._network = network
        self.directory = None
        self._transport = None
        self.signaling = None
        self.nat = None                              # Phase 5
        self._republish_timer_scheduler = None
        self._republish_interval_s: Optional[int] = None
        if network is not None:
            # Local imports to avoid cycles with non-network use.
            from ..directory.directory import Directory
            from ..signaling.engine import SignalingEngine
            from ..transport.inproc import InProcessTransport

            self._transport = InProcessTransport(network, self.peer_id.value)
            self.directory = Directory(
                self_peer_id=self.peer_id.value,
                transport=self._transport,
                audit=self.audit,
                k=dht_k,
                local_cache_observer=self._observe_from_dht,
                dht_persist_path=str(config.dht_store_db),
                topic_policy=self.topic_policy,
                reputation=self.reputation,
            )
            # Signaling engine wraps the transport's receive handler so
            # it can claim signaling messages and pass DHT ones through.
            self.signaling = SignalingEngine(
                local_peer_id=self.peer_id.value,
                keypair=self.keypair,
                transport=self._transport,
                local_cache=self.cache,
                audit=self.audit,
            )

        self.audit.record(
            "node.start",
            peer_id=self.peer_id.value,
            root=str(config.root),
            networked=self._network is not None,
        )

    def close(self) -> None:
        if self._transport is not None:
            try:
                self._transport.close()
            except Exception:
                pass
        if self.directory is not None:
            try:
                self.directory.shutdown()
            except Exception:
                pass
        self.cache.close()
        try:
            self.rotation_ledger.close()
        except Exception:
            pass
        try:
            self.confidence.close()
        except Exception:
            pass
        try:
            self.deferred.close()
        except Exception:
            pass
        try:
            self.reputation.close()
        except Exception:
            pass
        if self._refresh_scheduler is not None:
            try:
                self._refresh_scheduler.stop()
            except Exception:
                pass
        if self._keepalive_scheduler is not None:
            try:
                self._keepalive_scheduler.stop()
            except Exception:
                pass
        self.audit.record("node.stop", peer_id=self.peer_id.value)

    # ---------- context manager sugar ----------

    def __enter__(self) -> "Node":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    # ---------- publishing ----------

    def publish_own_record(
        self,
        endpoints: list[Endpoint],
        *,
        ttl_s: int = DEFAULT_TTL_S,
        soft_ttl_s: int = DEFAULT_SOFT_TTL_S,
        capabilities: Optional[list[str]] = None,
        nat_metadata: Optional[dict[str, Any]] = None,
        topic_hashes: Optional[list[str]] = None,
    ) -> LocatorRecord:
        """Build, sign, and store a new record for this node.

        In Phase 1 "publish" means "insert into our own local cache
        and write to the audit log". Phase 2 will also push to the
        distributed directory and optionally to directly-connected
        peers.
        """
        seq = self._seq.next()
        rec = LocatorRecord.build_and_sign(
            self.keypair,
            endpoints=endpoints,
            seq=seq,
            ttl_s=ttl_s,
            soft_ttl_s=soft_ttl_s,
            capabilities=capabilities,
            nat_metadata=nat_metadata,
            topic_hashes=topic_hashes,
        )
        result = self.cache.put(rec, source="self")
        if not result.accepted:
            # Should never happen: our own record must pass validation.
            # If it doesn't, surface it instead of silently swallowing.
            raise RuntimeError(
                f"Own record rejected by local cache: {result.reason}"
            )
        self.audit.record(
            "node.publish",
            peer_id=self.peer_id.value,
            seq=rec.seq,
            endpoints=[e.address for e in rec.endpoints],
            ttl_s=ttl_s,
        )
        return rec

    def own_record(self) -> Optional[LocatorRecord]:
        return self.cache.peek(self.peer_id.value)

    def export_own_record(self) -> bytes:
        rec = self.own_record()
        if rec is None:
            raise RuntimeError(
                "No own record published yet. Call publish_own_record() first."
            )
        return rec.to_wire_bytes()

    # ---------- global snapshotting / reconstruction ----------

    def take_snapshot(self):
        """Build a signed `GlobalSnapshot` containing every record we
        currently hold (L1 + DHT store, deduplicated, newest-wins)."""
        from ..repair.snapshot import GlobalSnapshot, SnapshotStore
        seen: dict[str, LocatorRecord] = {}
        for rec, _ in self.cache.entries():
            seen[rec.peer_id] = rec
        if self.directory is not None:
            for rec in self.directory.store.all_records():
                cur = seen.get(rec.peer_id)
                if cur is None or (rec.seq, rec.issued_at) > (
                    cur.seq, cur.issued_at
                ):
                    seen[rec.peer_id] = rec
        snap = GlobalSnapshot.build_and_sign(
            self.keypair,
            list(seen.values()),
            producer_peer_id=self.peer_id.value,
        )
        # Persist into our local snapshot archive.
        store = SnapshotStore(self.config.snapshot_db)
        try:
            store.store(snap)
        finally:
            store.close()
        self.audit.record(
            "node.snapshot_taken",
            record_count=snap.record_count,
            issued_at=snap.issued_at,
        )
        return snap

    def import_snapshot(self, snapshot_bytes: bytes) -> dict:
        """Validate a foreign snapshot, store it locally, and walk
        every record through our cache. Returns a tally."""
        from ..repair.snapshot import (
            GlobalSnapshot, SnapshotStore, reconstruct_from_snapshots,
        )
        snap = GlobalSnapshot.from_bytes(snapshot_bytes)
        store = SnapshotStore(self.config.snapshot_db)
        try:
            store.store(snap)
        finally:
            store.close()
        result = reconstruct_from_snapshots(
            [snap],
            cache_put=lambda rec, source: self.cache.put(rec, source=source),
        )
        self.audit.record(
            "node.snapshot_imported",
            from_producer=snap.producer_peer_id,
            records_seen=result.records_seen,
            records_accepted=result.records_accepted,
            records_rejected=result.records_rejected,
        )
        return {
            "snapshots_processed": result.snapshots_processed,
            "records_seen": result.records_seen,
            "records_accepted": result.records_accepted,
            "records_rejected": result.records_rejected,
            "rejection_reasons": dict(result.rejection_reasons),
        }

    def reconstruct_from_local_snapshots(self) -> dict:
        """Run reconstruction across every snapshot we've stored
        locally. Used after catastrophic loss when peers are still
        offline but historical snapshots are on disk."""
        from ..repair.snapshot import (
            SnapshotStore, reconstruct_from_snapshots,
        )
        store = SnapshotStore(self.config.snapshot_db)
        try:
            snapshots = store.all_snapshots()
            result = reconstruct_from_snapshots(
                snapshots,
                cache_put=lambda rec, source: self.cache.put(rec, source=source),
            )
        finally:
            store.close()
        self.audit.record(
            "node.reconstruct",
            snapshots_processed=result.snapshots_processed,
            records_accepted=result.records_accepted,
            records_rejected=result.records_rejected,
        )
        return {
            "snapshots_processed": result.snapshots_processed,
            "records_seen": result.records_seen,
            "records_accepted": result.records_accepted,
            "records_rejected": result.records_rejected,
            "rejection_reasons": dict(result.rejection_reasons),
        }

    # ---------- topic subscriptions ----------

    def subscribe_topic(self, name: str) -> str:
        """Subscribe to a topic by human-readable name. Returns the
        opaque topic_hash you'd put in records' `topic_hashes`."""
        h = self.topic_policy.subscribe_topic(name)
        self.topic_policy.set_replicate_all(False)
        self.audit.record("node.topic_subscribe", name=name, hash=h)
        return h

    def set_replicate_all(self, value: bool) -> None:
        self.topic_policy.set_replicate_all(value)
        self.audit.record("node.replicate_all", value=value)

    def subscribed_topics(self) -> set[str]:
        return set(self.topic_policy.subscribed_topics)

    # ---------- background maintenance ----------

    def enable_background_refresh(
        self, *, interval_s: int = 60, start: bool = True,
    ) -> BackgroundRefresh:
        if self._refresh_scheduler is None:
            self._refresh_scheduler = BackgroundRefresh(
                self, interval_s=interval_s,
            )
        if start:
            self._refresh_scheduler.start()
        return self._refresh_scheduler

    def disable_background_refresh(self) -> None:
        if self._refresh_scheduler is not None:
            self._refresh_scheduler.stop()

    def enable_keepalive(
        self, *, interval_s: int = 30, start: bool = True,
    ) -> KeepaliveScheduler:
        if self._keepalive_scheduler is None:
            self._keepalive_scheduler = KeepaliveScheduler(
                self, interval_s=interval_s,
            )
        if start:
            self._keepalive_scheduler.start()
        return self._keepalive_scheduler

    def disable_keepalive(self) -> None:
        if self._keepalive_scheduler is not None:
            self._keepalive_scheduler.stop()

    # ---------- selective disclosure ----------

    def publish_with_disclosure(
        self,
        public_endpoints: list[Endpoint],
        disclosed_endpoints: list[Endpoint],
        recipients: list[bytes],     # list of recipient Ed25519 pubkeys
        *,
        ttl_s: int = DEFAULT_TTL_S,
        soft_ttl_s: int = DEFAULT_SOFT_TTL_S,
        capabilities: Optional[list[str]] = None,
        nat_metadata: Optional[dict[str, Any]] = None,
        topic_hashes: Optional[list[str]] = None,
    ) -> LocatorRecord:
        """Publish a record carrying both:
          * `public_endpoints` — visible to everyone in the DHT.
          * `disclosed_endpoints` — encrypted and readable only by
            holders of the listed recipient keys.

        Each recipient gets a separate envelope so they can decrypt
        without coordinating.
        """
        from ..records.disclosure import encrypt_endpoints_for
        envelopes = [
            encrypt_endpoints_for(
                self.peer_id.value, recip_pub, disclosed_endpoints,
            ).to_dict()
            for recip_pub in recipients
        ]
        seq = self._seq.next()
        rec = LocatorRecord.build_and_sign(
            self.keypair,
            endpoints=list(public_endpoints),
            seq=seq,
            ttl_s=ttl_s,
            soft_ttl_s=soft_ttl_s,
            capabilities=capabilities,
            nat_metadata=nat_metadata,
            topic_hashes=topic_hashes,
            encrypted_endpoints=envelopes,
        )
        result = self.cache.put(rec, source="self")
        if not result.accepted:
            raise RuntimeError(
                f"Own disclosure record rejected: {result.reason}"
            )
        self.audit.record(
            "node.publish_with_disclosure",
            seq=rec.seq,
            public_count=len(public_endpoints),
            disclosed_count=len(disclosed_endpoints),
            recipients=len(recipients),
        )
        return rec

    def decrypt_disclosed(
        self, record: LocatorRecord
    ) -> list[Endpoint]:
        """Try every envelope on `record` with our private key. Returns
        endpoints from the first envelope that decrypts (typically at
        most one is addressed to us). Empty list if none address us."""
        from ..records.disclosure import EncryptedEnvelope, decrypt_envelope
        out: list[Endpoint] = []
        for env_dict in record.encrypted_endpoints:
            try:
                env = EncryptedEnvelope.from_dict(env_dict)
            except Exception:
                continue
            decoded = decrypt_envelope(env, record.peer_id, self.keypair)
            if decoded is not None:
                out.extend(decoded)
        return out

    # ---------- key rotation ----------

    def rotate_identity(
        self,
        endpoints: list[Endpoint],
        *,
        ttl_s: int = DEFAULT_TTL_S,
        soft_ttl_s: int = DEFAULT_SOFT_TTL_S,
    ) -> tuple[LocatorRecord, RotationReceipt]:
        """Generate a new keypair, sign a rotation receipt with the old
        key, install the new key, and publish a first record under the
        new identity carrying the receipt.

        Returns (new_record, receipt). The peer_id of the Node changes.

        Persistence: the new keypair OVERWRITES the old keyfile. Old
        cache rows under the prior peer_id remain (forwarded via the
        rotation ledger); old DHT replication is naturally superseded
        as the new record propagates.
        """
        old_keypair = self.keypair
        new_keypair = Keypair.generate()
        receipt = issue_rotation_receipt(old_keypair, new_keypair)
        # Install new identity in memory + on disk.
        new_keypair.save(self.config.keyfile)
        self.keypair = new_keypair
        old_pid = self.peer_id
        self.peer_id = PeerId.from_public_key(new_keypair.public_key_bytes)
        # Reset seq counter for the new identity.
        self._seq = _SeqCounter(self.config.seq_file)
        self._seq._value = 0  # restart at 0 so .next() returns 1
        self._seq._save()
        # Update signaling engine (it caches our peer_id + keypair).
        if self.signaling is not None:
            self.signaling._self = self.peer_id.value
            self.signaling._kp = self.keypair
        # Build first record under new key carrying receipt.
        seq = self._seq.next()
        rec = LocatorRecord.build_and_sign(
            self.keypair,
            endpoints=list(endpoints),
            seq=seq,
            ttl_s=ttl_s,
            soft_ttl_s=soft_ttl_s,
            prev_key_rotation=receipt.to_dict(),
        )
        result = self.cache.put(rec, source="self")
        if not result.accepted:
            raise RuntimeError(
                f"Own rotation record rejected: {result.reason}"
            )
        # Locally remember the forwarding too, so others on this node
        # who look up the old peer_id are forwarded.
        self.rotation_ledger.record_rotation(receipt)
        self.audit.record(
            "node.rotate_identity",
            old_peer_id=old_pid.value,
            new_peer_id=self.peer_id.value,
            seq=rec.seq,
        )
        return rec, receipt

    # ---------- lookup ----------

    def lookup(self, peer_id: str) -> Optional[LocatorRecord]:
        """L1-only lookup. Follows the rotation ledger if `peer_id`
        was succeeded by a newer one."""
        successor = self.rotation_ledger.successor_of(peer_id)
        effective_id = successor or peer_id
        rec = self.cache.get(effective_id)
        self.audit.record(
            "node.lookup",
            peer_id=peer_id,
            effective_id=effective_id,
            forwarded=successor is not None,
            hit=rec is not None,
        )
        return rec

    def resolve(
        self, peer_id: str, *, force_network: bool = False
    ) -> Optional[LocatorRecord]:
        """Full L1 → L3 resolution.

        If `force_network` is True we skip the L1 cache (useful for
        refreshing a soft-expired record). A record found via L3 is
        written back to L1 so future `lookup()` calls hit locally.
        """
        if not force_network:
            rec = self.cache.get(peer_id)
            if rec is not None and not rec.needs_soft_refresh():
                self.audit.record(
                    "node.resolve", peer_id=peer_id, source="l1"
                )
                return rec
        if self.directory is None:
            # No network available; return whatever L1 has (even if
            # soft-expired, since we can't refresh).
            rec = self.cache.peek(peer_id)
            self.audit.record(
                "node.resolve", peer_id=peer_id,
                source="l1_only", hit=rec is not None,
            )
            return rec
        # L3 lookup.
        result = self.directory.resolve(peer_id)
        if result.record is None:
            self.audit.record(
                "node.resolve", peer_id=peer_id, source="l3", hit=False,
                queried=result.queried,
            )
            return None
        # Write-through to L1 so subsequent lookups are fast.
        put_result = self.cache.put(result.record, source="l3")
        self.audit.record(
            "node.resolve",
            peer_id=peer_id, source="l3", hit=True,
            queried=result.queried,
            variants=len(result.quorum_records),
            cache_write=put_result.accepted,
        )
        return result.record

    # ---------- ingest ----------

    def ingest_record_bytes(
        self, data: bytes, *, source: str = "imported"
    ) -> PutResult:
        if not self._limiter.allow(source):
            self.audit.record(
                "node.ingest_rate_limited", source=source
            )
            return PutResult(False, reason="rate_limited")
        try:
            rec = LocatorRecord.from_wire_bytes(data)
        except Exception as e:
            self.audit.record(
                "node.ingest_parse_error",
                source=source,
                error=str(e),
            )
            return PutResult(False, reason=f"parse_error: {e}")
        return self.cache.put(rec, source=source)

    # Internal observer — called when a STORE RPC is accepted, so the
    # publisher's record also lands in L1 on replicas.
    def _observe_from_dht(self, record: LocatorRecord, source: str) -> None:
        self.cache.put(record, source=source)

    # ---------- Phase 2: network operations ----------

    def join_network(self, seeds: Iterable[tuple[str, str]]) -> int:
        """Bootstrap into the DHT using the given `(peer_id, endpoint)`
        seeds. Returns the number reachable. Requires a networked Node."""
        self._require_network()
        return self.directory.join(list(seeds))

    def publish_to_network(self) -> dict:
        """Push our own (most recent) record to the k DHT nodes
        closest to our peer_id. If we have no peers reachable at all,
        queue the record in the deferred-write buffer for retry by
        `drain_deferred()`. Returns a summary dict."""
        self._require_network()
        rec = self.own_record()
        if rec is None:
            raise RuntimeError(
                "No record to publish — call publish_own_record() first."
            )
        result = self.directory.publish(rec)
        if (
            len(result.get("accepted", [])) == 0
            and len(result.get("unreachable", [])) > 0
        ):
            # No replica reachable. Queue.
            self.deferred.enqueue(
                "publish",
                rec.to_wire_bytes().decode("utf-8"),
            )
            self.audit.record(
                "node.publish_deferred",
                seq=rec.seq,
                unreachable=len(result.get("unreachable", [])),
            )
            result["deferred"] = True
        return result

    def queue_publish_deferred(self) -> int:
        """Manually enqueue our current own record for later publication.
        Returns the queued item id."""
        rec = self.own_record()
        if rec is None:
            raise RuntimeError("No own record to queue.")
        return self.deferred.enqueue(
            "publish", rec.to_wire_bytes().decode("utf-8"),
        )

    def drain_deferred(self) -> dict:
        """Try every queued deferred publish/store. Items succeed and
        are removed when DHT publish accepts at least one replica."""
        if self.directory is None:
            return {"drained": 0, "attempted": 0, "remaining": self.deferred.size()}

        def _attempt(item):
            try:
                rec = LocatorRecord.from_wire_bytes(
                    item.record_json.encode("utf-8")
                )
            except Exception:
                return True   # malformed, drop
            if rec.is_hard_expired():
                return True   # expired, drop
            if item.kind == "publish":
                result = self.directory.publish(rec)
                return len(result.get("accepted", [])) > 0
            return False   # unknown kind; leave queued

        out = self.deferred.drain(_attempt)
        self.audit.record("node.drain_deferred", **out)
        return out

    def sync_with(self, peer_id: str):
        self._require_network()
        return self.directory.sync_with(peer_id)

    def dht_store(self):
        """Return the DHT replica store (for tests/inspection)."""
        self._require_network()
        return self.directory.store

    def routing_table(self):
        self._require_network()
        return self.directory.routing

    # ---------- Phase 5: NAT discovery ----------

    def enable_nat_discovery(
        self,
        stun_servers: list[tuple[str, int]],
        *,
        udp_transport=None,
    ) -> None:
        """Wire a `NATDiscovery` service onto a UDP-capable transport.

        By default we look for an attribute on the existing transport
        (`UDPTransport.set_stun_handler`); if the node is running over
        the in-process transport the caller must supply a standalone
        `UDPTransport` via `udp_transport`.
        """
        from ..nat.discovery import NATDiscovery

        tx = udp_transport if udp_transport is not None else self._transport
        if tx is None or not hasattr(tx, "set_stun_handler"):
            raise RuntimeError(
                "NAT discovery requires a UDP-capable transport; "
                "pass udp_transport=UDPTransport(...) explicitly."
            )
        self.nat = NATDiscovery(tx, stun_servers, audit=self.audit)

    def refresh_external_address(
        self, *, timeout_s: float = 2.0
    ) -> Optional[tuple[str, int]]:
        if self.nat is None:
            return None
        return self.nat.discover(timeout_s=timeout_s)

    def classify_nat(self, *, timeout_s: float = 2.0):
        if self.nat is None:
            return None
        return self.nat.classify(timeout_s=timeout_s)

    def detect_vpn_endpoints(
        self,
        *,
        port: int | None = None,
        env=None,
        ip_output: str | None = None,
        command_runner=None,
    ):
        from ..vpn import detect_vpn_endpoints

        bind_port = port
        if bind_port is None and self._transport is not None and hasattr(self._transport, "bind_port"):
            bind_port = int(getattr(self._transport, "bind_port"))
        if bind_port is None:
            raise RuntimeError("detect_vpn_endpoints requires an explicit port or a UDP transport with bind_port")
        return detect_vpn_endpoints(bind_port, env=env, ip_output=ip_output, command_runner=command_runner)

    def publish_with_external_address(
        self,
        extra_endpoints: Optional[list[Endpoint]] = None,
        *,
        stun_timeout_s: float = 2.0,
        auto_refresh: bool = True,
        include_vpn: bool = False,
        vpn_port: int | None = None,
        vpn_env=None,
        vpn_ip_output: str | None = None,
        vpn_command_runner=None,
        **kwargs,
    ) -> LocatorRecord:
        """Publish a fresh record, auto-injecting the STUN-learned
        public endpoint if NAT discovery is enabled.

        If `auto_refresh` is True and we have NAT discovery, we issue
        a Binding Request first to make sure the mapping is current.
        Extra endpoints supplied by the caller (LAN candidates, etc.)
        are appended alongside.
        """
        endpoints: list[Endpoint] = []
        if self.nat is not None:
            mapped: Optional[tuple[str, int]] = None
            if auto_refresh:
                mapped = self.refresh_external_address(timeout_s=stun_timeout_s)
            else:
                mapped = self.nat.last_mapped
            if mapped is not None:
                endpoints.append(
                    Endpoint(
                        type="public_udp",
                        address=f"{mapped[0]}:{mapped[1]}",
                        discovered_by="stun",
                        confidence=0.8,
                        priority=10,
                    )
                )
        if include_vpn:
            try:
                endpoints.extend(
                    self.detect_vpn_endpoints(
                        port=vpn_port,
                        env=vpn_env,
                        ip_output=vpn_ip_output,
                        command_runner=vpn_command_runner,
                    )
                )
            except Exception:
                pass
        if extra_endpoints:
            endpoints.extend(extra_endpoints)
        return self.publish_own_record(endpoints=endpoints, **kwargs)

    # ---------- Phase 3: scheduled republish ----------

    def enable_republish(self, clock, *, interval_s: int = 900) -> None:
        """Schedule periodic re-publication of this node's own record.

        `clock` is any object exposing `.after(delay_s, callback)` —
        typically a `VirtualClock`. Each fire re-signs a fresh record
        (bumping seq) and re-stores it across the k closest peers.

        Called on a real deployment loop this protects against:
          * record expiry during sustained uptime
          * replica churn (fresh nodes learn about us on their next fetch)
          * partition recovery (our next republish after heal refreshes
            the formerly-isolated side)

        Stop by calling `disable_republish()` or by letting the clock's
        timers drain (the timer doesn't self-reschedule after stop).
        """
        self._require_network()
        self._republish_interval_s = int(interval_s)
        self._republish_timer_scheduler = clock
        self._republish_active = True

        def _tick() -> None:
            if not self._republish_active:
                return
            # Re-sign a fresh record using last-known endpoints.
            current = self.own_record()
            if current is not None:
                endpoints = list(current.endpoints)
                try:
                    self.publish_own_record(endpoints=endpoints)
                    self.publish_to_network()
                    self.audit.record(
                        "node.republish_tick",
                        seq=self.own_record().seq if self.own_record() else None,
                    )
                except Exception as e:
                    self.audit.record("node.republish_error", error=str(e))
            # Reschedule.
            if self._republish_active:
                clock.after(self._republish_interval_s, _tick)

        clock.after(self._republish_interval_s, _tick)

    def disable_republish(self) -> None:
        self._republish_active = False
        self._republish_timer_scheduler = None

    def _require_network(self) -> None:
        if self.directory is None:
            raise RuntimeError(
                "This node was constructed without a network; "
                "pass network=InProcessNetwork(...) to Node(...)."
            )

    # ---------- endpoint outcome reporting ----------

    def report_endpoint_failure(self, peer_id: str, address: str) -> None:
        self.cache.mark_endpoint_failed(peer_id, address)

    def report_endpoint_success(self, peer_id: str, address: str) -> None:
        self.cache.mark_endpoint_success(peer_id, address)


# ------------------------------------------------------------------


class _SeqCounter:
    """Persistent monotonic counter, one JSON file on disk.

    We store both the counter and the peer_id we issued against, so
    copying a key to a new machine without also copying seq.json is
    detected and the counter is reset to max(observed_in_cache, file+1).
    The full protection is: we never issue a seq <= the one in our
    own cached record.
    """

    def __init__(self, path: Path) -> None:
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._value = self._load()

    def _load(self) -> int:
        if not self._path.exists():
            return 0
        try:
            data = json.loads(self._path.read_text())
            return int(data.get("seq", 0))
        except Exception:
            return 0

    def _save(self) -> None:
        tmp = self._path.with_suffix(self._path.suffix + ".tmp")
        tmp.write_text(
            json.dumps({"seq": self._value, "updated_at": now_s()}, indent=2)
        )
        os.replace(tmp, self._path)

    def next(self) -> int:
        self._value += 1
        self._save()
        return self._value

    def current(self) -> int:
        return self._value

    def bump_to_at_least(self, v: int) -> None:
        if v > self._value:
            self._value = v
            self._save()
