"""Node configuration.

Encapsulates on-disk layout so other modules don't hard-code paths.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


DEFAULT_ROOT_NAME = ".decentnet"


@dataclass
class NodeConfig:
    root: Path
    keyfile_name: str = "identity.key.json"
    cache_db_name: str = "cache.sqlite3"
    audit_log_name: str = "audit.jsonl"
    seq_file_name: str = "seq.json"
    dht_store_db_name: str = "dht_store.sqlite3"
    rotation_ledger_db_name: str = "rotation_ledger.sqlite3"
    deferred_writes_db_name: str = "deferred.sqlite3"
    snapshot_db_name: str = "snapshots.sqlite3"
    confidence_db_name: str = "confidence.sqlite3"
    reputation_db_name: str = "reputation.sqlite3"
    topic_subscriptions_name: str = "topics.json"

    @classmethod
    def at(cls, root: Optional[str | Path] = None) -> "NodeConfig":
        r = Path(root) if root else Path.home() / DEFAULT_ROOT_NAME
        return cls(root=r)

    @property
    def keyfile(self) -> Path:
        return self.root / self.keyfile_name

    @property
    def cache_db(self) -> Path:
        return self.root / self.cache_db_name

    @property
    def audit_log(self) -> Path:
        return self.root / self.audit_log_name

    @property
    def seq_file(self) -> Path:
        return self.root / self.seq_file_name

    @property
    def dht_store_db(self) -> Path:
        return self.root / self.dht_store_db_name

    @property
    def rotation_ledger_db(self) -> Path:
        return self.root / self.rotation_ledger_db_name

    @property
    def deferred_writes_db(self) -> Path:
        return self.root / self.deferred_writes_db_name

    @property
    def snapshot_db(self) -> Path:
        return self.root / self.snapshot_db_name

    @property
    def confidence_db(self) -> Path:
        return self.root / self.confidence_db_name

    @property
    def reputation_db(self) -> Path:
        return self.root / self.reputation_db_name

    @property
    def topic_subscriptions_file(self) -> Path:
        return self.root / self.topic_subscriptions_name

    def ensure(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
