"""decentnet daemon.

A long-running process wrapping a `Node` with a real `UDPTransport`
and exposing a Unix-domain control socket. Clients send newline-
delimited JSON requests; the daemon replies with newline-delimited
JSON.

Request format:
    {"cmd": "<verb>", ...args}

Supported verbs (non-exhaustive; extend in `_dispatch`):
    status          → node id, peer count, cache stats
    publish         → publish own record with given endpoints
    publish_network → push current record to DHT
    lookup          → L1 lookup for a peer_id
    resolve         → DHT-backed resolution
    peers           → list cached peers
    log             → tail of the audit log
    signaling.hello → initiate handshake
    signaling.ring  → send ring
    signaling.bye   → close session
    snapshot.take   → take a snapshot, return path
    deferred.drain  → drain deferred publish queue
    shutdown        → clean shutdown

Response format:
    {"ok": true, ...} on success
    {"ok": false, "error": "..."} on failure
"""
from __future__ import annotations

import json
import os
import signal
import socket as _sock
import sys
import threading
from pathlib import Path
from typing import Any, Optional

from .utils.time import now_s


def run_daemon(
    *,
    root: Optional[str],
    socket_path: str,
    udp_port: int = 0,
    udp_host: Optional[str] = None,
    config_path: Optional[str] = None,
    metrics_host: Optional[str] = None,
    metrics_port: int = 0,
    log_level: str = "info",
) -> int:
    from .config_file import DecentnetConfig, describe_endpoint_strategy, infer_profile_name, validate_peer_config
    from .log import get_logger, setup_logging
    from .metrics import MetricsRegistry, start_metrics_server
    from .node import Node, NodeConfig
    from .transport.udp import UDPTransport
    from .transport.inproc import InProcessNetwork
    from .signaling.engine import SignalingEngine
    from .records.endpoints import Endpoint
    from .interfaces import detect_lan_endpoints

    # Load file/env config.
    file_cfg = DecentnetConfig.load(config_path)
    setup_logging(log_level)
    log = get_logger("daemon")

    cfg = NodeConfig.at(root or file_cfg.node.root)
    cfg.ensure()

    net = InProcessNetwork()
    node = Node(cfg, network=net)
    effective_udp_host = udp_host or file_cfg.transport.bind_host
    effective_udp_port = udp_port or file_cfg.transport.bind_port or file_cfg.daemon.udp_port
    udp = UDPTransport(node.peer_id.value, bind_host=effective_udp_host, bind_port=effective_udp_port)

    node.signaling = SignalingEngine(
        local_peer_id=node.peer_id.value,
        keypair=node.keypair,
        transport=udp,
        local_cache=node.cache,
        audit=node.audit,
    )

    def _record_bind_validation() -> list[str]:
        warnings: list[str] = []
        own = node.own_record()
        if own is None:
            return warnings
        bind_loopback_only = str(udp.bind_host).startswith("127.") or udp.bind_host == "localhost"
        for ep in own.endpoints:
            host = ep.address.rsplit(":", 1)[0]
            if bind_loopback_only and host not in {"127.0.0.1", "localhost"}:
                warnings.append(
                    f"daemon UDP socket is bound to {udp.bind_host}:{udp.bind_port} but advertised endpoint {ep.address} is non-loopback"
                )
        return warnings

    def _publish_from_config() -> None:
        endpoints: list[Endpoint] = []
        seen: set[tuple[str, str]] = set()

        def _add_endpoint(ep: Endpoint) -> None:
            key = (ep.type, ep.address)
            if key not in seen:
                seen.add(key)
                endpoints.append(ep)

        for item in file_cfg.advertise.manual_endpoints:
            ep_type = str(item.get("type", "public_udp"))
            ep_addr = str(item.get("address", "")).strip()
            if not ep_addr:
                continue
            endpoint_kwargs = {
                "type": ep_type,
                "address": ep_addr,
                "discovered_by": str(item.get("discovered_by", "config")),
                "confidence": float(item.get("confidence", 0.9)),
                "priority": int(item.get("priority", 0)),
            }
            _add_endpoint(Endpoint(**endpoint_kwargs))

        mode = (file_cfg.advertise.mode or "hybrid").strip().lower()
        allow_auto = mode in {"auto", "hybrid", ""}

        if allow_auto and file_cfg.advertise.auto_lan:
            try:
                lan_port = file_cfg.advertise.lan_port or udp.bind_port
                for ep in detect_lan_endpoints(
                    lan_port,
                    allow=file_cfg.interfaces.allow,
                    deny=file_cfg.interfaces.deny,
                ):
                    _add_endpoint(ep)
            except Exception:
                pass

        if allow_auto and not endpoints and file_cfg.advertise.auto_publish:
            if udp.bind_host not in {"0.0.0.0", "::", "127.0.0.1", "localhost"}:
                _add_endpoint(Endpoint(type="lan_udp", address=f"{udp.bind_host}:{udp.bind_port}", discovered_by="bind", confidence=0.7))

        if allow_auto and file_cfg.advertise.auto_vpn:
            try:
                vpn_port = file_cfg.advertise.vpn_port or udp.bind_port
                for ep in node.detect_vpn_endpoints(port=vpn_port):
                    _add_endpoint(ep)
            except Exception:
                pass

        if endpoints:
            node.publish_own_record(
                endpoints=endpoints,
                capabilities=[name for name, enabled in vars(file_cfg.capabilities).items() if enabled],
            )
            node.audit.record("daemon.config_publish", endpoint_count=len(endpoints), mode=mode)

    _publish_from_config()

    # Metrics.
    registry = MetricsRegistry()
    metrics_srv = None
    effective_metrics_host = metrics_host or (
        file_cfg.metrics.host if file_cfg.metrics.enabled else None
    )
    effective_metrics_port = metrics_port or file_cfg.metrics.port
    if effective_metrics_host and effective_metrics_port:
        metrics_srv = start_metrics_server(
            registry,
            effective_metrics_host,
            effective_metrics_port,
            snapshot_cb=lambda: registry.snapshot_from_node(node),
        )
        log.info("metrics_listening", extra={
            "host": metrics_srv.host, "port": metrics_srv.port,
        })

    if os.path.exists(socket_path):
        os.unlink(socket_path)
    server = _sock.socket(_sock.AF_UNIX, _sock.SOCK_STREAM)
    server.bind(socket_path)
    os.chmod(socket_path, 0o600)
    server.listen(4)
    server.settimeout(0.5)

    node.audit.record(
        "daemon.start",
        socket_path=socket_path,
        udp_port=udp.bind_port,
        udp_host=udp.bind_host,
    )
    log.info("daemon_started", extra={
        "peer_id": node.peer_id.value,
        "udp_port": udp.bind_port,
        "socket_path": socket_path,
    })
    print(f"decentnet daemon running")
    print(f"  peer_id:  {node.peer_id}")
    print(f"  udp:      {udp.bind_host}:{udp.bind_port}")
    print(f"  control:  {socket_path}")
    if metrics_srv is not None:
        print(f"  metrics:  http://{metrics_srv.host}:{metrics_srv.port}/metrics")

    shutdown_event = threading.Event()
    reload_event = threading.Event()

    def handle_sig(*_):
        shutdown_event.set()

    def handle_hup(*_):
        reload_event.set()

    signal.signal(signal.SIGINT, handle_sig)
    signal.signal(signal.SIGTERM, handle_sig)
    try:
        signal.signal(signal.SIGHUP, handle_hup)
    except (AttributeError, ValueError):
        pass  # Windows

    def _dispatch(body: dict) -> dict:
        cmd = body.get("cmd")
        try:
            if cmd == "health":
                return {"ok": True, "status": "healthy",
                        "peer_id": node.peer_id.value,
                        "uptime_s": now_s() - registry.started_at}
            if cmd == "metrics":
                registry.snapshot_from_node(node)
                return {"ok": True,
                        "prometheus_text": registry.prometheus_text()}
            if cmd == "reload":
                reload_event.set()
                return {"ok": True, "reloading": True}
            if cmd == "status":
                return {
                    "ok": True,
                    "peer_id": node.peer_id.value,
                    "udp": f"{udp.bind_host}:{udp.bind_port}",
                    "bind_host": udp.bind_host,
                    "bind_port": udp.bind_port,
                    "advertised_endpoints": [e.address for e in (node.own_record().endpoints if node.own_record() is not None else [])],
                    "validation_warnings": _record_bind_validation(),
                    "profile_hint": infer_profile_name(file_cfg),
                    "endpoint_strategy": describe_endpoint_strategy(file_cfg),
                    "config_validation": validate_peer_config(file_cfg),
                    "cache_stats": node.cache.stats(),
                    "deferred_size": node.deferred.size(),
                    "subscribed_topics":
                        sorted(node.topic_policy.subscribed_topics),
                    "replicate_all": node.topic_policy.replicate_all,
                }
            if cmd == "publish":
                from .records.endpoints import Endpoint
                endpoints = [
                    Endpoint(**e) for e in body.get("endpoints", [])
                ]
                rec = node.publish_own_record(endpoints=endpoints)
                return {"ok": True, "seq": rec.seq,
                        "peer_id": rec.peer_id}
            if cmd == "publish_network":
                if node.own_record() is None:
                    _publish_from_config()
                result = node.publish_to_network()
                payload = {"ok": True, **result}
                payload["validation_warnings"] = _record_bind_validation()
                return payload
            if cmd == "lookup":
                rec = node.lookup(body["peer_id"])
                return {
                    "ok": True,
                    "found": rec is not None,
                    "record": rec.to_dict() if rec else None,
                }
            if cmd == "resolve":
                rec = node.resolve(
                    body["peer_id"],
                    force_network=bool(body.get("force_network", True)),
                )
                return {
                    "ok": True,
                    "found": rec is not None,
                    "record": rec.to_dict() if rec else None,
                }
            if cmd == "peers":
                return {
                    "ok": True,
                    "peers": [
                        {"peer_id": r.peer_id, "seq": r.seq,
                         "endpoints": [e.address for e in r.endpoints]}
                        for r, _ in node.cache.entries()
                    ],
                }
            if cmd == "log":
                tail = int(body.get("tail", 50))
                return {"ok": True, "entries": node.audit.tail(tail)}
            if cmd == "signaling.hello":
                r = node.signaling.hello(body["peer_id"])
                return {"ok": r.ok, "reason": r.reason,
                        "state": r.session_state}
            if cmd == "signaling.ring":
                r = node.signaling.ring(
                    body["peer_id"], body=body.get("body", {}),
                )
                return {"ok": r.ok, "reason": r.reason,
                        "state": r.session_state}
            if cmd == "signaling.bye":
                r = node.signaling.bye(body["peer_id"])
                return {"ok": r.ok, "reason": r.reason}
            if cmd == "signaling.peers":
                return {"ok": True, "trusted": node.signaling.trusted_peers(), "sessions": node.signaling.session_summaries()}
            if cmd == "signaling.sessions":
                return {"ok": True, "sessions": node.signaling.session_summaries()}
            if cmd == "snapshot.take":
                snap = node.take_snapshot()
                return {"ok": True,
                        "record_count": snap.record_count,
                        "issued_at": snap.issued_at}
            if cmd == "deferred.drain":
                return {"ok": True, **node.drain_deferred()}
            if cmd == "rotate":
                from .records.endpoints import Endpoint
                endpoints = [
                    Endpoint(**e) for e in body.get("endpoints", [])
                ]
                rec, receipt = node.rotate_identity(endpoints=endpoints)
                return {"ok": True,
                        "new_peer_id": node.peer_id.value,
                        "seq": rec.seq}
            if cmd == "shutdown":
                shutdown_event.set()
                return {"ok": True, "shutting_down": True}
            return {"ok": False, "error": f"unknown command {cmd!r}"}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    def serve():
        while not shutdown_event.is_set():
            try:
                conn, _ = server.accept()
            except _sock.timeout:
                continue
            except OSError:
                break
            try:
                conn.settimeout(5.0)
                data = b""
                while b"\n" not in data:
                    chunk = conn.recv(4096)
                    if not chunk:
                        break
                    data += chunk
                if not data:
                    continue
                try:
                    body = json.loads(data.decode("utf-8").strip())
                except json.JSONDecodeError as e:
                    reply = {"ok": False, "error": f"bad JSON: {e}"}
                else:
                    reply = _dispatch(body)
                conn.sendall((json.dumps(reply) + "\n").encode("utf-8"))
            except Exception:
                pass
            finally:
                try:
                    conn.close()
                except Exception:
                    pass

    thread = threading.Thread(target=serve, daemon=True)
    thread.start()

    try:
        while not shutdown_event.wait(timeout=1.0):
            if reload_event.is_set():
                reload_event.clear()
                try:
                    new_cfg = DecentnetConfig.load(config_path)
                    # Re-apply logging level.
                    from .log import reset_logging_for_tests as _reset
                    _reset()
                    setup_logging(new_cfg.logging.level)
                    # Re-apply node-side policies that can change live.
                    node.topic_policy.set_replicate_all(
                        new_cfg.policies.replicate_all
                    )
                    log.info("reloaded_config", extra={
                        "level": new_cfg.logging.level,
                        "replicate_all": new_cfg.policies.replicate_all,
                    })
                    node.audit.record("daemon.reload")
                except Exception as e:
                    log.warning("reload_failed", extra={"error": str(e)})
    finally:
        node.audit.record("daemon.stop")
        try:
            server.close()
        except Exception:
            pass
        try:
            os.unlink(socket_path)
        except Exception:
            pass
        try:
            udp.close()
        except Exception:
            pass
        if metrics_srv is not None:
            try:
                metrics_srv.close()
            except Exception:
                pass
        node.close()
    return 0
