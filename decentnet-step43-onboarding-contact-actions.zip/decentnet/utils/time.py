"""Time helpers.

All wall-clock times in locator records are UNIX seconds as integers.
We standardize on integers to avoid floating-point surprises inside
canonical serialization.

Virtual clock
-------------
`now_s()` reads from a module-level provider that defaults to the
real system clock. Tests and the Phase 3 simulator can install a
custom provider via `install_clock(fn)` / `reset_clock()` so that
TTLs, record issuance, and cache expiry become deterministic without
monkey-patching individual modules.
"""
from __future__ import annotations

import time as _time
from typing import Callable


_now_fn: Callable[[], float] = _time.time


def now_s() -> int:
    """Current wall-clock time in UNIX seconds (integer)."""
    return int(_now_fn())


def install_clock(fn: Callable[[], float]) -> None:
    """Install a custom clock provider (simulator/tests). Affects every
    module that imports `now_s` — callsites don't need to be updated."""
    global _now_fn
    _now_fn = fn


def reset_clock() -> None:
    """Restore the real system clock."""
    global _now_fn
    _now_fn = _time.time


def monotonic_ms() -> int:
    """Monotonic clock in milliseconds — used for local event ordering only,
    never serialized into signed records."""
    return int(_time.monotonic() * 1000)
