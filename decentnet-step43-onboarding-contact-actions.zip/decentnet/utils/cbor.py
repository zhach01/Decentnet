"""CBOR canonical encoding option (RFC 8949 §4.2.1).

Canonical JSON (Phase 1-6 default) is human-readable and easy to
debug, but verbose. For deployments that care about bytes on the
wire — mesh networks, LoRa/BLE, mobile data caps — this module
provides a parallel CBOR codec that preserves the same value
semantics and canonicalisation rules (sorted map keys, shortest
integer encoding, fixed-width floats).

The codec only runs when version field `"codec": "cbor"` is
explicitly carried in the envelope — it's an opt-in alternative,
never a silent upgrade.

We implement a small subset of CBOR by hand rather than pulling a
dependency:
    major type 0 (unsigned int)
    major type 1 (negative int)
    major type 2 (byte string)
    major type 3 (text string)
    major type 4 (array)
    major type 5 (map)
    major type 7: true, false, null, float64

Canonicalisation:
    * integers use shortest representation
    * map keys are sorted byte-wise
    * floats always encoded as 8-byte IEEE 754 (we don't encode NaN
      or special values in records)
"""
from __future__ import annotations

import struct
from typing import Any


# ---- encoding ------------------------------------------------------


def _encode_head(major: int, value: int) -> bytes:
    if value < 0:
        raise ValueError("negative argument to head")
    if value < 24:
        return bytes([(major << 5) | value])
    if value < 0x100:
        return bytes([(major << 5) | 24, value])
    if value < 0x10000:
        return bytes([(major << 5) | 25]) + struct.pack(">H", value)
    if value < 0x100000000:
        return bytes([(major << 5) | 26]) + struct.pack(">I", value)
    return bytes([(major << 5) | 27]) + struct.pack(">Q", value)


def canonical_cbor(value: Any) -> bytes:
    if value is None:
        return bytes([0xF6])
    if value is True:
        return bytes([0xF5])
    if value is False:
        return bytes([0xF4])
    if isinstance(value, int) and not isinstance(value, bool):
        if value >= 0:
            return _encode_head(0, value)
        return _encode_head(1, -1 - value)
    if isinstance(value, float):
        return bytes([0xFB]) + struct.pack(">d", value)
    if isinstance(value, (bytes, bytearray)):
        data = bytes(value)
        return _encode_head(2, len(data)) + data
    if isinstance(value, str):
        data = value.encode("utf-8")
        return _encode_head(3, len(data)) + data
    if isinstance(value, list):
        out = _encode_head(4, len(value))
        for item in value:
            out += canonical_cbor(item)
        return out
    if isinstance(value, tuple):
        return canonical_cbor(list(value))
    if isinstance(value, dict):
        # Sort keys byte-wise after encoding.
        pairs = []
        for k, v in value.items():
            ek = canonical_cbor(k)
            ev = canonical_cbor(v)
            pairs.append((ek, ev))
        pairs.sort(key=lambda p: p[0])
        out = _encode_head(5, len(pairs))
        for k, v in pairs:
            out += k + v
        return out
    raise TypeError(f"unsupported CBOR type: {type(value).__name__}")


# ---- decoding ------------------------------------------------------


class _CborReader:
    def __init__(self, data: bytes) -> None:
        self.data = data
        self.pos = 0

    def _read(self, n: int) -> bytes:
        if self.pos + n > len(self.data):
            raise ValueError("truncated CBOR input")
        out = self.data[self.pos:self.pos + n]
        self.pos += n
        return out

    def _read_head(self) -> tuple[int, int, bool]:
        """Return (major, info, has_payload). For major 7 floats, the
        head is only 1 byte and the float payload follows separately."""
        b = self._read(1)[0]
        major = b >> 5
        info = b & 0x1F
        # Major type 7 with info 25/26/27 indicates half/single/double
        # float following — we only decode 27 (double).
        if major == 7 and info in (25, 26, 27):
            return major, info, True
        if info < 24:
            return major, info, False
        if info == 24:
            return major, self._read(1)[0], False
        if info == 25:
            import struct as _s
            return major, _s.unpack(">H", self._read(2))[0], False
        if info == 26:
            import struct as _s
            return major, _s.unpack(">I", self._read(4))[0], False
        if info == 27:
            import struct as _s
            return major, _s.unpack(">Q", self._read(8))[0], False
        raise ValueError(f"indefinite-length CBOR not supported (info={info})")

    def read_value(self) -> Any:
        major, arg, float_marker = self._read_head()
        if major == 0:
            return arg
        if major == 1:
            return -1 - arg
        if major == 2:
            return bytes(self._read(arg))
        if major == 3:
            return self._read(arg).decode("utf-8")
        if major == 4:
            return [self.read_value() for _ in range(arg)]
        if major == 5:
            out: dict = {}
            for _ in range(arg):
                k = self.read_value()
                v = self.read_value()
                out[k] = v
            return out
        if major == 7:
            if float_marker:
                if arg == 27:
                    return struct.unpack(">d", self._read(8))[0]
                raise ValueError(f"unsupported float info {arg}")
            if arg == 20:
                return False
            if arg == 21:
                return True
            if arg == 22:
                return None
            raise ValueError(f"unsupported simple value {arg}")
        raise ValueError(f"unknown CBOR major type {major}")


def decode_cbor(data: bytes) -> Any:
    reader = _CborReader(data)
    return reader.read_value()


# ---- record codec wrapper -----------------------------------------


def encode_record_cbor(record_dict: dict) -> bytes:
    """Encode a LocatorRecord dict to canonical CBOR."""
    return canonical_cbor(record_dict)


def decode_record_cbor(data: bytes) -> dict:
    out = decode_cbor(data)
    if not isinstance(out, dict):
        raise ValueError("expected CBOR map at record root")
    return out
