"""Binary encoding helpers.

Design choices for Phase 1
--------------------------
* **Peer IDs** use unpadded lowercase base32 (RFC 4648). This is
  URL- and filesystem-safe and easy to read aloud.
* **Binary fields inside records** (public key, signature) use unpadded
  base64url so canonical JSON stays ASCII.
* **Record canonicalization** uses JSON with sorted keys, no whitespace,
  and NFC-normalized strings. This is sufficient for deterministic
  signing at the Phase 1 level. CBOR deterministic encoding (RFC 8949
  §4.2) is the preferred future wire format and the serialization
  module is structured so it can be swapped in without touching
  callers.
"""
from __future__ import annotations

import base64
import json
import unicodedata
from typing import Any


# ---------------- base32 (peer IDs) ----------------


def b32encode_nopad(data: bytes) -> str:
    return base64.b32encode(data).decode("ascii").rstrip("=").lower()


def b32decode_nopad(s: str) -> bytes:
    s = s.upper()
    pad = (-len(s)) % 8
    return base64.b32decode(s + "=" * pad)


# ---------------- base64url (binary in records) ----------------


def b64u_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def b64u_decode(s: str) -> bytes:
    pad = (-len(s)) % 4
    return base64.urlsafe_b64decode(s + "=" * pad)


# ---------------- canonical JSON ----------------


def canonical_json_bytes(obj: Any) -> bytes:
    """Deterministic JSON encoding used as the signing input.

    * sorted keys, recursively
    * no whitespace
    * ensure_ascii=False (UTF-8 on the wire)
    * strings are NFC-normalized before encoding so the same
      "apparent" string always produces the same bytes
    """
    return json.dumps(
        _normalize(obj),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def _normalize(obj: Any) -> Any:
    if isinstance(obj, str):
        return unicodedata.normalize("NFC", obj)
    if isinstance(obj, dict):
        return {_normalize(k): _normalize(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_normalize(v) for v in obj]
    if isinstance(obj, tuple):
        return [_normalize(v) for v in obj]
    return obj
