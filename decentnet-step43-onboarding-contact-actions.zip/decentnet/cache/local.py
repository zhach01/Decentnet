"""L1 local cache.

Responsibilities:
    * validate incoming LocatorRecords (signature, TTL, seq monotonicity)
    * reject stale/replayed/rolled-back records
    * persist accepted records
    * track access popularity for eviction
    * maintain a negative cache for failed endpoints
    * emit audit events for every non-trivial decision

What this layer does NOT do (yet):
    * network I/O
    * pulling records from a global directory
    * key rotation acceptance (the current rule: same peer_id implies
      same public_key; a rotation would change the peer_id)

The cache is intentionally synchronous and thread-safe via SQLite's
connection lock. For higher concurrency we'd move to asyncio and
per-peer coalesced lookups — a Phase 2+ concern.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from ..audit.log import AuditLog
from ..identity.ledger import RotationLedger
from ..identity.rotation import RotationReceipt
from ..records.locator import LocatorRecord, record_is_newer
from ..records.validation import (
    DEFAULT_MAX_FUTURE_SKEW_S,
    validate_for_storage,
)
from ..utils.time import now_s
from .storage import CacheStorage


# Default cap on retained records before popularity eviction kicks in.
DEFAULT_MAX_RECORDS = 10_000


@dataclass
class PutResult:
    """Outcome of LocalCache.put()."""

    accepted: bool
    reason: Optional[str] = None
    previous_seq: Optional[int] = None
    new_seq: Optional[int] = None


class LocalCache:
    def __init__(
        self,
        db_path: str | Path | None,
        audit: Optional[AuditLog] = None,
        *,
        max_records: int = DEFAULT_MAX_RECORDS,
        max_future_skew_s: int = DEFAULT_MAX_FUTURE_SKEW_S,
        rotation_ledger: Optional[RotationLedger] = None,
        on_accept: Optional[
            "Callable[[LocatorRecord, str], None]"
        ] = None,
    ) -> None:
        self._store = CacheStorage(db_path)
        self._audit = audit or AuditLog(None)
        self._max_records = max_records
        self._max_future_skew_s = max_future_skew_s
        self._rot_ledger = rotation_ledger
        self._on_accept = on_accept

    def close(self) -> None:
        self._store.close()

    # ---------- writes ----------

    def put(
        self, record: LocatorRecord, *, source: str = "imported"
    ) -> PutResult:
        """Validate and insert a record. Returns a PutResult with reason on reject.

        Delegates to the shared `validate_for_storage` pipeline so the
        DHT store applies identical rules.
        """
        existing_row = self._store.get_record(record.peer_id)
        existing_rec: Optional[LocatorRecord] = None
        previous_seq: Optional[int] = None
        if existing_row is not None:
            existing_rec = LocatorRecord.from_wire_bytes(
                existing_row["record_json"].encode("utf-8")
            )
            previous_seq = existing_rec.seq

        result = validate_for_storage(
            record,
            existing=existing_rec,
            max_future_skew_s=self._max_future_skew_s,
        )
        if not result.ok:
            self._audit.record(
                "cache.reject",
                peer_id=record.peer_id,
                reason=result.reason,
                source=source,
                **(
                    {"existing_seq": existing_rec.seq,
                     "candidate_seq": record.seq}
                    if existing_rec is not None and result.reason == "not_newer"
                    else {}
                ),
            )
            return PutResult(
                False,
                reason=result.reason,
                previous_seq=previous_seq,
                new_seq=record.seq if result.reason == "not_newer" else None,
            )

        self._store.upsert_record(
            peer_id=record.peer_id,
            record_json=record.to_wire_bytes().decode("utf-8"),
            seq=record.seq,
            issued_at=record.issued_at,
            expires_at=record.expires_at,
            soft_expires_at=record.soft_expires_at,
            source=source,
            inserted_at=now_s(),
        )
        # If this is a rotation, record the forwarding mapping.
        if result.rotation_accepted and self._rot_ledger is not None and record.prev_key_rotation:
            try:
                receipt = RotationReceipt.from_dict(record.prev_key_rotation)
                self._rot_ledger.record_rotation(receipt)
                self._audit.record(
                    "cache.rotation_accepted",
                    old_peer_id=receipt.prev_peer_id,
                    new_peer_id=receipt.new_peer_id,
                )
            except Exception as e:
                self._audit.record(
                    "cache.rotation_record_failed", error=str(e)
                )
        self._audit.record(
            "cache.put",
            peer_id=record.peer_id,
            seq=record.seq,
            source=source,
            endpoints=[e.address for e in record.endpoints],
        )
        if self._on_accept is not None:
            try:
                self._on_accept(record, source)
            except Exception:
                pass

        # Enforce cap.
        evicted = self._store.evict_least_popular(self._max_records)
        if evicted:
            self._audit.record("cache.evict", count=evicted)

        return PutResult(
            True, previous_seq=previous_seq, new_seq=record.seq
        )

    # ---------- reads ----------

    def get(self, peer_id: str) -> Optional[LocatorRecord]:
        """Return the cached record or None. Drops hard-expired entries."""
        row = self._store.get_record(peer_id)
        if row is None:
            return None
        if row["expires_at"] <= now_s():
            self._store.delete_record(peer_id)
            self._audit.record(
                "cache.expire", peer_id=peer_id, expires_at=row["expires_at"]
            )
            return None
        self._store.touch_access(peer_id, now_s())
        return LocatorRecord.from_wire_bytes(
            row["record_json"].encode("utf-8")
        )

    def peek(self, peer_id: str) -> Optional[LocatorRecord]:
        """Like get() but does not update access counters (for debugging/UI)."""
        row = self._store.get_record(peer_id)
        if row is None:
            return None
        return LocatorRecord.from_wire_bytes(
            row["record_json"].encode("utf-8")
        )

    def all_peers(self) -> list[str]:
        return [row["peer_id"] for row in self._store.all_records()]

    def entries(self) -> list[tuple[LocatorRecord, dict]]:
        """Return (record, metadata) pairs for all cached peers."""
        out: list[tuple[LocatorRecord, dict]] = []
        for row in self._store.all_records():
            rec = LocatorRecord.from_wire_bytes(
                row["record_json"].encode("utf-8")
            )
            meta = {
                "source": row["source"],
                "inserted_at": row["inserted_at"],
                "last_accessed": row["last_accessed"],
                "access_count": row["access_count"],
            }
            out.append((rec, meta))
        return out

    # ---------- negative cache ----------

    def mark_endpoint_failed(self, peer_id: str, address: str) -> None:
        self._store.record_endpoint_failure(peer_id, address, now_s())
        self._audit.record(
            "negcache.fail", peer_id=peer_id, endpoint=address
        )

    def mark_endpoint_success(self, peer_id: str, address: str) -> None:
        self._store.clear_endpoint_failure(peer_id, address)
        self._audit.record(
            "negcache.clear", peer_id=peer_id, endpoint=address
        )

    def failed_endpoints(self, peer_id: str) -> dict[str, dict]:
        out: dict[str, dict] = {}
        for row in self._store.failed_endpoints(peer_id):
            out[row["endpoint_address"]] = {
                "last_failure": row["last_failure"],
                "failure_count": row["failure_count"],
            }
        return out

    # ---------- maintenance ----------

    def gc(self) -> dict[str, int]:
        """Delete hard-expired records. Returns counts."""
        n = self._store.delete_expired(now_s())
        if n:
            self._audit.record("cache.gc", removed=n)
        return {"removed": n}

    def stats(self) -> dict:
        base = self._store.counts()
        base["max_records"] = self._max_records
        return base
