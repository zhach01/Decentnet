"""Multi-source confidence tracking.

For every (peer_id, source_label) we've seen for a record, remember
when we saw it. The confidence score for a peer_id is a function of:

    * number of distinct sources that have corroborated the same
      (seq, issued_at)
    * recency of the most recent corroboration
    * whether at least one direct connection has succeeded (from the
      negative-cache reverse — if `last_success` is set on any
      cached endpoint we treat the peer as ground-truth confirmed)

Persistence: a tiny SQLite table next to the cache.
"""
from __future__ import annotations

import sqlite3
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from ..utils.time import now_s


# Confidence weights — chosen so a single source caps at 0.5 and
# a third corroboration crosses 0.9. Tunable later.
SCORE_BASE_PER_SOURCE = 0.35
SCORE_RECENCY_HALFLIFE_S = 3600
SCORE_MAX = 0.99


@dataclass
class Observation:
    peer_id: str
    source: str        # opaque label: "self", "imported", "dht:<peerid>", ...
    seq: int
    issued_at: int
    observed_at: int


class ConfidenceTracker:
    def __init__(self, db_path: Path | str | None) -> None:
        if db_path is None:
            self._conn = sqlite3.connect(":memory:", check_same_thread=False)
        else:
            p = Path(db_path)
            p.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(p), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        with self._lock, self._conn:
            self._conn.executescript("""
                CREATE TABLE IF NOT EXISTS observations (
                    peer_id TEXT NOT NULL,
                    source TEXT NOT NULL,
                    seq INTEGER NOT NULL,
                    issued_at INTEGER NOT NULL,
                    observed_at INTEGER NOT NULL,
                    PRIMARY KEY (peer_id, source)
                );
                CREATE INDEX IF NOT EXISTS idx_obs_peer ON observations(peer_id);
            """)

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    # ---- mutations ----

    def record(
        self,
        peer_id: str,
        source: str,
        seq: int,
        issued_at: int,
    ) -> None:
        t = now_s()
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT INTO observations
                   (peer_id, source, seq, issued_at, observed_at)
                   VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT(peer_id, source) DO UPDATE SET
                     seq = max(observations.seq, excluded.seq),
                     issued_at = max(observations.issued_at, excluded.issued_at),
                     observed_at = excluded.observed_at""",
                (peer_id, source, seq, issued_at, t),
            )

    # ---- queries ----

    def sources_for(self, peer_id: str) -> list[Observation]:
        with self._lock, self._conn:
            rows = self._conn.execute(
                "SELECT * FROM observations WHERE peer_id = ?",
                (peer_id,),
            ).fetchall()
        return [
            Observation(
                peer_id=r["peer_id"], source=r["source"],
                seq=r["seq"], issued_at=r["issued_at"],
                observed_at=r["observed_at"],
            )
            for r in rows
        ]

    def confidence(
        self,
        peer_id: str,
        *,
        current_seq: Optional[int] = None,
    ) -> float:
        """Score in [0,1]. If `current_seq` is given, only sources
        that corroborate that seq count toward the score."""
        sources = self.sources_for(peer_id)
        if current_seq is not None:
            sources = [s for s in sources if s.seq == current_seq]
        if not sources:
            return 0.0
        t = now_s()
        score = 0.0
        for s in sources:
            age = max(0, t - s.observed_at)
            recency = 0.5 ** (age / SCORE_RECENCY_HALFLIFE_S)
            score += SCORE_BASE_PER_SOURCE * recency
        return min(SCORE_MAX, score)

    def gc_stale(self, *, older_than_s: int = 86400 * 7) -> int:
        cutoff = now_s() - older_than_s
        with self._lock, self._conn:
            cur = self._conn.execute(
                "DELETE FROM observations WHERE observed_at < ?", (cutoff,),
            )
            return cur.rowcount or 0
