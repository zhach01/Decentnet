"""SQLite-backed persistent storage for cache entries.

We use SQLite because it ships with Python, gives us transactional
durability for free, and supports the handful of indexed queries we
need without an ORM.

Schema (v1)
-----------
locator_records
    peer_id TEXT PRIMARY KEY
    record_json TEXT NOT NULL         -- canonical wire JSON
    seq INTEGER NOT NULL
    issued_at INTEGER NOT NULL
    expires_at INTEGER NOT NULL
    soft_expires_at INTEGER NOT NULL
    source TEXT NOT NULL              -- "self" | "imported" | "peer:<id>" | ...
    inserted_at INTEGER NOT NULL
    last_accessed INTEGER NOT NULL
    access_count INTEGER NOT NULL DEFAULT 0

negative_endpoints
    peer_id TEXT NOT NULL
    endpoint_address TEXT NOT NULL
    last_failure INTEGER NOT NULL
    failure_count INTEGER NOT NULL DEFAULT 1
    PRIMARY KEY (peer_id, endpoint_address)

meta
    key TEXT PRIMARY KEY
    value TEXT NOT NULL
"""
from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path
from typing import Any, Iterable, Optional


SCHEMA_VERSION = 1


class CacheStorage:
    def __init__(self, path: str | Path | None) -> None:
        """`path=None` selects an in-memory database (useful for tests)."""
        if path is None:
            self._conn = sqlite3.connect(":memory:", check_same_thread=False)
        else:
            p = Path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(p), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        self._init_schema()

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    # ---------- schema ----------

    def _init_schema(self) -> None:
        with self._lock, self._conn:
            self._conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS locator_records (
                    peer_id TEXT PRIMARY KEY,
                    record_json TEXT NOT NULL,
                    seq INTEGER NOT NULL,
                    issued_at INTEGER NOT NULL,
                    expires_at INTEGER NOT NULL,
                    soft_expires_at INTEGER NOT NULL,
                    source TEXT NOT NULL,
                    inserted_at INTEGER NOT NULL,
                    last_accessed INTEGER NOT NULL,
                    access_count INTEGER NOT NULL DEFAULT 0
                );
                CREATE INDEX IF NOT EXISTS idx_records_expires
                    ON locator_records(expires_at);
                CREATE INDEX IF NOT EXISTS idx_records_popularity
                    ON locator_records(access_count, last_accessed);

                CREATE TABLE IF NOT EXISTS negative_endpoints (
                    peer_id TEXT NOT NULL,
                    endpoint_address TEXT NOT NULL,
                    last_failure INTEGER NOT NULL,
                    failure_count INTEGER NOT NULL DEFAULT 1,
                    PRIMARY KEY (peer_id, endpoint_address)
                );

                CREATE TABLE IF NOT EXISTS meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                """
            )
            cur = self._conn.execute(
                "SELECT value FROM meta WHERE key='schema_version'"
            )
            row = cur.fetchone()
            if row is None:
                self._conn.execute(
                    "INSERT INTO meta(key,value) VALUES('schema_version',?)",
                    (str(SCHEMA_VERSION),),
                )
            else:
                existing = int(row["value"])
                if existing != SCHEMA_VERSION:
                    raise RuntimeError(
                        f"cache schema version mismatch: "
                        f"got {existing}, expected {SCHEMA_VERSION}"
                    )

    # ---------- records ----------

    def upsert_record(
        self,
        peer_id: str,
        record_json: str,
        seq: int,
        issued_at: int,
        expires_at: int,
        soft_expires_at: int,
        source: str,
        inserted_at: int,
    ) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                """
                INSERT INTO locator_records
                    (peer_id, record_json, seq, issued_at, expires_at,
                     soft_expires_at, source, inserted_at, last_accessed,
                     access_count)
                VALUES (?,?,?,?,?,?,?,?,?, 0)
                ON CONFLICT(peer_id) DO UPDATE SET
                    record_json = excluded.record_json,
                    seq = excluded.seq,
                    issued_at = excluded.issued_at,
                    expires_at = excluded.expires_at,
                    soft_expires_at = excluded.soft_expires_at,
                    source = excluded.source,
                    inserted_at = excluded.inserted_at
                """,
                (
                    peer_id,
                    record_json,
                    seq,
                    issued_at,
                    expires_at,
                    soft_expires_at,
                    source,
                    inserted_at,
                    inserted_at,
                ),
            )

    def get_record(self, peer_id: str) -> Optional[sqlite3.Row]:
        with self._lock, self._conn:
            cur = self._conn.execute(
                "SELECT * FROM locator_records WHERE peer_id = ?", (peer_id,)
            )
            return cur.fetchone()

    def touch_access(self, peer_id: str, when: int) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                """UPDATE locator_records
                   SET access_count = access_count + 1,
                       last_accessed = ?
                   WHERE peer_id = ?""",
                (when, peer_id),
            )

    def all_records(self) -> list[sqlite3.Row]:
        with self._lock, self._conn:
            cur = self._conn.execute(
                "SELECT * FROM locator_records ORDER BY peer_id"
            )
            return list(cur.fetchall())

    def delete_record(self, peer_id: str) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "DELETE FROM locator_records WHERE peer_id = ?", (peer_id,)
            )

    def delete_expired(self, at: int) -> int:
        with self._lock, self._conn:
            cur = self._conn.execute(
                "DELETE FROM locator_records WHERE expires_at <= ?", (at,)
            )
            return cur.rowcount or 0

    def evict_least_popular(self, keep: int) -> int:
        """Remove entries beyond `keep`, chosen by least access_count then
        oldest last_accessed. Returns number of rows deleted."""
        with self._lock, self._conn:
            cur = self._conn.execute(
                "SELECT COUNT(*) AS n FROM locator_records"
            )
            n = cur.fetchone()["n"]
            if n <= keep:
                return 0
            cur = self._conn.execute(
                """DELETE FROM locator_records
                   WHERE peer_id IN (
                     SELECT peer_id FROM locator_records
                     ORDER BY access_count ASC, last_accessed ASC
                     LIMIT ?
                   )""",
                (n - keep,),
            )
            return cur.rowcount or 0

    # ---------- negative cache ----------

    def record_endpoint_failure(
        self, peer_id: str, endpoint_address: str, when: int
    ) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                """
                INSERT INTO negative_endpoints
                    (peer_id, endpoint_address, last_failure, failure_count)
                VALUES (?, ?, ?, 1)
                ON CONFLICT(peer_id, endpoint_address) DO UPDATE SET
                    last_failure = excluded.last_failure,
                    failure_count = failure_count + 1
                """,
                (peer_id, endpoint_address, when),
            )

    def clear_endpoint_failure(
        self, peer_id: str, endpoint_address: str
    ) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                """DELETE FROM negative_endpoints
                   WHERE peer_id = ? AND endpoint_address = ?""",
                (peer_id, endpoint_address),
            )

    def failed_endpoints(self, peer_id: str) -> list[sqlite3.Row]:
        with self._lock, self._conn:
            cur = self._conn.execute(
                """SELECT * FROM negative_endpoints
                   WHERE peer_id = ?""",
                (peer_id,),
            )
            return list(cur.fetchall())

    # ---------- stats ----------

    def counts(self) -> dict[str, int]:
        with self._lock, self._conn:
            cur = self._conn.execute(
                "SELECT COUNT(*) AS n FROM locator_records"
            )
            records = cur.fetchone()["n"]
            cur = self._conn.execute(
                "SELECT COUNT(*) AS n FROM negative_endpoints"
            )
            negatives = cur.fetchone()["n"]
        return {"records": records, "negative_endpoints": negatives}
