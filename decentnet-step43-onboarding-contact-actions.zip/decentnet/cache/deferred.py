"""Deferred-write buffer.

When publishing or DHT-storing fails (offline, transient
unreachable), we queue the record locally. On the next opportunity
the queue is drained and each record is retried.

Persisted in SQLite so we don't lose pending publishes across
restarts.

Schema:
    deferred (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kind TEXT NOT NULL,                  -- 'publish' | 'store_remote'
        target TEXT,                         -- peer_id or null
        record_json TEXT NOT NULL,
        queued_at INTEGER NOT NULL,
        attempts INTEGER NOT NULL DEFAULT 0,
        last_attempt_at INTEGER
    )
"""
from __future__ import annotations

import sqlite3
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from ..utils.time import now_s


@dataclass
class DeferredItem:
    id: int
    kind: str
    target: Optional[str]
    record_json: str
    queued_at: int
    attempts: int
    last_attempt_at: Optional[int]


class DeferredWriteBuffer:
    def __init__(self, db_path: Path | str | None) -> None:
        if db_path is None:
            self._conn = sqlite3.connect(":memory:", check_same_thread=False)
        else:
            p = Path(db_path)
            p.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(p), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        with self._lock, self._conn:
            self._conn.executescript("""
                CREATE TABLE IF NOT EXISTS deferred (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    kind TEXT NOT NULL,
                    target TEXT,
                    record_json TEXT NOT NULL,
                    queued_at INTEGER NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    last_attempt_at INTEGER
                );
            """)

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    # ---- writes ----

    def enqueue(
        self, kind: str, record_json: str, *,
        target: Optional[str] = None,
    ) -> int:
        with self._lock, self._conn:
            cur = self._conn.execute(
                """INSERT INTO deferred
                   (kind, target, record_json, queued_at)
                   VALUES (?, ?, ?, ?)""",
                (kind, target, record_json, now_s()),
            )
            return cur.lastrowid

    def remove(self, item_id: int) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "DELETE FROM deferred WHERE id = ?", (item_id,),
            )

    def mark_attempt(self, item_id: int) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                """UPDATE deferred
                   SET attempts = attempts + 1, last_attempt_at = ?
                   WHERE id = ?""",
                (now_s(), item_id),
            )

    # ---- reads ----

    def items(self, *, limit: Optional[int] = None) -> list[DeferredItem]:
        with self._lock, self._conn:
            sql = "SELECT * FROM deferred ORDER BY queued_at"
            params: tuple = ()
            if limit is not None:
                sql += " LIMIT ?"
                params = (int(limit),)
            rows = self._conn.execute(sql, params).fetchall()
        return [
            DeferredItem(
                id=r["id"], kind=r["kind"], target=r["target"],
                record_json=r["record_json"], queued_at=r["queued_at"],
                attempts=r["attempts"], last_attempt_at=r["last_attempt_at"],
            )
            for r in rows
        ]

    def size(self) -> int:
        with self._lock, self._conn:
            row = self._conn.execute(
                "SELECT COUNT(*) AS n FROM deferred"
            ).fetchone()
        return row["n"]

    # ---- drain ----

    def drain(
        self, attempt_fn: Callable[[DeferredItem], bool],
    ) -> dict:
        """Walk pending items in order; for each, call `attempt_fn`.
        If it returns True, item is removed; else `attempts` is bumped
        and item stays for next drain.
        Returns {"drained": int, "remaining": int, "attempted": int}.
        """
        attempted = 0
        drained = 0
        for item in self.items():
            attempted += 1
            try:
                ok = bool(attempt_fn(item))
            except Exception:
                ok = False
            if ok:
                self.remove(item.id)
                drained += 1
            else:
                self.mark_attempt(item.id)
        return {
            "drained": drained,
            "attempted": attempted,
            "remaining": self.size(),
        }
