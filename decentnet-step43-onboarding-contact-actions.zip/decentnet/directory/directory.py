"""Directory — the L3 facade a Node uses.

Wires together routing table, DHT storage, DHT engine, and anti-entropy
into one object with a small, stable surface:

    join(seeds)       -- bootstrap by PINGing seeds and populating RT
    publish(record)   -- STORE the record at the k closest nodes
    resolve(peer_id)  -- iterative FIND_VALUE, quorum-merged
    sync_with(peer)   -- one-shot anti-entropy exchange
    shutdown()

Receive routing:
    * Anti-entropy messages (DIGEST_*, RECORD_PUSH) are funnelled to
      AntiEntropy.handle_message.
    * Everything else is handled by the DHTEngine (it was installed as
      the transport's receive handler; we wrap it so repair gets first
      dibs on its own message types).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable, Optional

from ..audit.log import AuditLog
from ..dht.node import DHTEngine, LookupResult
from ..dht.routing import RoutingTable, DEFAULT_K
from ..dht.storage import DHTStore
from ..records.locator import LocatorRecord
from ..repair.antientropy import AntiEntropy, SyncResult
from ..transport.base import Transport
from ..transport.messages import Message, MsgType, TransportError


class Directory:
    def __init__(
        self,
        *,
        self_peer_id: str,
        transport: Transport,
        audit: AuditLog,
        k: int = DEFAULT_K,
        local_cache_observer: Optional[Callable[[LocatorRecord, str], None]] = None,
        dht_persist_path: Optional[str] = None,
        topic_policy=None,
        reputation=None,
    ) -> None:
        self.routing = RoutingTable(self_peer_id, k=k)
        self.store = DHTStore(
            persist_path=dht_persist_path,
            topic_policy=topic_policy,
        )
        self._audit = audit
        self._transport = transport
        self._self_id = self_peer_id
        self._observer = local_cache_observer

        # AntiEntropy installed first so it can claim its messages.
        self.repair = AntiEntropy(
            self_peer_id=self_peer_id,
            store=self.store,
            transport=transport,
            audit=audit,
        )
        self.engine = DHTEngine(
            routing_table=self.routing,
            store=self.store,
            transport=transport,
            audit=audit,
            local_cache_observer=local_cache_observer,
            k=k,
            reputation=reputation,
        )
        # Wrap the transport's receive handler so anti-entropy gets first
        # look at its message types.
        engine_handler = transport  # type: ignore[assignment]  # just for typing
        self._install_router()

    def _install_router(self) -> None:
        engine_on_message = self.engine._on_message  # noqa: SLF001

        def router(from_peer: str, msg: Message) -> None:
            self.routing.observe(from_peer)
            if self.repair.handle_message(from_peer, msg):
                return
            engine_on_message(from_peer, msg)

        self._transport.set_receive_handler(router)

    # ---------- lifecycle ----------

    def join(self, seeds: Iterable[tuple[str, str]]) -> int:
        """PING each seed; on success, insert into routing table. Then
        run a FIND_NODE on our own ID to populate nearby buckets.

        `seeds` is a list of `(peer_id, endpoint_hint)`; endpoint_hint
        is opaque to the in-process transport.
        """
        reachable = 0
        for pid, endpoint in seeds:
            ping = Message.make(MsgType.PING, sender=self._self_id)
            try:
                reply = self._transport.send_and_wait(pid, ping)
                if reply.type == MsgType.PONG.value:
                    self.routing.observe(pid, endpoint)
                    reachable += 1
            except TransportError:
                continue
        # Seed further by discovering our own neighborhood.
        if reachable > 0:
            self.engine.find_node(self._self_id)
        self._audit.record(
            "directory.join",
            reachable_seeds=reachable,
            rt_size=self.routing.size(),
        )
        return reachable

    def publish(self, record: LocatorRecord) -> dict:
        return self.engine.store_on_network(record)

    def resolve(self, peer_id: str) -> LookupResult:
        return self.engine.find_value(peer_id)

    def sync_with(self, peer_id: str) -> SyncResult:
        return self.repair.sync_with(peer_id)

    def shutdown(self) -> None:
        try:
            self.store.close()
        except Exception:
            pass
        self._audit.record("directory.shutdown")
