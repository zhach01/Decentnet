"""Signed bootstrap manifest.

A bootstrap manifest is a small, signed file listing the seed peers
a new node can contact to join the network. The manifest is signed
by a well-known key held by whoever publishes it; by checking the
signature, a new node verifies the seed list hasn't been tampered
with in transit.

The list itself is rotating: a bootstrap publisher re-signs a new
manifest as seeds change. Nodes can cache the manifest and refresh
from any of several URLs or distribution channels.

Note: there is no way around needing *some* rendezvous bootstrap in
a wide-area decentralized network. The goal is to make that bootstrap
(a) replaceable, (b) checkable, and (c) minimal — it hands out a list
of seed peers and nothing else.

This module only defines the data format and sign/verify helpers.
Distribution is left to the operator.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Optional

from ..identity.keypair import Keypair, verify_with_public_key
from ..utils.encoding import b64u_decode, b64u_encode, canonical_json_bytes
from ..utils.time import now_s


MANIFEST_VERSION = 1


@dataclass
class BootstrapSeed:
    peer_id: str
    endpoints: list[dict[str, Any]]    # same shape as LocatorRecord endpoints

    def to_dict(self) -> dict[str, Any]:
        return {"peer_id": self.peer_id, "endpoints": list(self.endpoints)}

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "BootstrapSeed":
        return cls(peer_id=d["peer_id"], endpoints=list(d.get("endpoints", [])))


@dataclass
class BootstrapManifest:
    version: int
    issued_at: int
    expires_at: int
    publisher_public_key: bytes     # raw 32-byte Ed25519
    seeds: list[BootstrapSeed] = field(default_factory=list)
    signature: Optional[bytes] = None

    # ---- build / sign ----

    @classmethod
    def build_and_sign(
        cls,
        publisher: Keypair,
        seeds: list[BootstrapSeed],
        *,
        ttl_s: int = 86400,
        issued_at: Optional[int] = None,
    ) -> "BootstrapManifest":
        t = issued_at if issued_at is not None else now_s()
        m = cls(
            version=MANIFEST_VERSION,
            issued_at=t,
            expires_at=t + ttl_s,
            publisher_public_key=publisher.public_key_bytes,
            seeds=list(seeds),
        )
        m.signature = publisher.sign(m._signing_input())
        return m

    def _signing_input(self) -> bytes:
        return canonical_json_bytes(self._to_dict_nosig())

    def _to_dict_nosig(self) -> dict[str, Any]:
        return {
            "version": self.version,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
            "publisher_public_key": b64u_encode(self.publisher_public_key),
            "seeds": [s.to_dict() for s in self.seeds],
        }

    # ---- serialization ----

    def to_bytes(self) -> bytes:
        assert self.signature is not None, "manifest not signed"
        d = self._to_dict_nosig()
        d["signature"] = b64u_encode(self.signature)
        return canonical_json_bytes(d)

    @classmethod
    def from_bytes(cls, data: bytes) -> "BootstrapManifest":
        d = json.loads(data.decode("utf-8"))
        m = cls(
            version=int(d["version"]),
            issued_at=int(d["issued_at"]),
            expires_at=int(d["expires_at"]),
            publisher_public_key=b64u_decode(d["publisher_public_key"]),
            seeds=[BootstrapSeed.from_dict(x) for x in d.get("seeds", [])],
            signature=b64u_decode(d["signature"]) if "signature" in d else None,
        )
        return m

    # ---- verify ----

    def verify(
        self, expected_publisher_key: Optional[bytes] = None
    ) -> tuple[bool, Optional[str]]:
        if self.version != MANIFEST_VERSION:
            return False, f"unsupported version {self.version}"
        if self.signature is None:
            return False, "unsigned"
        if expected_publisher_key is not None and \
           expected_publisher_key != self.publisher_public_key:
            return False, "publisher key mismatch"
        if self.expires_at <= now_s():
            return False, "expired"
        if not verify_with_public_key(
            self.publisher_public_key, self._signing_input(), self.signature
        ):
            return False, "signature verification failed"
        return True, None
