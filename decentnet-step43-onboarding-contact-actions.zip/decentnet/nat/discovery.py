"""NAT discovery: learn the external UDP mapping of the node's socket.

This service sends STUN Binding Requests on the node's existing
`UDPTransport` socket and parses the Binding Success Response to
extract the server-observed (public_ip, public_port). Because the
request goes out the same socket the node uses for DHT and
signaling, the returned mapping is the one other peers will
actually see — which is the whole point.

NAT classification (RFC 5780)
-----------------------------
`classify()` runs the full RFC 5780 NAT-behaviour discovery:

    Mapping behaviour — how the NAT picks the external port when
    the client sends to different destinations:
        ENDPOINT_INDEPENDENT_MAPPING  = same mapping for every dest
        ADDRESS_DEPENDENT_MAPPING     = same mapping per dest IP
        ADDRESS_AND_PORT_DEPENDENT_MAPPING = per (dest IP, dest port)

    Filtering behaviour — which inbound packets the NAT will allow
    back through the mapping:
        ENDPOINT_INDEPENDENT_FILTERING = anyone can hit it
        ADDRESS_DEPENDENT_FILTERING    = only hosts we've sent to
        ADDRESS_AND_PORT_DEPENDENT_FILTERING = only (host, port) pairs
                                               we've sent to

Combining the two gives the classic taxonomy:

    full cone           = indep mapping + indep filtering
    restricted cone     = indep mapping + addr-dep filtering
    port-restricted     = indep mapping + addr+port-dep filtering
    symmetric           = addr(+port)-dep mapping (any filtering)

If the configured STUN server implements RFC 5780 (i.e. advertises
OTHER-ADDRESS and honours CHANGE-REQUEST), we can run all the tests
and produce a precise label. If the server doesn't (i.e. no
OTHER-ADDRESS in the response), we fall back to the heuristic
classifier (OPEN_INTERNET / CONE_LIKE / SYMMETRIC / UNKNOWN) used
prior to this upgrade.
"""
from __future__ import annotations

import threading
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Optional

from ..audit.log import AuditLog
from ..utils.time import now_s
from .stun import (
    build_binding_request,
    build_binding_request_with_change,
    parse_stun_message,
)

if TYPE_CHECKING:
    from ..transport.udp import UDPTransport


class NATType(str, Enum):
    UNKNOWN = "unknown"
    OPEN_INTERNET = "open_internet"
    CONE_LIKE = "cone_like"
    SYMMETRIC = "symmetric"
    # RFC 5780 fine-grained labels (only assigned when the STUN
    # server is RFC 5780-compliant, i.e. advertises OTHER-ADDRESS).
    FULL_CONE = "full_cone"
    RESTRICTED_CONE = "restricted_cone"
    PORT_RESTRICTED_CONE = "port_restricted_cone"
    BLOCKED = "blocked"


class MappingBehaviour(str, Enum):
    ENDPOINT_INDEPENDENT = "endpoint_independent_mapping"
    ADDRESS_DEPENDENT = "address_dependent_mapping"
    ADDRESS_AND_PORT_DEPENDENT = "address_and_port_dependent_mapping"
    UNKNOWN = "unknown"


class FilteringBehaviour(str, Enum):
    ENDPOINT_INDEPENDENT = "endpoint_independent_filtering"
    ADDRESS_DEPENDENT = "address_dependent_filtering"
    ADDRESS_AND_PORT_DEPENDENT = "address_and_port_dependent_filtering"
    UNKNOWN = "unknown"


@dataclass
class NATBehaviour:
    """The full RFC 5780 output."""
    reachable: bool = False                    # Test I succeeded
    mapping: MappingBehaviour = MappingBehaviour.UNKNOWN
    filtering: FilteringBehaviour = FilteringBehaviour.UNKNOWN
    nat_type: NATType = NATType.UNKNOWN
    mapped_primary: Optional[tuple[str, int]] = None
    mapped_alt_ip: Optional[tuple[str, int]] = None
    mapped_alt_port: Optional[tuple[str, int]] = None
    server_alt: Optional[tuple[str, int]] = None   # OTHER-ADDRESS
    notes: list[str] = field(default_factory=list)


@dataclass
class _PendingProbe:
    event: threading.Event = field(default_factory=threading.Event)
    response_from: Optional[tuple[str, int]] = None
    response_data: Optional[bytes] = None


class NATDiscovery:
    """Binds a STUN handler onto the node's `UDPTransport`."""

    def __init__(
        self,
        transport: "UDPTransport",
        stun_servers: list[tuple[str, int]],
        *,
        audit: Optional[AuditLog] = None,
    ) -> None:
        if not stun_servers:
            raise ValueError("stun_servers must be non-empty")
        self._tx = transport
        self._servers = list(stun_servers)
        self._audit = audit or AuditLog(None)
        self._pending: dict[bytes, _PendingProbe] = {}
        self._pending_lock = threading.Lock()
        self._last_mapped: Optional[tuple[str, int]] = None
        self._last_observed_at: int = 0
        self._nat_type: NATType = NATType.UNKNOWN
        transport.set_stun_handler(self._on_stun)

    # ---- accessors ----

    @property
    def last_mapped(self) -> Optional[tuple[str, int]]:
        return self._last_mapped

    @property
    def last_observed_at(self) -> int:
        return self._last_observed_at

    @property
    def nat_type(self) -> NATType:
        return self._nat_type

    @property
    def stun_servers(self) -> list[tuple[str, int]]:
        return list(self._servers)

    # ---- probe ----

    def _probe(
        self,
        target: tuple[str, int],
        *,
        packet: Optional[bytes] = None,
        tid: Optional[bytes] = None,
        timeout_s: float,
    ):
        """Low-level probe. Returns the full parsed STUNResponse
        (or None on timeout) plus the (host, port) the response
        actually arrived from. Allows the classifier to inspect
        both the mapped address and CHANGE-* reply origin."""
        if packet is None or tid is None:
            packet, tid = build_binding_request()
        probe = _PendingProbe()
        with self._pending_lock:
            self._pending[tid] = probe
        try:
            self._tx.send_raw(packet, target)
            if not probe.event.wait(timeout_s):
                return None, None
            if probe.response_data is None:
                return None, probe.response_from
            try:
                resp = parse_stun_message(probe.response_data)
            except Exception:
                return None, probe.response_from
            return resp, probe.response_from
        finally:
            with self._pending_lock:
                self._pending.pop(tid, None)

    def discover(
        self,
        *,
        server: Optional[tuple[str, int]] = None,
        timeout_s: float = 2.0,
    ) -> Optional[tuple[str, int]]:
        """Send a Binding Request to `server` (default: first configured).

        Returns the mapped (host, port) or None on timeout."""
        target = server if server is not None else self._servers[0]
        resp, _ = self._probe(target, timeout_s=timeout_s)
        if resp is None:
            self._audit.record(
                "nat.stun_timeout",
                server=f"{target[0]}:{target[1]}",
            )
            return None
        mapped = resp.mapped_address
        if mapped is not None:
            self._last_mapped = mapped
            self._last_observed_at = now_s()
            self._audit.record(
                "nat.stun_mapping",
                server=f"{target[0]}:{target[1]}",
                mapped=f"{mapped[0]}:{mapped[1]}",
            )
        return mapped

    # ---- heuristic classifier (back-compat) ----

    def classify(self, *, timeout_s: float = 2.0) -> NATType:
        """Run the full RFC 5780 behaviour-discovery FSM if the server
        advertises OTHER-ADDRESS; fall back to the pre-RFC-5780
        heuristic (OPEN_INTERNET / CONE_LIKE / SYMMETRIC / UNKNOWN)
        otherwise.

        For the full behaviour breakdown (mapping + filtering), call
        `classify_behaviour()` directly.
        """
        b = self.classify_behaviour(timeout_s=timeout_s)
        self._nat_type = b.nat_type
        return self._nat_type

    def classify_behaviour(self, *, timeout_s: float = 2.0) -> NATBehaviour:
        """Full RFC 5780 NAT behaviour discovery."""
        behaviour = NATBehaviour()
        primary = self._servers[0]

        # --- Test I: plain Binding Request to primary ---
        resp_i, from_i = self._probe(primary, timeout_s=timeout_s)
        if resp_i is None or resp_i.mapped_address is None:
            behaviour.nat_type = NATType.BLOCKED
            behaviour.notes.append("Test I timed out → UDP blocked")
            self._audit.record("nat.classify", nat_type=behaviour.nat_type.value)
            self._nat_type = behaviour.nat_type
            return behaviour

        behaviour.reachable = True
        behaviour.mapped_primary = resp_i.mapped_address
        self._last_mapped = resp_i.mapped_address
        self._last_observed_at = now_s()

        # Open internet detection: mapped == local bind.
        if (
            resp_i.mapped_address[0] == self._tx.bind_host
            and resp_i.mapped_address[1] == self._tx.bind_port
        ):
            behaviour.nat_type = NATType.OPEN_INTERNET
            behaviour.mapping = MappingBehaviour.ENDPOINT_INDEPENDENT
            behaviour.filtering = FilteringBehaviour.ENDPOINT_INDEPENDENT
            behaviour.notes.append("mapped == local bind → no NAT")
            self._audit.record("nat.classify", nat_type=behaviour.nat_type.value)
            self._nat_type = behaviour.nat_type
            return behaviour

        # Does the server advertise OTHER-ADDRESS? If not, fall back
        # to the heuristic classifier.
        behaviour.server_alt = resp_i.other_address or resp_i.changed_address
        if behaviour.server_alt is None:
            # Can't run RFC 5780 — use the heuristic.
            if len(self._servers) >= 2:
                m2_resp, _ = self._probe(self._servers[1], timeout_s=timeout_s)
                m2 = m2_resp.mapped_address if m2_resp else None
                if m2 is None:
                    behaviour.nat_type = NATType.UNKNOWN
                elif m2 == resp_i.mapped_address:
                    behaviour.nat_type = NATType.CONE_LIKE
                    behaviour.mapping = MappingBehaviour.ENDPOINT_INDEPENDENT
                elif m2[0] == resp_i.mapped_address[0]:
                    behaviour.nat_type = NATType.SYMMETRIC
                    behaviour.mapping = MappingBehaviour.ADDRESS_AND_PORT_DEPENDENT
                else:
                    behaviour.nat_type = NATType.UNKNOWN
                behaviour.notes.append(
                    "server lacks OTHER-ADDRESS — used heuristic classifier"
                )
            else:
                behaviour.nat_type = NATType.UNKNOWN
                behaviour.notes.append(
                    "single server + no OTHER-ADDRESS → cannot classify"
                )
            self._audit.record(
                "nat.classify", nat_type=behaviour.nat_type.value,
                mapping=behaviour.mapping.value,
            )
            self._nat_type = behaviour.nat_type
            return behaviour

        # --- RFC 5780 §3 mapping-behaviour tests ---
        # Test II: send to primary IP, alt port. RFC 5780 recommends
        # using CHANGE-REQUEST(port) which causes the server to reply
        # from alt port, but for mapping we actually want to hit the
        # other (addr,port) directly — so we just send a plain
        # request to (primary_ip, alt_port).
        primary_ip = primary[0]
        alt_addr = behaviour.server_alt
        alt_port_same_ip = (primary_ip, alt_addr[1])

        resp_ii, _ = self._probe(alt_port_same_ip, timeout_s=timeout_s)
        if resp_ii and resp_ii.mapped_address:
            behaviour.mapped_alt_port = resp_ii.mapped_address
            if resp_ii.mapped_address == resp_i.mapped_address:
                behaviour.mapping = MappingBehaviour.ENDPOINT_INDEPENDENT
            else:
                # Test III: send to alt IP entirely.
                resp_iii, _ = self._probe(alt_addr, timeout_s=timeout_s)
                if resp_iii and resp_iii.mapped_address:
                    behaviour.mapped_alt_ip = resp_iii.mapped_address
                    if resp_iii.mapped_address == resp_ii.mapped_address:
                        # Same mapping for any dest with same IP,
                        # different for different IP.
                        behaviour.mapping = MappingBehaviour.ADDRESS_DEPENDENT
                    else:
                        behaviour.mapping = MappingBehaviour.ADDRESS_AND_PORT_DEPENDENT
                else:
                    behaviour.mapping = MappingBehaviour.UNKNOWN
        else:
            behaviour.mapping = MappingBehaviour.UNKNOWN

        # --- RFC 5780 §4 filtering-behaviour tests ---
        # Test F1: CHANGE-REQUEST with change_ip + change_port — ask
        # the server to reply from its *other* IP and port. If the
        # reply arrives, the NAT lets in packets from anywhere →
        # Endpoint-Independent Filtering (full cone).
        packet_f1, tid_f1 = build_binding_request_with_change(
            change_ip=True, change_port=True,
        )
        resp_f1, from_f1 = self._probe(
            primary, packet=packet_f1, tid=tid_f1, timeout_s=timeout_s,
        )
        if resp_f1 is not None:
            behaviour.filtering = FilteringBehaviour.ENDPOINT_INDEPENDENT
        else:
            # Test F2: CHANGE-REQUEST change_port only — ask server
            # to reply from same IP, different port. If that comes
            # through, we have address-dependent filtering
            # (restricted cone); else port-restricted.
            packet_f2, tid_f2 = build_binding_request_with_change(
                change_port=True,
            )
            resp_f2, _ = self._probe(
                primary, packet=packet_f2, tid=tid_f2, timeout_s=timeout_s,
            )
            if resp_f2 is not None:
                behaviour.filtering = FilteringBehaviour.ADDRESS_DEPENDENT
            else:
                behaviour.filtering = FilteringBehaviour.ADDRESS_AND_PORT_DEPENDENT

        # --- Collapse into a friendly NAT type label ---
        if behaviour.mapping == MappingBehaviour.ENDPOINT_INDEPENDENT:
            if behaviour.filtering == FilteringBehaviour.ENDPOINT_INDEPENDENT:
                behaviour.nat_type = NATType.FULL_CONE
            elif behaviour.filtering == FilteringBehaviour.ADDRESS_DEPENDENT:
                behaviour.nat_type = NATType.RESTRICTED_CONE
            elif behaviour.filtering == FilteringBehaviour.ADDRESS_AND_PORT_DEPENDENT:
                behaviour.nat_type = NATType.PORT_RESTRICTED_CONE
            else:
                behaviour.nat_type = NATType.CONE_LIKE
        elif behaviour.mapping in (
            MappingBehaviour.ADDRESS_DEPENDENT,
            MappingBehaviour.ADDRESS_AND_PORT_DEPENDENT,
        ):
            behaviour.nat_type = NATType.SYMMETRIC
        else:
            behaviour.nat_type = NATType.UNKNOWN

        self._audit.record(
            "nat.classify",
            nat_type=behaviour.nat_type.value,
            mapping=behaviour.mapping.value,
            filtering=behaviour.filtering.value,
            server_alt=(
                f"{behaviour.server_alt[0]}:{behaviour.server_alt[1]}"
                if behaviour.server_alt else None
            ),
        )
        self._nat_type = behaviour.nat_type
        return behaviour

    # ---- handler ----

    def _on_stun(self, data: bytes, addr: tuple[str, int]) -> None:
        try:
            resp = parse_stun_message(data)
        except Exception:
            return
        with self._pending_lock:
            probe = self._pending.pop(resp.transaction_id, None)
        if probe is None:
            return
        probe.response_from = addr
        probe.response_data = data
        probe.event.set()
