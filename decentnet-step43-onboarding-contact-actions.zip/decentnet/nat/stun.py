"""Minimal STUN (RFC 5389 / 8489) client + mock server.

Scope of this implementation
----------------------------
* Message types: Binding Request, Binding Success Response.
* Attributes: XOR-MAPPED-ADDRESS (IPv4 only).
* Anything else (MESSAGE-INTEGRITY, FINGERPRINT, USERNAME, legacy
  MAPPED-ADDRESS) is intentionally NOT implemented. Basic STUN for
  external-address discovery does not need them; TURN (Phase 6)
  will.

Why no auth?
------------
For pure address discovery you don't need to prove anything to the
STUN server. A malicious server can lie about your mapped address,
which just means you'll try to publish an invalid endpoint and peers
will fail to reach you at it. That's a configuration problem (point
at a server you trust), not a security hole.

Mock server
-----------
`MockSTUNServer` binds a UDP socket, reads Binding Requests, and
echoes the client's observed source address back as a
XOR-MAPPED-ADDRESS in a Binding Success Response. Used by the test
suite to exercise the discovery service without depending on a
public STUN server.
"""
from __future__ import annotations

import os
import socket
import struct
import threading
from dataclasses import dataclass
from typing import Optional


# -------- constants --------

STUN_MAGIC_COOKIE: int = 0x2112_A442
STUN_MAGIC_COOKIE_BYTES: bytes = STUN_MAGIC_COOKIE.to_bytes(4, "big")

BINDING_REQUEST: int = 0x0001
BINDING_SUCCESS: int = 0x0101
BINDING_ERROR: int = 0x0111

ATTR_MAPPED_ADDRESS: int = 0x0001           # legacy, unused here for output
ATTR_XOR_MAPPED_ADDRESS: int = 0x0020
# RFC 5780 attributes (NAT behaviour discovery):
ATTR_CHANGE_REQUEST: int = 0x0003           # request server flips src ip/port
ATTR_RESPONSE_ORIGIN: int = 0x802b          # where *this* reply originated from
ATTR_OTHER_ADDRESS: int = 0x802c            # the "other" (ip, port) pair the server can reply from
ATTR_SOURCE_ADDRESS: int = 0x0004           # legacy SOURCE-ADDRESS (some servers still emit it)
ATTR_CHANGED_ADDRESS: int = 0x0005          # legacy CHANGED-ADDRESS (RFC 3489)

# CHANGE-REQUEST flag bits
CHANGE_IP_FLAG: int = 0x04
CHANGE_PORT_FLAG: int = 0x02

FAMILY_IPV4: int = 0x01
FAMILY_IPV6: int = 0x02

STUN_HEADER_SIZE: int = 20
TID_SIZE: int = 12


def is_stun_packet(data: bytes) -> bool:
    """Cheap prefilter: first two bits must be zero (RFC 5389 §6), and
    magic cookie must match at offset 4."""
    if len(data) < STUN_HEADER_SIZE:
        return False
    # First byte: top two bits zero
    if (data[0] & 0xC0) != 0:
        return False
    return data[4:8] == STUN_MAGIC_COOKIE_BYTES


# -------- client: build / parse --------


def build_binding_request(transaction_id: Optional[bytes] = None) -> tuple[bytes, bytes]:
    """Build a STUN Binding Request. Returns (packet_bytes, transaction_id)."""
    tid = transaction_id if transaction_id is not None else os.urandom(TID_SIZE)
    if len(tid) != TID_SIZE:
        raise ValueError(f"transaction ID must be {TID_SIZE} bytes")
    packet = struct.pack(
        ">HH4s12s",
        BINDING_REQUEST,
        0,                                # message length (no attributes)
        STUN_MAGIC_COOKIE_BYTES,
        tid,
    )
    return packet, tid


@dataclass
class STUNResponse:
    msg_type: int
    transaction_id: bytes
    mapped_address: Optional[tuple[str, int]] = None   # from XOR-MAPPED-ADDRESS
    # RFC 5780 fields:
    other_address: Optional[tuple[str, int]] = None    # OTHER-ADDRESS attribute
    response_origin: Optional[tuple[str, int]] = None  # RESPONSE-ORIGIN
    # Legacy fallbacks (RFC 3489 servers):
    changed_address: Optional[tuple[str, int]] = None
    source_address: Optional[tuple[str, int]] = None


def parse_stun_message(data: bytes) -> STUNResponse:
    """Parse any STUN message. Raises ValueError on malformed input."""
    if len(data) < STUN_HEADER_SIZE:
        raise ValueError("STUN message too short")
    msg_type, msg_length, cookie, tid = struct.unpack(
        ">HH4s12s", data[:STUN_HEADER_SIZE]
    )
    if cookie != STUN_MAGIC_COOKIE_BYTES:
        raise ValueError("bad STUN magic cookie")
    resp = STUNResponse(msg_type=msg_type, transaction_id=tid)

    off = STUN_HEADER_SIZE
    end = STUN_HEADER_SIZE + msg_length
    if end > len(data):
        raise ValueError("STUN message length exceeds buffer")
    while off + 4 <= end:
        attr_type, attr_len = struct.unpack(">HH", data[off:off + 4])
        off += 4
        attr_val = data[off:off + attr_len]
        padded = (attr_len + 3) & ~3
        off += padded
        if attr_type == ATTR_XOR_MAPPED_ADDRESS:
            resp.mapped_address = _parse_xor_mapped_address(attr_val, tid)
        elif attr_type == ATTR_OTHER_ADDRESS:
            resp.other_address = _parse_plain_address(attr_val)
        elif attr_type == ATTR_RESPONSE_ORIGIN:
            resp.response_origin = _parse_plain_address(attr_val)
        elif attr_type == ATTR_CHANGED_ADDRESS:
            resp.changed_address = _parse_plain_address(attr_val)
        elif attr_type == ATTR_SOURCE_ADDRESS:
            resp.source_address = _parse_plain_address(attr_val)
    return resp


def _parse_xor_mapped_address(value: bytes, tid: bytes) -> tuple[str, int]:
    if len(value) < 8:
        raise ValueError("XOR-MAPPED-ADDRESS too short")
    _reserved = value[0]
    family = value[1]
    (xport,) = struct.unpack(">H", value[2:4])
    port = xport ^ (STUN_MAGIC_COOKIE >> 16)
    if family == FAMILY_IPV4:
        xaddr_bytes = value[4:8]
        cookie_bytes = STUN_MAGIC_COOKIE_BYTES
        addr_bytes = bytes(a ^ b for a, b in zip(xaddr_bytes, cookie_bytes))
        host = ".".join(str(b) for b in addr_bytes)
        return host, port
    if family == FAMILY_IPV6:
        if len(value) < 20:
            raise ValueError("XOR-MAPPED-ADDRESS (IPv6) too short")
        xor_key = STUN_MAGIC_COOKIE_BYTES + tid
        xaddr_bytes = value[4:20]
        addr_bytes = bytes(a ^ b for a, b in zip(xaddr_bytes, xor_key))
        host = socket.inet_ntop(socket.AF_INET6, addr_bytes)
        return host, port
    raise ValueError(f"unknown STUN address family {family}")


def _parse_plain_address(value: bytes) -> tuple[str, int]:
    """Parse a plain (non-XOR) address attribute: MAPPED-ADDRESS,
    RESPONSE-ORIGIN, OTHER-ADDRESS, CHANGED-ADDRESS, SOURCE-ADDRESS."""
    if len(value) < 8:
        raise ValueError("plain address attribute too short")
    _reserved = value[0]
    family = value[1]
    (port,) = struct.unpack(">H", value[2:4])
    if family == FAMILY_IPV4:
        host = ".".join(str(b) for b in value[4:8])
        return host, port
    if family == FAMILY_IPV6:
        if len(value) < 20:
            raise ValueError("plain IPv6 attribute too short")
        host = socket.inet_ntop(socket.AF_INET6, value[4:20])
        return host, port
    raise ValueError(f"unknown STUN address family {family}")


def _encode_plain_address(addr: tuple[str, int]) -> bytes:
    """Inverse of `_parse_plain_address`. Returns the attribute VALUE
    (the caller wraps with TLV + padding)."""
    host, port = addr
    try:
        ip_bytes = socket.inet_aton(host)
        family = FAMILY_IPV4
    except OSError:
        ip_bytes = socket.inet_pton(socket.AF_INET6, host)
        family = FAMILY_IPV6
    return struct.pack(">BBH", 0, family, port & 0xFFFF) + ip_bytes


def _pad4(data: bytes) -> bytes:
    pad = (4 - (len(data) % 4)) % 4
    return data + b"\x00" * pad


def find_change_request(data: bytes) -> int:
    """Return the CHANGE-REQUEST flag byte from an incoming STUN
    message, or 0 if the attribute isn't present. Raises on malformed."""
    if len(data) < STUN_HEADER_SIZE:
        raise ValueError("STUN message too short")
    _, msg_length, _, _ = struct.unpack(">HH4s12s", data[:STUN_HEADER_SIZE])
    off = STUN_HEADER_SIZE
    end = STUN_HEADER_SIZE + msg_length
    if end > len(data):
        raise ValueError("truncated")
    while off + 4 <= end:
        attr_type, attr_len = struct.unpack(">HH", data[off:off + 4])
        off += 4
        if attr_type == ATTR_CHANGE_REQUEST and attr_len == 4:
            (flags,) = struct.unpack(">I", data[off:off + 4])
            return flags
        off += (attr_len + 3) & ~3
    return 0


def build_binding_request_with_change(
    *,
    change_ip: bool = False,
    change_port: bool = False,
    transaction_id: Optional[bytes] = None,
) -> tuple[bytes, bytes]:
    """Build a STUN Binding Request carrying a CHANGE-REQUEST attribute
    (RFC 5780). Returns (packet_bytes, transaction_id)."""
    tid = transaction_id if transaction_id is not None else os.urandom(TID_SIZE)
    flags = 0
    if change_ip:
        flags |= CHANGE_IP_FLAG
    if change_port:
        flags |= CHANGE_PORT_FLAG
    attr_value = struct.pack(">I", flags)
    attribute = _pad4(
        struct.pack(">HH", ATTR_CHANGE_REQUEST, len(attr_value)) + attr_value
    )
    header = struct.pack(
        ">HH4s12s",
        BINDING_REQUEST,
        len(attribute),
        STUN_MAGIC_COOKIE_BYTES,
        tid,
    )
    return header + attribute, tid


# -------- server side (for the mock) --------


def build_binding_success_response(
    transaction_id: bytes,
    mapped: tuple[str, int],
    *,
    other_address: Optional[tuple[str, int]] = None,
    response_origin: Optional[tuple[str, int]] = None,
    changed_address: Optional[tuple[str, int]] = None,
) -> bytes:
    """Build a Binding Success Response.

    Always carries XOR-MAPPED-ADDRESS.
    If `other_address`, `response_origin`, or `changed_address` are
    provided they're appended as plain address attributes — these are
    what RFC 5780 NAT-behaviour discovery reads.
    """
    host, port = mapped
    xport = (port & 0xFFFF) ^ (STUN_MAGIC_COOKIE >> 16)
    try:
        addr_bytes = socket.inet_aton(host)
        family = FAMILY_IPV4
    except OSError:
        addr_bytes = socket.inet_pton(socket.AF_INET6, host)
        family = FAMILY_IPV6

    if family == FAMILY_IPV4:
        xaddr = bytes(a ^ b for a, b in zip(addr_bytes, STUN_MAGIC_COOKIE_BYTES))
    else:
        xor_key = STUN_MAGIC_COOKIE_BYTES + transaction_id
        xaddr = bytes(a ^ b for a, b in zip(addr_bytes, xor_key))

    attr_value = struct.pack(">BBH", 0, family, xport) + xaddr
    attributes = _pad4(
        struct.pack(">HH", ATTR_XOR_MAPPED_ADDRESS, len(attr_value)) + attr_value
    )

    def _append(attr_type: int, addr: tuple[str, int]) -> bytes:
        val = _encode_plain_address(addr)
        return _pad4(
            struct.pack(">HH", attr_type, len(val)) + val
        )

    if other_address is not None:
        attributes += _append(ATTR_OTHER_ADDRESS, other_address)
    if response_origin is not None:
        attributes += _append(ATTR_RESPONSE_ORIGIN, response_origin)
    if changed_address is not None:
        # Legacy RFC 3489 clients expect CHANGED-ADDRESS.
        attributes += _append(ATTR_CHANGED_ADDRESS, changed_address)

    return struct.pack(
        ">HH4s12s",
        BINDING_SUCCESS,
        len(attributes),
        STUN_MAGIC_COOKIE_BYTES,
        transaction_id,
    ) + attributes


# -------- mock server --------


class MockSTUNServer:
    """RFC 5780-capable mock STUN server for tests.

    A compliant RFC 5780 server listens on two IP:port pairs — call
    them A and B — and each bundle advertises the other pair as
    OTHER-ADDRESS, letting a client distinguish:

        * "same source, different port from same IP" (CHANGE-REQUEST
          with change-port flag only)
        * "different IP entirely" (CHANGE-REQUEST with change-ip flag)

    Since we can't easily bind two arbitrary IPs on a CI host, the
    mock runs both "IPs" as *127.0.0.1* but on different ports and
    presents them as distinct interfaces via OTHER-ADDRESS. That is
    sufficient to exercise the client-side classification FSM.

    If `alternate_host` / `alternate_port` are supplied, an additional
    socket on that (host, port) is bound and used for the CHANGE-IP
    path.

    Backwards-compat: the server still accepts plain Binding Requests
    with no CHANGE-REQUEST and answers them exactly like the old
    implementation (single XOR-MAPPED-ADDRESS) if `rfc5780=False`.
    """

    def __init__(
        self,
        bind_host: str = "127.0.0.1",
        bind_port: int = 0,
        *,
        alternate_host: Optional[str] = None,
        alternate_port: Optional[int] = None,
        rfc5780: bool = True,
    ) -> None:
        self._rfc5780 = rfc5780
        # Primary socket.
        self._primary = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._primary.bind((bind_host, bind_port))
        self._primary.settimeout(0.25)
        self.bind_host, self.bind_port = self._primary.getsockname()
        # Alternate socket (for CHANGE-PORT / CHANGE-IP). Only bound
        # if this is an RFC 5780 mock.
        self._alternate: Optional[socket.socket] = None
        self.alt_host: Optional[str] = None
        self.alt_port: Optional[int] = None
        if rfc5780:
            alt_h = alternate_host or bind_host
            alt_p = alternate_port or 0
            self._alternate = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self._alternate.bind((alt_h, alt_p))
            self._alternate.settimeout(0.25)
            self.alt_host, self.alt_port = self._alternate.getsockname()
        self._running = threading.Event()
        self._running.set()
        self.request_count = 0
        self.change_ip_count = 0
        self.change_port_count = 0
        # Behaviour knobs tests can flip:
        self.drop_change_ip = False
        self.drop_change_port = False
        self._threads = []
        t1 = threading.Thread(
            target=self._run_on, args=(self._primary, "primary"),
            name="mock-stun-primary", daemon=True,
        )
        self._threads.append(t1)
        t1.start()
        if self._alternate is not None:
            t2 = threading.Thread(
                target=self._run_on, args=(self._alternate, "alt"),
                name="mock-stun-alt", daemon=True,
            )
            self._threads.append(t2)
            t2.start()

    def _run_on(self, sock: socket.socket, label: str) -> None:
        while self._running.is_set():
            try:
                data, addr = sock.recvfrom(1500)
            except socket.timeout:
                continue
            except OSError:
                break
            try:
                if not is_stun_packet(data):
                    continue
                msg_type, _, _, tid = struct.unpack(
                    ">HH4s12s", data[:STUN_HEADER_SIZE]
                )
                if msg_type != BINDING_REQUEST:
                    continue
                self.request_count += 1
                change_flags = 0
                try:
                    change_flags = find_change_request(data)
                except Exception:
                    change_flags = 0

                # Determine which socket should send the response.
                # RFC 5780 §7.2: an RFC-5780-compliant server, upon
                # receiving a request with CHANGE-REQUEST, replies
                # from the alternate (ip/port) combination that
                # matches the requested flags.
                reply_sock = sock
                reply_label = label
                if self._rfc5780 and change_flags:
                    if change_flags & CHANGE_IP_FLAG:
                        self.change_ip_count += 1
                        if self.drop_change_ip:
                            continue
                        # Use the alternate socket (our "other IP").
                        reply_sock = (
                            self._alternate if label == "primary" else self._primary
                        )
                        reply_label = "alt" if label == "primary" else "primary"
                    elif change_flags & CHANGE_PORT_FLAG:
                        self.change_port_count += 1
                        if self.drop_change_port:
                            continue
                        # Use the alternate socket (different port).
                        reply_sock = (
                            self._alternate if label == "primary" else self._primary
                        )
                        reply_label = "alt" if label == "primary" else "primary"

                # Advertise the OTHER address (from the perspective
                # of the socket that is about to send the reply).
                other_addr: Optional[tuple[str, int]] = None
                response_origin: Optional[tuple[str, int]] = None
                changed_addr: Optional[tuple[str, int]] = None
                if self._rfc5780 and self._alternate is not None:
                    if reply_label == "primary":
                        other_addr = (self.alt_host, self.alt_port)
                        response_origin = (self.bind_host, self.bind_port)
                    else:
                        other_addr = (self.bind_host, self.bind_port)
                        response_origin = (self.alt_host, self.alt_port)
                    changed_addr = other_addr  # RFC 3489 legacy

                response = build_binding_success_response(
                    tid, addr,
                    other_address=other_addr,
                    response_origin=response_origin,
                    changed_address=changed_addr,
                )
                reply_sock.sendto(response, addr)
            except Exception:
                continue

    def close(self) -> None:
        self._running.clear()
        try:
            self._primary.close()
        except Exception:
            pass
        if self._alternate is not None:
            try:
                self._alternate.close()
            except Exception:
                pass
        for t in self._threads:
            t.join(timeout=1.0)

    def __enter__(self) -> "MockSTUNServer":
        return self

    def __exit__(self, *exc) -> None:
        self.close()
