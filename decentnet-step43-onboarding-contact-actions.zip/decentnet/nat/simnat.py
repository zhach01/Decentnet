"""A UDP pseudo-NAT for testing RFC 5780 NAT behaviour discovery.

The real thing we're classifying is network middleboxes — which we
obviously can't conjure in a unit test. Instead, this module
provides `SimulatedNAT`, a userspace bridge that sits between a
client socket and two STUN servers and applies a configurable NAT
behaviour (mapping + filtering).

Architecture:

                +------------+
                | client UDP |  <---- talks to NAT's external ports
                +-----+------+        (the "LAN side")
                      |
                      v
                +------------+
                | SimulatedNAT |  knows mapping & filtering rules
                +-----+------+
                      |
                      v
                +------------+
                |  STUN A/B  |  the mock servers (real RFC 5780)
                +------------+

Client sends to NAT's LAN-side port. NAT picks (or reuses) an
external port depending on mapping behaviour, then forwards to the
real target. Replies from the STUN server come back to NAT's
external socket; NAT checks filtering rules and, if allowed,
forwards to the client's LAN-side address.

This lets us exercise every limb of the classify_behaviour FSM on
loopback without needing kernel-level NAT.
"""
from __future__ import annotations

import socket
import threading
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class SimMapping(str, Enum):
    ENDPOINT_INDEPENDENT = "endpoint_independent"
    ADDRESS_DEPENDENT = "address_dependent"
    ADDRESS_AND_PORT_DEPENDENT = "address_and_port_dependent"


class SimFiltering(str, Enum):
    ENDPOINT_INDEPENDENT = "endpoint_independent"
    ADDRESS_DEPENDENT = "address_dependent"
    ADDRESS_AND_PORT_DEPENDENT = "address_and_port_dependent"


@dataclass
class _Mapping:
    """One (outbound internal addr, outbound dest addr) → external port."""
    external_port: int
    # (ext_port -> set of dest addresses we've sent to, for filtering).
    dests_contacted: set[tuple[str, int]]


class SimulatedNAT:
    """A userspace NAT.

    Listens on `lan_port` (the client's "LAN-side gateway"). Forwards
    outbound datagrams to their real destination and records the
    mapping. Allocates external sockets in `external_port_pool` (one
    socket per mapping slot).

    For the classifier to notice the mapping difference, the mapping
    behaviour must be reflected in *which external socket* carries
    the outbound traffic — so STUN servers see different source
    (host, port) tuples.
    """

    def __init__(
        self,
        *,
        mapping: SimMapping,
        filtering: SimFiltering,
        lan_host: str = "127.0.0.1",
        lan_port: int = 0,
        external_host: str = "127.0.0.1",
        external_port_pool_size: int = 8,
    ) -> None:
        self.mapping = mapping
        self.filtering = filtering

        # LAN-side socket (client talks to this).
        self._lan = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._lan.bind((lan_host, lan_port))
        self._lan.settimeout(0.2)
        self.lan_host, self.lan_port = self._lan.getsockname()

        # Pool of external sockets — one per distinct NAT mapping we need.
        self._pool: list[socket.socket] = []
        self._pool_addrs: list[tuple[str, int]] = []
        for _ in range(external_port_pool_size):
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.bind((external_host, 0))
            s.settimeout(0.2)
            self._pool.append(s)
            self._pool_addrs.append(s.getsockname())

        # client_addr -> list of (dest_key, external_socket, dests_contacted)
        self._map_lock = threading.Lock()
        self._mappings: dict[
            tuple[str, int],
            list[tuple[tuple, socket.socket, set]]
        ] = {}
        # Reverse: external_socket -> client_addr
        self._back: dict[int, tuple[str, int]] = {}

        self._running = threading.Event()
        self._running.set()
        self._threads = []
        t = threading.Thread(
            target=self._lan_loop, name="sim-nat-lan", daemon=True
        )
        self._threads.append(t)
        t.start()
        for s in self._pool:
            th = threading.Thread(
                target=self._ext_loop, args=(s,),
                name=f"sim-nat-ext-{s.getsockname()[1]}", daemon=True,
            )
            self._threads.append(th)
            th.start()

    # ---- API ----

    def close(self) -> None:
        self._running.clear()
        try:
            self._lan.close()
        except Exception:
            pass
        for s in self._pool:
            try:
                s.close()
            except Exception:
                pass
        for t in self._threads:
            t.join(timeout=1.0)

    def __enter__(self) -> "SimulatedNAT":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # ---- LAN → external forwarding (mapping side) ----

    def _mapping_key(self, dest: tuple[str, int]) -> tuple:
        if self.mapping == SimMapping.ENDPOINT_INDEPENDENT:
            return ("ei",)
        if self.mapping == SimMapping.ADDRESS_DEPENDENT:
            return ("ad", dest[0])
        return ("apd", dest[0], dest[1])

    def _get_external_socket(
        self, client: tuple[str, int], dest: tuple[str, int]
    ) -> Optional[socket.socket]:
        key = self._mapping_key(dest)
        with self._map_lock:
            entries = self._mappings.setdefault(client, [])
            for k, sock, dests in entries:
                if k == key:
                    dests.add(dest)
                    return sock
            # Allocate a new external socket.
            for sock in self._pool:
                if id(sock) not in self._back:
                    self._back[id(sock)] = client
                    entries.append((key, sock, {dest}))
                    return sock
        return None

    def _lan_loop(self) -> None:
        while self._running.is_set():
            try:
                data, client = self._lan.recvfrom(1500)
            except socket.timeout:
                continue
            except OSError:
                break
            # LAN datagrams arrive framed as: 2-byte dest-host-len +
            # dest-host + 2-byte dest-port + payload.
            # This is a simple framing to let the client tell the NAT
            # which upstream server it wants to talk to (since UDP
            # doesn't normally carry that).
            try:
                hl = int.from_bytes(data[:2], "big")
                host = data[2:2 + hl].decode("ascii")
                port = int.from_bytes(data[2 + hl:4 + hl], "big")
                payload = data[4 + hl:]
            except Exception:
                continue
            dest = (host, port)
            ext = self._get_external_socket(client, dest)
            if ext is None:
                continue
            try:
                ext.sendto(payload, dest)
            except OSError:
                continue

    # ---- external → LAN (filtering side) ----

    def _ext_loop(self, sock: socket.socket) -> None:
        while self._running.is_set():
            try:
                data, src = sock.recvfrom(1500)
            except socket.timeout:
                continue
            except OSError:
                break
            with self._map_lock:
                client = self._back.get(id(sock))
                if client is None:
                    continue
                entries = self._mappings.get(client, [])
                # Find the mapping slot this socket belongs to.
                slot = None
                for k, s, dests in entries:
                    if s is sock:
                        slot = (k, s, dests)
                        break
            if slot is None:
                continue
            _, _, dests = slot
            # Apply filtering.
            allowed = False
            if self.filtering == SimFiltering.ENDPOINT_INDEPENDENT:
                allowed = True
            elif self.filtering == SimFiltering.ADDRESS_DEPENDENT:
                allowed = any(d[0] == src[0] for d in dests)
            elif self.filtering == SimFiltering.ADDRESS_AND_PORT_DEPENDENT:
                allowed = src in dests
            if not allowed:
                continue
            try:
                self._lan.sendto(data, client)
            except OSError:
                continue


def pack_lan_datagram(dest: tuple[str, int], payload: bytes) -> bytes:
    """Framing helper: prepend (dest_host, dest_port) so the NAT
    knows where to forward."""
    host_bytes = dest[0].encode("ascii")
    return (
        len(host_bytes).to_bytes(2, "big")
        + host_bytes
        + int(dest[1]).to_bytes(2, "big")
        + payload
    )
