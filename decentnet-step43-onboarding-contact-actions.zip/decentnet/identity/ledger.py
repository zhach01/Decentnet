"""Persistent rotation ledger.

When a record carrying a valid rotation receipt is accepted, we
remember the mapping `old_peer_id -> new_peer_id` along with the
verified receipt. Lookups for the old peer_id can transparently
forward to the new one for a configurable grace period.

Schema (alongside the regular cache DB):

    rotations
        old_peer_id TEXT PRIMARY KEY
        new_peer_id TEXT NOT NULL
        receipt_json TEXT NOT NULL
        accepted_at INTEGER NOT NULL
        forward_until INTEGER NOT NULL
"""
from __future__ import annotations

import json
import sqlite3
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from ..identity.rotation import RotationReceipt
from ..utils.time import now_s


DEFAULT_FORWARD_GRACE_S = 30 * 86400   # 30 days


@dataclass
class ForwardEntry:
    old_peer_id: str
    new_peer_id: str
    receipt: RotationReceipt
    accepted_at: int
    forward_until: int


class RotationLedger:
    def __init__(self, path: Path | str | None) -> None:
        if path is None:
            self._conn = sqlite3.connect(":memory:", check_same_thread=False)
        else:
            p = Path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(p), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        with self._lock, self._conn:
            self._conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS rotations (
                    old_peer_id   TEXT PRIMARY KEY,
                    new_peer_id   TEXT NOT NULL,
                    receipt_json  TEXT NOT NULL,
                    accepted_at   INTEGER NOT NULL,
                    forward_until INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_rot_new
                    ON rotations(new_peer_id);
                """
            )

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    # ---- writes ----

    def record_rotation(
        self,
        receipt: RotationReceipt,
        *,
        grace_s: int = DEFAULT_FORWARD_GRACE_S,
    ) -> None:
        ok, reason = receipt.verify()
        if not ok:
            raise ValueError(f"rotation receipt invalid: {reason}")
        t = now_s()
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT INTO rotations
                   (old_peer_id, new_peer_id, receipt_json,
                    accepted_at, forward_until)
                   VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT(old_peer_id) DO UPDATE SET
                     new_peer_id = excluded.new_peer_id,
                     receipt_json = excluded.receipt_json,
                     accepted_at = excluded.accepted_at,
                     forward_until = excluded.forward_until""",
                (
                    receipt.prev_peer_id,
                    receipt.new_peer_id,
                    json.dumps(receipt.to_dict()),
                    t, t + grace_s,
                ),
            )

    # ---- reads ----

    def successor_of(self, old_peer_id: str) -> Optional[str]:
        """Return the current peer_id `old_peer_id` rotated to (chain
        followed transitively), or None if no forwarding."""
        seen: set[str] = set()
        cur_id = old_peer_id
        while True:
            if cur_id in seen:
                return None  # cycle (should be impossible with valid receipts)
            seen.add(cur_id)
            with self._lock, self._conn:
                row = self._conn.execute(
                    "SELECT new_peer_id, forward_until FROM rotations "
                    "WHERE old_peer_id = ?",
                    (cur_id,),
                ).fetchone()
            if row is None:
                return None if cur_id == old_peer_id else cur_id
            if row["forward_until"] <= now_s():
                return None if cur_id == old_peer_id else cur_id
            cur_id = row["new_peer_id"]

    def chain(self, peer_id: str) -> list[str]:
        """Return the chain old → new starting from peer_id."""
        chain = [peer_id]
        seen = {peer_id}
        cur = peer_id
        while True:
            with self._lock, self._conn:
                row = self._conn.execute(
                    "SELECT new_peer_id FROM rotations WHERE old_peer_id = ?",
                    (cur,),
                ).fetchone()
            if row is None:
                return chain
            nxt = row["new_peer_id"]
            if nxt in seen:
                return chain
            seen.add(nxt)
            chain.append(nxt)
            cur = nxt

    def all_entries(self) -> list[ForwardEntry]:
        out = []
        with self._lock, self._conn:
            rows = self._conn.execute(
                "SELECT * FROM rotations ORDER BY accepted_at"
            ).fetchall()
        for row in rows:
            try:
                receipt = RotationReceipt.from_dict(
                    json.loads(row["receipt_json"])
                )
            except Exception:
                continue
            out.append(ForwardEntry(
                old_peer_id=row["old_peer_id"],
                new_peer_id=row["new_peer_id"],
                receipt=receipt,
                accepted_at=row["accepted_at"],
                forward_until=row["forward_until"],
            ))
        return out

    def gc(self) -> int:
        with self._lock, self._conn:
            cur = self._conn.execute(
                "DELETE FROM rotations WHERE forward_until <= ?",
                (now_s(),),
            )
            return cur.rowcount or 0
