"""Peer ID = unpadded lowercase base32 of SHA-256(public_key_bytes).

Why SHA-256 over the raw public key?
    * decouples the on-wire identifier length from the key length
    * lets us rotate keys while keeping the ID stable IF we later add
      a signed rotation record (planned for Phase 2+)
    * hashing is cheap and the ID becomes opaque/fixed-width

A peer ID is 52 characters of base32 (256 bits = 32 bytes -> 52 chars
unpadded). For human use we also support a short-form prefix.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass

from ..utils.encoding import b32encode_nopad, b32decode_nopad


PEER_ID_HASH = "sha256"
PEER_ID_HASH_LEN = 32


@dataclass(frozen=True)
class PeerId:
    value: str  # full base32 string

    # ---------- constructors ----------

    @classmethod
    def from_public_key(cls, public_key_bytes: bytes) -> "PeerId":
        digest = hashlib.sha256(public_key_bytes).digest()
        return cls(value=b32encode_nopad(digest))

    @classmethod
    def from_string(cls, s: str) -> "PeerId":
        s = s.strip().lower()
        if not s:
            raise ValueError("Empty peer ID")
        # Round-trip to validate.
        decoded = b32decode_nopad(s)
        if len(decoded) != PEER_ID_HASH_LEN:
            raise ValueError(
                f"Peer ID decodes to {len(decoded)} bytes; "
                f"expected {PEER_ID_HASH_LEN}"
            )
        return cls(value=s)

    # ---------- helpers ----------

    def short(self, n: int = 8) -> str:
        """Short prefix for logs/UI. Never use in protocol messages."""
        return self.value[:n]

    def matches_public_key(self, public_key_bytes: bytes) -> bool:
        return self == PeerId.from_public_key(public_key_bytes)

    def __str__(self) -> str:
        return self.value
