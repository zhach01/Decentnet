"""Ed25519 keypair management with on-disk persistence.

The keypair is stored in a simple JSON file with base64url-encoded
fields. Private keys are written with 0600 permissions where the OS
supports it. We do **not** encrypt the key at rest in Phase 1; adding
a passphrase-wrapped key store is a documented follow-up (see
docs/ARCHITECTURE.md, Security Roadmap).

We deliberately wrap the `cryptography` library rather than using it
directly in higher layers so that (a) we have one place to swap crypto
primitives and (b) we can add key-rotation semantics cleanly.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization as _ser
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

from ..utils.encoding import b64u_decode, b64u_encode


KEY_FILE_VERSION = 1


@dataclass
class Keypair:
    """An Ed25519 keypair. Private key may be None for verify-only use."""

    public_key_bytes: bytes
    private_key_bytes: Optional[bytes] = None  # raw 32-byte seed

    # ---------- construction ----------

    @classmethod
    def generate(cls) -> "Keypair":
        sk = Ed25519PrivateKey.generate()
        return cls._from_cryptography(sk)

    @classmethod
    def from_public_bytes(cls, pub: bytes) -> "Keypair":
        # Validate shape by round-tripping through cryptography.
        Ed25519PublicKey.from_public_bytes(pub)
        return cls(public_key_bytes=pub, private_key_bytes=None)

    @classmethod
    def _from_cryptography(cls, sk: Ed25519PrivateKey) -> "Keypair":
        pub_bytes = sk.public_key().public_bytes(
            encoding=_ser.Encoding.Raw,
            format=_ser.PublicFormat.Raw,
        )
        priv_bytes = sk.private_bytes(
            encoding=_ser.Encoding.Raw,
            format=_ser.PrivateFormat.Raw,
            encryption_algorithm=_ser.NoEncryption(),
        )
        return cls(public_key_bytes=pub_bytes, private_key_bytes=priv_bytes)

    # ---------- sign / verify ----------

    def sign(self, message: bytes) -> bytes:
        if self.private_key_bytes is None:
            raise ValueError("Cannot sign: private key not loaded.")
        sk = Ed25519PrivateKey.from_private_bytes(self.private_key_bytes)
        return sk.sign(message)

    def verify(self, message: bytes, signature: bytes) -> bool:
        return verify_with_public_key(self.public_key_bytes, message, signature)

    # ---------- persistence ----------

    def save(self, path: os.PathLike | str) -> None:
        """Save keypair to a JSON file with 0600 permissions (best effort)."""
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": KEY_FILE_VERSION,
            "algorithm": "ed25519",
            "public_key": b64u_encode(self.public_key_bytes),
        }
        if self.private_key_bytes is not None:
            payload["private_key"] = b64u_encode(self.private_key_bytes)

        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, indent=2))
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass  # e.g. Windows
        os.replace(tmp, p)

    @classmethod
    def load(
        cls, path: os.PathLike | str, *, passphrase: Optional[str] = None,
    ) -> "Keypair":
        data = json.loads(Path(path).read_text())
        version = int(data.get("version", 1))
        if version == 2:
            # Encrypted keystore (scrypt + AES-GCM).
            from .keystore import EncryptedKeystore, decrypt_keystore
            if passphrase is None:
                raise ValueError(
                    "keyfile is encrypted; pass passphrase= to load it"
                )
            ks = EncryptedKeystore.from_dict(data)
            seed = decrypt_keystore(ks, passphrase)
            return cls(
                public_key_bytes=ks.public_key, private_key_bytes=seed,
            )
        if version != KEY_FILE_VERSION:
            raise ValueError(f"Unsupported key file version: {version}")
        if data.get("algorithm") != "ed25519":
            raise ValueError(f"Unsupported algorithm: {data.get('algorithm')}")
        pub = b64u_decode(data["public_key"])
        priv = b64u_decode(data["private_key"]) if "private_key" in data else None
        return cls(public_key_bytes=pub, private_key_bytes=priv)

    @classmethod
    def load_or_create(cls, path: os.PathLike | str) -> "Keypair":
        p = Path(path)
        if p.exists():
            return cls.load(p)
        kp = cls.generate()
        kp.save(p)
        return kp


def verify_with_public_key(pub: bytes, message: bytes, signature: bytes) -> bool:
    """Return True iff `signature` is a valid Ed25519 sig over `message` by `pub`."""
    try:
        Ed25519PublicKey.from_public_bytes(pub).verify(signature, message)
        return True
    except (InvalidSignature, ValueError):
        return False
