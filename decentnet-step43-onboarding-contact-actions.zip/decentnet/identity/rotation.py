"""Key rotation receipts.

A peer rotates its identity by:
  1. Generating a new keypair.
  2. The OLD key signs a `RotationReceipt` proving it authorizes
     the NEW peer_id as its successor.
  3. The first record published under the new key carries the
     receipt in its `prev_key_rotation` field.

A receiver that sees a record with `prev_key_rotation`:
  * Verifies the receipt signature with the OLD public key.
  * Looks up any cached record under the OLD peer_id and checks
     that the OLD record's public_key matches the receipt.
  * If everything matches, treats the new peer_id as the
     **canonical successor** of the old one. Future lookups for the
     old peer_id can transparently resolve to the new one (with a
     forwarding record kept for a grace period).
  * Records the chain in a small persistent table so subsequent
     rotations can be verified back to the original identity.

This means a user can rotate their key without losing their handle
in others' caches, and an attacker cannot retroactively claim a
peer_id they never controlled.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Optional

from ..identity.keypair import Keypair, verify_with_public_key
from ..identity.peer_id import PeerId
from ..utils.encoding import b64u_decode, b64u_encode, canonical_json_bytes
from ..utils.time import now_s


ROTATION_VERSION = 1


@dataclass
class RotationReceipt:
    version: int
    prev_peer_id: str
    prev_public_key: bytes
    new_peer_id: str
    new_public_key: bytes
    issued_at: int
    signature: Optional[bytes] = None       # by prev key, over the rest

    def signing_input(self) -> bytes:
        return canonical_json_bytes({
            "version": self.version,
            "prev_peer_id": self.prev_peer_id,
            "prev_public_key": b64u_encode(self.prev_public_key),
            "new_peer_id": self.new_peer_id,
            "new_public_key": b64u_encode(self.new_public_key),
            "issued_at": self.issued_at,
        })

    def to_dict(self) -> dict:
        assert self.signature is not None, "receipt unsigned"
        return {
            "version": self.version,
            "prev_peer_id": self.prev_peer_id,
            "prev_public_key": b64u_encode(self.prev_public_key),
            "new_peer_id": self.new_peer_id,
            "new_public_key": b64u_encode(self.new_public_key),
            "issued_at": self.issued_at,
            "signature": b64u_encode(self.signature),
        }

    @classmethod
    def from_dict(cls, d: dict) -> "RotationReceipt":
        return cls(
            version=int(d["version"]),
            prev_peer_id=d["prev_peer_id"],
            prev_public_key=b64u_decode(d["prev_public_key"]),
            new_peer_id=d["new_peer_id"],
            new_public_key=b64u_decode(d["new_public_key"]),
            issued_at=int(d["issued_at"]),
            signature=b64u_decode(d["signature"]) if "signature" in d else None,
        )

    def verify(self) -> tuple[bool, Optional[str]]:
        if self.version != ROTATION_VERSION:
            return False, f"unsupported version {self.version}"
        if PeerId.from_public_key(self.prev_public_key).value != self.prev_peer_id:
            return False, "prev_peer_id does not match prev_public_key"
        if PeerId.from_public_key(self.new_public_key).value != self.new_peer_id:
            return False, "new_peer_id does not match new_public_key"
        if self.signature is None:
            return False, "missing signature"
        if not verify_with_public_key(
            self.prev_public_key, self.signing_input(), self.signature
        ):
            return False, "signature does not verify under prev key"
        return True, None


def issue_rotation_receipt(
    old_keypair: Keypair, new_keypair: Keypair
) -> RotationReceipt:
    """The OLD keypair signs a receipt authorizing the new one."""
    receipt = RotationReceipt(
        version=ROTATION_VERSION,
        prev_peer_id=PeerId.from_public_key(old_keypair.public_key_bytes).value,
        prev_public_key=old_keypair.public_key_bytes,
        new_peer_id=PeerId.from_public_key(new_keypair.public_key_bytes).value,
        new_public_key=new_keypair.public_key_bytes,
        issued_at=now_s(),
    )
    receipt.signature = old_keypair.sign(receipt.signing_input())
    return receipt
