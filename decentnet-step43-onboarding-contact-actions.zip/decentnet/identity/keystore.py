"""Key-at-rest encryption for the node's Ed25519 identity keyfile.

Design
------
The on-disk keyfile is a JSON envelope. It has two forms:

    Unencrypted (Phase 1 backwards-compat):
        { "version": 1, "private_key": "<b64url>", "public_key": "<b64url>" }

    Encrypted (Phase Final):
        {
            "version": 2,
            "public_key": "<b64url>",
            "kdf": "scrypt",
            "kdf_params": { "n": ..., "r": ..., "p": ..., "salt": "<b64>" },
            "cipher": "aes-256-gcm",
            "nonce": "<b64>",
            "ciphertext": "<b64>"   // encrypts the raw 32-byte Ed25519 seed
        }

When loading, we detect `version == 2` and prompt / require a
passphrase. The library function `Keypair.load_encrypted(path,
passphrase)` is the supported API. The CLI adds
`decentnet keystore encrypt/decrypt/change-passphrase`.

scrypt parameters default to `n=2**15, r=8, p=1` — ~50ms on a
laptop, strong enough for an at-rest threat model where the
attacker has offline access to the keyfile but no GPU cluster
targeting it.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

from ..utils.encoding import b64u_decode, b64u_encode


DEFAULT_SCRYPT_N = 2 ** 15
DEFAULT_SCRYPT_R = 8
DEFAULT_SCRYPT_P = 1
KEY_BYTES = 32           # AES-256 key size
NONCE_BYTES = 12
SALT_BYTES = 16


class KeystoreError(Exception):
    pass


@dataclass
class EncryptedKeystore:
    version: int
    public_key: bytes
    kdf: str
    n: int
    r: int
    p: int
    salt: bytes
    cipher: str
    nonce: bytes
    ciphertext: bytes

    def to_dict(self) -> dict:
        return {
            "version": self.version,
            "public_key": b64u_encode(self.public_key),
            "kdf": self.kdf,
            "kdf_params": {
                "n": self.n, "r": self.r, "p": self.p,
                "salt": b64u_encode(self.salt),
            },
            "cipher": self.cipher,
            "nonce": b64u_encode(self.nonce),
            "ciphertext": b64u_encode(self.ciphertext),
        }

    @classmethod
    def from_dict(cls, d: dict) -> "EncryptedKeystore":
        params = d["kdf_params"]
        return cls(
            version=int(d["version"]),
            public_key=b64u_decode(d["public_key"]),
            kdf=d["kdf"],
            n=int(params["n"]),
            r=int(params["r"]),
            p=int(params["p"]),
            salt=b64u_decode(params["salt"]),
            cipher=d["cipher"],
            nonce=b64u_decode(d["nonce"]),
            ciphertext=b64u_decode(d["ciphertext"]),
        )


def _derive_key(
    passphrase: str, salt: bytes, *,
    n: int = DEFAULT_SCRYPT_N, r: int = DEFAULT_SCRYPT_R, p: int = DEFAULT_SCRYPT_P,
) -> bytes:
    kdf = Scrypt(salt=salt, length=KEY_BYTES, n=n, r=r, p=p)
    return kdf.derive(passphrase.encode("utf-8"))


def encrypt_keystore(
    private_seed: bytes,
    public_key: bytes,
    passphrase: str,
    *,
    n: int = DEFAULT_SCRYPT_N,
    r: int = DEFAULT_SCRYPT_R,
    p: int = DEFAULT_SCRYPT_P,
) -> EncryptedKeystore:
    if len(private_seed) != 32:
        raise KeystoreError("expected 32-byte Ed25519 seed")
    salt = os.urandom(SALT_BYTES)
    nonce = os.urandom(NONCE_BYTES)
    key = _derive_key(passphrase, salt, n=n, r=r, p=p)
    aead = AESGCM(key)
    # AAD binds public_key: you can't swap envelopes between peers.
    ct = aead.encrypt(nonce, private_seed, public_key)
    return EncryptedKeystore(
        version=2, public_key=public_key,
        kdf="scrypt", n=n, r=r, p=p, salt=salt,
        cipher="aes-256-gcm", nonce=nonce, ciphertext=ct,
    )


def decrypt_keystore(
    keystore: EncryptedKeystore, passphrase: str
) -> bytes:
    if keystore.version != 2:
        raise KeystoreError(f"unsupported keystore version {keystore.version}")
    if keystore.kdf != "scrypt":
        raise KeystoreError(f"unsupported kdf {keystore.kdf}")
    if keystore.cipher != "aes-256-gcm":
        raise KeystoreError(f"unsupported cipher {keystore.cipher}")
    key = _derive_key(
        passphrase, keystore.salt,
        n=keystore.n, r=keystore.r, p=keystore.p,
    )
    aead = AESGCM(key)
    try:
        seed = aead.decrypt(
            keystore.nonce, keystore.ciphertext, keystore.public_key
        )
    except Exception as e:
        raise KeystoreError("decryption failed (wrong passphrase?)") from e
    if len(seed) != 32:
        raise KeystoreError("decrypted blob wrong size")
    return seed


# -- file helpers ---------------------------------------------------


def wrap_keyfile(
    path: Path | str, passphrase: str, *,
    scrypt_n: int = DEFAULT_SCRYPT_N,
) -> None:
    """Convert an unencrypted keyfile at `path` into an encrypted one
    (in place, atomic)."""
    from ..identity.keypair import Keypair
    p = Path(path)
    kp = Keypair.load(p)
    if kp.private_key_bytes is None:
        raise KeystoreError("keyfile has no private key")
    ks = encrypt_keystore(
        kp.private_key_bytes, kp.public_key_bytes, passphrase,
        n=scrypt_n,
    )
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(ks.to_dict(), indent=2))
    os.chmod(tmp, 0o600)
    tmp.replace(p)


def unwrap_keyfile(
    path: Path | str, passphrase: str,
) -> None:
    """Convert an encrypted keyfile into a plain Phase-1-style one."""
    p = Path(path)
    d = json.loads(p.read_text())
    if d.get("version") != 2:
        raise KeystoreError("not an encrypted keystore")
    ks = EncryptedKeystore.from_dict(d)
    seed = decrypt_keystore(ks, passphrase)
    plain = {
        "version": 1,
        "algorithm": "ed25519",
        "private_key": b64u_encode(seed),
        "public_key": b64u_encode(ks.public_key),
    }
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(plain, indent=2))
    os.chmod(tmp, 0o600)
    tmp.replace(p)


def is_encrypted_keyfile(path: Path | str) -> bool:
    p = Path(path)
    if not p.exists():
        return False
    try:
        d = json.loads(p.read_text())
        return int(d.get("version", 1)) == 2
    except Exception:
        return False
